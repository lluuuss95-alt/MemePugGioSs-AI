import { db } from './db.js';
import { enqueue, ingestQueue } from './ingestion.js';

type DexPair = {
  chainId?: string;
  dexId?: string;
  pairAddress?: string;
  baseToken?: { address?: string; name?: string; symbol?: string };
  quoteToken?: { address?: string; name?: string; symbol?: string };
  priceUsd?: string;
  priceNative?: string;
  liquidity?: { usd?: number };
  volume?: { m5?: number };
  txns?: { m5?: { buys?: number; sells?: number } };
  pairCreatedAt?: number;
  url?: string;
};
type PumpCoin = { mint?: string; symbol?: string; name?: string; usd_market_cap?: number | string; market_cap?: number | string; total_supply?: number | string; decimals?: number | string; complete?: boolean; };
type GeckoPool = { id?: string; attributes?: { name?: string; address?: string; base_token_price_usd?: string; reserve_in_usd?: string; volume_usd?: { m5?: string }; pool_created_at?: string }; relationships?: { base_token?: { data?: { id?: string } } } };

// Recheck shortly after startup and often enough to catch tokens that arrive
// just after the first cycle. Provider request budget remains below DexScreener's
// documented 300 requests/minute limit (batch + bounded per-token fallback).
const INTERVAL_MS = 60_000;
const BATCH_SIZE = 30;
const MAX_TOKENS_PER_CYCLE = 30;
const INVENTORY_SCAN_LIMIT = 200;
const REQUEST_TIMEOUT_MS = 8_000;
const FALLBACK_TIMEOUT_MS = 7_000;
const MAX_GECKO_FALLBACKS_PER_CYCLE = 2;
// Cache only negative GeckoTerminal lookups: they reduce repeated requests for
// tokens without a pool without ever refreshing the timestamp of stale prices.
const GECKO_NO_POOL_CACHE_MS = 120_000;
const geckoNoPoolUntil = new Map<string, number>();
const geckoInFlight = new Map<string, Promise<Response>>();
// Keep individual probes deliberately low; batch lookup is the primary path.
// One batched request per cycle; only two rotating GeckoTerminal fallbacks are
// allowed per cycle to avoid amplifying provider throttling.
// Conservative 429 backoff: 30 min, 1 h, 2 h, then 4 h (6 h local cap).
// Honor Retry-After even when it is longer than our local exponential backoff.
// Cooldowns are persisted in SQLite so a process restart does not immediately retry.
const RATE_LIMIT_COOLDOWN_MS = 1_800_000;
const MAX_RATE_LIMIT_COOLDOWN_MS = 21_600_000;
let providerCooldownUntil = 0;
let rateLimitFailures = 0;
let inventoryCursor = 0;
let fallbackCursor = 0;
let geckoCooldownUntil = 0;
let geckoRateLimitFailures = 0;
let dexRequestsTotal = 0;
let geckoRequestsTotal = 0;
let lastDexHttpStatus: number | null = null;
let lastGeckoHttpStatus: number | null = null;
let timer: ReturnType<typeof setInterval> | undefined;
let running = false;
let cycleHadError = false;

db.exec(`CREATE TABLE IF NOT EXISTS market_provider_cooldowns (
  provider TEXT PRIMARY KEY,
  cooldown_until INTEGER NOT NULL,
  failures INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
)`);
const loadCooldown = db.prepare('SELECT cooldown_until, failures FROM market_provider_cooldowns WHERE provider = ?');
const saveCooldown = db.prepare(`INSERT INTO market_provider_cooldowns(provider,cooldown_until,failures,updated_at)
  VALUES(?,?,?,?) ON CONFLICT(provider) DO UPDATE SET cooldown_until=excluded.cooldown_until, failures=excluded.failures, updated_at=excluded.updated_at`);
const clearCooldown = db.prepare('DELETE FROM market_provider_cooldowns WHERE provider = ?');
function restoreCooldowns() {
  const dex = loadCooldown.get('dexscreener') as { cooldown_until?: number; failures?: number } | undefined;
  if (dex) { providerCooldownUntil = Number(dex.cooldown_until || 0); rateLimitFailures = Number(dex.failures || 0); }
  const gecko = loadCooldown.get('geckoterminal') as { cooldown_until?: number; failures?: number } | undefined;
  if (gecko) { geckoCooldownUntil = Number(gecko.cooldown_until || 0); geckoRateLimitFailures = Number(gecko.failures || 0); }
}
function persistCooldown(provider: 'dexscreener' | 'geckoterminal', until: number, failures: number) {
  saveCooldown.run(provider, until, failures, new Date().toISOString());
}
function clearPersistedCooldown(provider: 'dexscreener' | 'geckoterminal') { clearCooldown.run(provider); }
restoreCooldowns();
function retryAfterMs(response: Response): number {
  const value = response.headers.get('retry-after');
  if (!value) return 0;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds > 0) return Math.ceil(seconds * 1000);
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : 0;
}
function isSolanaMint(value: unknown): value is string {
  return typeof value === 'string' && value.length >= 32 && value.length <= 44 && /^[1-9A-HJ-NP-Za-km-z]+$/.test(value);
}
function responseDiagnostics(response: Response, body: string): string {
  const names = ['retry-after', 'date', 'server', 'via', 'cf-ray', 'x-ratelimit-limit', 'x-ratelimit-remaining', 'x-ratelimit-reset', 'ratelimit-limit', 'ratelimit-remaining', 'ratelimit-reset'];
  const headers = names.map(name => {
    const value = response.headers.get(name);
    return value ? `${name}=${value}` : '';
  }).filter(Boolean).join(',');
  const safeBody = body.replace(/\s+/g, ' ').slice(0, 240);
  return `status=${response.status}; ${headers || 'no-rate-limit-headers'}; body=${safeBody || '<empty>'}`.slice(0, 600);
}

function describeFetchError(stage: string, error: unknown): string {
  const e = error as { name?: string; message?: string; cause?: { code?: string; message?: string; name?: string } };
  const parts = [`${stage}: ${e?.name || 'Error'}: ${e?.message || String(error)}`];
  if (e?.cause) parts.push(`cause=${e.cause.code || e.cause.name || 'unknown'}:${e.cause.message || ''}`);
  return parts.join(' | ').slice(0, 500);
}
async function fetchDexBatch(url: string): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 0; attempt < 2; attempt++) {
    health.requests++;
    try {
      const response = await fetch(url, {
        headers: { accept: 'application/json' },
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
      if (attempt === 0 && response.status >= 500) {
        await new Promise(resolve => setTimeout(resolve, 250));
        continue;
      }
      return response;
    } catch (error) {
      lastError = error;
      if (attempt === 0) {
        await new Promise(resolve => setTimeout(resolve, 250));
        continue;
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error(String(lastError ?? 'DEXSCREENER_FETCH_FAILED'));
}

async function fetchGeckoPools(mint: string): Promise<Response> {
  const existing = geckoInFlight.get(mint);
  if (existing) {
    health.geckoRequestsDeduplicated++;
    return (await existing).clone();
  }
  geckoRequestsTotal++;
  const request = fetch(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/${encodeURIComponent(mint)}/pools?page=1`, {
    headers: { accept: 'application/json' },
    signal: AbortSignal.timeout(FALLBACK_TIMEOUT_MS),
  });
  geckoInFlight.set(mint, request);
  try {
    return (await request).clone();
  } finally {
    if (geckoInFlight.get(mint) === request) geckoInFlight.delete(mint);
  }
}

function recordFetchError(stage: string, error: unknown) {
  cycleHadError = true;
  const e = error as { message?: string; retryAfterMs?: number };
  if (String(e?.message || error).includes('HTTP_429')) {
    const requestedDelay = Number(e?.retryAfterMs ?? 0);
    rateLimitFailures = Math.min(rateLimitFailures + 1, 6);
    const exponentialDelay = Math.min(MAX_RATE_LIMIT_COOLDOWN_MS, RATE_LIMIT_COOLDOWN_MS * (2 ** (rateLimitFailures - 1)));
    providerCooldownUntil = Date.now() + Math.max(exponentialDelay, requestedDelay);
    persistCooldown('dexscreener', providerCooldownUntil, rateLimitFailures);
  }
  const detail = describeFetchError(stage, error);
  if (stage.startsWith('DexScreener')) health.lastDexScreenerError = detail;
  if (stage.startsWith('GeckoTerminal')) health.lastGeckoError = detail;
  health.lastError = [health.lastDexScreenerError, health.lastGeckoError].filter(Boolean).join(' | ').slice(0, 900) || detail;
}
const health = {
  status: 'IDLE' as 'IDLE' | 'RUNNING' | 'OK' | 'DEGRADED' | 'WAITING_FOR_TOKENS',
  lastRunAt: null as string | null,
  lastSuccessAt: null as string | null,
  lastError: '',
  lastDexScreenerError: '',
  lastGeckoError: '',
  tokensChecked: 0,
  pairsMatched: 0,
  observationsQueued: 0,
  requests: 0,
  tokensWithoutPair: 0,
  tokensWithoutPrice: 0,
  lastMissingMints: [] as string[],
  pumpFunFallbacks: 0,
  pumpFunPrices: 0,
  dexTokenPairProbes: 0,
  dexTokenPairErrors: 0,
  pumpFunNotFound: 0,
  geckoFallbacks: 0,
  geckoMatches: 0,
  geckoErrors: 0,
  geckoCacheHits: 0,
  geckoRequestsDeduplicated: 0,
};


let lastProviderProbeAt = 0;
let lastProviderProbe: Record<string, unknown> | null = null;
const PROVIDER_PROBE_MIN_INTERVAL_MS = 5 * 60_000;
const PROBE_MINT = 'So11111111111111111111111111111111111111112';

/** One-shot diagnostic initiated by an authenticated operator; never runs on every health poll. */
export async function probeMarketProviders(force = false) {
  const now = Date.now();
  if (!force && lastProviderProbe && now - lastProviderProbeAt < PROVIDER_PROBE_MIN_INTERVAL_MS) {
    return { ...lastProviderProbe, cached: true, nextProbeAllowedAt: new Date(lastProviderProbeAt + PROVIDER_PROBE_MIN_INTERVAL_MS).toISOString() };
  }
  const probe = async (provider: 'dexscreener' | 'geckoterminal', url: string, cooldownUntil: number) => {
    const started = Date.now();
    if (Date.now() < cooldownUntil) {
      return { provider, skipped: true, reason: 'COOLDOWN_ACTIVE', cooldownRemainingMs: cooldownUntil - Date.now() };
    }
    try {
      const response = await fetch(url, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(7_000) });
      const body = await response.text().catch(() => '');
      const elapsedMs = Date.now() - started;
      const headers: Record<string, string> = {};
      for (const key of ['retry-after','server','via','cf-ray','x-ratelimit-limit','x-ratelimit-remaining','x-ratelimit-reset','ratelimit-limit','ratelimit-remaining','ratelimit-reset']) { const value = response.headers.get(key); if (value) headers[key] = value; }
      if (response.status === 429) {
        const delay = retryAfterMs(response);
        if (provider === 'dexscreener') {
          rateLimitFailures = Math.min(rateLimitFailures + 1, 6);
          providerCooldownUntil = Date.now() + Math.max(Math.min(MAX_RATE_LIMIT_COOLDOWN_MS, RATE_LIMIT_COOLDOWN_MS * (2 ** (rateLimitFailures - 1))), delay);
          persistCooldown('dexscreener', providerCooldownUntil, rateLimitFailures);
          lastDexHttpStatus = 429;
        } else {
          geckoRateLimitFailures = Math.min(geckoRateLimitFailures + 1, 6);
          geckoCooldownUntil = Date.now() + Math.max(Math.min(MAX_RATE_LIMIT_COOLDOWN_MS, RATE_LIMIT_COOLDOWN_MS * (2 ** (geckoRateLimitFailures - 1))), delay);
          persistCooldown('geckoterminal', geckoCooldownUntil, geckoRateLimitFailures);
          lastGeckoHttpStatus = 429;
        }
      } else if (response.ok) {
        // A diagnostic probe is not evidence that the production token workload
        // is healthy; do not clear an active provider cooldown from this endpoint.
        if (provider === 'dexscreener') lastDexHttpStatus = response.status;
        else lastGeckoHttpStatus = response.status;
      }
      return { provider, status: response.status, ok: response.ok, elapsedMs, headers, bodyPreview: body.replace(/\s+/g, ' ').slice(0, 180), cooldownRemainingMs: provider === 'dexscreener' ? Math.max(0, providerCooldownUntil - Date.now()) : Math.max(0, geckoCooldownUntil - Date.now()) };
    } catch (error) {
      return { provider, ok: false, elapsedMs: Date.now() - started, error: describeFetchError(`${provider} diagnostic probe`, error) };
    }
  };
  const [dexscreener, geckoterminal] = await Promise.all([
    probe('dexscreener', `https://api.dexscreener.com/tokens/v1/solana/${PROBE_MINT}`, providerCooldownUntil),
    probe('geckoterminal', `https://api.geckoterminal.com/api/v2/networks/solana/tokens/${PROBE_MINT}/pools?page=1`, geckoCooldownUntil),
  ]);
  const has429 = [dexscreener, geckoterminal].some((x: any) => x.status === 429);
  lastProviderProbeAt = Date.now();
  lastProviderProbe = {
    checkedAt: new Date(lastProviderProbeAt).toISOString(), cached: false,
    runtime: 'Render backend process',
    providers: { dexscreener, geckoterminal },
    interpretation: has429
      ? 'Una richiesta singola dal processo Render ha ricevuto HTTP 429. È compatibile con un limite del provider o della sorgente di rete; non prova da sola che l’IP sia condiviso.'
      : 'La richiesta diagnostica non ha ricevuto HTTP 429. Questo non garantisce che le richieste del feed o i limiti successivi funzionino sempre.',
    liveExecutionEnabled: false,
  };
  return lastProviderProbe;
}

export function marketEnrichmentStatus() {
  // Expose the inventory and queue independently from market-provider results.
  // This distinguishes an empty token pipeline from a provider returning no pairs.
  const inventory = db.prepare(`SELECT COUNT(*) AS total, SUM(CASE WHEN source = 'pumpportal-new-token' THEN 1 ELSE 0 END) AS pumpPortal FROM tokens`).get() as { total?: number; pumpPortal?: number };
  const allMints = db.prepare('SELECT mint FROM tokens').all() as Array<{ mint: string }>;
  const eligibleCount = allMints.reduce((n, row) => n + (isSolanaMint(row.mint) ? 1 : 0), 0);
  return {
    ...health,
    inventoryTokens: Number(inventory.total ?? 0),
    eligibleTokens: eligibleCount,
    invalidMintRows: Math.max(0, allMints.length - eligibleCount),
    geckoCooldownRemainingMs: Math.max(0, geckoCooldownUntil - Date.now()),
    geckoRateLimitFailures,
    dexRequestsTotal,
    geckoRequestsTotal,
    lastDexHttpStatus,
    lastGeckoHttpStatus,
    pumpPortalTokens: Number(inventory.pumpPortal ?? 0),
    ingestionQueueDepth: ingestQueue.size,
    configured: true,
    provider: 'DexScreener',
    intervalMs: INTERVAL_MS,
    rateLimitFailures,
    cooldownRemainingMs: Math.max(0, providerCooldownUntil - Date.now()),
    maxTokensPerCycle: MAX_TOKENS_PER_CYCLE,
  };
}

/** Adds observed market data to the local paper/shadow database. Never trades. */
export function startMarketEnrichment() {
  if (timer) return;
  // Delay the first batch slightly so the HTTP server and primary feed can start.
  setTimeout(() => { void runMarketEnrichment(); }, 3_000);
  timer = setInterval(() => { void runMarketEnrichment(); }, INTERVAL_MS);
}

export async function runMarketEnrichment() {
  if (running) return marketEnrichmentStatus();
  running = true;
  health.lastRunAt = new Date().toISOString();
  // During a DexScreener cooldown, keep the market pipeline alive and use
  // the bounded GeckoTerminal fallback rotation. A provider 429 must pause
  // requests to DexScreener, not suppress verified data from other providers.
  const dexCoolingDownAtStart = Date.now() < providerCooldownUntil;
  health.status = dexCoolingDownAtStart ? 'DEGRADED' : 'RUNNING';
  health.lastDexScreenerError = dexCoolingDownAtStart
    ? `DEXSCREENER_RATE_LIMIT_COOLDOWN: retry in ${Math.ceil((providerCooldownUntil - Date.now()) / 1000)}s; DexScreener requests paused; using fallback provider`
    : '';
  health.lastGeckoError = Date.now() < geckoCooldownUntil
    ? `GECKOTERMINAL_RATE_LIMIT_COOLDOWN: retry in ${Math.ceil((geckoCooldownUntil - Date.now()) / 1000)}s`
    : '';
  health.lastError = [health.lastDexScreenerError, health.lastGeckoError].filter(Boolean).join(' | ');
  cycleHadError = dexCoolingDownAtStart || Date.now() < geckoCooldownUntil;
  health.tokensChecked = 0;
  health.pairsMatched = 0;
  health.observationsQueued = 0;
  health.tokensWithoutPair = 0;
  health.tokensWithoutPrice = 0;
  health.lastMissingMints = [];
  health.pumpFunFallbacks = 0;
  health.pumpFunPrices = 0;
  health.dexTokenPairProbes = 0;
  health.dexTokenPairErrors = 0;
  health.pumpFunNotFound = 0;
  health.geckoFallbacks = 0;
  health.geckoMatches = 0;
  health.geckoErrors = 0;
  try {
    // Length-only filtering allowed symbols and malformed values into the market pipeline.
    // Accept only plausible base58 Solana public keys before querying providers.
    const inventoryRows = db.prepare(
      `SELECT mint,symbol,name FROM tokens ORDER BY last_seen DESC`
    ).all() as Array<{ mint: string; symbol: string | null; name: string | null }>;
    const inventory = inventoryRows.filter(t => isSolanaMint(t.mint)).slice(0, INVENTORY_SCAN_LIMIT);
    if (inventory.length > MAX_TOKENS_PER_CYCLE) {
      const start = inventoryCursor % inventory.length;
      const rotated = [...inventory.slice(start), ...inventory.slice(0, start)];
      const tokens = rotated.slice(0, MAX_TOKENS_PER_CYCLE);
      inventoryCursor = (start + MAX_TOKENS_PER_CYCLE) % inventory.length;
      inventory.splice(0, inventory.length, ...tokens);
    } else {
      inventoryCursor = 0;
    }
    const tokens = inventory;
    if (tokens.length === 0) {
      health.status = 'WAITING_FOR_TOKENS';
      health.lastError = ingestQueue.size > 0
        ? `WAITING_FOR_INGESTION: queue=${ingestQueue.size}, inventory=${Number((db.prepare('SELECT COUNT(*) AS n FROM tokens').get() as { n?: number }).n ?? 0)}`
        : 'WAITING_FOR_ELIGIBLE_TOKENS: no token mints of 32–44 characters are persisted yet';
      return marketEnrichmentStatus();
    }
    const seenAt = Date.now();
    // DexScreener may be unreachable from a hosting region or transiently fail.
    // Rotate a small, bounded set of token-specific GeckoTerminal lookups each
    // cycle so a provider outage does not permanently starve the token inventory.
    const fallbackRotation = [...tokens.slice(fallbackCursor % Math.max(tokens.length, 1)), ...tokens.slice(0, fallbackCursor % Math.max(tokens.length, 1))];
    const fallbackMints = new Set(fallbackRotation.slice(0, Math.min(MAX_GECKO_FALLBACKS_PER_CYCLE, tokens.length)).map(t => t.mint));
    if (tokens.length) fallbackCursor = (fallbackCursor + fallbackMints.size) % tokens.length;
    for (let offset = 0; offset < tokens.length; offset += BATCH_SIZE) {
      const batch = tokens.slice(offset, offset + BATCH_SIZE);
      if (!batch.length) continue;
      const addresses = batch.map(t => t.mint).join(',');
      health.tokensChecked += batch.length;
      let pairs: DexPair[] = [];
      if (Date.now() < providerCooldownUntil) {
        // Deliberately skip only DexScreener. The per-token fallback below is
        // still allowed to return and enqueue verified market data.
        cycleHadError = true;
      } else {
        try {
          dexRequestsTotal++;
          const response = await fetchDexBatch(`https://api.dexscreener.com/tokens/v1/solana/${addresses}`);
          lastDexHttpStatus = response.status;
          if (!response.ok) {
            const bodyText = await response.clone().text().catch(() => '');
            const diagnostic = responseDiagnostics(response, bodyText);
            const retryDelay = retryAfterMs(response);
            const err = new Error(`DEXSCREENER_HTTP_${response.status}; ${diagnostic}`) as Error & { retryAfterMs?: number };
            if (response.status === 429 && retryDelay > 0) err.retryAfterMs = retryDelay;
            throw err;
          }
          const body: unknown = await response.json();
          if (!Array.isArray(body)) throw new Error('DEXSCREENER_INVALID_RESPONSE');
          pairs = body as DexPair[];
          rateLimitFailures = 0;
          providerCooldownUntil = 0;
          clearPersistedCooldown('dexscreener');
        } catch (error) {
          // A failed batch records the provider error; no extra requests are issued
          // to DexScreener during the same cycle, preventing a 429 from being amplified.
          recordFetchError('DexScreener batch request', error);
        }
      }
      const byMint = new Map<string, DexPair>();
      for (const rawPair of pairs) {
        if (rawPair.chainId && rawPair.chainId.toLowerCase() !== 'solana') continue;
        // DexScreener can return a pool with the requested mint on either side.
        // priceUsd is the BASE token price; if the target is the quote token, derive
        // its USD price from base USD / base price in quote units (priceNative).
        let pair: DexPair | undefined;
        let mint: string | undefined;
        if (rawPair.baseToken?.address && batch.some(t => t.mint === rawPair.baseToken!.address)) {
          mint = rawPair.baseToken.address;
          pair = rawPair;
        } else if (rawPair.quoteToken?.address && batch.some(t => t.mint === rawPair.quoteToken!.address)) {
          const baseUsd = Number(rawPair.priceUsd);
          const baseInQuote = Number(rawPair.priceNative);
          if (Number.isFinite(baseUsd) && baseUsd > 0 && Number.isFinite(baseInQuote) && baseInQuote > 0) {
            mint = rawPair.quoteToken.address;
            pair = {
              ...rawPair,
              baseToken: { address: mint, name: rawPair.quoteToken.name, symbol: rawPair.quoteToken.symbol },
              priceUsd: String(baseUsd / baseInQuote),
              dexId: rawPair.dexId ? `${rawPair.dexId}-quote-derived` : 'dexscreener-quote-derived',
            };
          }
        }
        if (!mint || !pair) continue;
        const current = byMint.get(mint);
        const liquidity = Number(pair.liquidity?.usd ?? 0);
        const currentLiquidity = Number(current?.liquidity?.usd ?? 0);
        if (!current || liquidity > currentLiquidity) byMint.set(mint, pair);
      }
      for (const token of batch) {
        let pair = byMint.get(token.mint);
        // A DexScreener pair can exist while its price/liquidity fields are absent or invalid.
        // Treat that as a failed market match too; otherwise the GeckoTerminal fallback
        // is skipped and the dashboard reports zero observations despite attempting a batch.
        const pairHasVerifiedMarketData = Boolean(pair)
          && Number.isFinite(Number(pair?.priceUsd)) && Number(pair?.priceUsd) > 0
          && Number.isFinite(Number(pair?.liquidity?.usd)) && Number(pair?.liquidity?.usd) > 0;
        const noPoolUntil = geckoNoPoolUntil.get(token.mint) || 0;
        const hasNegativeCache = noPoolUntil > Date.now();
        if ((!pair || !pairHasVerifiedMarketData) && hasNegativeCache) {
          health.geckoCacheHits++;
          health.tokensWithoutPair++;
          health.lastMissingMints.push(token.mint);
          continue;
        }
        if ((!pair || !pairHasVerifiedMarketData) && fallbackMints.has(token.mint) && Date.now() >= geckoCooldownUntil) {
          health.geckoFallbacks++;
          try {
            const response = await fetchGeckoPools(token.mint);
            lastGeckoHttpStatus = response.status;
            if (!response.ok) {
              const bodyText = await response.clone().text().catch(() => '');
              const diagnostic = responseDiagnostics(response, bodyText);
              const retryDelay = retryAfterMs(response);
              const err = new Error(`GECKOTERMINAL_HTTP_${response.status}; ${diagnostic}`) as Error & { retryAfterMs?: number };
              if (response.status === 429 && retryDelay > 0) err.retryAfterMs = retryDelay;
              throw err;
            }
            // An HTTP 200 means the provider accepted the request; clear its
            // previous rate-limit state even when this token has no eligible pool.
            geckoRateLimitFailures = 0;
            geckoCooldownUntil = 0;
            clearPersistedCooldown('geckoterminal');
            const payload = await response.json() as { data?: GeckoPool[] };
            const pools = Array.isArray(payload?.data) ? payload.data : [];
            const ranked = pools.map(pool => {
              const a = pool.attributes || {};
              const relationId = pool.relationships?.base_token?.data?.id || '';
              const relationMint = relationId.startsWith('solana_') ? relationId.slice('solana_'.length) : relationId;
              return { pool, a, relationMint, liquidity: Number(a.reserve_in_usd), price: Number(a.base_token_price_usd) };
            }).filter(x => (!x.relationMint || x.relationMint === token.mint) && Number.isFinite(x.price) && x.price > 0 && Number.isFinite(x.liquidity) && x.liquidity > 0).sort((a,b) => b.liquidity-a.liquidity);
            const best = ranked[0];
            if (best) {
              geckoNoPoolUntil.delete(token.mint);
              health.lastGeckoError = '';
              const createdAt = best.a.pool_created_at ? Date.parse(best.a.pool_created_at) : NaN;
              pair = {
                chainId: 'solana', pairAddress: best.a.address || best.pool.attributes?.address,
                baseToken: { address: token.mint, symbol: token.symbol || undefined, name: token.name || undefined },
                priceUsd: String(best.price), liquidity: { usd: best.liquidity },
                volume: { m5: Number(best.a.volume_usd?.m5 || 0) },
                pairCreatedAt: Number.isFinite(createdAt) ? createdAt : undefined,
                url: best.a.address ? `https://www.geckoterminal.com/solana/pools/${best.a.address}` : undefined,
                dexId: 'geckoterminal',
              };
              byMint.set(token.mint, pair);
              health.geckoMatches++;
            } else {
              geckoNoPoolUntil.set(token.mint, Date.now() + GECKO_NO_POOL_CACHE_MS);
            }
          } catch (error) {
            health.geckoErrors++;
            const errorText = String((error as { message?: string })?.message || error);
            if (errorText.includes('GECKOTERMINAL_HTTP_429')) {
              geckoRateLimitFailures = Math.min(geckoRateLimitFailures + 1, 6);
              const requestedDelay = Number((error as { retryAfterMs?: number })?.retryAfterMs ?? 0);
              const backoff = Math.min(MAX_RATE_LIMIT_COOLDOWN_MS, RATE_LIMIT_COOLDOWN_MS * (2 ** (geckoRateLimitFailures - 1)));
              geckoCooldownUntil = Date.now() + Math.max(backoff, requestedDelay);
              persistCooldown('geckoterminal', geckoCooldownUntil, geckoRateLimitFailures);
            }
            health.lastGeckoError = describeFetchError('GeckoTerminal fallback', error);
            health.lastError = [health.lastDexScreenerError, health.lastGeckoError].filter(Boolean).join(' | ').slice(0, 900);
          }
        }
        // Do not reject a verified fallback pair just because DexScreener is
        // cooling down. The cooldown gates provider requests above, not data quality.
        if (!pair) {
          health.tokensWithoutPair++;
          health.lastMissingMints.push(token.mint);
          // No verified market pair means no defensible market price. Keep the
          // price blank rather than deriving one from an unauthenticated Pump.fun
          // endpoint or inventing a value.
          continue;
        }
        const price = Number(pair.priceUsd);
        const liquidity = Number(pair.liquidity?.usd);
        const volume5m = Number(pair.volume?.m5);
        const buys = Number(pair.txns?.m5?.buys ?? 0);
        const sells = Number(pair.txns?.m5?.sells ?? 0);
        const txTotal = buys + sells;
        const buyPressure = txTotal > 0 ? buys / txTotal : undefined;
        const createdAt = Number(pair.pairCreatedAt);
        const ageSeconds = Number.isFinite(createdAt) && createdAt > 0 ? Math.max(0, Math.floor((seenAt - createdAt) / 1000)) : undefined;
        // Only enqueue genuinely observed, finite positive market values.
        const validPrice = Number.isFinite(price) && price > 0 ? price : undefined;
        if (validPrice === undefined) health.tokensWithoutPrice++;
        const validLiquidity = Number.isFinite(liquidity) && liquidity >= 0 ? liquidity : undefined;
        const validVolume = Number.isFinite(volume5m) && volume5m >= 0 ? volume5m : undefined;
        if (validPrice === undefined && validLiquidity === undefined && validVolume === undefined) continue;
        const observedAt = new Date(seenAt).toISOString();
        enqueue({
          eventId: `dexscreener:${token.mint}:${Math.floor(seenAt / INTERVAL_MS)}`,
          mint: token.mint,
          symbol: pair.baseToken?.symbol || token.symbol || undefined,
          name: pair.baseToken?.name || token.name || undefined,
          source: pair.dexId?.includes('geckoterminal') ? 'geckoterminal-market-observation' : 'dexscreener-market-observation',
          eventTime: observedAt,
          price: validPrice,
          liquidity: validLiquidity,
          volume5m: validVolume,
          ageSeconds,
          buyPressure,
          raw: { provider: pair.dexId === 'geckoterminal' ? 'GeckoTerminal' : 'DexScreener', pairAddress: pair.pairAddress, dexId: pair.dexId, pairUrl: pair.url, buys5m: buys, sells5m: sells, observedAt },
        });
        health.pairsMatched++;
        health.observationsQueued++;
      }
    }
    const missingMarketData = health.tokensChecked > 0 && health.pairsMatched === 0 && health.observationsQueued === 0;
    health.status = cycleHadError || missingMarketData ? 'DEGRADED' : 'OK';
    health.lastError = [health.lastDexScreenerError, health.lastGeckoError].filter(Boolean).join(' | ').slice(0, 900);
    if (missingMarketData && !health.lastError) health.lastError = `NO_VERIFIED_MARKET_DATA: checked=${health.tokensChecked}, pairs=${health.pairsMatched}, observations=${health.observationsQueued}`;
    if (!cycleHadError && !missingMarketData) health.lastSuccessAt = new Date().toISOString();
  } catch (error) {
    health.status = 'DEGRADED';
    health.lastError = String(error);
  } finally {
    running = false;
  }
  return marketEnrichmentStatus();
}
