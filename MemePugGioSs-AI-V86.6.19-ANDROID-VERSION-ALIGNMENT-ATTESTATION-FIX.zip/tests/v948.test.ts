import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/market-enrichment.ts', import.meta.url), 'utf8');
assert.match(source, /const INTERVAL_MS = 60_000/, 'market enrichment must use the rate-limit-aware 60-second cadence');
assert.match(source, /const MAX_GECKO_FALLBACKS_PER_CYCLE = 2/, 'individual fallback probes must use the reduced rate-limit-safe budget');
assert.match(source, /DEXSCREENER_RATE_LIMIT_COOLDOWN/, 'HTTP 429 must activate a cooldown');
assert.match(source, /response\.headers\.get\('retry-after'\)/, 'batch request should honor Retry-After');
assert.match(source, /const RATE_LIMIT_COOLDOWN_MS = 1_800_000/, 'rate-limit cooldown must be bounded');
console.log('V948 RATE LIMIT BACKOFF REGRESSION PASS');
