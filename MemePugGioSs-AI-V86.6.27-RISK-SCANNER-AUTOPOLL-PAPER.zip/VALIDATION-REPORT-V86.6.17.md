# V86.6.17 — Targeted market resilience and PAPER auto-start validation

## Changes included
- GeckoTerminal fallback budget reduced from 8 to 2 token lookups per cycle.
- Added a per-mint 120-second negative cache for successful lookups with no eligible pool; cached misses never create market observations or refresh timestamps.
- Added per-mint in-flight request sharing for GeckoTerminal; callers receive cloned Response objects so each can read its own body.
- Provider diagnostic probes no longer clear the production cooldown; real market-cycle success is required to clear persisted cooldown state.
- Current-cycle provider errors and cooldown messages are recalculated to avoid stale GeckoTerminal error text persisting after a successful response.
- New PAPER databases start with automation enabled. Existing legacy default-off rows are migrated only when their timestamp is the untouched SQLite default format; explicit user choices written with ISO timestamps are preserved.
- Live execution remains disabled; PAPER mode is required for the automation setting.

## Checks completed in this workspace
- PASS: `ci/v8617-market-resilience-paper-autostart.mjs`
- PASS: `ci/v8613-provider-paper-diagnostics.mjs`
- PASS: `ci/v8612-cooldown-regression.mjs`
- PASS: `ci/v867-market-fallback-automation-test.mjs`
- PASS: `ci/v868-market-data-pipeline-repair.mjs`
- PASS: `ci/v866-market-recovery-test.mjs`
- PASS: `ci/build-source-validation.mjs` (217 source files; no extensionless relative imports)
- PASS: `ci/test-source-validation.mjs` (79 test files; no extensionless relative imports)
- PASS: `ci/validate-paper-shadow.mjs`
- PASS: TypeScript transpilation/syntax diagnostics for changed TypeScript modules.

## Not yet verified
- Full dependency-backed TypeScript build and full npm test suite were not run in this workspace because project dependencies are not installed and network access is unavailable here. Render/GitHub CI must perform the authoritative dependency-backed build and test run.
- Hosted HTTP 429 recovery and fresh token price/liquidity ingestion require post-deploy verification.
- Existing PAPER automation is migrated only if the database row is still the untouched legacy default. If the row contains an explicit saved preference, that preference is preserved.
