import fs from 'node:fs';
import assert from 'node:assert/strict';

const app = fs.readFileSync('dashboard/app.js', 'utf8');
const risk = fs.readFileSync('src/v86-token-risk-engine.ts', 'utf8');
const server = fs.readFileSync('src/server.ts', 'utf8');

assert.match(app, /async function executeRiskScan\(manual=false\)/,
  'Risk scan must have one shared execution path');
assert.match(app, /riskPoll=setInterval\(\(\)=>\{if\(!document\.hidden\)executeRiskScan\(false\)\},30000\)/,
  'Risk scanner should refresh every 30 seconds while the page is visible');
assert.match(app, /if\(riskScanBusy\|\|!state\.token\)return/,
  'Automatic scanning must be authenticated and prevent overlapping runs');
assert.match(app, /riskScanBusy=false/,
  'The busy lock must be released after each scan');
assert.match(risk, /checks\.lpLock='UNKNOWN';\s*checks\.sellability='UNKNOWN';[\s\S]{0,250}insufficient=true;/,
  'Unknown LP lock and sellability must fail closed');
assert.match(server, /\/api\/v86\/risk-scan\/run/);
assert.match(server, /liveExecutionEnabled:false/);
console.log('V86.6.27 risk auto-scan static regression checks passed.');
console.log('This test does not replace full build, API runtime tests, on-chain validation, or APK build.');
