import fs from 'node:fs';
import assert from 'node:assert/strict';

const risk = fs.readFileSync('src/v86-token-risk-engine.ts', 'utf8');
const dist = fs.readFileSync('dist/v86-token-risk-engine.js', 'utf8');
const server = fs.readFileSync('src/server.ts', 'utf8');
const androidGradle = fs.readFileSync('android-app/app/build.gradle.kts', 'utf8');

assert.match(risk, /checks\.lpLock='UNKNOWN';\s*checks\.sellability='UNKNOWN';[\s\S]{0,250}insufficient=true;/,
  'Unknown LP-lock and sellability evidence must fail closed');
assert.match(risk, /insufficient\|\|score>=35\?'WATCH'/,
  'Incomplete risk checks must remain WATCH');
assert.match(dist, /checks\.lpLock = 'UNKNOWN';\s*checks\.sellability = 'UNKNOWN';[\s\S]{0,180}insufficient = true;/,
  'Compiled runtime must contain the same fail-closed gate');
assert.match(server, /\/api\/v86\/risk-scan\/run/);
assert.match(server, /liveExecutionEnabled:false/);
assert.match(androidGradle, /versionName = "1\.0-v86\.6\.27-paper"/);
console.log('V86.6.26 fail-closed risk scanner static checks passed.');
console.log('Note: static checks do not replace clean dependency installation, full tests, runtime/on-chain validation, or APK build.');
