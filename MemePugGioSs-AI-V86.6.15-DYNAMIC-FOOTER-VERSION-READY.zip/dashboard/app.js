(()=>{'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={token:sessionStorage.getItem('mpg_v5_token')||'',snapshot:null,health:null,tokens:[],opportunities:[],signals:[],traders:[],view:'home',busy:false};
const money=v=>{const n=Number(v);return Number.isFinite(n)?new Intl.NumberFormat('it-IT',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n):'—'};
const tokenPrice=v=>{const n=Number(v);if(v===null||v===undefined||v===''||!Number.isFinite(n)||n<=0)return'—';return new Intl.NumberFormat('it-IT',{style:'decimal',maximumSignificantDigits:8}).format(n)+' USD'};
const num=v=>{const n=Number(v);return Number.isFinite(n)?new Intl.NumberFormat('it-IT',{maximumFractionDigits:4}).format(n):'—'};
const short=v=>{if(v===null||v===undefined||v==='')return'—';const s=String(v);return s.length>18?s.slice(0,8)+'…'+s.slice(-5):s};
const fmtDate=v=>{if(!v)return'—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('it-IT',{dateStyle:'short',timeStyle:'short'})};
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(msg,bad=false){const el=$('#toast');el.textContent=msg;el.classList.toggle('bad',bad);el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,3500)}
async function api(url,opts={}){const headers={...(opts.headers||{})};if(state.token)headers.Authorization='Bearer '+state.token;if(opts.body)headers['Content-Type']='application/json';const r=await fetch(url,{...opts,headers});if(r.status===401){logout(false);throw new Error('Sessione scaduta. Accedi di nuovo.')}if(!r.ok)throw new Error(url+' · HTTP '+r.status);return r.json()}
function showApp(){ $('#login-screen').hidden=true;$('#app').hidden=false; }
function showLogin(){ $('#app').hidden=true;$('#login-screen').hidden=false; }
function logout(notify=true){state.token='';sessionStorage.removeItem('mpg_v5_token');showLogin();if(notify)toast('Hai effettuato la disconnessione.')}
$('#login-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.submitter;const error=$('#login-error');error.hidden=true;btn.disabled=true;btn.textContent='Accesso in corso…';try{const result=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#username').value.trim(),password:$('#password').value})});const data=await result.json().catch(()=>({}));if(!result.ok||!data.token)throw new Error('Credenziali non valide. Controlla ADMIN_USER e ADMIN_PASSWORD nelle variabili Render.');state.token=data.token;sessionStorage.setItem('mpg_v5_token',data.token);$('#password').value='';showApp();await refreshAll();startPolling();}catch(err){error.textContent=err.message||'Accesso non riuscito.';error.hidden=false;}finally{btn.disabled=false;btn.innerHTML='Accedi alla dashboard <span>↗</span>'}});
function setText(id,v){const el=document.getElementById(id);if(el)el.textContent=v===undefined||v===null?'—':String(v)}
function setScrollableText(id,v){const el=document.getElementById(id);if(!el)return;const next=v===undefined||v===null?'—':String(v);if(el.textContent===next)return;const previousTop=el.scrollTop;el.textContent=next;el.scrollTop=Math.min(previousTop,Math.max(0,el.scrollHeight-el.clientHeight));}
function setRows(id,rows,cols,empty){const el=document.getElementById(id);if(!el)return;if(!rows||!rows.length){el.innerHTML=`<tr><td class="empty-cell" colspan="${cols}">${esc(empty||'Nessun dato restituito dal backend.')}</td></tr>`;return}el.innerHTML=rows.map(row=>'<tr>'+row.map(cell=>`<td>${cell===null||cell===undefined?'—':cell}</td>`).join('')+'</tr>').join('')}
function pick(o,keys){for(const k of keys)if(o&&o[k]!==undefined&&o[k]!==null)return o[k];return undefined}
function renderState(s){state.snapshot=s;const a=s.account||{},e=s.engine||{};setText('equity',money(a.equity));setText('cash',money(a.cash));setText('position-count',(s.positions||[]).length);setText('engine-status',e.running?'RUNNING':'IDLE');setText('engine-subtitle',e.running?'Motore segnalato come attivo':'Il motore non risulta in esecuzione');setText('chart-equity',money(a.equity));setText('paper-cash',money(a.cash));setText('paper-equity',money(a.equity));setText('paper-positions',(s.positions||[]).length);setText('updated-at','Aggiornato '+new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'}));setText('health-time',new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'}));setText('runtime-engine',e.running?'RUNNING':'IDLE');setScrollableText('runtime-json',JSON.stringify(e,null,2));setText('connection-label','COLLEGATO');setText('api-health','ONLINE');setText('health-badge','ONLINE');
const orders=s.orders||[];setRows('recent-orders',orders.slice(0,6).map(o=>[esc(pick(o,['side','type','action'])||'Ordine'),esc(short(pick(o,['symbol','mint','token','tokenMint']))),esc(num(pick(o,['quantity','amount','size']))),esc(pick(o,['status','state'])||'—')]),4,'Nessun ordine registrato.');setRows('orders-table',orders.slice(0,100).map(o=>[esc(pick(o,['id','order_id'])||'—'),esc(short(pick(o,['symbol','mint','token']))),esc(pick(o,['side','type'])||'—'),esc(num(pick(o,['quantity','amount','size']))),esc(pick(o,['status','state'])||'—')]),5,'Nessun ordine registrato.');
const positions=s.positions||[];setRows('positions-table',positions.map(p=>[esc(short(pick(p,['symbol','mint','token']))),esc(num(pick(p,['quantity','amount','size']))),esc(money(pick(p,['averageEntry','avgPrice','avg_price','entryPrice','entry_price']))),esc(money(pick(p,['marketValue','market_value','value']))),esc(money(pick(p,['unrealizedPnl','pnl','unrealized_pnl'])))]),5,'Nessuna posizione aperta.');}
function renderTokens(rows){
  state.tokens=Array.isArray(rows)?rows:[];
  renderPaperTokenOptions();
  renderAssistantTokenOptions();
  setText('token-caption',`${state.tokens.length} token · aggiornamento automatico ogni 10 secondi · ultimo aggiornamento ${new Date().toLocaleTimeString('it-IT')}`);
  setText('market-token-count',state.tokens.length);
  const data=state.tokens.slice(0,200).map(t=>[
    esc(pick(t,['symbol','name'])||'—'),
    (t.mint&&/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(String(t.mint))?`<a class="mint-link" href="https://solscan.io/token/${encodeURIComponent(t.mint)}" target="_blank" rel="noopener noreferrer" title="Apri il token su Solscan">${esc(short(t.mint))}</a> <button type="button" class="copy-mint" data-mint="${esc(t.mint)}" aria-label="Copia mint address">Copia</button>`:'—'),
    esc(tokenPrice(pick(t,['verified_price']))),
    esc(Number(t.verified_liquidity)>0?money(t.verified_liquidity):'Non verificata'),
    esc(t.risk_score===null||t.risk_score===undefined?'Non disponibile':num(t.risk_score)),
    esc(t.largest_holder_pct===null||t.largest_holder_pct===undefined?'—':num(t.largest_holder_pct)+'%'),
    esc(t.mint_authority_present===null||t.mint_authority_present===undefined?'Non verificata':(t.mint_authority_present?'Presente':'Assente')),
    esc(t.source||'—'),
    esc(fmtDate(pick(t,['market_observed_at','last_observed_at','last_seen','updated_at','created_at'])))
  ]);
  setRows('tokens-table',data,9,'Nessun token trovato nel database. La fonte potrebbe non essere configurata.');
}
function renderOpp(rows){
  state.opportunities=Array.isArray(rows)?rows:[];
  setText('market-opp-count',state.opportunities.length);
  const data=state.opportunities.slice(0,100).map(x=>[
    esc(pick(x,['symbol','name'])||short(x.mint)),
    (x.mint&&/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(String(x.mint))?`<a class="mint-link" href="https://solscan.io/token/${encodeURIComponent(x.mint)}" target="_blank" rel="noopener noreferrer">${esc(short(x.mint))}</a>`:'—'),
    esc(tokenPrice(x.price)),esc(Number(x.liquidity)>0?money(x.liquidity):'Non verificata'),
    esc(num(x.score)),esc(x.riskScore===100&&Array.isArray(x.flags)&&x.flags.includes('RISK_DATA_UNAVAILABLE')?'Non disponibile':num(x.riskScore)),
    esc(x.tradable?'AMMESSO':'BLOCCATO')
  ]);
  setRows('signals-table',data,7,'Nessuna opportunità disponibile. Non vengono generati segnali dimostrativi.');
}
function renderTraders(rows){
  state.traders=Array.isArray(rows)?rows:[];
  const data=state.traders.slice(0,100).map(t=>[
    esc(short(pick(t,['wallet','address','publicKey','trader','name']))),
    esc(num(pick(t,['score','rank','performanceScore']))),
    esc(num(pick(t,['reputation','reputationScore','score']))),
    esc(pick(t,['status'])||'Osservato')
  ]);
  setRows('traders-table',data,4,'Nessun trader disponibile tramite le API correnti.');
}
function paperEligibleTokens(){
  return state.tokens.filter(t=>{
    const mint=String(t.mint||'');
    const price=Number(pick(t,['verified_price']));
    const liquidity=Number(pick(t,['verified_liquidity']));
    const observed=Date.parse(pick(t,['market_observed_at'])||'');
    return mint.length>=32&&mint.length<=44&&Number.isFinite(price)&&price>0&&Number.isFinite(liquidity)&&liquidity>0&&Number.isFinite(observed);
  });
}
function renderAssistantTokenOptions(){const select=$('#assistant-token');if(!select)return;const prior=select.value;select.innerHTML=state.tokens.length?'<option value="">Seleziona token…</option>'+state.tokens.map(t=>`<option value="${esc(t.mint||'')}">${esc(t.symbol||t.name||short(t.mint))} · ${esc(short(t.mint))}</option>`).join(''):'<option value="">Nessun token disponibile</option>';if(prior&&state.tokens.some(t=>t.mint===prior))select.value=prior;}
function renderPaperTokenOptions(){
  const select=$('#paper-token');if(!select)return;
  const prior=select.value;const eligible=paperEligibleTokens();
  select.innerHTML=eligible.length?'<option value="">Seleziona un token verificato…</option>'+eligible.map(t=>`<option value="${esc(t.mint)}">${esc(t.symbol||t.name||short(t.mint))} · ${esc(short(t.mint))} · ${esc(tokenPrice(pick(t,['verified_price'])))}</option>`).join(''):'<option value="">Nessun token con prezzo e liquidità verificati</option>';
  if(prior&&eligible.some(t=>t.mint===prior))select.value=prior;
  updatePaperTokenInfo();
}
function updatePaperTokenInfo(){
  const select=$('#paper-token'),info=$('#paper-token-info'),submit=$('#paper-submit');if(!select||!info||!submit)return;
  const t=state.tokens.find(x=>x.mint===select.value);const side=$('#paper-side')?.value||'BUY';
  if(!t){info.textContent='Il sistema non propone token senza dati di mercato verificati.';submit.disabled=true;return;}
  const price=Number(pick(t,['verified_price'])),liquidity=Number(pick(t,['verified_liquidity']));const observed=Date.parse(pick(t,['market_observed_at'])||'');const age=Date.now()-observed;
  const position=(state.snapshot?.positions||[]).find(p=>p.mint===t.mint);const fresh=Number.isFinite(age)&&age>=0&&age<=90000;
  const liquidityOK=Number.isFinite(liquidity)&&liquidity>=Math.max(100,Number($('#paper-quote')?.value||25)*10);
  const sellQuantity=price>0?Number($('#paper-quote')?.value||25)/price:Infinity;const canSell=side!=='SELL'||(Number(position?.quantity||0)>0&&sellQuantity<=Number(position?.quantity||0));
  info.textContent=`Prezzo: ${tokenPrice(price)} · Liquidità: ${money(liquidity)} · Osservazione: ${Number.isFinite(age)?(age<0?'orario non valido':`${Math.floor(age/1000)}s fa`):'non disponibile'}. ${!fresh?'DATO NON AGGIORNATO: ordine bloccato.':!liquidityOK?'Liquidità insufficiente per l’importo selezionato.':!canSell?'Quantità superiore alla posizione PAPER disponibile.':'Dati verificati; l’ordine resta soggetto ai controlli di rischio del backend.'}`;
  submit.disabled=!(fresh&&liquidityOK&&canSell&&price>0&&liquidity>0);
}
$('#paper-token')?.addEventListener('change',updatePaperTokenInfo);
$('#paper-side')?.addEventListener('change',updatePaperTokenInfo);
$('#paper-quote')?.addEventListener('input',updatePaperTokenInfo);
$('#paper-order-form')?.addEventListener('submit',async e=>{
  e.preventDefault();const result=$('#paper-order-result'),btn=$('#paper-submit');if(!result||!btn)return;
  const mint=$('#paper-token').value,t=state.tokens.find(x=>x.mint===mint),side=$('#paper-side').value,quote=Number($('#paper-quote').value);
  if(!t||!Number.isFinite(quote)||quote<5||quote>1000){result.textContent='Seleziona un token valido e un importo tra 5 e 1.000 USD.';result.className='form-result bad';result.hidden=false;return;}
  const price=Number(pick(t,['verified_price'])),liquidity=Number(pick(t,['verified_liquidity'])),observedAt=pick(t,['market_observed_at']);
  const age=Date.now()-Date.parse(observedAt||'');
  if(!Number.isFinite(age)||age<0||age>90000||price<=0||liquidity<Math.max(100,quote*10)){result.textContent='Ordine bloccato: prezzo/liquidità mancanti, dati scaduti o liquidità insufficiente. Aggiorna i dati e riprova.';result.className='form-result bad';result.hidden=false;return;}
  const quantity=quote/price;const position=(state.snapshot?.positions||[]).find(p=>p.mint===mint);
  if(side==='SELL'&&quantity>Number(position?.quantity||0)){result.textContent='Ordine bloccato: quantità da vendere superiore alla posizione PAPER disponibile.';result.className='form-result bad';result.hidden=false;return;}
  btn.disabled=true;btn.textContent='Verifica ordine…';result.hidden=true;
  try{
    const response=await api('/api/paper/order',{method:'POST',body:JSON.stringify({orderId:`paper-${crypto.randomUUID()}`,mint,symbol:t.symbol||t.name||short(mint),side,quantity,ask:price,bid:price,liquidity,observedAt})});
    result.textContent=`Ordine PAPER confermato: ${side} ${num(response.quantity)} unità a ${tokenPrice(response.price)}. Commissione simulata: ${money(response.fee)}. Nessuna transazione reale inviata.`;result.className='form-result good';result.hidden=false;
    await refreshAll();
  }catch(err){result.textContent=`Ordine non eseguito: ${err.message||'errore backend'}. Nessun ordine è stato dichiarato riuscito.`;result.className='form-result bad';result.hidden=false;}
  finally{btn.textContent='Esegui ordine simulato';updatePaperTokenInfo();}
});


function analyzePumpfunToken(t){
  const price=Number(pick(t,['verified_price']));
  const liquidity=Number(pick(t,['verified_liquidity']));
  const observed=Date.parse(pick(t,['market_observed_at'])||'');
  const age=Date.now()-observed;
  const riskKnown=t.risk_score!==null&&t.risk_score!==undefined&&Number.isFinite(Number(t.risk_score));
  const authorityKnown=[true,false,0,1].includes(t.mint_authority_present);
  const freezeKnown=[true,false,0,1].includes(t.freeze_authority_present);
  const mintAuthorityPresent=t.mint_authority_present===true||Number(t.mint_authority_present)===1;
  const freezeAuthorityPresent=t.freeze_authority_present===true||Number(t.freeze_authority_present)===1;
  const checks={mint:!!t.mint,price:Number.isFinite(price)&&price>0,liquidity:Number.isFinite(liquidity)&&liquidity>0,fresh:Number.isFinite(age)&&age>=0&&age<=90000,risk:riskKnown,authority:authorityKnown&&!mintAuthorityPresent,freezeAuthority:freezeKnown&&!freezeAuthorityPresent,holderKnown:t.largest_holder_pct!==null&&t.largest_holder_pct!==undefined&&Number.isFinite(Number(t.largest_holder_pct))&&Number(t.largest_holder_pct)<=25,liquidityDepth:Number.isFinite(liquidity)&&liquidity>=10000,lowRisk:riskKnown&&Number(t.risk_score)<=35};
  const reasons=[];
  if(!checks.mint)reasons.push('mint mancante');
  if(!checks.price)reasons.push('prezzo non verificato');
  if(!checks.liquidity)reasons.push('liquidità non verificata');
  else if(!checks.liquidityDepth)reasons.push('liquidità sotto 10.000 USD');
  if(!checks.fresh)reasons.push('dati più vecchi di 90 secondi o data assente');
  if(!checks.risk)reasons.push('punteggio rischio assente');
  else if(!checks.lowRisk)reasons.push('rischio oltre soglia conservativa (35/100)');
  if(!checks.authority)reasons.push('autorità mint non verificata o ancora presente');
  if(!checks.freezeAuthority)reasons.push('freeze authority non verificata o ancora presente');
  if(!checks.holderKnown)reasons.push('holder maggiore non verificato o oltre 25%');
  const eligible=Object.values(checks).every(Boolean);
  return {t,price,liquidity,age,riskKnown,eligible,reasons};
}
function renderPumpfunAnalysis(rows){
  const analyzed=rows.map(analyzePumpfunToken);
  const candidates=analyzed.filter(x=>x.eligible).length;
  const blocked=analyzed.length-candidates;
  const summary=$('#pumpfun-analysis-summary');
  summary.hidden=false;summary.className='form-result '+(candidates?'good':'bad');
  summary.textContent=`Analisi completata: ${analyzed.length} token esaminati · ${candidates} candidati da valutare esclusivamente in PAPER · ${blocked} esclusi per rischio o dati mancanti. Nessun ordine è stato inviato.`;
  setRows('pumpfun-analysis-table',analyzed.map(x=>[
    esc(pick(x.t,['symbol','name'])||short(x.t.mint)),
    esc(tokenPrice(x.price)),
    esc(x.liquidity>0?money(x.liquidity):'Non verificata'),
    esc(x.riskKnown?num(x.t.risk_score)+'/100':'Non disponibile'),
    esc(Number.isFinite(x.age)&&x.age>=0?`${Math.floor(x.age/1000)} s`:'Non disponibile'),
    esc([true,false,0,1].includes(x.t.mint_authority_present)?((x.t.mint_authority_present===true||Number(x.t.mint_authority_present)===1)?'Presente':'Assente'):'Non verificata'),
    `<strong>${x.eligible?'CANDIDATO PAPER':'ESCLUSO'}</strong>`,
    esc(x.reasons.length?x.reasons.join('; '):'Controlli base superati; non è una raccomandazione di acquisto')
  ]),8,'Nessun token ricevuto dal feed.');
}
$('#pumpfun-bulk-analyze')?.addEventListener('click',async e=>{
  const btn=e.currentTarget,summary=$('#pumpfun-analysis-summary');btn.disabled=true;btn.textContent='Analisi dei token in corso…';
  summary.hidden=false;summary.className='form-result';summary.textContent='Aggiorno l’elenco dal backend e controllo tutti i token disponibili…';
  try{const rows=await api('/api/tokens');renderTokens(rows);if(!Array.isArray(rows)||!rows.length){renderPumpfunAnalysis([]);summary.className='form-result bad';summary.textContent='Nessun token disponibile da analizzare. Verifica ingestione PumpPortal/Pump.fun e connessione al database. Trading automatico non attivato.';return;}renderPumpfunAnalysis(rows);const auto=await api('/api/paper/auto',{method:'POST',body:JSON.stringify({enabled:true})});renderAutoPaper(auto);summary.textContent+=` Motore PAPER attivato: monitora ogni 10 secondi e apre posizioni solo se tutti i gate sono superati. Nessuna transazione reale.`;}
  catch(err){summary.className='form-result bad';summary.textContent=`Analisi non completata: ${err.message||'errore backend'}. Nessun token è stato valutato come idoneo.`;}
  finally{btn.disabled=false;btn.textContent='Avvia analisi e trading automatico PAPER';}
});
$('#assistant-analysis-form')?.addEventListener('submit',e=>{e.preventDefault();const out=$('#assistant-analysis-result');const mint=$('#assistant-token')?.value;const t=state.tokens.find(x=>x.mint===mint);if(!out)return;out.hidden=false;if(!t){out.className='form-result bad';out.textContent='Nessun token selezionato.';return;}const price=Number(pick(t,['verified_price']));const liquidity=Number(pick(t,['verified_liquidity']));const observed=Date.parse(pick(t,['market_observed_at'])||'');const age=Date.now()-observed;const riskKnown=t.risk_score!==null&&t.risk_score!==undefined&&Number.isFinite(Number(t.risk_score));const checks=[['Mint address',t.mint?'presente':'mancante'],['Prezzo',Number.isFinite(price)&&price>0?tokenPrice(price):'non verificato'],['Liquidità',Number.isFinite(liquidity)&&liquidity>0?money(liquidity):'non verificata'],['Età dato',Number.isFinite(age)&&age>=0?`${Math.floor(age/1000)} secondi`:'non disponibile'],['Punteggio rischio',riskKnown?num(t.risk_score):'non disponibile'],['Autorità mint',[true,false,0,1].includes(t.mint_authority_present)?((t.mint_authority_present===true||Number(t.mint_authority_present)===1)?'presente':'assente'):'non verificata'],['Holder maggiore',t.largest_holder_pct===null||t.largest_holder_pct===undefined?'non disponibile':num(t.largest_holder_pct)+'%']];const hardBlock=!t.mint||!Number.isFinite(price)||price<=0||!Number.isFinite(liquidity)||liquidity<=0||!Number.isFinite(age)||age<0||age>90000||!riskKnown;out.className='form-result '+(hardBlock?'bad':'good');out.innerHTML=`<strong>${hardBlock?'RISCHIO NON VALUTABILE — operazione bloccata':'Dati disponibili — non è una previsione di rendimento'}</strong><ul>${checks.map(([k,v])=>`<li><b>${esc(k)}:</b> ${esc(v)}</li>`).join('')}</ul><p>${hardBlock?'Mancano dati verificati o aggiornati. Non eseguire operazioni su questo token.':'Controlli informativi completati. Verifica sempre il contratto e la coppia di mercato.'}</p>`;});

function drawEquityChart(curve,lineId,areaId,emptyId){
  const line=document.getElementById(lineId),area=areaId?document.getElementById(areaId):null,empty=document.getElementById(emptyId);
  const points=(Array.isArray(curve)?curve:[]).filter(x=>Number.isFinite(Number(x.equity))).slice(-180);
  if(points.length<2){if(line)line.setAttribute('points','');if(area)area.setAttribute('points','');if(empty)empty.hidden=false;return;}
  const vals=points.map(x=>Number(x.equity)),min=Math.min(...vals),max=Math.max(...vals),span=max-min||1;
  const coords=vals.map((v,i)=>`${(i/(vals.length-1)*700+10).toFixed(2)},${(175-(v-min)/span*150).toFixed(2)}`).join(' ');
  if(line)line.setAttribute('points',coords);
  if(area)area.setAttribute('points',`10,180 ${coords} 710,180`);
  if(empty)empty.hidden=true;
}
function renderAutoPaper(data){
  if(!data)return;
  const pnl=Number(data.totalPnl||0),realized=Number(data.realizedPnl||0),unrealized=Number(data.unrealizedPnl||0);
  setText('paper-total-pnl',money(pnl));setText('paper-realized-pnl',money(realized));setText('paper-unrealized-pnl',money(unrealized));
  setText('chart-pnl-label',`P/L totale: ${money(pnl)}`);
  const status=$('#auto-paper-status'),detail=$('#auto-paper-detail'),button=$('#auto-paper-toggle');
  if(status)status.textContent=data.enabled?'AUTOMAZIONE PAPER ATTIVA':'AUTOMAZIONE PAPER DISATTIVATA';
  if(detail){const l=data.limits||{},d=data.diagnostics||{},blocks=Object.entries(d.blockedBy||{}).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([k,v])=>`${k}: ${v}`).join(', ');detail.textContent=`Capitale iniziale ${money(data.startingCapital)} · ${data.openPositions||0} posizioni aperte · max ${l.maxOpenPositions||3} posizioni · allocazione ${l.positionPct||2}% per posizione · stop-loss ${l.stopLossPct||8}% · take-profit ${l.takeProfitPct||15}%. Stato: ${d.scanStatus||'IN ATTESA'} · ultimo ciclo ${d.lastTickAt?fmtDate(d.lastTickAt):'in attesa'} · ultima scansione ${d.lastScanAt?fmtDate(d.lastScanAt):'in attesa'} · token esaminati ${d.candidateCount||0} · idonei ${d.eligibleCount||0}${blocks?` · blocchi: ${blocks}`:''}${d.lastTickError?` · errore motore: ${d.lastTickError}`:''}. I dati non verificati bloccano l’ingresso.`;}
  if(button){button.textContent=data.enabled?'Disattiva trading automatico PAPER':'Attiva trading automatico PAPER';button.classList.toggle('danger',Boolean(data.enabled));button.disabled=false;}
  drawEquityChart(data.curve,'paper-equity-line',null,'paper-equity-chart-empty');
  drawEquityChart(data.curve,'equity-line','equity-area','equity-chart-empty');
  const events=(data.events||[]).slice(0,30).map(x=>[
    esc(fmtDate(x.ts)),esc(x.symbol||short(x.mint)),esc(x.action||'—'),esc(x.price?tokenPrice(x.price):'—'),esc(money(x.pnl||0)),esc(x.reason||'—')
  ]);
  setRows('auto-paper-events',events,6,'Nessuna attività automatica registrata. Abilita il motore per avviare il monitoraggio PAPER.');
}
$('#auto-paper-toggle')?.addEventListener('click',async()=>{
  const button=$('#auto-paper-toggle');if(!button)return;const enable=button.textContent.toLowerCase().includes('attiva');
  button.disabled=true;button.textContent=enable?'Attivazione…':'Disattivazione…';
  try{const data=await api('/api/paper/auto',{method:'POST',body:JSON.stringify({enabled:enable})});renderAutoPaper(data);toast(enable?'Trading automatico PAPER attivato. Nessuna transazione reale.':'Trading automatico PAPER disattivato.');await refreshAll();}
  catch(e){button.disabled=false;button.textContent=enable?'Attiva trading automatico PAPER':'Disattiva trading automatico PAPER';toast(`Impossibile modificare il motore: ${e.message||'errore'}`,true);}
});
$('#wallet-monitor-form')?.addEventListener('submit',async e=>{e.preventDefault();const result=$('#wallet-monitor-result'),btn=$('#wallet-monitor-submit');const wallet=$('#wallet-address').value.trim();if(!result||!btn)return;result.hidden=false;if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(wallet)){result.className='form-result bad';result.textContent='Indirizzo Solana non valido.';return;}btn.disabled=true;btn.textContent='Verifica wallet…';try{const history=await api(`/api/v34/wallet/${encodeURIComponent(wallet)}/history?limit=20`);await api('/api/v34/follow',{method:'POST',body:JSON.stringify({wallet,copyPaper:true})});result.className='form-result good';result.textContent=`Wallet pubblico registrato in PAPER. Firme recenti restituite dall'RPC: ${(history.signatures||[]).length}. Questo conteggio non equivale a trade classificati.`;$('#wallet-address').value='';await refreshAll();await renderFollowingWallets();const h=$('#wallet-history');if(h){h.hidden=false;h.textContent=`Ultima verifica ${new Date().toLocaleTimeString('it-IT')}: ${(history.signatures||[]).length} firme recenti. Per classificare BUY/SELL serve parsing delle transazioni e dati quote verificati.`}}catch(err){result.className='form-result bad';result.textContent=`Wallet non aggiunto: ${err.message||'errore API'}. Verifica che RPC Solana sia configurato su Render.`}finally{btn.disabled=false;btn.textContent='Aggiungi wallet da monitorare';}});
async function renderFollowingWallets(){const box=$('#wallet-following');if(!box||!state.token)return;try{const rows=await api('/api/v34/following');if(!Array.isArray(rows)||!rows.length){box.textContent='Nessun wallet seguito.';return;}box.innerHTML=rows.map(w=>`<div class="health-row"><span><a class="mint-link" href="https://solscan.io/account/${encodeURIComponent(w.wallet)}" target="_blank" rel="noopener noreferrer">${esc(short(w.wallet))}</a></span><strong>${w.copy_paper?'PAPER':'MONITORAGGIO'}</strong></div>`).join('')}catch{box.textContent='Impossibile caricare i wallet seguiti.'}}
document.addEventListener('click',async e=>{const b=e.target.closest('[data-mint]');if(!b)return;try{await navigator.clipboard.writeText(b.dataset.mint);toast('Mint address copiato.')}catch{toast('Copia non disponibile nel browser.',true)}});
async function refreshAll(){if(state.busy||!state.token)return;state.busy=true;setText('connection-label','AGGIORNAMENTO');try{const healthP=fetch('/api/health').then(r=>r.json()).catch(()=>null);const results=await Promise.allSettled([api('/api/state'),api('/api/tokens'),api('/api/opportunities'),api('/api/v34/traders'),healthP,api('/api/paper/auto')]);if(results[0].status==='fulfilled')renderState(results[0].value);else throw results[0].reason;if(results[1].status==='fulfilled')renderTokens(results[1].value);if(results[2].status==='fulfilled')renderOpp(results[2].value);if(results[3].status==='fulfilled')renderTraders(results[3].value);if(results[5].status==='fulfilled')renderAutoPaper(results[5].value);await renderFollowingWallets();if(results[4].status==='fulfilled'&&results[4].value){state.health=results[4].value;setText('footer-version',String(state.health.release||state.health.diagnosticBuildId||`Versione ${state.health.version||'non verificata'}`));setText('rpc-status',String(state.health.rpc||'—').toUpperCase());setText('api-health',state.health.ok?'ONLINE':'ATTENZIONE');setText('runtime-api',state.health.ok?'ONLINE':'ATTENZIONE');const feed=state.health.pumpPortal||{};const feedTime=feed.lastMessageAt?fmtDate(feed.lastMessageAt):'nessun messaggio ancora';const feedError=feed.lastError?' · Ultimo errore segnalato: sì (dettaglio nei log backend)':' · Nessun errore segnalato';setText('market-summary',`Servizio: ${state.health.ok?'online':'da verificare'} · Versione: ${state.health.version||'—'} · RPC: ${state.health.rpc||'non configurato'} · WebSocket Solana: ${state.health.chainStream?'configurato':'non configurato'} · PumpPortal: ${feed.status||'stato non disponibile'} · messaggi ricevuti: ${Number(feed.messages||0)} · token nuovi ricevuti: ${Number(feed.tokensReceived||0)} · ultimo messaggio: ${feedTime}${feedError}. Un endpoint collegato non garantisce da solo un feed aggiornato né costituisce un segnale di trading.`);setScrollableText('runtime-json',JSON.stringify({health:state.health,engine:state.snapshot?.engine||{}},null,2));}else{setText('rpc-status','NON VERIFICATO');setText('market-summary','Health check non disponibile. Controlla la connessione del backend.')}setText('connection-label','COLLEGATO');}catch(err){setText('connection-label','ERRORE');toast(err.message||'Errore durante il caricamento dei dati.',true)}finally{state.busy=false}}
function go(view){if(!document.getElementById('view-'+view))return;state.view=view;$$('.page').forEach(p=>p.classList.toggle('active',p.id==='view-'+view));$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));setText('page-name',({home:'Home',market:'Mercato Solana',tokens:'Nuovi token',signals:'Segnali AI',paper:'Paper Trading',copy:'Copy Trading',assistant:'Assistente AI',runtime:'Stato motore'})[view]||view);$('#sidebar').classList.remove('open');}
$('#market-provider-probe')?.addEventListener('click',async e=>{const btn=e.currentTarget,box=$('#market-provider-diagnostics');btn.disabled=true;btn.textContent='Verifica in corso…';box.hidden=false;box.textContent='Richiesta diagnostica al backend Render…';try{const data=await api('/api/diagnostics/market-providers?force=1');box.textContent=JSON.stringify(data,null,2);toast('Diagnostica provider completata.')}catch(err){box.textContent=err.message||'Diagnostica non riuscita.';toast('Diagnostica provider non riuscita.',true)}finally{btn.disabled=false;btn.textContent='Verifica accesso provider'}});
$('#paper-engine-diagnostic')?.addEventListener('click',async e=>{const btn=e.currentTarget,box=$('#paper-engine-diagnostics');btn.disabled=true;btn.textContent='Verifica in corso…';box.hidden=false;box.textContent='Lettura stato motore PAPER…';try{const data=await api('/api/diagnostics/paper-engine');box.textContent=JSON.stringify(data,null,2);toast('Diagnostica motore PAPER completata.')}catch(err){box.textContent=err.message||'Diagnostica non riuscita.';toast('Diagnostica motore PAPER non riuscita.',true)}finally{btn.disabled=false;btn.textContent='Verifica motore PAPER'}});
$('#navigation').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b)go(b.dataset.view)});document.addEventListener('click',e=>{const b=e.target.closest('[data-goto]');if(b)go(b.dataset.goto)});$('#menu-toggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));$('#refresh').addEventListener('click',refreshAll);$('#runtime-refresh').addEventListener('click',refreshAll);$('#reload-tokens').addEventListener('click',async()=>{try{renderTokens(await api('/api/tokens'));toast('Elenco token aggiornato.')}catch(e){toast(e.message,true)}});$('#logout').addEventListener('click',()=>logout());
let poll=null;function startPolling(){if(poll)clearInterval(poll);poll=setInterval(refreshAll,10000)}
if(state.token){showApp();refreshAll().then(startPolling)}else showLogin();
})();