import {describe, expect, it} from "vitest";
import {buildPumpSwapLiveState} from "../src/v25-reconcile.js";
import {toHomeFeed} from "../src/v25-home-feed.js";
import {V25_SAFETY, assertV25Shadow} from "../src/v25-safety.js";

describe("V25 live state", () => {
  it("combines pool metadata and vault balances with slot coherence", () => {
    const now = Date.now();
    const s = buildPumpSwapLiveState({
      pool: {
        poolBump:1,index:2,creator:"c",baseMint:"BASE",quoteMint:"QUOTE",lpMint:"LP",
        poolBaseTokenAccount:"BV",poolQuoteTokenAccount:"QV",lpSupply:100n,coinCreator:"cc",
        isMayhemMode:false,isCashbackCoin:false,creatorFeeBps:0n,isHolderReward:false,
        virtualQuoteReserves:50n,slot:100,observedAt:now,
      },
      baseVault:{address:"BV",mint:"BASE",amount:1000n,decimals:6,slot:100,observedAt:now,source:"RPC"},
      quoteVault:{address:"QV",mint:"QUOTE",amount:2500n,decimals:9,slot:101,observedAt:now,source:"RPC"},
      totalSupply:1000000n,supplyDecimals:6,now,
    });
    expect(s.effectiveQuoteReserves).toBe(2550n);
    expect(s.priceQuotePerBaseUnit.numerator).toBe(2550n);
    expect(s.priceQuotePerBaseUnit.denominator).toBe(1000n);
    expect(s.slotSpread).toBe(1);
    expect(s.coherent).toBe(true);
  });

  it("marks stale state as not coherent", () => {
    const old = Date.now() - 30_000;
    const s = buildPumpSwapLiveState({
      pool: {poolBump:1,index:2,creator:"c",baseMint:"BASE",quoteMint:"QUOTE",lpMint:"LP",poolBaseTokenAccount:"BV",poolQuoteTokenAccount:"QV",lpSupply:1n,coinCreator:"cc",isMayhemMode:false,isCashbackCoin:false,creatorFeeBps:0n,isHolderReward:false,virtualQuoteReserves:0n,slot:1,observedAt:old},
      baseVault:{address:"BV",mint:"BASE",amount:1n,decimals:0,slot:1,observedAt:old,source:"RPC"},
      quoteVault:{address:"QV",mint:"QUOTE",amount:1n,decimals:0,slot:1,observedAt:old,source:"RPC"},
      totalSupply:1n,supplyDecimals:0,now:Date.now(),
    });
    expect(s.stale).toBe(true);
    expect(s.coherent).toBe(false);
    expect(s.confidence).toBe(0);
  });

  it("maps state into the unchanged home-screen data contract", () => {
    const feed = toHomeFeed([], {websocket:"CONNECTED",subscriptions:3,staleAccounts:0,errors:0,reconnects:0});
    expect(feed.mode).toBe("PAPER");
    expect(feed.system.websocket).toBe("CONNECTED");
  });

  it("keeps V25 shadow-only", () => {
    assertV25Shadow();
    expect(V25_SAFETY.liveTrading).toBe(false);
    expect(V25_SAFETY.signingEnabled).toBe(false);
    expect(V25_SAFETY.broadcastEnabled).toBe(false);
  });
});
