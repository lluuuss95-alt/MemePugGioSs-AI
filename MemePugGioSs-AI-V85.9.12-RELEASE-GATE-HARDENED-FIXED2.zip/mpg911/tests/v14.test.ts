import assert from "node:assert/strict";
import { runSignalLab } from "../src/v14-run.js";

const rows=Array.from({length:100},(_,i)=>({
 mint:`M${i%10}`,ts:i,signalState:i%5===0?"CONFIRMED":"WATCH",score:70,confidence:.8,
 futureReturnPct:i%3===0?5:-2,mfePct:8,maePct:-3,horizonMs:60000
}));
const r=runSignalLab(rows);
assert.equal(r.overall.rows,100);
assert.ok(r.overall.ci95);
assert.equal(r.grouped.test.length>0,true);
assert.equal(r.manifest.length,64);
console.log("V14 tests passed");
