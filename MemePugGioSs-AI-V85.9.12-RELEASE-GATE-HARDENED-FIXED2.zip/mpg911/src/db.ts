import fs from "node:fs"; import path from "node:path"; import Database from "better-sqlite3"; import {config} from "./config.js";
const dir=path.dirname(config.db); if(dir && dir!==".") fs.mkdirSync(dir,{recursive:true});
export const db=new Database(config.db); db.pragma("journal_mode=WAL"); db.pragma("busy_timeout=5000");
db.exec(`
CREATE TABLE IF NOT EXISTS tokens(mint TEXT PRIMARY KEY,symbol TEXT,name TEXT,source TEXT,first_seen TEXT,last_seen TEXT,metadata_json TEXT);
CREATE TABLE IF NOT EXISTS observations(id INTEGER PRIMARY KEY AUTOINCREMENT,mint TEXT NOT NULL,observed_at TEXT NOT NULL,slot INTEGER,price REAL,liquidity REAL,volume5m REAL,holders INTEGER,age_seconds INTEGER,buy_pressure REAL,raw_json TEXT,quality TEXT DEFAULT 'OK');
CREATE TABLE IF NOT EXISTS orders(order_id TEXT PRIMARY KEY,mint TEXT,side TEXT,quantity REAL,limit_price REAL,status TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS fills(order_id TEXT PRIMARY KEY,mint TEXT,side TEXT,quantity REAL,price REAL,fee REAL,filled_at TEXT);
CREATE TABLE IF NOT EXISTS positions(mint TEXT PRIMARY KEY,symbol TEXT,quantity REAL,avg_entry REAL,realized_pnl REAL,updated_at TEXT);
CREATE TABLE IF NOT EXISTS account(id INTEGER PRIMARY KEY CHECK(id=1),cash REAL NOT NULL,equity REAL NOT NULL,updated_at TEXT);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT UNIQUE,type TEXT,timestamp TEXT,payload_json TEXT);
CREATE TABLE IF NOT EXISTS ingestion_events(event_id TEXT PRIMARY KEY,mint TEXT,event_time TEXT,source TEXT,payload_json TEXT,status TEXT,error TEXT);
CREATE TABLE IF NOT EXISTS cursors(source TEXT PRIMARY KEY,cursor TEXT,updated_at TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,role TEXT);
CREATE TABLE IF NOT EXISTS token_intelligence(mint TEXT PRIMARY KEY,supply REAL,decimals INTEGER,largest_holder_pct REAL,top10_holder_pct REAL,mint_authority_present INTEGER,freeze_authority_present INTEGER,risk_score REAL,flags_json TEXT,checked_at TEXT);
CREATE TABLE IF NOT EXISTS strategy_signals(signal_id TEXT PRIMARY KEY,mint TEXT,action TEXT,score REAL,risk_score REAL,reasons_json TEXT,created_at TEXT,status TEXT);
CREATE TABLE IF NOT EXISTS dead_letters(id INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT,source TEXT,error TEXT,payload_json TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS v26_discovered_tokens(mint TEXT PRIMARY KEY,bonding_curve TEXT NOT NULL,signature TEXT NOT NULL,slot INTEGER NOT NULL,block_time INTEGER,create_kind TEXT NOT NULL,name TEXT,symbol TEXT,uri TEXT,creator TEXT,quote_mint TEXT,mayhem_mode INTEGER,holder_reward INTEGER,detected_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_obs_mint_time ON observations(mint,observed_at);
CREATE INDEX IF NOT EXISTS idx_ingest_time ON ingestion_events(event_time);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit(timestamp);
`);
const row=db.prepare("SELECT id FROM account WHERE id=1").get(); if(!row) db.prepare("INSERT INTO account(id,cash,equity,updated_at) VALUES(1,?,?,?)").run(config.startingCash,config.startingCash,new Date().toISOString());
export function audit(eventId:string,type:string,payload:unknown){db.prepare("INSERT OR IGNORE INTO audit(event_id,type,timestamp,payload_json) VALUES(?,?,?,?)").run(eventId,type,new Date().toISOString(),JSON.stringify(payload));}
