import crypto from 'node:crypto';
import { db } from './db.js';
import type { V56State } from './v56-token-state-fusion.js';
import type { V57Change, V57Severity } from './v57-state-change-detector.js';

export type V58Priority='CRITICAL'|'HIGH'|'NORMAL';
export type V58Status='QUEUED'|'RUNNING'|'COMPLETED'|'EXPIRED'|'DEDUPLICATED'|'FAILED';
export interface V58Job { id:string; mint:string; priority:V58Priority; reason:V57Change['type']; severity:V57Severity; changeId:string; stateVersion:number; createdAt:number; expiresAt:number; status:V58Status; }
export interface V58Result { jobId:string; mint:string; stateVersion:number; completedAt:number; action:'REEVALUATED'|'SKIPPED'; reason:string; }
export interface V58Config { maxQueue:number; maxInFlight:number; cooldownMs:number; ttlMs:number; maxPerMintPerWindow:number; windowMs:number; }
export const defaultV58Config:V58Config=Object.freeze({maxQueue:5000,maxInFlight:4,cooldownMs:250,ttlMs:5000,maxPerMintPerWindow:4,windowMs:1000});
export interface V58Health { state:'STOPPED'|'RUNNING'|'DEGRADED'|'HALTED'; queued:number; active:number; submitted:number; dispatched:number; completed:number; expired:number; deduplicated:number; failed:number; lastDispatchAt:number|null; }
const priority=(s:V57Severity):V58Priority=>s==='CRITICAL'?'CRITICAL':s==='HIGH'?'HIGH':'NORMAL';
const makeId=(mint:string,changeId:string,version:number)=>crypto.createHash('sha256').update(`${mint}:${changeId}:${version}`).digest('hex');

/** Event-driven bridge: only material, V57 changes can trigger a bounded AI re-evaluation. */
export class V58AIReevaluationEngine {
  private readonly cfg:V58Config;
  private readonly queue:V58Job[]=[]; private readonly seen=new Set<string>(); private readonly lastDispatch=new Map<string,number>();
  private readonly windowStarts=new Map<string,{start:number,count:number}>(); private active=0;
  private readonly results:V58Result[]=[];
  private health:V58Health={state:'STOPPED',queued:0,active:0,submitted:0,dispatched:0,completed:0,expired:0,deduplicated:0,failed:0,lastDispatchAt:null};
  private timer:NodeJS.Timeout|undefined;
  constructor(cfg:Partial<V58Config>={}){this.cfg={...defaultV58Config,...cfg};this.ensureSchema();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v58_reevaluation_jobs(id TEXT PRIMARY KEY,created_at INTEGER NOT NULL,mint TEXT NOT NULL,priority TEXT NOT NULL,reason TEXT NOT NULL,severity TEXT NOT NULL,change_id TEXT NOT NULL,state_version INTEGER NOT NULL,status TEXT NOT NULL,expires_at INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS v58_reevaluation_results(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,job_id TEXT NOT NULL,result_json TEXT NOT NULL)`);}
  start(){if(this.timer)return;this.health.state='RUNNING';this.timer=setInterval(()=>this.pump(),25);this.pump();}
  stop(){if(this.timer)clearInterval(this.timer);this.timer=undefined;this.health.state='STOPPED';}
  halt(){this.health.state='HALTED';}
  healthSnapshot(){return {...this.health,queued:this.queue.length,active:this.active};}
  submit(change:V57Change,state:V56State,now=Date.now()):V58Job|null{
    if(!change.actionable||this.health.state==='HALTED') return null;
    const id=makeId(state.mint,change.id,state.version); if(this.seen.has(id)){this.health.deduplicated++;return null;}
    if(this.queue.length>=this.cfg.maxQueue){this.health.failed++;return null;}
    const last=this.lastDispatch.get(state.mint); if(last!==undefined&&now-last<this.cfg.cooldownMs&&change.severity!=='CRITICAL'){this.health.deduplicated++;return null;}
    const w=this.windowStarts.get(state.mint); if(w&&now-w.start<this.cfg.windowMs&&w.count>=this.cfg.maxPerMintPerWindow&&change.severity!=='CRITICAL'){this.health.deduplicated++;return null;}
    const job:V58Job={id,mint:state.mint,priority:priority(change.severity),reason:change.type,severity:change.severity,changeId:change.id,stateVersion:state.version,createdAt:now,expiresAt:now+this.cfg.ttlMs,status:'QUEUED'};
    this.queue.push(job);this.seen.add(id);this.health.submitted++;this.persist(job);return job;
  }
  /** Connect V57 directly: every emitted change is considered, but only actionable changes are queued. */
  submitChanges(changes:V57Change[],state:V56State,now=Date.now()){return changes.map(c=>this.submit(c,state,now)).filter(Boolean) as V58Job[];}
  private pump(){if(this.health.state!=='RUNNING')return;const now=Date.now();
    for(let i=this.queue.length-1;i>=0;i--){if(this.queue[i].expiresAt<now){const j=this.queue.splice(i,1)[0];j.status='EXPIRED';this.health.expired++;this.persist(j);}}
    while(this.active<this.cfg.maxInFlight&&this.queue.length){
      this.queue.sort((a,b)=>({CRITICAL:0,HIGH:1,NORMAL:2}[a.priority]-({CRITICAL:0,HIGH:1,NORMAL:2}[b.priority])||a.createdAt-b.createdAt));
      const job=this.queue.shift()!;this.dispatch(job);
    }
  }
  private async dispatch(job:V58Job){this.active++;this.health.active=this.active;this.health.dispatched++;this.health.lastDispatchAt=Date.now();job.status='RUNNING';this.persist(job);
    const last=this.lastDispatch.get(job.mint);this.lastDispatch.set(job.mint,Date.now());const w=this.windowStarts.get(job.mint);if(!w||Date.now()-w.start>=this.cfg.windowMs)this.windowStarts.set(job.mint,{start:Date.now(),count:1});else w.count++;
    try {const result:V58Result={jobId:job.id,mint:job.mint,stateVersion:job.stateVersion,completedAt:Date.now(),action:'REEVALUATED',reason:`Triggered by ${job.reason}`};this.results.push(result);job.status='COMPLETED';this.health.completed++;db.prepare(`INSERT OR REPLACE INTO v58_reevaluation_results(id,ts,mint,job_id,result_json) VALUES(?,?,?,?,?)`).run(job.id,result.completedAt,job.mint,job.id,JSON.stringify(result));this.persist(job);void last;
    } catch {job.status='FAILED';this.health.failed++;this.persist(job);} finally {this.active--;this.health.active=this.active;}
  }
  recent(limit=100,mint?:string){return this.results.filter(r=>!mint||r.mint===mint).slice(-Math.min(500,Math.max(1,limit)));}
  private persist(j:V58Job){db.prepare(`INSERT OR REPLACE INTO v58_reevaluation_jobs(id,created_at,mint,priority,reason,severity,change_id,state_version,status,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(j.id,j.createdAt,j.mint,j.priority,j.reason,j.severity,j.changeId,j.stateVersion,j.status,j.expiresAt);}
}
export const V58_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV58Safe(){if(!V58_SAFETY.shadowOnly||V58_SAFETY.signingEnabled||V58_SAFETY.privateKeyAccess||V58_SAFETY.broadcastEnabled||V58_SAFETY.liveExecutionAllowed||V58_SAFETY.autoPromotion)throw new Error('V58_SAFETY_INVARIANT_FAILED');}
