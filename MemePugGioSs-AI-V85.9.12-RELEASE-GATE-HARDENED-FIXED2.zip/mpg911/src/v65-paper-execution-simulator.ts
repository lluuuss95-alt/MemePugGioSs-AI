import crypto from 'node:crypto';
import { db } from './db.js';

export type V65Side='BUY'|'SELL';
export type V65Decision='EXECUTABLE'|'BLOCK';

export interface V65PoolState {
  mint:string;
  baseReserve:number;
  quoteReserve:number;
  feeBps:number;
  updatedAt:number;
  verified?:boolean;
}

export interface V65ExecutionRequest {
  side:V65Side;
  mint:string;
  quoteAmount?:number;
  baseAmount?:number;
  maxSlippageBps:number;
  externalSlippageBps?:number;
  now?:number;
}

export interface V65ExecutionResult {
  id:string;
  ts:number;
  mint:string;
  side:V65Side;
  decision:V65Decision;
  inputAmount:number;
  outputAmount:number;
  effectivePrice:number;
  referencePrice:number;
  priceImpactBps:number;
  externalSlippageBps:number;
  totalSlippageBps:number;
  feeAmount:number;
  remainingBaseReserve:number;
  remainingQuoteReserve:number;
  blockers:string[];
  warnings:string[];
  liveExecutionEnabled:false;
}

export interface V65Config {
  maxStateAgeMs:number;
  maxFeeBps:number;
  maxPriceImpactBps:number;
  maxExternalSlippageBps:number;
  requireVerifiedPool:boolean;
  minReserve:number;
}

export const defaultV65Config:V65Config=Object.freeze({
  maxStateAgeMs:5000,
  maxFeeBps:100,
  maxPriceImpactBps:800,
  maxExternalSlippageBps:250,
  requireVerifiedPool:true,
  minReserve:100,
});

const finite=(n:unknown)=>Number.isFinite(Number(n))?Number(n):NaN;
const bps=(x:number)=>x*10000;

/**
 * V65 models a constant-product paper execution from verified pool reserves.
 * It never submits, signs, broadcasts or promotes a transaction.
 */
export class V65PaperExecutionSimulator {
  constructor(private readonly cfg:V65Config=defaultV65Config){this.ensureSchema();}

  private ensureSchema(){
    db.exec(`CREATE TABLE IF NOT EXISTS v65_execution_simulations(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, mint TEXT NOT NULL, side TEXT NOT NULL,
      decision TEXT NOT NULL, input_amount REAL NOT NULL, output_amount REAL NOT NULL,
      effective_price REAL NOT NULL, reference_price REAL NOT NULL, price_impact_bps REAL NOT NULL,
      external_slippage_bps REAL NOT NULL, total_slippage_bps REAL NOT NULL, fee_amount REAL NOT NULL,
      remaining_base_reserve REAL NOT NULL, remaining_quote_reserve REAL NOT NULL,
      blockers_json TEXT NOT NULL, warnings_json TEXT NOT NULL, details_json TEXT NOT NULL
    )`);
  }

  simulate(pool:V65PoolState, req:V65ExecutionRequest):V65ExecutionResult{
    const now=req.now??Date.now();
    const blockers:string[]=[]; const warnings:string[]=[];
    const base=finite(pool.baseReserve), quote=finite(pool.quoteReserve), feeBps=finite(pool.feeBps);
    const ext=Math.max(0,finite(req.externalSlippageBps) || 0);
    const maxSlip=Math.max(0,finite(req.maxSlippageBps));
    const input=req.side==='BUY'?finite(req.quoteAmount):finite(req.baseAmount);

    if(pool.mint!==req.mint) blockers.push('MINT_MISMATCH');
    if(!Number.isFinite(base)||!Number.isFinite(quote)||base<=this.cfg.minReserve||quote<=this.cfg.minReserve) blockers.push('INSUFFICIENT_POOL_RESERVES');
    if(!Number.isFinite(feeBps)||feeBps<0||feeBps>this.cfg.maxFeeBps) blockers.push('FEE_OUT_OF_RANGE');
    if(now-pool.updatedAt>this.cfg.maxStateAgeMs) blockers.push('POOL_STATE_STALE');
    if(this.cfg.requireVerifiedPool && pool.verified!==true) blockers.push('POOL_NOT_VERIFIED');
    if(!Number.isFinite(input)||input<=0) blockers.push('INVALID_INPUT_AMOUNT');
    if(!Number.isFinite(maxSlip)||maxSlip<0) blockers.push('INVALID_MAX_SLIPPAGE');
    if(ext>this.cfg.maxExternalSlippageBps) blockers.push('EXTERNAL_SLIPPAGE_TOO_HIGH');

    let output=0, fee=0, reference=0, effective=0, impact=0, total=0, remBase=base, remQuote=quote;
    if(blockers.length===0){
      const k=base*quote;
      reference=quote/base;
      fee=input*feeBps/10000;
      const net=input-fee;
      if(req.side==='BUY'){
        if(net>=quote) blockers.push('QUOTE_INPUT_EXCEEDS_RESERVE');
        else {
          remQuote=quote+net;
          remBase=k/remQuote;
          output=base-remBase;
          effective=input/output;
          impact=Math.max(0,bps(effective/reference-1));
        }
      } else {
        if(input>=base) blockers.push('BASE_INPUT_EXCEEDS_RESERVE');
        else {
          remBase=base+net;
          remQuote=k/remBase;
          output=quote-remQuote;
          effective=output/input;
          impact=Math.max(0,bps(1-effective/reference));
        }
      }
      total=impact+ext;
      if(impact>this.cfg.maxPriceImpactBps) blockers.push('PRICE_IMPACT_TOO_HIGH');
      if(total>maxSlip) blockers.push('MAX_SLIPPAGE_EXCEEDED');
      if(impact>this.cfg.maxPriceImpactBps*0.75) warnings.push('PRICE_IMPACT_NEAR_LIMIT');
      if(ext>this.cfg.maxExternalSlippageBps*0.75) warnings.push('EXTERNAL_SLIPPAGE_NEAR_LIMIT');
    }

    const result:V65ExecutionResult={
      id:crypto.randomUUID(),ts:now,mint:req.mint,side:req.side,decision:blockers.length?'BLOCK':'EXECUTABLE',
      inputAmount:Number.isFinite(input)?input:0,outputAmount:output,effectivePrice:effective,referencePrice:reference,
      priceImpactBps:impact,externalSlippageBps:ext,totalSlippageBps:total,feeAmount:fee,
      remainingBaseReserve:remBase,remainingQuoteReserve:remQuote,blockers,warnings,liveExecutionEnabled:false,
    };
    db.prepare(`INSERT INTO v65_execution_simulations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      result.id,now,result.mint,result.side,result.decision,result.inputAmount,result.outputAmount,result.effectivePrice,
      result.referencePrice,result.priceImpactBps,result.externalSlippageBps,result.totalSlippageBps,result.feeAmount,
      result.remainingBaseReserve,result.remainingQuoteReserve,JSON.stringify(blockers),JSON.stringify(warnings),JSON.stringify({pool,request:req,liveExecutionEnabled:false})
    );
    return result;
  }

  recent(limit=100){return db.prepare(`SELECT * FROM v65_execution_simulations ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}
}

export const V65_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV65Safe(){if(!V65_SAFETY.shadowOnly||V65_SAFETY.signingEnabled||V65_SAFETY.privateKeyAccess||V65_SAFETY.broadcastEnabled||V65_SAFETY.liveExecutionAllowed||V65_SAFETY.autoPromotion)throw new Error('V65_SAFETY_INVARIANT_FAILED');}
