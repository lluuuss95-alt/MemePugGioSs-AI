import crypto from 'node:crypto';
import { db } from './db.js';
import { V59DecisionReevaluationEngine, type V59Context, type V59Result } from './v59-decision-reevaluation.js';
import type { V58Job } from './v58-ai-reevaluation.js';
import type { V57Change } from './v57-state-change-detector.js';
import type { V56State } from './v56-token-state-fusion.js';
import type { V48Candidate } from './v48-ultra-discovery.js';
import type { V49Score } from './v49-instant-scoring.js';
import type { V46Regime } from './v46-types.js';
import { V52AutonomousPaperLoop, type V52MarketTick, type V52Result } from './v52-autonomous-paper-loop.js';
import { V53TradeSupervisor, type V53Result } from './v53-trade-supervisor.js';

export type V60Lifecycle='IDLE'|'ANALYZING'|'DECIDED'|'OPEN_PAPER'|'MONITORING'|'CLOSED_PAPER'|'BLOCKED'|'ERROR';
export type V60Action='ANALYZE'|'ENTER_PAPER'|'HOLD'|'EXIT_PAPER'|'BLOCK'|'NO_ACTION';
export interface V60Input { job:V58Job; change:V57Change; state:V56State; candidate:V48Candidate; instant:V49Score; side?:'BUY'|'SELL'; currentPrice?:number; entryPrice?:number; regime?:V46Regime; }
export interface V60Result { id:string; ts:number; mint:string; lifecycle:V60Lifecycle; action:V60Action; decision?:V59Result; execution?:V52Result|V53Result; reason:string; liveExecutionEnabled:false; }
export interface V60Config { maxActiveTokens:number; dedupeWindowMs:number; staleAfterMs:number; }
export const defaultV60Config:V60Config=Object.freeze({maxActiveTokens:1000,dedupeWindowMs:3000,staleAfterMs:5000});

/**
 * V60 is the single per-token control loop for Paper/Shadow operation.
 * It makes the pipeline idempotent: one token has one lifecycle and duplicate
 * reevaluation events cannot create duplicate Paper entries inside the window.
 * Live signing/broadcast is structurally unavailable.
 */
export class V60AutonomousLoopCoordinator {
  private readonly lifecycle=new Map<string,V60Lifecycle>();
  private readonly lastEvent=new Map<string,number>();
  private readonly decisions=new Map<string,V59Result>();
  private readonly paper:V52AutonomousPaperLoop;
  private readonly supervisor:V53TradeSupervisor;
  private readonly decisionEngine:V59DecisionReevaluationEngine;

  constructor(private readonly cfg:V60Config=defaultV60Config, decisionEngine=new V59DecisionReevaluationEngine(), paper=new V52AutonomousPaperLoop(), supervisor=new V53TradeSupervisor(paper)){
    this.decisionEngine=decisionEngine; this.paper=paper; this.supervisor=supervisor; this.ensureSchema();
  }

  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v60_loop_events(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,action TEXT NOT NULL,lifecycle TEXT NOT NULL,reason TEXT NOT NULL,decision_id TEXT,execution_action TEXT,details_json TEXT NOT NULL)`);}

  process(input:V60Input, now=Date.now()):V60Result {
    this.validate(input,now);
    const mint=input.state.mint;
    const key=`${mint}:${input.change.id}`;
    const previous=this.lastEvent.get(key)??0;
    if(now-previous<this.cfg.dedupeWindowMs){
      return this.emit(mint,'NO_ACTION','IDLE','DUPLICATE_EVENT_WINDOW',now);
    }
    if(!this.lifecycle.has(mint) && this.lifecycle.size>=this.cfg.maxActiveTokens){
      return this.emit(mint,'BLOCK','BLOCKED','MAX_ACTIVE_TOKENS',now);
    }
    this.lastEvent.set(key,now);
    this.lifecycle.set(mint,'ANALYZING');
    try {
      const context:V59Context={candidate:input.candidate,instant:input.instant,existingPosition:this.paper.state().openPositions.some(p=>p.mint===input.state.mint),side:input.side,currentPrice:input.currentPrice,entryPrice:input.entryPrice};
      const decision=this.decisionEngine.reevaluate(input.job,input.change,input.state,context,now);
      this.decisions.set(input.state.mint,decision);
      if(decision.outcome==='BLOCK') return this.finish(mint,'BLOCK','BLOCKED',decision,'DECISION_BLOCKED',now);
      if(decision.outcome==='WAIT'||decision.outcome==='INSUFFICIENT_DATA') return this.finish(mint,'HOLD','DECIDED',decision,'WAIT_FOR_NEXT_VERIFIED_STATE',now);
      if(decision.outcome==='EXIT_PAPER'){
        const tick=this.tick(input,now,true);
        const execution=this.supervisor.tick(tick,now);
        const lifecycle=execution.action==='EXIT_PAPER'?'CLOSED_PAPER':'MONITORING';
        return this.finishWithExecution(mint,'EXIT_PAPER',lifecycle,decision,execution,execution.reason,now);
      }
      if(decision.outcome==='ENTER_PAPER'){
        const tick=this.tick(input,now,false);
        const execution=this.supervisor.tick(tick,now);
        const lifecycle=execution.action==='ENTER_PAPER'?'OPEN_PAPER':execution.action==='EXIT_PAPER'?'CLOSED_PAPER':'MONITORING';
        return this.finishWithExecution(mint,execution.action==='ENTER_PAPER'?'ENTER_PAPER':execution.action==='EXIT_PAPER'?'EXIT_PAPER':'HOLD',lifecycle,decision,execution,execution.reason,now);
      }
      return this.finish(mint,'NO_ACTION','DECIDED',decision,'NO_ACTION',now);
    } catch(err){
      this.lifecycle.set(input.state.mint,'ERROR');
      const reason=err instanceof Error?err.message:'V60_COORDINATOR_ERROR';
      return this.emit(mint,'BLOCK','ERROR',reason,now);
    }
  }

  monitorTick(tick:V52MarketTick,now=tick.timestamp):V60Result{
    const execution=this.supervisor.tick(tick,now);
    const lifecycle:V60Lifecycle=execution.action==='EXIT_PAPER'?'CLOSED_PAPER':execution.action==='ENTER_PAPER'?'OPEN_PAPER':'MONITORING';
    this.lifecycle.set(tick.mint,lifecycle);
    return this.emit(tick.mint,execution.action==='EXIT_PAPER'?'EXIT_PAPER':execution.action==='ENTER_PAPER'?'ENTER_PAPER':'HOLD',lifecycle,execution.reason,now,undefined,execution);
  }

  heartbeat(now=Date.now()):V60Result[]{
    return this.supervisor.heartbeat(now).map(execution=>{
      const lifecycle:V60Lifecycle=execution.action==='EXIT_PAPER'?'CLOSED_PAPER':'MONITORING';
      this.lifecycle.set(execution.mint,lifecycle);
      return this.emit(execution.mint,execution.action==='EXIT_PAPER'?'EXIT_PAPER':'HOLD',lifecycle,execution.reason,now,undefined,execution);
    });
  }

  status(mint?:string){
    if(mint) return {mint,lifecycle:this.lifecycle.get(mint)??'IDLE',decision:this.decisions.get(mint)??null,paper:this.paper.state().openPositions.filter(p=>p.mint===mint),liveExecutionEnabled:false};
    return {lifecycle:Object.fromEntries(this.lifecycle),decisions:this.decisions.size,openPositions:this.paper.state().openPositions.length,health:this.supervisor.health(),liveExecutionEnabled:false};
  }

  recent(limit=100){return db.prepare(`SELECT * FROM v60_loop_events ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}

  private tick(input:V60Input,now:number,exit:boolean):V52MarketTick{
    const price=input.currentPrice??input.state.price??0;
    const liquidity=input.state.liquidity??0;
    return {mint:input.state.mint,price,liquidity,timestamp:now,signalInvalidated:exit,risk:input.state.risk,};
  }

  private validate(input:V60Input,now:number){
    if(input.job.mint!==input.state.mint||input.change.mint!==input.state.mint||input.candidate.token.mint!==input.state.mint||input.instant.mint!==input.state.mint) throw new Error('V60_MINT_CONTEXT_MISMATCH');
    if(now<input.state.lastUpdatedAt) throw new Error('V60_FUTURE_STATE');
    const price=input.state.price; const liquidity=input.state.liquidity;
    if(price===undefined||!Number.isFinite(price)||price<=0) throw new Error('V60_INVALID_PRICE');
    if(liquidity===undefined||!Number.isFinite(liquidity)||liquidity<0) throw new Error('V60_INVALID_LIQUIDITY');
  }

  private finish(mint:string,action:V60Action,lifecycle:V60Lifecycle,decision:V59Result|undefined,reason:string,now:number):V60Result{
    this.lifecycle.set(mint,lifecycle); return this.emit(mint,action,lifecycle,reason,now,decision);
  }
  private finishWithExecution(mint:string,action:V60Action,lifecycle:V60Lifecycle,decision:V59Result,execution:V52Result|V53Result,reason:string,now:number):V60Result{
    this.lifecycle.set(mint,lifecycle); return this.emit(mint,action,lifecycle,reason,now,decision,execution);
  }
  private emit(mint:string,action:V60Action,lifecycle:V60Lifecycle,reason:string,now:number,decision?:V59Result,execution?:V52Result|V53Result):V60Result{
    const r:V60Result={id:crypto.randomUUID(),ts:now,mint,lifecycle,action,decision,execution,reason,liveExecutionEnabled:false};
    db.prepare(`INSERT INTO v60_loop_events(id,ts,mint,action,lifecycle,reason,decision_id,execution_action,details_json) VALUES(?,?,?,?,?,?,?,?,?)`).run(r.id,r.ts,mint,action,lifecycle,reason,decision?.id??null,execution?.action??null,JSON.stringify({liveExecutionEnabled:false}));
    return r;
  }
}

export const V60_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV60Safe(){if(!V60_SAFETY.shadowOnly||V60_SAFETY.signingEnabled||V60_SAFETY.privateKeyAccess||V60_SAFETY.broadcastEnabled||V60_SAFETY.liveExecutionAllowed||V60_SAFETY.autoPromotion)throw new Error('V60_SAFETY_INVARIANT_FAILED');}
