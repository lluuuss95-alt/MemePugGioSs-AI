import crypto from 'node:crypto';
import { db } from './db.js';
import { V52AutonomousPaperLoop, type V52MarketTick, type V52Result } from './v52-autonomous-paper-loop.js';
import { V53TradeSupervisor, type V53Tick, type V53Result } from './v53-trade-supervisor.js';
import type { V51Decision } from './v51-decision-engine.js';
import type { V76Result } from './v76-allocation-pretrade-simulation-bridge.js';

export type V77Status='COMMITTED'|'ALREADY_COMMITTED'|'BLOCKED'|'INVALID';
export interface V77Input { bridge:V76Result; decision:V51Decision; tick:V52MarketTick; now?:number; idempotencyKey?:string; }
export interface V77Result { id:string; ts:number; mint:string; status:V77Status; action:V52Result['action']; reason:string; paperResult?:V52Result; commitKey:string; supervisorState?:V53Result['supervisorState']; liveExecutionEnabled:false; }

export const V77_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV77Safe(){ if(!V77_SAFETY.shadowOnly||V77_SAFETY.signingEnabled||V77_SAFETY.privateKeyAccess||V77_SAFETY.broadcastEnabled||V77_SAFETY.liveExecutionAllowed||V77_SAFETY.autoPromotion) throw new Error('V77_SAFETY_INVARIANT_FAILED'); }

export class V77PaperExecutionCommitLayer {
  private readonly loop:V52AutonomousPaperLoop;
  private readonly supervisor:V53TradeSupervisor;
  constructor(loop?:V52AutonomousPaperLoop, supervisor?:V53TradeSupervisor){
    this.loop=loop??new V52AutonomousPaperLoop();
    this.supervisor=supervisor??new V53TradeSupervisor(this.loop);
    this.ensureSchema(); assertV77Safe();
  }
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v77_execution_commits(
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, mint TEXT NOT NULL, commit_key TEXT NOT NULL UNIQUE,
    bridge_id TEXT NOT NULL, decision_id TEXT NOT NULL, status TEXT NOT NULL, action TEXT NOT NULL,
    reason TEXT NOT NULL, paper_result_json TEXT, supervisor_state TEXT, details_json TEXT NOT NULL
  ); CREATE INDEX IF NOT EXISTS idx_v77_commits_ts ON v77_execution_commits(ts); CREATE INDEX IF NOT EXISTS idx_v77_commits_mint ON v77_execution_commits(mint);`);}

  commit(input:V77Input):V77Result{
    const now=input.now??Date.now(); const b=input.bridge; const key=input.idempotencyKey??`V76:${b.id}`;
    const existing=db.prepare(`SELECT * FROM v77_execution_commits WHERE commit_key=?`).get(key) as any;
    if(existing) return {id:existing.id,ts:existing.ts,mint:existing.mint,status:'ALREADY_COMMITTED',action:existing.action,reason:'IDEMPOTENT_REPLAY_IGNORED',paperResult:existing.paper_result_json?JSON.parse(existing.paper_result_json):undefined,commitKey:key,supervisorState:existing.supervisor_state,liveExecutionEnabled:false};
    if(b.status!=='PAPER_ENTRY_READY') return this.persist({id:crypto.randomUUID(),ts:now,mint:b.mint,status:'BLOCKED',action:'BLOCKED',reason:'V76_NOT_PAPER_ENTRY_READY',commitKey:key,liveExecutionEnabled:false},b,input);
    if(input.decision.mint!==b.mint||input.tick.mint!==b.mint) return this.persist({id:crypto.randomUUID(),ts:now,mint:b.mint,status:'INVALID',action:'BLOCKED',reason:'MINT_CONTEXT_MISMATCH',commitKey:key,liveExecutionEnabled:false},b,input);
    if(input.decision.action!=='ENTER_PAPER') return this.persist({id:crypto.randomUUID(),ts:now,mint:b.mint,status:'BLOCKED',action:'BLOCKED',reason:'DECISION_NOT_ENTER_PAPER',commitKey:key,liveExecutionEnabled:false},b,input);
    if(!Number.isFinite(input.tick.price)||input.tick.price<=0||!Number.isFinite(input.tick.liquidity)||input.tick.liquidity<0) return this.persist({id:crypto.randomUUID(),ts:now,mint:b.mint,status:'INVALID',action:'BLOCKED',reason:'INVALID_MARKET_TICK',commitKey:key,liveExecutionEnabled:false},b,input);

    this.supervisor.registerDecision(input.decision);
    const paper=this.loop.evaluate(input.decision,input.tick,now);
    const status:V77Status=paper.action==='ENTER_PAPER'?'COMMITTED':paper.action==='BLOCKED'?'BLOCKED':'INVALID';
    const result:V77Result={id:crypto.randomUUID(),ts:now,mint:b.mint,status,action:paper.action,reason:paper.reason, paperResult:paper,commitKey:key,supervisorState:this.supervisor.health().state,liveExecutionEnabled:false};
    return this.persist(result,b,input);
  }

  monitor(tick:V53Tick,now=tick.timestamp):V53Result{return this.supervisor.tick(tick,now);}
  heartbeat(now=Date.now()){return this.supervisor.heartbeat(now);}
  recent(limit=100,mint?:string){const n=Math.min(500,Math.max(1,limit));return db.prepare(`SELECT * FROM v77_execution_commits ${mint?'WHERE mint=?':''} ORDER BY ts DESC LIMIT ?`).all(...(mint?[mint,n]:[n]));}
  health(){const r=db.prepare(`SELECT COUNT(*) c,SUM(CASE WHEN status='COMMITTED' THEN 1 ELSE 0 END) committed,SUM(CASE WHEN status='BLOCKED' THEN 1 ELSE 0 END) blocked FROM v77_execution_commits`).get() as any;return {state:this.supervisor.health().state,commits:Number(r?.c||0),committed:Number(r?.committed||0),blocked:Number(r?.blocked||0),paper:this.loop.state(),liveExecutionEnabled:false};}

  private persist(r:V77Result,b:V76Result,input:V77Input){
    db.prepare(`INSERT INTO v77_execution_commits(id,ts,mint,commit_key,bridge_id,decision_id,status,action,reason,paper_result_json,supervisor_state,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(r.id,r.ts,r.mint,r.commitKey,b.id,input.decision.id,r.status,r.action,r.reason,r.paperResult?JSON.stringify(r.paperResult):null,r.supervisorState??null,JSON.stringify({liveExecutionEnabled:false,bridgeStatus:b.status}));
    return r;
  }
}
