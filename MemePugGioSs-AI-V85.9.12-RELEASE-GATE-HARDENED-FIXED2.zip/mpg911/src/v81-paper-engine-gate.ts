import crypto from 'node:crypto';
import { db } from './db.js';
import { V80AutonomousPaperRecoverySupervisor, assertV80Safe, type V80Result } from './v80-autonomous-paper-recovery-supervisor.js';

export type V81Decision = 'ALLOW' | 'BLOCK';
export type V81Reason = 'SUPERVISOR_READY'|'SUPERVISOR_MISSING'|'SUPERVISOR_BLOCKED'|'RECOVERY_REQUIRED'|'STALE_GATE'|'SAFETY_INVARIANT_FAILED';

export interface V81GateInput {
  operation?: 'ENTER'|'EXIT'|'ORDER'|'RECONCILE';
  now?: number;
  maxAgeMs?: number;
  refresh?: boolean;
}

export interface V81GateResult {
  id: string;
  ts: number;
  operation: string;
  decision: V81Decision;
  allowed: boolean;
  reason: V81Reason;
  supervisorState: string;
  paperExecutionAllowed: boolean;
  supervisorRunId?: string;
  liveExecutionEnabled: false;
}

export const V81_SAFETY = Object.freeze({
  mode: 'PAPER',
  shadowOnly: true,
  signingEnabled: false,
  privateKeyAccess: false,
  broadcastEnabled: false,
  liveExecutionAllowed: false,
  autoPromotion: false,
});

export function assertV81Safe() {
  assertV80Safe();
  if (!V81_SAFETY.shadowOnly || V81_SAFETY.signingEnabled || V81_SAFETY.privateKeyAccess || V81_SAFETY.broadcastEnabled || V81_SAFETY.liveExecutionAllowed || V81_SAFETY.autoPromotion) {
    throw new Error('V81_SAFETY_INVARIANT_FAILED');
  }
}

export class V81PaperEngineGate {
  private readonly supervisor: V80AutonomousPaperRecoverySupervisor;
  private last?: V81GateResult;

  constructor(supervisor?: V80AutonomousPaperRecoverySupervisor) {
    this.supervisor = supervisor ?? new V80AutonomousPaperRecoverySupervisor();
    this.ensureSchema();
    assertV81Safe();
  }

  private ensureSchema() {
    db.exec(`
      CREATE TABLE IF NOT EXISTS v81_paper_engine_gate_runs(
        id TEXT PRIMARY KEY,
        ts INTEGER NOT NULL,
        operation TEXT NOT NULL,
        decision TEXT NOT NULL,
        allowed INTEGER NOT NULL,
        reason TEXT NOT NULL,
        supervisor_state TEXT NOT NULL,
        paper_execution_allowed INTEGER NOT NULL,
        supervisor_run_id TEXT,
        result_json TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_v81_gate_ts ON v81_paper_engine_gate_runs(ts);
    `);
  }

  evaluate(input: V81GateInput = {}): V81GateResult {
    const now = input.now ?? Date.now();
    const operation = input.operation ?? 'ORDER';
    const maxAgeMs = Math.max(0, input.maxAgeMs ?? 5000);
    assertV81Safe();

    let supervisorResult = this.supervisor.current() as V80Result | null;
    const stale = !supervisorResult || (now - supervisorResult.ts > maxAgeMs);
    if (!supervisorResult || stale || input.refresh) {
      supervisorResult = this.supervisor.tick({ now });
    }

    let reason: V81Reason;
    let allowed = false;
    if (!supervisorResult) {
      reason = 'SUPERVISOR_MISSING';
    } else if (supervisorResult.state !== 'READY' || !supervisorResult.paperExecutionAllowed) {
      reason = supervisorResult.recovery ? 'RECOVERY_REQUIRED' : 'SUPERVISOR_BLOCKED';
    } else if (supervisorResult.ts > now || now - supervisorResult.ts > maxAgeMs) {
      reason = 'STALE_GATE';
    } else {
      reason = 'SUPERVISOR_READY';
      allowed = true;
    }

    const result: V81GateResult = {
      id: crypto.randomUUID(), ts: now, operation, decision: allowed ? 'ALLOW' : 'BLOCK', allowed,
      reason, supervisorState: supervisorResult?.state ?? 'UNKNOWN',
      paperExecutionAllowed: Boolean(supervisorResult?.paperExecutionAllowed),
      supervisorRunId: supervisorResult?.id,
      liveExecutionEnabled: false,
    };
    this.last = result;
    db.prepare(`INSERT INTO v81_paper_engine_gate_runs VALUES(?,?,?,?,?,?,?,?,?,?)`).run(
      result.id, result.ts, result.operation, result.decision, result.allowed ? 1 : 0,
      result.reason, result.supervisorState, result.paperExecutionAllowed ? 1 : 0,
      result.supervisorRunId ?? null, JSON.stringify(result)
    );
    return result;
  }

  assertAllowed(input: V81GateInput = {}) {
    const result = this.evaluate(input);
    if (!result.allowed) throw new Error(`PAPER_ENGINE_GATE_BLOCK:${result.reason}`);
    return result;
  }

  current() { return this.last ?? this.recent(1)[0] ?? null; }
  recent(limit = 50) { return db.prepare(`SELECT * FROM v81_paper_engine_gate_runs ORDER BY ts DESC LIMIT ?`).all(Math.min(200, Math.max(1, limit))); }
  status() {
    const r: any = this.current();
    return {
      state: r?.decision ?? 'UNKNOWN',
      allowed: Boolean(r?.allowed),
      reason: r?.reason ?? 'SUPERVISOR_MISSING',
      supervisorState: r?.supervisorState ?? 'UNKNOWN',
      paperExecutionAllowed: Boolean(r?.paperExecutionAllowed),
      lastTs: Number(r?.ts || 0),
      liveExecutionEnabled: false,
    };
  }
}

export const v81Gate = new V81PaperEngineGate();
