import crypto from 'node:crypto';
import { db } from './db.js';
import { V47PortfolioCoordinator, type V47Candidate, type V47Snapshot } from './v47-portfolio-coordinator.js';
import type { V46Regime } from './v46-types.js';
import type { V52Position } from './v52-autonomous-paper-loop.js';

export type V61Decision = 'APPROVE_PAPER'|'REDUCE_PAPER'|'BLOCK'|'HOLD';
export type V61State = 'NORMAL'|'WARNING'|'HALTED';

export interface V61PositionExposure {
  mint: string;
  notional: number;
  correlationGroup?: string;
  source?: 'AI_SIGNAL'|'COPY_TRADER'|'UNKNOWN';
  wallet?: string;
}

export interface V61Candidate extends V47Candidate {
  correlationGroup?: string;
  requestedPct?: number;
  priority?: number;
}

export interface V61Config {
  capital: number;
  reservePct: number;
  maxTotalExposurePct: number;
  maxPositionPct: number;
  maxTokenPct: number;
  maxCorrelationGroupPct: number;
  maxSourcePct: number;
  maxTraderPct: number;
  maxPositions: number;
  warningExposurePct: number;
  haltExposurePct: number;
  minAllocation: number;
}

export interface V61Allocation {
  id: string;
  candidateId: string;
  mint: string;
  source: string;
  wallet?: string;
  correlationGroup: string;
  decision: V61Decision;
  requestedQuote: number;
  approvedQuote: number;
  totalExposureAfter: number;
  reasons: string[];
}

export interface V61Snapshot {
  evaluatedAt: number;
  state: V61State;
  capital: number;
  reserveQuote: number;
  existingExposure: number;
  newExposure: number;
  totalExposure: number;
  exposurePct: number;
  availableQuote: number;
  openPositions: number;
  requestedCount: number;
  approvedCount: number;
  blockedCount: number;
  allocations: V61Allocation[];
  liveExecutionEnabled: false;
}

export const defaultV61Config: V61Config = Object.freeze({
  capital: 10000,
  reservePct: 20,
  maxTotalExposurePct: 35,
  maxPositionPct: 5,
  maxTokenPct: 10,
  maxCorrelationGroupPct: 12,
  maxSourcePct: 20,
  maxTraderPct: 12,
  maxPositions: 10,
  warningExposurePct: 30,
  haltExposurePct: 35,
  minAllocation: 25,
});

const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
const finite=(n:unknown,d=0)=>Number.isFinite(Number(n))?Number(n):d;

/**
 * V61 is the portfolio-level gate in front of autonomous Paper execution.
 * It evaluates all new opportunities against capital already committed,
 * correlation/source concentration and position-count limits. It does not
 * sign, broadcast, or enable live execution.
 */
export class V61PortfolioExecutionCoordinator {
  constructor(private readonly cfg:V61Config=defaultV61Config, private readonly base=new V47PortfolioCoordinator()){this.ensureSchema();}

  private ensureSchema(){
    db.exec(`CREATE TABLE IF NOT EXISTS v61_portfolio_decisions(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, candidate_id TEXT NOT NULL,
      mint TEXT NOT NULL, source TEXT NOT NULL, wallet TEXT, correlation_group TEXT NOT NULL,
      decision TEXT NOT NULL, requested_quote REAL NOT NULL, approved_quote REAL NOT NULL,
      total_exposure_after REAL NOT NULL, reasons_json TEXT NOT NULL
    )`);
    db.exec(`CREATE TABLE IF NOT EXISTS v61_portfolio_snapshots(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, state TEXT NOT NULL, capital REAL NOT NULL,
      reserve_quote REAL NOT NULL, existing_exposure REAL NOT NULL, new_exposure REAL NOT NULL,
      total_exposure REAL NOT NULL, exposure_pct REAL NOT NULL, open_positions INTEGER NOT NULL,
      requested_count INTEGER NOT NULL, approved_count INTEGER NOT NULL, blocked_count INTEGER NOT NULL,
      details_json TEXT NOT NULL
    )`);
  }

  coordinate(
    candidates: V61Candidate[],
    positions: V61PositionExposure[] = [],
    regime: V46Regime = 'UNKNOWN',
    now = Date.now(),
  ): V61Snapshot {
    const capital=this.cfg.capital;
    const reserve=capital*clamp(this.cfg.reservePct,0,100)/100;
    const maxExposure=capital*clamp(this.cfg.maxTotalExposurePct,0,100)/100;
    const maxPosition=capital*clamp(this.cfg.maxPositionPct,0,100)/100;
    const maxToken=capital*clamp(this.cfg.maxTokenPct,0,100)/100;
    const maxGroup=capital*clamp(this.cfg.maxCorrelationGroupPct,0,100)/100;
    const maxSource=capital*clamp(this.cfg.maxSourcePct,0,100)/100;
    const maxTrader=capital*clamp(this.cfg.maxTraderPct,0,100)/100;

    const existingExposure=Math.max(0,positions.reduce((s,p)=>s+Math.max(0,finite(p.notional)),0));
    const groupUsed=new Map<string,number>();
    const tokenUsed=new Map<string,number>();
    const sourceUsed=new Map<string,number>();
    const traderUsed=new Map<string,number>();
    for(const p of positions){
      const amount=Math.max(0,finite(p.notional));
      const group=p.correlationGroup||p.mint;
      groupUsed.set(group,(groupUsed.get(group)||0)+amount);
      tokenUsed.set(p.mint,(tokenUsed.get(p.mint)||0)+amount);
      sourceUsed.set(p.source||'UNKNOWN',(sourceUsed.get(p.source||'UNKNOWN')||0)+amount);
      if(p.wallet) traderUsed.set(p.wallet,(traderUsed.get(p.wallet)||0)+amount);
    }

    // V47 remains the deterministic upstream allocator. V61 applies current
    // portfolio state on top of that baseline so old exposure is not ignored.
    const baseline:V47Snapshot=this.base.coordinate(candidates,regime,now);
    const ordered=[...baseline.allocations].sort((a,b)=>{
      const ca=candidates.find(c=>c.id===a.candidateId); const cb=candidates.find(c=>c.id===b.candidateId);
      return finite(cb?.priority,cb?.score||0)-finite(ca?.priority,ca?.score||0);
    });

    let newExposure=0;
    const allocations:V61Allocation[]=[];
    for(const a of ordered){
      const c=candidates.find(x=>x.id===a.candidateId);
      const reasons=[...a.reasons];
      const group=c?.correlationGroup||a.correlationGroup||a.mint;
      const source=a.source||c?.source||'UNKNOWN';
      const wallet=c?.wallet;
      const requested=Math.min(maxPosition,Math.max(0,finite(a.allocationQuote)));

      if(!c) reasons.push('CANDIDATE_NOT_FOUND');
      if(regime==='NO_TRADE'||regime==='STRESSED'||regime==='UNKNOWN') reasons.push('REGIME_BLOCKS_PORTFOLIO');
      if(positions.some(p=>p.mint===a.mint)) reasons.push('TOKEN_ALREADY_OPEN');
      if(positions.length + allocations.filter(x=>x.approvedQuote>0).length >= this.cfg.maxPositions) reasons.push('MAX_POSITIONS_REACHED');

      const tokenAfter=(tokenUsed.get(a.mint)||0)+requested;
      const groupAfter=(groupUsed.get(group)||0)+requested;
      const sourceAfter=(sourceUsed.get(source)||0)+requested;
      const traderAfter=wallet?(traderUsed.get(wallet)||0)+requested:requested;
      if(tokenAfter>maxToken) reasons.push('TOKEN_CONCENTRATION_LIMIT');
      if(groupAfter>maxGroup) reasons.push('CORRELATION_GROUP_LIMIT');
      if(sourceAfter>maxSource) reasons.push('SOURCE_CONCENTRATION_LIMIT');
      if(wallet && traderAfter>maxTrader) reasons.push('TRADER_CONCENTRATION_LIMIT');

      const remaining=Math.max(0,maxExposure-existingExposure-newExposure);
      let approved=Math.min(requested,remaining,Math.max(0,capital-reserve-existingExposure-newExposure));
      if(approved<this.cfg.minAllocation) reasons.push('ALLOCATION_BELOW_MINIMUM');
      if(existingExposure>=maxExposure) reasons.push('PORTFOLIO_EXPOSURE_LIMIT');
      if(reasons.length) approved=0;

      const decision:V61Decision=reasons.length?'BLOCK':approved<requested?'REDUCE_PAPER':'APPROVE_PAPER';
      if(decision!=='BLOCK'){
        newExposure+=approved;
        tokenUsed.set(a.mint,(tokenUsed.get(a.mint)||0)+approved);
        groupUsed.set(group,(groupUsed.get(group)||0)+approved);
        sourceUsed.set(source,(sourceUsed.get(source)||0)+approved);
        if(wallet) traderUsed.set(wallet,(traderUsed.get(wallet)||0)+approved);
      }
      const totalAfter=existingExposure+newExposure;
      const row:V61Allocation={id:crypto.randomUUID(),candidateId:a.candidateId,mint:a.mint,source,wallet,correlationGroup:group,decision,requestedQuote:requested,approvedQuote:approved,totalExposureAfter:totalAfter,reasons};
      allocations.push(row);
      db.prepare(`INSERT INTO v61_portfolio_decisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(row.id,now,row.candidateId,row.mint,row.source,row.wallet||null,row.correlationGroup,row.decision,row.requestedQuote,row.approvedQuote,row.totalExposureAfter,JSON.stringify(row.reasons));
    }

    const totalExposure=existingExposure+newExposure;
    const exposurePct=capital?totalExposure/capital*100:100;
    const state:V61State=exposurePct>=this.cfg.haltExposurePct?'HALTED':exposurePct>=this.cfg.warningExposurePct?'WARNING':'NORMAL';
    const snapshot:V61Snapshot={
      evaluatedAt:now,state,capital,reserveQuote:reserve,existingExposure,newExposure,totalExposure,exposurePct,
      availableQuote:Math.max(0,capital-reserve-totalExposure),openPositions:positions.length+allocations.filter(a=>a.approvedQuote>0).length,
      requestedCount:candidates.length,approvedCount:allocations.filter(a=>a.approvedQuote>0).length,
      blockedCount:allocations.filter(a=>a.decision==='BLOCK').length,allocations,liveExecutionEnabled:false,
    };
    db.prepare(`INSERT INTO v61_portfolio_snapshots VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      crypto.randomUUID(),now,state,capital,reserve,existingExposure,newExposure,totalExposure,exposurePct,snapshot.openPositions,
      candidates.length,snapshot.approvedCount,snapshot.blockedCount,JSON.stringify(snapshot),
    );
    return snapshot;
  }

  recent(limit=100){
    return db.prepare(`SELECT * FROM v61_portfolio_snapshots ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));
  }
}

export const V61_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV61Safe(){
  if(!V61_SAFETY.shadowOnly||V61_SAFETY.signingEnabled||V61_SAFETY.privateKeyAccess||V61_SAFETY.broadcastEnabled||V61_SAFETY.liveExecutionAllowed||V61_SAFETY.autoPromotion) throw new Error('V61_SAFETY_INVARIANT_FAILED');
}
