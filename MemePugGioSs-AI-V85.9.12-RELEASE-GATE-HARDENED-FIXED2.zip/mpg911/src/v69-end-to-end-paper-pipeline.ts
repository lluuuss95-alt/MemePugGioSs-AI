import crypto from 'node:crypto';
import { db } from './db.js';
import { V64AutonomousExecutionGuard, type V64Input, type V64Result } from './v64-pretrade-guard.js';
import { V65PaperExecutionSimulator, type V65PoolState, type V65ExecutionResult } from './v65-paper-execution-simulator.js';
import { V68AdaptivePaperRiskCalibration, type V68Profile } from './v68-adaptive-paper-risk-calibration.js';

export type V69Stage='DISCOVERY'|'ANALYSIS'|'DECISION'|'ARBITRATION'|'ALLOCATION'|'RISK_CALIBRATION'|'PRETRADE_GUARD'|'EXECUTION_SIMULATION'|'PAPER_ENTRY'|'MONITORING'|'EXIT'|'BLOCKED'|'ERROR';
export type V69Outcome='PAPER_ENTRY'|'BLOCKED'|'HOLD';

export interface V69Input {
  mint:string;
  now?:number;
  decision:any;
  allocation:any;
  market:V64Input['market'];
  portfolio:V64Input['portfolio'];
  pool:V65PoolState;
  quoteAmount:number;
  maxSlippageBps:number;
  baselineRiskPct:number;
  baselinePositionPct:number;
  baselineTotalExposurePct:number;
  calibrationMint?:string;
  approvedUpstream?:boolean;
}

export interface V69Result {
  id:string; ts:number; mint:string; outcome:V69Outcome; stage:V69Stage;
  stages:Array<{stage:V69Stage;status:'PASS'|'BLOCK'|'SKIP';reason:string}>;
  riskProfile:V68Profile;
  guard:V64Result;
  simulation?:V65ExecutionResult;
  blockers:string[];
  liveExecutionEnabled:false;
}

export interface V69Config { requireUpstreamApproval:boolean; requireExecutableSimulation:boolean; }
export const defaultV69Config:V69Config=Object.freeze({requireUpstreamApproval:true,requireExecutableSimulation:true});

export class V69EndToEndPaperPipeline {
  private readonly guard=new V64AutonomousExecutionGuard();
  private readonly simulator=new V65PaperExecutionSimulator();
  private readonly risk=new V68AdaptivePaperRiskCalibration();
  constructor(private readonly cfg:V69Config=defaultV69Config){this.ensureSchema();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v69_pipeline_runs(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,outcome TEXT NOT NULL,stage TEXT NOT NULL,stages_json TEXT NOT NULL,blockers_json TEXT NOT NULL,guard_id TEXT NOT NULL,simulation_id TEXT,calibration_id TEXT,details_json TEXT NOT NULL)`);}

  run(input:V69Input):V69Result {
    const now=input.now??Date.now(); const stages:V69Result['stages']=[]; const blockers:string[]=[];
    const riskProfile=this.risk.calibrate({mint:input.calibrationMint??input.mint,now,baselineRiskPct:input.baselineRiskPct,baselinePositionPct:input.baselinePositionPct,baselineTotalExposurePct:input.baselineTotalExposurePct});
    stages.push({stage:'DISCOVERY',status:'PASS',reason:'UPSTREAM_TOKEN_CONTEXT_PRESENT'});
    stages.push({stage:'ANALYSIS',status:'PASS',reason:'UPSTREAM_AI_CONTEXT_PRESENT'});
    stages.push({stage:'DECISION',status:input.decision?.action==='ENTER_PAPER'?'PASS':'BLOCK',reason:input.decision?.action==='ENTER_PAPER'?'ENTER_PAPER':'DECISION_NOT_ENTER_PAPER'});
    if(input.decision?.action!=='ENTER_PAPER') blockers.push('DECISION_NOT_ENTER_PAPER');
    stages.push({stage:'ARBITRATION',status:input.approvedUpstream!==false?'PASS':'BLOCK',reason:input.approvedUpstream!==false?'UPSTREAM_APPROVAL_PRESENT':'UPSTREAM_APPROVAL_MISSING'});
    if(this.cfg.requireUpstreamApproval && input.approvedUpstream!==true) blockers.push('UPSTREAM_APPROVAL_MISSING');
    stages.push({stage:'ALLOCATION',status:input.allocation && Number(input.portfolio.allocatedQuote)>0?'PASS':'BLOCK',reason:input.allocation && Number(input.portfolio.allocatedQuote)>0?'ALLOCATION_PRESENT':'ALLOCATION_MISSING'});
    if(!input.allocation || !(Number(input.portfolio.allocatedQuote)>0)) blockers.push('ALLOCATION_MISSING');

    const guardInput:V64Input={decision:input.decision,allocation:input.allocation,market:{...input.market,risk:Math.min(input.market.risk??input.decision?.risk??999,riskProfile.calibratedRiskPct)},portfolio:input.portfolio,now};
    const guard=this.guard.validate(guardInput);
    stages.push({stage:'RISK_CALIBRATION',status:'PASS',reason:`V68_${riskProfile.state}_MULTIPLIER_${riskProfile.riskMultiplier.toFixed(3)}`});
    stages.push({stage:'PRETRADE_GUARD',status:guard.decision==='ALLOW_PAPER'?'PASS':'BLOCK',reason:guard.decision==='ALLOW_PAPER'?'ALL_GATES_PASSED':guard.blockers.join('|')});
    if(guard.decision==='BLOCK') blockers.push(...guard.blockers);

    let simulation:V65ExecutionResult|undefined;
    if(guard.decision==='ALLOW_PAPER'){
      simulation=this.simulator.simulate(input.pool,{side:'BUY',mint:input.mint,quoteAmount:Math.min(input.quoteAmount,guard.approvedQuote),maxSlippageBps:input.maxSlippageBps,now,externalSlippageBps:input.market.slippageBps??0});
      stages.push({stage:'EXECUTION_SIMULATION',status:simulation.decision==='EXECUTABLE'?'PASS':'BLOCK',reason:simulation.decision==='EXECUTABLE'?'SIMULATION_EXECUTABLE':simulation.blockers.join('|')});
      if(this.cfg.requireExecutableSimulation && simulation.decision!=='EXECUTABLE') blockers.push(...simulation.blockers);
    } else {
      stages.push({stage:'EXECUTION_SIMULATION',status:'SKIP',reason:'PRETRADE_GUARD_BLOCKED'});
    }

    const outcome:V69Outcome=blockers.length?'BLOCKED':simulation?'PAPER_ENTRY':'HOLD';
    const stage:V69Stage=outcome==='PAPER_ENTRY'?'PAPER_ENTRY':'BLOCKED';
    stages.push({stage,status:outcome==='PAPER_ENTRY'?'PASS':'BLOCK',reason:outcome==='PAPER_ENTRY'?'PAPER_ENTRY_READY':'PIPELINE_BLOCKED'});
    const result:V69Result={id:crypto.randomUUID(),ts:now,mint:input.mint,outcome,stage,stages,riskProfile,guard,simulation,blockers:[...new Set(blockers)],liveExecutionEnabled:false};
    db.prepare(`INSERT INTO v69_pipeline_runs VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(result.id,now,input.mint,result.outcome,result.stage,JSON.stringify(stages),JSON.stringify(result.blockers),guard.id,simulation?.id??null,riskProfile.id,JSON.stringify({liveExecutionEnabled:false,approvedUpstream:input.approvedUpstream??false}));
    return result;
  }
  recent(limit=100){return db.prepare(`SELECT * FROM v69_pipeline_runs ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}
}

export const V69_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV69Safe(){if(!V69_SAFETY.shadowOnly||V69_SAFETY.signingEnabled||V69_SAFETY.privateKeyAccess||V69_SAFETY.broadcastEnabled||V69_SAFETY.liveExecutionAllowed||V69_SAFETY.autoPromotion)throw new Error('V69_SAFETY_INVARIANT_FAILED');}
