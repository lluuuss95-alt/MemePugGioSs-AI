
import { DatasetRow, StrategyParams } from "./v15-types.js";
import { WalkForwardWindow, WalkForwardResult } from "./v17-types.js";
import { evaluateSplit } from "./v15-evaluator.js";
import { detectRegime } from "./v17-regime.js";

export function makeWindows(rows:DatasetRow[],trainSize=60,validationSize=20,testSize=20,step=20):WalkForwardWindow[]{
  const out:WalkForwardWindow[]=[];
  let id=0;
  for(let i=0;i+trainSize+validationSize+testSize<=rows.length;i+=step){
    out.push({id:id++,trainStart:i,trainEnd:i+trainSize,validationStart:i+trainSize,
      validationEnd:i+trainSize+validationSize,testStart:i+trainSize+validationSize,
      testEnd:i+trainSize+validationSize+testSize,trainSamples:trainSize,
      validationSamples:validationSize,testSamples:testSize});
  }
  return out;
}
export function runWalkForward(rows:DatasetRow[],space:Record<keyof StrategyParams,number[]>,maxCandidates=100){
  const windows=makeWindows(rows);
  return windows.map(w=>{
    const train=rows.slice(w.trainStart,w.trainEnd), val=rows.slice(w.validationStart,w.validationEnd), test=rows.slice(w.testStart,w.testEnd);
    let best:any=undefined;
    for(const a of space.buySellRatio)for(const b of space.smartMoneyShare)for(const c of space.riskMax)
      for(const d of space.liquidityDeltaMin)for(const e of space.holderDeltaMin){
        const p={buySellRatio:a,smartMoneyShare:b,riskMax:c,liquidityDeltaMin:d,holderDeltaMin:e};
        const x=evaluateSplit(p,train,val);
        if(x.eligible&&(!best||x.adjustedScore>best.adjustedScore))best=x;
      }
    const selected=best?.params;
    const filter=(xs:DatasetRow[])=>selected?xs.filter(r=>r.buySellRatio>=selected.buySellRatio&&r.smartMoneyShare>=selected.smartMoneyShare&&r.risk<=selected.riskMax&&r.liquidityDelta>=selected.liquidityDeltaMin&&r.holderDelta>=selected.holderDeltaMin):[];
    const tv=filter(val), tt=filter(test);
    const vm=tv.length?tv.reduce((s,r)=>s+r.futureReturnPct,0)/tv.length:0;
    const tm=tt.length?tt.reduce((s,r)=>s+r.futureReturnPct,0)/tt.length:0;
    return {window:w,selectedParams:selected,validationMean:vm,testMean:tm,
      testWinRate:tt.length?tt.filter(r=>r.futureReturnPct>0).length/tt.length*100:0,
      degradation:Math.max(0,vm-tm),regime:detectRegime(test).regime} as WalkForwardResult;
  });
}
