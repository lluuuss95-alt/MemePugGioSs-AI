import { AdapterRegistry, NormalizedDexEvent } from "./protocols.js";
import { aggregateFlow } from "./flow.js";
import { classifyLifecycle } from "./lifecycle.js";
import { scoreV7 } from "./v7-risk.js";

export interface V7Analysis {
  mint:string;
  events:NormalizedDexEvent[];
  flow:ReturnType<typeof aggregateFlow>;
  lifecycle:ReturnType<typeof classifyLifecycle>;
  risk:ReturnType<typeof scoreV7>;
  tradable:boolean;
}

export function analyzeV7(mint:string, txs:any[], registry:AdapterRegistry): V7Analysis {
  const events = txs.flatMap(tx => registry.decode(tx,mint));
  const flow = aggregateFlow(events);
  const lifecycle = classifyLifecycle(events);
  const risk = scoreV7(flow,lifecycle);
  return { mint, events, flow, lifecycle, risk, tradable:!risk.blocked && risk.riskScore < 60 };
}
