import crypto from 'node:crypto';
import { db } from './db.js';

export type V67CalibrationState='INSUFFICIENT_DATA'|'STABLE'|'ADAPTIVE'|'DEGRADED';
export type V67Dimension='SLIPPAGE_BPS'|'PRICE_IMPACT_BPS'|'LATENCY_MS';

export interface V67Observation { mint:string; observedAt:number; liquidity?:number; simulatedSlippageBps?:number; simulatedPriceImpactBps?:number; paperDeviationBps?:number|null; paperLatencyMs?:number|null; quality?:string; }
export interface V67Config {
  minSamples:number;
  windowSamples:number;
  maxAdjustmentPct:number;
  maxAbsoluteBpsAdjustment:number;
  maxLatencyAdjustmentMs:number;
  warningDeviationBps:number;
  warningLatencyMs:number;
  minLiquidity:number;
}
export interface V67Calibration {
  id:string; ts:number; mint:string; state:V67CalibrationState; samples:number;
  baselineSlippageBps:number; calibratedSlippageBps:number;
  baselinePriceImpactBps:number; calibratedPriceImpactBps:number;
  baselineLatencyMs:number; calibratedLatencyMs:number;
  confidence:number; reasons:string[]; safety:{liveExecutionEnabled:false};
}

export const defaultV67Config:V67Config=Object.freeze({minSamples:10,windowSamples:100,maxAdjustmentPct:0.20,maxAbsoluteBpsAdjustment:100,maxLatencyAdjustmentMs:1000,warningDeviationBps:150,warningLatencyMs:1500,minLiquidity:1000});
const n=(v:unknown)=>Number.isFinite(Number(v))?Number(v):NaN;
const clamp=(x:number,a:number,b:number)=>Math.max(a,Math.min(b,x));
const median=(xs:number[])=>{const a=xs.filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return 0;const m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2;};

export class V67ExecutionCalibrationEngine {
  constructor(private readonly cfg:V67Config=defaultV67Config){this.ensureSchema();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v67_execution_calibrations(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,state TEXT NOT NULL,samples INTEGER NOT NULL,baseline_slippage_bps REAL NOT NULL,calibrated_slippage_bps REAL NOT NULL,baseline_price_impact_bps REAL NOT NULL,calibrated_price_impact_bps REAL NOT NULL,baseline_latency_ms REAL NOT NULL,calibrated_latency_ms REAL NOT NULL,confidence REAL NOT NULL,reasons_json TEXT NOT NULL,details_json TEXT NOT NULL)`);}
  calibrate(mint:string, baseline:{slippageBps:number;priceImpactBps:number;latencyMs:number}, now=Date.now()):V67Calibration {
    const rows=db.prepare(`SELECT * FROM v66_execution_quality WHERE mint=? ORDER BY ts DESC LIMIT ?`).all(mint,this.cfg.windowSamples) as any[];
    const slippage=rows.map(r=>n(r.simulated_slippage_bps)).filter(Number.isFinite);
    const impact=rows.map(r=>n(r.simulated_price_impact_bps)).filter(Number.isFinite);
    const latency=rows.map(r=>n(r.paper_latency_ms)).filter(Number.isFinite);
    const dev=rows.map(r=>n(r.paper_deviation_bps)).filter(Number.isFinite);
    const samples=rows.length; const reasons:string[]=[];
    if(samples<this.cfg.minSamples){reasons.push('INSUFFICIENT_SAMPLES');return this.persist({id:crypto.randomUUID(),ts:now,mint,state:'INSUFFICIENT_DATA',samples,baselineSlippageBps:baseline.slippageBps,calibratedSlippageBps:baseline.slippageBps,baselinePriceImpactBps:baseline.priceImpactBps,calibratedPriceImpactBps:baseline.priceImpactBps,baselineLatencyMs:baseline.latencyMs,calibratedLatencyMs:baseline.latencyMs,confidence:clamp(samples/this.cfg.minSamples,0,1)*0.5,reasons,safety:{liveExecutionEnabled:false}});}
    const observedS=median(slippage), observedI=median(impact), observedL=median(latency);
    const adjust=(base:number,obs:number,absCap:number)=>{if(!Number.isFinite(obs)||obs<0)return base;const boundedRel=clamp(obs/base-1,-this.cfg.maxAdjustmentPct,this.cfg.maxAdjustmentPct);return Math.max(0,base*(1+boundedRel),Math.max(0,obs-Math.abs(absCap)));};
    const cs=adjust(baseline.slippageBps,observedS,this.cfg.maxAbsoluteBpsAdjustment);
    const ci=adjust(baseline.priceImpactBps,observedI,this.cfg.maxAbsoluteBpsAdjustment);
    const cl=clamp(baseline.latencyMs*(Number.isFinite(observedL)&&baseline.latencyMs>0?1+clamp(observedL/baseline.latencyMs-1,-this.cfg.maxAdjustmentPct,this.cfg.maxAdjustmentPct):1),baseline.latencyMs-this.cfg.maxLatencyAdjustmentMs,baseline.latencyMs+this.cfg.maxLatencyAdjustmentMs);
    if(dev.length && median(dev)>this.cfg.warningDeviationBps) reasons.push('HIGH_EXECUTION_DEVIATION');
    if(latency.length && median(latency)>this.cfg.warningLatencyMs) reasons.push('HIGH_LATENCY');
    const qualityBlocked=rows.filter(r=>r.quality==='BLOCKED').length;
    if(qualityBlocked>samples*0.2) reasons.push('HIGH_BLOCK_RATE');
    const confidence=clamp(Math.min(1,samples/50)*(1-Math.min(0.8,qualityBlocked/Math.max(1,samples))),0,1);
    const state:V67CalibrationState=reasons.includes('HIGH_BLOCK_RATE')||confidence<0.4?'DEGRADED':Math.abs(cs-baseline.slippageBps)>0.001||Math.abs(ci-baseline.priceImpactBps)>0.001||Math.abs(cl-baseline.latencyMs)>0.001?'ADAPTIVE':'STABLE';
    if(!reasons.length) reasons.push('CALIBRATED_FROM_ROLLING_V66_OBSERVATIONS');
    return this.persist({id:crypto.randomUUID(),ts:now,mint,state,samples,baselineSlippageBps:baseline.slippageBps,calibratedSlippageBps:cs,baselinePriceImpactBps:baseline.priceImpactBps,calibratedPriceImpactBps:ci,baselineLatencyMs:baseline.latencyMs,calibratedLatencyMs:cl,confidence,reasons,safety:{liveExecutionEnabled:false}});
  }
  private persist(r:V67Calibration){db.prepare(`INSERT INTO v67_execution_calibrations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(r.id,r.ts,r.mint,r.state,r.samples,r.baselineSlippageBps,r.calibratedSlippageBps,r.baselinePriceImpactBps,r.calibratedPriceImpactBps,r.baselineLatencyMs,r.calibratedLatencyMs,r.confidence,JSON.stringify(r.reasons),JSON.stringify(r));return r;}
  latest(mint?:string){return mint?db.prepare(`SELECT * FROM v67_execution_calibrations WHERE mint=? ORDER BY ts DESC LIMIT 1`).get(mint):db.prepare(`SELECT * FROM v67_execution_calibrations ORDER BY ts DESC LIMIT 1`).get();}
}
export const V67_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV67Safe(){if(!V67_SAFETY.shadowOnly||V67_SAFETY.signingEnabled||V67_SAFETY.privateKeyAccess||V67_SAFETY.broadcastEnabled||V67_SAFETY.liveExecutionAllowed||V67_SAFETY.autoPromotion)throw new Error('V67_SAFETY_INVARIANT_FAILED');}
