import {db,audit} from "./db.js"; import {config} from "./config.js"; import {checkRisk} from "./risk.js"; import {v81Gate} from "./v81-paper-engine-gate.js";
export function paperOrder(input:any){
  if(!input||!['BUY','SELL'].includes(input.side))throw new Error('INVALID_SIDE');
  if(typeof input.mint!=='string'||!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(input.mint))throw new Error('INVALID_MINT');
  if(typeof input.orderId!=='string'||input.orderId.length<8)throw new Error('INVALID_ORDER_ID');
  const quantity=Number(input.quantity);
  if(!Number.isFinite(quantity)||quantity<=0)throw new Error('INVALID_ORDER');
  const market:any=db.prepare(`SELECT price,liquidity,observed_at FROM observations WHERE mint=? AND quality='OK' AND price>0 AND liquidity>0 ORDER BY observed_at DESC,id DESC LIMIT 1`).get(input.mint);
  if(!market)throw new Error('VERIFIED_MARKET_OBSERVATION_REQUIRED');
  const price0=Number(market.price),liquidity=Number(market.liquidity),observedMs=Date.parse(String(market.observed_at||''));
  if(!Number.isFinite(price0)||price0<=0)throw new Error('VERIFIED_PRICE_REQUIRED');
  if(!Number.isFinite(liquidity)||liquidity<=0)throw new Error('VERIFIED_LIQUIDITY_REQUIRED');
  if(!Number.isFinite(observedMs)||observedMs>Date.now()+5000||Date.now()-observedMs>config.staleMs)throw new Error('STALE_OR_INVALID_MARKET_DATA');
  v81Gate.assertAllowed({operation: input.side === 'SELL' ? 'EXIT' : 'ENTER'});
  const risk=checkRisk({mint:input.mint,side:input.side,quantity,price:price0,liquidity,observedAt:new Date(observedMs).toISOString()});
  if(!risk.allowed)throw new Error(`RISK_BLOCK:${risk.reasons.join(',')}`);
  const slip=(config.slippageBps/10000)*(input.side==='BUY'?1:-1); const price=price0*(1+slip);
  if(input.limitPrice!==undefined&&((input.side==='BUY'&&price>input.limitPrice)||(input.side==='SELL'&&price<input.limitPrice)))throw new Error('LIMIT_NOT_FILLED');
  const fee=price*quantity*(config.feeBps/10000); const now=new Date().toISOString();
  const tx=db.transaction(()=>{let a:any=db.prepare('SELECT * FROM account WHERE id=1').get(); const notional=price*quantity+fee; if(input.side==='BUY'&&a.cash<notional)throw new Error('INSUFFICIENT_PAPER_CASH'); const token:any=db.prepare('SELECT symbol,name FROM tokens WHERE mint=?').get(input.mint); let p:any=db.prepare('SELECT * FROM positions WHERE mint=?').get(input.mint)??{mint:input.mint,symbol:token?.symbol||token?.name||input.mint.slice(0,8),quantity:0,avg_entry:0,realized_pnl:0}; if(input.side==='BUY'){const q=p.quantity+quantity;p.avg_entry=(p.quantity*p.avg_entry+quantity*price)/q;p.quantity=q;a.cash-=notional;}else{if(quantity>p.quantity)throw new Error('SELL_EXCEEDS_POSITION');p.realized_pnl+=(price-p.avg_entry)*quantity-fee;p.quantity-=quantity;a.cash+=price*quantity-fee;} db.prepare('INSERT INTO orders(order_id,mint,side,quantity,limit_price,status,created_at) VALUES(?,?,?,?,?,?,?)').run(input.orderId,input.mint,input.side,quantity,input.limitPrice??null,'FILLED',now); db.prepare('INSERT INTO fills(order_id,mint,side,quantity,price,fee,filled_at) VALUES(?,?,?,?,?,?,?)').run(input.orderId,input.mint,input.side,quantity,price,fee,now); db.prepare('INSERT OR REPLACE INTO positions(mint,symbol,quantity,avg_entry,realized_pnl,updated_at) VALUES(?,?,?,?,?,?)').run(p.mint,p.symbol,p.quantity,p.avg_entry,p.realized_pnl,now); db.prepare('UPDATE account SET cash=?,updated_at=? WHERE id=1').run(a.cash,now); audit(`fill:${input.orderId}`,'PAPER_FILL',{input,price,fee,risk});}); tx(); return {orderId:input.orderId,mint:input.mint,side:input.side,quantity,price,fee,filledAt:now};
}
export function positions(){
  const rows=db.prepare(`SELECT p.mint,p.symbol,p.quantity,p.avg_entry AS averageEntry,p.realized_pnl AS realizedPnl,
    (SELECT o.price FROM observations o WHERE o.mint=p.mint AND o.quality='OK' AND o.price>0 ORDER BY o.observed_at DESC,o.id DESC LIMIT 1) AS marketPrice,
    (SELECT o.observed_at FROM observations o WHERE o.mint=p.mint AND o.quality='OK' AND o.price>0 ORDER BY o.observed_at DESC,o.id DESC LIMIT 1) AS priceObservedAt
    FROM positions p WHERE p.quantity>0`).all() as Array<{mint:string;symbol:string;quantity:number;averageEntry:number;realizedPnl:number;marketPrice?:number|null;priceObservedAt?:string|null}>;
  return rows.map(p=>{const mark=Number(p.marketPrice)>0?Number(p.marketPrice):Number(p.averageEntry);return {...p,markPrice:mark,marketValue:Number(p.quantity)*mark,unrealizedPnl:(mark-Number(p.averageEntry))*Number(p.quantity),markPriceSource:Number(p.marketPrice)>0?'OBSERVATION':'ENTRY_FALLBACK'}});
}
export function orders(){return db.prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT 200").all()}
export function account(){
  const a=db.prepare("SELECT * FROM account WHERE id=1").get() as {id:number;cash:number;equity:number;updated_at:string};
  if(!a)return a;
  const assets=positions().reduce((sum,p)=>sum+Number((p as any).marketValue||0),0);
  return {...a,equity:Number(a.cash)+assets};
}
