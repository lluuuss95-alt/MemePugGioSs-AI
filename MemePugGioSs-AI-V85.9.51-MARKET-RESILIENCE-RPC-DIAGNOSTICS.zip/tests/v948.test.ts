import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/market-enrichment.ts', import.meta.url), 'utf8');
assert.match(source, /const INTERVAL_MS = 30_000/, 'market enrichment must slow down to 30 seconds');
assert.match(source, /const FALLBACK_TOKENS_PER_CYCLE = 2/, 'individual fallback probes must be bounded');
assert.match(source, /DEXSCREENER_RATE_LIMIT_COOLDOWN/, 'HTTP 429 must activate a cooldown');
assert.match(source, /response\.headers\.get\('retry-after'\)/, 'batch request should honor Retry-After');
assert.match(source, /single\.headers\.get\('retry-after'\)/, 'individual request should honor Retry-After');
console.log('V948 RATE LIMIT BACKOFF REGRESSION PASS');
