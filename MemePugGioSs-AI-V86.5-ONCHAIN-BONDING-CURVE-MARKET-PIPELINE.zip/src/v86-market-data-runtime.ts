import { config } from './config.js';
import { enqueue } from './ingestion.js';
import { V25LiveStateEngine } from './v25-state-engine.js';
import { JsonRpcHttpClient } from './v25-rpc.js';
import { deriveSolQuotedMarket } from './v86-market-math.js';

const WSOL_MINT = 'So11111111111111111111111111111111111111112';
const SOL_DECIMALS = 9;
const PRICE_TIMEOUT_MS = 3_500;
const PRICE_CACHE_MS = 20_000;
const PUBLISH_INTERVAL_MS = 3_000;

type PumpEvent = {
  txType?: string;
  mint?: string;
  bondingCurveKey?: string;
  poolAddress?: string;
  pool?: string;
  quoteMint?: string;
};

let stateEngine: V25LiveStateEngine | undefined;
let publishTimer: ReturnType<typeof setInterval> | undefined;
let priceBusy = false;
let lastSolUsdAt = 0;
let lastSolUsd = 0;
let lastSolUsdProvider = '';
let lastSolUsdError = '';
let lastMarketError = '';
let stateUpdates = 0;
let lastPublishedAt: string | null = null;
const lastPublishedStateAt = new Map<string, number>();
const trackedCurves = new Map<string, string>();
const trackedPools = new Map<string, string>();

function validPrice(value: unknown): number | undefined {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 && n < 100_000 ? n : undefined;
}

async function readJson(url: string): Promise<any> {
  const response = await fetch(url, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(PRICE_TIMEOUT_MS) });
  if (!response.ok) throw new Error(`SOL_USD_HTTP_${response.status}`);
  return response.json();
}

async function solUsd(): Promise<number | undefined> {
  if (Date.now() - lastSolUsdAt < PRICE_CACHE_MS && lastSolUsd > 0) return lastSolUsd;
  if (priceBusy) return lastSolUsd > 0 ? lastSolUsd : undefined;
  priceBusy = true;
  const providers = [
    { name: 'Coinbase', url: 'https://api.coinbase.com/v2/prices/SOL-USD/spot', parse: (j: any) => j?.data?.amount },
    { name: 'Binance', url: 'https://api.binance.com/api/v3/ticker/price?symbol=SOLUSDT', parse: (j: any) => j?.price },
  ];
  const failures: string[] = [];
  try {
    // Race independent public price sources: the first valid answer wins, while
    // failures are retained for diagnostics instead of being hidden by DexScreener.
    const attempts = providers.map(async provider => {
      try {
        const body = await readJson(provider.url);
        const price = validPrice(provider.parse(body));
        if (!price) throw new Error('SOL_USD_INVALID_PRICE');
        return { price, provider: provider.name };
      } catch (error) {
        const e = error as { name?: string; message?: string; cause?: { code?: string; message?: string } };
        failures.push(`${provider.name}:${e?.name || 'Error'}:${e?.message || String(error)}${e?.cause ? ` cause=${e.cause.code || ''}:${e.cause.message || ''}` : ''}`);
        throw error;
      }
    });
    try {
      const result = await Promise.any(attempts);
      lastSolUsd = result.price;
      lastSolUsdProvider = result.provider;
      lastSolUsdAt = Date.now();
      lastSolUsdError = '';
      return result.price;
    } catch {
      lastSolUsdError = failures.join(' | ').slice(0, 700) || 'SOL_USD_ALL_PROVIDERS_FAILED';
      return undefined;
    }
  } finally {
    priceBusy = false;
  }
}

function quoteMintSupported(mint?: string): boolean {
  // This runtime intentionally accepts only SOL-quoted Pump curves/pools.
  // Other quote assets must be converted with their own verified oracle.
  return !mint || mint === WSOL_MINT;
}

export function handlePumpPortalMarketEvent(event: PumpEvent): void {
  if (!stateEngine || !event?.mint) return;
  const mint = String(event.mint);
  if (event.txType === 'create' && event.bondingCurveKey && event.pool !== 'pump-amm' && quoteMintSupported(event.quoteMint)) {
    const curve = String(event.bondingCurveKey);
    if (trackedCurves.get(mint) === curve) return;
    trackedCurves.set(mint, curve);
    void stateEngine.hydrateBondingCurve(curve, mint).catch(error => {
      lastMarketError = `BONDING_CURVE_HYDRATE:${String(error)}`.slice(0, 500);
    });
    return;
  }
  if (event.txType === 'migrate' && event.poolAddress && quoteMintSupported(event.quoteMint)) {
    const pool = String(event.poolAddress);
    if (trackedPools.get(mint) === pool) return;
    trackedPools.set(mint, pool);
    stateEngine.track({ mint, pumpPool: pool });
    void stateEngine.hydratePumpPool(pool).catch(error => {
      lastMarketError = `PUMPSWAP_POOL_HYDRATE:${String(error)}`.slice(0, 500);
    });
  }
}

async function publishStates(): Promise<void> {
  if (!stateEngine) return;
  const states = stateEngine.all();
  if (!states.length) return;
  const usd = await solUsd();
  if (!usd) {
    lastMarketError = `SOL_USD_PRICE_UNAVAILABLE: ${lastSolUsdError}`.slice(0, 700);
    return;
  }
  const seenAt = Date.now();
  for (const state of states) {
    if (state.stale || !state.coherent || Date.now() - state.observedAt > 10_000 || !quoteMintSupported(state.quoteMint)) continue;
    if (state.supplyDecimals === undefined || state.supplyDecimals < 0 || state.supplyDecimals > 18) continue;
    const previous = lastPublishedStateAt.get(state.mint) ?? 0;
    if (state.observedAt <= previous) continue;
    const realQuote = state.realQuoteReserve ?? 0n;
    // RPC account amounts are raw units. The pure converter rejects missing,
    // zero, negative, or non-finite values and never treats virtual reserves as liquidity.
    const market = deriveSolQuotedMarket({
      priceNumerator: state.priceQuotePerBaseUnit.numerator,
      priceDenominator: state.priceQuotePerBaseUnit.denominator,
      tokenDecimals: state.supplyDecimals,
      realQuoteReserve: realQuote,
      solUsd: usd,
      quoteDecimals: SOL_DECIMALS,
    });
    if (!market) continue;
    const priceSol = market.priceQuote;
    const priceUsd = market.priceUsd;
    const liquidityUsd = market.liquidityUsd;
    const observedAt = new Date(state.observedAt).toISOString();
    enqueue({
      eventId: `pumpcurve:${state.mint}:${state.slot}:${state.observedAt}`,
      mint: state.mint,
      source: 'pumpfun-onchain-market-observation',
      eventTime: observedAt,
      price: priceUsd,
      liquidity: liquidityUsd,
      raw: {
        provider: 'SolanaRPC-PumpCurve', venue: state.venue, slot: state.slot,
        priceSol, solUsd: usd, solUsdProvider: lastSolUsdProvider,
        realQuoteReserve: realQuote, curveProgressBps: state.graduationProgressBps === undefined ? undefined : Number(state.graduationProgressBps),
        complete: state.complete, confidence: state.confidence, observedAt,
      },
    });
    lastPublishedStateAt.set(state.mint, state.observedAt);
    stateUpdates++;
    lastPublishedAt = new Date(seenAt).toISOString();
  }
  lastMarketError = '';
}

export function startOnChainMarketData(): void {
  if (stateEngine || !config.rpc || !config.rpcWs) return;
  const rpc = new JsonRpcHttpClient(config.rpc);
  stateEngine = new V25LiveStateEngine(rpc, config.rpcWs, 'confirmed');
  stateEngine.start();
  publishTimer = setInterval(() => { void publishStates().catch(error => { lastMarketError = `PUBLISH_STATES:${String(error)}`.slice(0, 500); }); }, PUBLISH_INTERVAL_MS);
  publishTimer.unref?.();
}

export function onChainMarketDataStatus() {
  return {
    enabled: Boolean(stateEngine), websocketConfigured: Boolean(config.rpcWs),
    websocket: stateEngine?.health().websocket ?? 'DISABLED', subscriptions: stateEngine?.health().subscriptions ?? 0,
    websocketErrors: stateEngine?.health().errors ?? 0, websocketReconnects: stateEngine?.health().reconnects ?? 0,
    lastNotificationAt: stateEngine?.health().lastNotificationAt ? new Date(stateEngine.health().lastNotificationAt!).toISOString() : null,
    trackedBondingCurves: trackedCurves.size, trackedPools: trackedPools.size, stateUpdates,
    solUsdPrice: lastSolUsd || null, solUsdProvider: lastSolUsdProvider || null,
    solUsdLastSuccessAt: lastSolUsdAt ? new Date(lastSolUsdAt).toISOString() : null,
    solUsdError: lastSolUsdError || null, lastPublishedAt, lastError: lastMarketError || null,
  };
}
