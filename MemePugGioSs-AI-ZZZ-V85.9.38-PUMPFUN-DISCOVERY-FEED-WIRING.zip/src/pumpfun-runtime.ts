import {config} from './config.js';
import {db, audit} from './db.js';
import {enqueue} from './ingestion.js';
import {rpc} from './solana.js';
import {V26PumpDiscovery} from './v26-discovery-feed.js';
import {PUMP_PROGRAM_ID, type V26DiscoveryStore, type V26TokenDiscovery} from './v26-types.js';

const store:V26DiscoveryStore={
  has(mint){return Boolean(db.prepare('SELECT mint FROM v26_discovered_tokens WHERE mint=?').get(mint));},
  upsert(token){
    db.prepare(`INSERT INTO v26_discovered_tokens(mint,bonding_curve,signature,slot,block_time,create_kind,name,symbol,uri,creator,quote_mint,mayhem_mode,holder_reward,detected_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(mint) DO NOTHING`)
      .run(token.mint,token.bondingCurve,token.signature,token.slot,token.blockTime??null,token.createKind,token.name??null,token.symbol??null,token.uri??null,token.creator??null,token.quoteMint??null,token.mayhemMode?1:0,token.holderReward?1:0,token.detectedAt);
  },
  all(){return db.prepare('SELECT mint,bonding_curve as bondingCurve,signature,slot,block_time as blockTime,create_kind as createKind,name,symbol,uri,creator,quote_mint as quoteMint,mayhem_mode as mayhemMode,holder_reward as holderReward,detected_at as detectedAt FROM v26_discovered_tokens ORDER BY detected_at DESC LIMIT 500').all() as V26TokenDiscovery[];}
};

const rpcAdapter={async getTransaction(signature:string,commitment='confirmed'){
  return rpc('getTransaction',[signature,{encoding:'json',commitment,maxSupportedTransactionVersion:0}]);
}};
let discovery:V26PumpDiscovery|undefined;
let startupReason='NOT_STARTED';

export function startPumpfunDiscovery(){
  if(discovery)return health();
  if(!config.rpcWs){startupReason='SOLANA_RPC_WS_URL_NOT_CONFIGURED';return health();}
  if(!config.rpc){startupReason='SOLANA_RPC_URL_NOT_CONFIGURED';return health();}
  discovery=new V26PumpDiscovery(config.rpcWs,rpcAdapter,store,{
    onToken(token){
      const observedAt=new Date((token.blockTime??Math.floor(token.detectedAt/1000))*1000).toISOString();
      enqueue({eventId:`pumpfun:${token.signature}:${token.mint}`,mint:token.mint,symbol:token.symbol,name:token.name,source:'pump.fun-verified-create',eventTime:observedAt,slot:token.slot,raw:token});
      audit(`pumpfun-discovered:${token.mint}`,'PUMPFUN_TOKEN_DISCOVERED',{mint:token.mint,signature:token.signature,slot:token.slot,createKind:token.createKind});
    },
    onError(error){audit(`pumpfun-error:${Date.now()}`,'PUMPFUN_DISCOVERY_ERROR',{error:error.message});}
  });
  discovery.start();
  startupReason='STARTED';
  return health();
}

export function stopPumpfunDiscovery(){discovery?.stop();discovery=undefined;startupReason='STOPPED';}
export function health(){return {enabled:Boolean(config.rpcWs&&config.rpc),state:discovery?.health().websocket??'STOPPED',reason:startupReason,programId:PUMP_PROGRAM_ID,discovery:discovery?.health()??null,liveExecutionEnabled:false,mode:'PAPER'};}
