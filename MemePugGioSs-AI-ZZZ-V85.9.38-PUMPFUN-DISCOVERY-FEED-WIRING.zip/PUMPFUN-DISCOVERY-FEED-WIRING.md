# Pump.fun Discovery Feed Wiring — V85.9.38 source patch

## Changes
- Wires the existing V26 Pump.fun transaction verifier into the production server startup path.
- Subscribes to the official Pump.fun program through `SOLANA_RPC_WS_URL` and verifies candidate transactions through `SOLANA_RPC_URL` before storing them.
- Persists verified creations in `v26_discovered_tokens` and enqueues them into the existing ingestion pipeline for the tokens/observations tables.
- Adds authenticated `GET /api/pumpfun/discovery` health details and includes discovery health in `/api/health`.
- Keeps PAPER mode and live execution disabled; this discovery module has no signing, wallet, or transaction-broadcast path.

## Required runtime configuration
- `APP_MODE=PAPER`
- `SOLANA_RPC_URL` must be a working Solana HTTP JSON-RPC endpoint.
- `SOLANA_RPC_WS_URL` must be a working Solana WebSocket JSON-RPC endpoint for the same provider.

If either Solana endpoint is missing, the discovery module remains disabled and reports the missing configuration. A WebSocket URL alone does not guarantee token creation events; the backend verifies transaction instructions against the Pump.fun program and parser.

## Validation status
- `node ci/build-source-validation.mjs`: PASS (relative-import source gate).
- Full TypeScript build/tests were not run in this environment because dependencies could not be installed before timeout. Do not treat this ZIP as a certified or production-tested release until GitHub Actions/Render build and runtime checks pass.
- `package.json` version remains `85.9.38-DASHBOARD-UI-REFRESH` because the repository's existing release-evidence gate explicitly requires that exact value.
