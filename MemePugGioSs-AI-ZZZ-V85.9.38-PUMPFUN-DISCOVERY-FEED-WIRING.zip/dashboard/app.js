(()=>{'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={token:sessionStorage.getItem('mpg_v5_token')||'',snapshot:null,health:null,tokens:[],opportunities:[],signals:[],traders:[],view:'home',busy:false};
const money=v=>{const n=Number(v);return Number.isFinite(n)?new Intl.NumberFormat('it-IT',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n):'—'};
const num=v=>{const n=Number(v);return Number.isFinite(n)?new Intl.NumberFormat('it-IT',{maximumFractionDigits:4}).format(n):'—'};
const short=v=>{if(v===null||v===undefined||v==='')return'—';const s=String(v);return s.length>18?s.slice(0,8)+'…'+s.slice(-5):s};
const fmtDate=v=>{if(!v)return'—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('it-IT',{dateStyle:'short',timeStyle:'short'})};
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(msg,bad=false){const el=$('#toast');el.textContent=msg;el.classList.toggle('bad',bad);el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,3500)}
async function api(url,opts={}){const headers={...(opts.headers||{})};if(state.token)headers.Authorization='Bearer '+state.token;if(opts.body)headers['Content-Type']='application/json';const r=await fetch(url,{...opts,headers});if(r.status===401){logout(false);throw new Error('Sessione scaduta. Accedi di nuovo.')}if(!r.ok)throw new Error(url+' · HTTP '+r.status);return r.json()}
function showApp(){ $('#login-screen').hidden=true;$('#app').hidden=false; }
function showLogin(){ $('#app').hidden=true;$('#login-screen').hidden=false; }
function logout(notify=true){state.token='';sessionStorage.removeItem('mpg_v5_token');showLogin();if(notify)toast('Hai effettuato la disconnessione.')}
$('#login-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.submitter;const error=$('#login-error');error.hidden=true;btn.disabled=true;btn.textContent='Accesso in corso…';try{const result=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#username').value.trim(),password:$('#password').value})});const data=await result.json().catch(()=>({}));if(!result.ok||!data.token)throw new Error('Credenziali non valide. Controlla ADMIN_USER e ADMIN_PASSWORD nelle variabili Render.');state.token=data.token;sessionStorage.setItem('mpg_v5_token',data.token);$('#password').value='';showApp();await refreshAll();startPolling();}catch(err){error.textContent=err.message||'Accesso non riuscito.';error.hidden=false;}finally{btn.disabled=false;btn.innerHTML='Accedi alla dashboard <span>↗</span>'}});
function setText(id,v){const el=document.getElementById(id);if(el)el.textContent=v===undefined||v===null?'—':String(v)}
function setRows(id,rows,cols,empty){const el=document.getElementById(id);if(!el)return;if(!rows||!rows.length){el.innerHTML=`<tr><td class="empty-cell" colspan="${cols}">${esc(empty||'Nessun dato restituito dal backend.')}</td></tr>`;return}el.innerHTML=rows.map(row=>'<tr>'+row.map(cell=>`<td>${cell===null||cell===undefined?'—':cell}</td>`).join('')+'</tr>').join('')}
function pick(o,keys){for(const k of keys)if(o&&o[k]!==undefined&&o[k]!==null)return o[k];return undefined}
function renderState(s){state.snapshot=s;const a=s.account||{},e=s.engine||{};setText('equity',money(a.equity));setText('cash',money(a.cash));setText('position-count',(s.positions||[]).length);setText('engine-status',e.running?'RUNNING':'IDLE');setText('engine-subtitle',e.running?'Motore segnalato come attivo':'Il motore non risulta in esecuzione');setText('chart-equity',money(a.equity));setText('paper-cash',money(a.cash));setText('paper-equity',money(a.equity));setText('paper-positions',(s.positions||[]).length);setText('updated-at','Aggiornato '+new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'}));setText('health-time',new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'}));setText('runtime-engine',e.running?'RUNNING':'IDLE');setText('runtime-json',JSON.stringify(e,null,2));setText('connection-label','COLLEGATO');setText('api-health','ONLINE');setText('health-badge','ONLINE');
const orders=s.orders||[];setRows('recent-orders',orders.slice(0,6).map(o=>[esc(pick(o,['side','type','action'])||'Ordine'),esc(short(pick(o,['symbol','mint','token','tokenMint']))),esc(num(pick(o,['quantity','amount','size']))),esc(pick(o,['status','state'])||'—')]),4,'Nessun ordine registrato.');setRows('orders-table',orders.slice(0,100).map(o=>[esc(pick(o,['id','order_id'])||'—'),esc(short(pick(o,['symbol','mint','token']))),esc(pick(o,['side','type'])||'—'),esc(num(pick(o,['quantity','amount','size']))),esc(pick(o,['status','state'])||'—')]),5,'Nessun ordine registrato.');
const positions=s.positions||[];setRows('positions-table',positions.map(p=>[esc(short(pick(p,['symbol','mint','token']))),esc(num(pick(p,['quantity','amount','size']))),esc(money(pick(p,['avgPrice','avg_price','entryPrice','entry_price']))),esc(money(pick(p,['value','marketValue','market_value']))),esc(money(pick(p,['pnl','unrealizedPnl','unrealized_pnl'])))]),5,'Nessuna posizione aperta.');}
function renderTokens(rows){
  state.tokens=Array.isArray(rows)?rows:[];
  setText('market-token-count',state.tokens.length);
  setText('token-caption',`${state.tokens.length} record restituiti dal backend`);
  const data=state.tokens.slice(0,200).map(t=>[
    esc(short(pick(t,['symbol','name','mint']))),
    esc(money(pick(t,['price','price_usd']))),
    esc(num(pick(t,['risk_score','riskScore']))),
    esc(pick(t,['largest_holder_pct'])===undefined?'—':num(t.largest_holder_pct)+'%'),
    esc(t.mint_authority_present===undefined?'—':(t.mint_authority_present?'Presente':'Assente')),
    esc(fmtDate(pick(t,['last_seen','updated_at','created_at'])))
  ]);
  setRows('tokens-table',data,6,'Nessun token trovato nel database. La fonte potrebbe non essere configurata.');
}
function renderOpp(rows){
  state.opportunities=Array.isArray(rows)?rows:[];
  setText('market-opp-count',state.opportunities.length);
  const data=state.opportunities.slice(0,100).map(x=>[
    esc(short(pick(x,['symbol','mint','name']))),esc(money(x.price)),esc(money(x.liquidity)),
    esc(num(pick(x,['score','riskScore']))),esc(num(pick(x,['riskScore','risk_score']))),
    esc(x.tradable?'AMMESSO':'BLOCCATO')
  ]);
  setRows('signals-table',data,6,'Nessuna opportunità disponibile. Non vengono generati segnali dimostrativi.');
}
function renderTraders(rows){
  state.traders=Array.isArray(rows)?rows:[];
  const data=state.traders.slice(0,100).map(t=>[
    esc(short(pick(t,['wallet','address','publicKey','trader','name']))),
    esc(num(pick(t,['score','rank','performanceScore']))),
    esc(num(pick(t,['reputation','reputationScore','score']))),
    esc(pick(t,['status'])||'Osservato')
  ]);
  setRows('traders-table',data,4,'Nessun trader disponibile tramite le API correnti.');
}
async function refreshAll(){if(state.busy||!state.token)return;state.busy=true;setText('connection-label','AGGIORNAMENTO');try{const healthP=fetch('/api/health').then(r=>r.json()).catch(()=>null);const results=await Promise.allSettled([api('/api/state'),api('/api/tokens'),api('/api/opportunities'),api('/api/v34/traders'),healthP]);if(results[0].status==='fulfilled')renderState(results[0].value);else throw results[0].reason;if(results[1].status==='fulfilled')renderTokens(results[1].value);if(results[2].status==='fulfilled')renderOpp(results[2].value);if(results[3].status==='fulfilled')renderTraders(results[3].value);if(results[4].status==='fulfilled'&&results[4].value){state.health=results[4].value;setText('rpc-status',String(state.health.rpc||'—').toUpperCase());setText('api-health',state.health.ok?'ONLINE':'ATTENZIONE');setText('runtime-api',state.health.ok?'ONLINE':'ATTENZIONE');setText('market-summary',`Servizio: ${state.health.ok?'online':'da verificare'} · Versione: ${state.health.version||'—'} · RPC: ${state.health.rpc||'non configurato'} · WebSocket Solana: ${state.health.chainStream?'configurato':'non configurato'}. La presenza di un endpoint non garantisce che il feed stia ricevendo nuovi token.`);setText('runtime-json',JSON.stringify({health:state.health,engine:state.snapshot?.engine||{}},null,2));}else{setText('rpc-status','NON VERIFICATO');setText('market-summary','Health check non disponibile. Controlla la connessione del backend.')}setText('connection-label','COLLEGATO');}catch(err){setText('connection-label','ERRORE');toast(err.message||'Errore durante il caricamento dei dati.',true)}finally{state.busy=false}}
function go(view){if(!document.getElementById('view-'+view))return;state.view=view;$$('.page').forEach(p=>p.classList.toggle('active',p.id==='view-'+view));$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));setText('page-name',({home:'Home',market:'Mercato Solana',tokens:'Nuovi token',signals:'Segnali AI',paper:'Paper Trading',copy:'Copy Trading',assistant:'Assistente AI',runtime:'Stato motore'})[view]||view);$('#sidebar').classList.remove('open');}
$('#navigation').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b)go(b.dataset.view)});document.addEventListener('click',e=>{const b=e.target.closest('[data-goto]');if(b)go(b.dataset.goto)});$('#menu-toggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));$('#refresh').addEventListener('click',refreshAll);$('#runtime-refresh').addEventListener('click',refreshAll);$('#reload-tokens').addEventListener('click',async()=>{try{renderTokens(await api('/api/tokens'));toast('Elenco token aggiornato.')}catch(e){toast(e.message,true)}});$('#logout').addEventListener('click',()=>logout());
let poll=null;function startPolling(){if(poll)clearInterval(poll);poll=setInterval(refreshAll,20000)}
if(state.token){showApp();refreshAll().then(startPolling)}else showLogin();
})();