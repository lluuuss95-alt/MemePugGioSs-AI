export class EventDeduplicator{
 private seen=new Set<string>();
 constructor(private maxEntries=100000){}
 accept(id:string){if(this.seen.has(id))return false;this.seen.add(id);if(this.seen.size>this.maxEntries)this.seen.delete(this.seen.values().next().value);return true}
 size(){return this.seen.size}
}
