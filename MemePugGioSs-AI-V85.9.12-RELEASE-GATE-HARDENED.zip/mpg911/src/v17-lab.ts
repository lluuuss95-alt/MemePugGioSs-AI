
import crypto from "node:crypto";
import { DatasetRow, StrategyParams } from "./v15-types.js";
import { V17Report } from "./v17-types.js";
import { runWalkForward } from "./v17-walkforward.js";
import { regimePerformance } from "./v17-regime.js";

export function v17Lab(rows:DatasetRow[],space:Record<keyof StrategyParams,number[]>):V17Report{
  const windows=runWalkForward(rows,space);
  const rp=regimePerformance(rows);
  if(rows.length<100)return {runId:hash(rows,space),windows,regimePerformance:rp,regimeCoverage:rp.length/6,consistencyScore:0,status:"INSUFFICIENT_DATA"};
  const valid=windows.filter(w=>w.selectedParams&&w.testSamples>0);
  const positive=valid.filter(w=>w.testMean>0).length;
  const consistency=valid.length?positive/valid.length*100:0;
  const regimeCoverage=rp.length/6;
  const status=consistency>=70&&regimeCoverage>=.5?"CONSISTENT":consistency>=50?"REGIME_SENSITIVE":"UNSTABLE";
  return {runId:hash(rows,space),windows,regimePerformance:rp,regimeCoverage,consistencyScore:consistency,status};
}
function hash(rows:DatasetRow[],space:any){return crypto.createHash("sha256").update(JSON.stringify({rows,space})).digest("hex");}
