import {TransactionFetchConfig,VerifiedTransaction} from "./v21-types.js";
export class SolanaTransactionRpc{
 constructor(private cfg:TransactionFetchConfig){}
 async getTransaction(signature:string):Promise<VerifiedTransaction|null>{
  const body={jsonrpc:"2.0",id:Date.now(),method:"getTransaction",params:[signature,{
   commitment:this.cfg.commitment,maxSupportedTransactionVersion:this.cfg.maxSupportedTransactionVersion,encoding:this.cfg.encoding
  }]};
  const r=await fetch(this.cfg.rpcUrl,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)});
  if(!r.ok)throw new Error(`RPC_HTTP_${r.status}`);
  const j:any=await r.json(); if(j.error)throw new Error(`RPC_${j.error.code||"ERROR"}:${j.error.message||""}`);
  if(!j.result)return null;
  const tx=j.result, msg=tx.transaction?.message;
  const keys=(msg?.accountKeys||[]).map((k:any)=>typeof k==="string"?k:k.pubkey).filter(Boolean);
  const programs=(msg?.instructions||[]).map((i:any)=>i.programId||i.program).filter(Boolean);
  return {signature,slot:tx.slot,blockTime:tx.blockTime??null,err:tx.meta?.err??null,fee:tx.meta?.fee??null,
   accountKeys:keys,programIds:[...new Set(programs)],instructions:(msg?.instructions||[]).length,
   innerInstructions:(tx.meta?.innerInstructions||[]).reduce((n:any,x:any)=>n+(x.instructions?.length||0),0),raw:tx};
 }
}