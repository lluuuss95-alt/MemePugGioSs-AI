import { db } from './db.js';
import { enqueue, ingestQueue } from './ingestion.js';

type DexPair = {
  chainId?: string;
  dexId?: string;
  pairAddress?: string;
  baseToken?: { address?: string; name?: string; symbol?: string };
  priceUsd?: string;
  liquidity?: { usd?: number };
  volume?: { m5?: number };
  txns?: { m5?: { buys?: number; sells?: number } };
  pairCreatedAt?: number;
  url?: string;
};
type PumpCoin = { mint?: string; symbol?: string; name?: string; usd_market_cap?: number | string; market_cap?: number | string; total_supply?: number | string; decimals?: number | string; complete?: boolean; };
type GeckoPool = { id?: string; attributes?: { name?: string; address?: string; base_token_price_usd?: string; reserve_in_usd?: string; volume_usd?: { m5?: string }; pool_created_at?: string }; relationships?: { base_token?: { data?: { id?: string } } } };

// Recheck shortly after startup and often enough to catch tokens that arrive
// just after the first cycle. Provider request budget remains below DexScreener's
// documented 300 requests/minute limit (batch + bounded per-token fallback).
const INTERVAL_MS = 60_000;
const BATCH_SIZE = 30;
const MAX_TOKENS_PER_CYCLE = 30;
const INVENTORY_SCAN_LIMIT = 200;
const REQUEST_TIMEOUT_MS = 8_000;
const FALLBACK_TIMEOUT_MS = 7_000;
const MAX_GECKO_FALLBACKS_PER_CYCLE = 8;
// Keep individual probes deliberately low; batch lookup is the primary path.
// One batched request per cycle; per-token fallback probes are disabled to avoid
// amplifying provider throttling. The token window rotates through the inventory.
const RATE_LIMIT_COOLDOWN_MS = 300_000;
const MAX_RATE_LIMIT_COOLDOWN_MS = 900_000;
let providerCooldownUntil = 0;
let rateLimitFailures = 0;
let inventoryCursor = 0;
let fallbackCursor = 0;
let timer: ReturnType<typeof setInterval> | undefined;
let running = false;
let cycleHadError = false;
function describeFetchError(stage: string, error: unknown): string {
  const e = error as { name?: string; message?: string; cause?: { code?: string; message?: string; name?: string } };
  const parts = [`${stage}: ${e?.name || 'Error'}: ${e?.message || String(error)}`];
  if (e?.cause) parts.push(`cause=${e.cause.code || e.cause.name || 'unknown'}:${e.cause.message || ''}`);
  return parts.join(' | ').slice(0, 500);
}
async function fetchDexBatch(url: string): Promise<Response> {
  let lastError: unknown;
  for (let attempt = 0; attempt < 2; attempt++) {
    health.requests++;
    try {
      const response = await fetch(url, {
        headers: { accept: 'application/json' },
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
      if (attempt === 0 && response.status >= 500) {
        await new Promise(resolve => setTimeout(resolve, 250));
        continue;
      }
      return response;
    } catch (error) {
      lastError = error;
      if (attempt === 0) {
        await new Promise(resolve => setTimeout(resolve, 250));
        continue;
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error(String(lastError ?? 'DEXSCREENER_FETCH_FAILED'));
}

function recordFetchError(stage: string, error: unknown) {
  cycleHadError = true;
  const e = error as { message?: string; retryAfterMs?: number };
  if (String(e?.message || error).includes('HTTP_429')) {
    const requestedDelay = Number(e?.retryAfterMs ?? 0);
    rateLimitFailures = Math.min(rateLimitFailures + 1, 4);
    const exponentialDelay = Math.min(MAX_RATE_LIMIT_COOLDOWN_MS, RATE_LIMIT_COOLDOWN_MS * (2 ** (rateLimitFailures - 1)));
    providerCooldownUntil = Date.now() + Math.min(MAX_RATE_LIMIT_COOLDOWN_MS, Math.max(exponentialDelay, requestedDelay));
  }
  const detail = describeFetchError(stage, error);
  if (stage.startsWith('DexScreener')) health.lastDexScreenerError = detail;
  if (stage.startsWith('GeckoTerminal')) health.lastGeckoError = detail;
  health.lastError = [health.lastDexScreenerError, health.lastGeckoError].filter(Boolean).join(' | ').slice(0, 900) || detail;
}
const health = {
  status: 'IDLE' as 'IDLE' | 'RUNNING' | 'OK' | 'DEGRADED' | 'WAITING_FOR_TOKENS',
  lastRunAt: null as string | null,
  lastSuccessAt: null as string | null,
  lastError: '',
  lastDexScreenerError: '',
  lastGeckoError: '',
  tokensChecked: 0,
  pairsMatched: 0,
  observationsQueued: 0,
  requests: 0,
  tokensWithoutPair: 0,
  tokensWithoutPrice: 0,
  lastMissingMints: [] as string[],
  pumpFunFallbacks: 0,
  pumpFunPrices: 0,
  dexTokenPairProbes: 0,
  dexTokenPairErrors: 0,
  pumpFunNotFound: 0,
  geckoFallbacks: 0,
  geckoMatches: 0,
  geckoErrors: 0,
};

export function marketEnrichmentStatus() {
  // Expose the inventory and queue independently from market-provider results.
  // This distinguishes an empty token pipeline from a provider returning no pairs.
  const inventory = db.prepare(`SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN length(mint) >= 32 AND length(mint) <= 44 THEN 1 ELSE 0 END) AS eligible,
    SUM(CASE WHEN source = 'pumpportal-new-token' THEN 1 ELSE 0 END) AS pumpPortal
    FROM tokens`).get() as { total?: number; eligible?: number; pumpPortal?: number };
  return {
    ...health,
    inventoryTokens: Number(inventory.total ?? 0),
    eligibleTokens: Number(inventory.eligible ?? 0),
    pumpPortalTokens: Number(inventory.pumpPortal ?? 0),
    ingestionQueueDepth: ingestQueue.size,
    configured: true,
    provider: 'DexScreener',
    intervalMs: INTERVAL_MS,
    rateLimitFailures,
    cooldownRemainingMs: Math.max(0, providerCooldownUntil - Date.now()),
    maxTokensPerCycle: MAX_TOKENS_PER_CYCLE,
  };
}

/** Adds observed market data to the local paper/shadow database. Never trades. */
export function startMarketEnrichment() {
  if (timer) return;
  // Delay the first batch slightly so the HTTP server and primary feed can start.
  setTimeout(() => { void runMarketEnrichment(); }, 3_000);
  timer = setInterval(() => { void runMarketEnrichment(); }, INTERVAL_MS);
}

export async function runMarketEnrichment() {
  if (running) return marketEnrichmentStatus();
  running = true;
  health.lastRunAt = new Date().toISOString();
  // Keep the last real cycle's counters visible during cooldown instead of
  // resetting them to zero and making a paused provider look like an empty feed.
  if (Date.now() < providerCooldownUntil) {
    health.status = 'DEGRADED';
    health.lastError = `DEXSCREENER_RATE_LIMIT_COOLDOWN: retry in ${Math.ceil((providerCooldownUntil - Date.now()) / 1000)}s; requests paused`;
    running = false;
    return marketEnrichmentStatus();
  }
  health.status = 'RUNNING';
  health.lastError = '';
  health.lastDexScreenerError = '';
  health.lastGeckoError = '';
  cycleHadError = false;
  health.tokensChecked = 0;
  health.pairsMatched = 0;
  health.observationsQueued = 0;
  health.tokensWithoutPair = 0;
  health.tokensWithoutPrice = 0;
  health.lastMissingMints = [];
  health.pumpFunFallbacks = 0;
  health.pumpFunPrices = 0;
  health.dexTokenPairProbes = 0;
  health.dexTokenPairErrors = 0;
  health.pumpFunNotFound = 0;
  health.geckoFallbacks = 0;
  health.geckoMatches = 0;
  health.geckoErrors = 0;
  try {
    const inventory = db.prepare(
      `SELECT mint,symbol,name FROM tokens WHERE length(mint)>=32 AND length(mint)<=44 ORDER BY last_seen DESC LIMIT ?`
    ).all(INVENTORY_SCAN_LIMIT) as Array<{ mint: string; symbol: string | null; name: string | null }>;
    if (inventory.length > MAX_TOKENS_PER_CYCLE) {
      const start = inventoryCursor % inventory.length;
      const rotated = [...inventory.slice(start), ...inventory.slice(0, start)];
      const tokens = rotated.slice(0, MAX_TOKENS_PER_CYCLE);
      inventoryCursor = (start + MAX_TOKENS_PER_CYCLE) % inventory.length;
      inventory.splice(0, inventory.length, ...tokens);
    } else {
      inventoryCursor = 0;
    }
    const tokens = inventory;
    if (tokens.length === 0) {
      health.status = 'WAITING_FOR_TOKENS';
      health.lastError = ingestQueue.size > 0
        ? `WAITING_FOR_INGESTION: queue=${ingestQueue.size}, inventory=${Number((db.prepare('SELECT COUNT(*) AS n FROM tokens').get() as { n?: number }).n ?? 0)}`
        : 'WAITING_FOR_ELIGIBLE_TOKENS: no token mints of 32–44 characters are persisted yet';
      return marketEnrichmentStatus();
    }
    const seenAt = Date.now();
    // DexScreener may be unreachable from a hosting region or transiently fail.
    // Rotate a small, bounded set of token-specific GeckoTerminal lookups each
    // cycle so a provider outage does not permanently starve the token inventory.
    const fallbackRotation = [...tokens.slice(fallbackCursor % Math.max(tokens.length, 1)), ...tokens.slice(0, fallbackCursor % Math.max(tokens.length, 1))];
    const fallbackMints = new Set(fallbackRotation.slice(0, Math.min(MAX_GECKO_FALLBACKS_PER_CYCLE, tokens.length)).map(t => t.mint));
    if (tokens.length) fallbackCursor = (fallbackCursor + fallbackMints.size) % tokens.length;
    for (let offset = 0; offset < tokens.length; offset += BATCH_SIZE) {
      const batch = tokens.slice(offset, offset + BATCH_SIZE);
      if (!batch.length) continue;
      const addresses = batch.map(t => t.mint).join(',');
      health.tokensChecked += batch.length;
      let pairs: DexPair[] = [];
      try {
        const response = await fetchDexBatch(`https://api.dexscreener.com/tokens/v1/solana/${addresses}`);
        if (!response.ok) {
          const retryAfter = Number(response.headers.get('retry-after') ?? 0);
          const err = new Error(`DEXSCREENER_HTTP_${response.status}`) as Error & { retryAfterMs?: number };
          if (response.status === 429 && Number.isFinite(retryAfter) && retryAfter > 0) err.retryAfterMs = retryAfter * 1000;
          throw err;
        }
        const body: unknown = await response.json();
        if (!Array.isArray(body)) throw new Error('DEXSCREENER_INVALID_RESPONSE');
        pairs = body as DexPair[];
        rateLimitFailures = 0;
        providerCooldownUntil = 0;
      } catch (error) {
        // A failed batch records the provider error; no extra requests are issued
        // during the same cycle, preventing a 429 from being amplified.
        recordFetchError('DexScreener batch request', error);
      }
      const byMint = new Map<string, DexPair>();
      for (const pair of pairs) {
        if (pair.chainId && pair.chainId !== 'solana') continue;
        const mint = pair.baseToken?.address;
        if (!mint || !batch.some(t => t.mint === mint)) continue;
        const current = byMint.get(mint);
        const liquidity = Number(pair.liquidity?.usd ?? 0);
        const currentLiquidity = Number(current?.liquidity?.usd ?? 0);
        if (!current || liquidity > currentLiquidity) byMint.set(mint, pair);
      }
      for (const token of batch) {
        let pair = byMint.get(token.mint);
        // A DexScreener pair can exist while its price/liquidity fields are absent or invalid.
        // Treat that as a failed market match too; otherwise the GeckoTerminal fallback
        // is skipped and the dashboard reports zero observations despite attempting a batch.
        const pairHasVerifiedMarketData = Boolean(pair)
          && Number.isFinite(Number(pair?.priceUsd)) && Number(pair?.priceUsd) > 0
          && Number.isFinite(Number(pair?.liquidity?.usd)) && Number(pair?.liquidity?.usd) > 0;
        if ((!pair || !pairHasVerifiedMarketData) && fallbackMints.has(token.mint)) {
          health.geckoFallbacks++;
          try {
            const response = await fetch(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/${encodeURIComponent(token.mint)}/pools?page=1`, {
              headers: { accept: 'application/json' },
              signal: AbortSignal.timeout(FALLBACK_TIMEOUT_MS),
            });
            if (!response.ok) throw new Error(`GECKOTERMINAL_HTTP_${response.status}`);
            const payload = await response.json() as { data?: GeckoPool[] };
            const pools = Array.isArray(payload?.data) ? payload.data : [];
            const ranked = pools.map(pool => {
              const a = pool.attributes || {};
              const relationId = pool.relationships?.base_token?.data?.id || '';
              const relationMint = relationId.startsWith('solana_') ? relationId.slice('solana_'.length) : relationId;
              return { pool, a, relationMint, liquidity: Number(a.reserve_in_usd), price: Number(a.base_token_price_usd) };
            }).filter(x => (!x.relationMint || x.relationMint === token.mint) && Number.isFinite(x.price) && x.price > 0 && Number.isFinite(x.liquidity) && x.liquidity > 0).sort((a,b) => b.liquidity-a.liquidity);
            const best = ranked[0];
            if (best) {
              const createdAt = best.a.pool_created_at ? Date.parse(best.a.pool_created_at) : NaN;
              pair = {
                chainId: 'solana', pairAddress: best.a.address || best.pool.attributes?.address,
                baseToken: { address: token.mint, symbol: token.symbol || undefined, name: token.name || undefined },
                priceUsd: String(best.price), liquidity: { usd: best.liquidity },
                volume: { m5: Number(best.a.volume_usd?.m5 || 0) },
                pairCreatedAt: Number.isFinite(createdAt) ? createdAt : undefined,
                url: best.a.address ? `https://www.geckoterminal.com/solana/pools/${best.a.address}` : undefined,
                dexId: 'geckoterminal',
              };
              byMint.set(token.mint, pair);
              health.geckoMatches++;
            }
          } catch (error) {
            health.geckoErrors++;
            health.lastGeckoError = describeFetchError('GeckoTerminal fallback', error);
            health.lastError = [health.lastDexScreenerError, health.lastGeckoError].filter(Boolean).join(' | ').slice(0, 900);
          }
        }
        if (Date.now() < providerCooldownUntil) {
          health.tokensWithoutPair++;
          health.lastMissingMints.push(token.mint);
          continue;
        }
        // No per-token fallback calls: one batch request is the cycle budget.
        if (!pair) {
          health.tokensWithoutPair++;
          health.lastMissingMints.push(token.mint);
          // No verified market pair means no defensible market price. Keep the
          // price blank rather than deriving one from an unauthenticated Pump.fun
          // endpoint or inventing a value.
          continue;
        }
        const price = Number(pair.priceUsd);
        const liquidity = Number(pair.liquidity?.usd);
        const volume5m = Number(pair.volume?.m5);
        const buys = Number(pair.txns?.m5?.buys ?? 0);
        const sells = Number(pair.txns?.m5?.sells ?? 0);
        const txTotal = buys + sells;
        const buyPressure = txTotal > 0 ? buys / txTotal : undefined;
        const createdAt = Number(pair.pairCreatedAt);
        const ageSeconds = Number.isFinite(createdAt) && createdAt > 0 ? Math.max(0, Math.floor((seenAt - createdAt) / 1000)) : undefined;
        // Only enqueue genuinely observed, finite positive market values.
        const validPrice = Number.isFinite(price) && price > 0 ? price : undefined;
        if (validPrice === undefined) health.tokensWithoutPrice++;
        const validLiquidity = Number.isFinite(liquidity) && liquidity >= 0 ? liquidity : undefined;
        const validVolume = Number.isFinite(volume5m) && volume5m >= 0 ? volume5m : undefined;
        if (validPrice === undefined && validLiquidity === undefined && validVolume === undefined) continue;
        const observedAt = new Date(seenAt).toISOString();
        enqueue({
          eventId: `dexscreener:${token.mint}:${Math.floor(seenAt / INTERVAL_MS)}`,
          mint: token.mint,
          symbol: pair.baseToken?.symbol || token.symbol || undefined,
          name: pair.baseToken?.name || token.name || undefined,
          source: 'dexscreener-market-observation',
          eventTime: observedAt,
          price: validPrice,
          liquidity: validLiquidity,
          volume5m: validVolume,
          ageSeconds,
          buyPressure,
          raw: { provider: pair.dexId === 'geckoterminal' ? 'GeckoTerminal' : 'DexScreener', pairAddress: pair.pairAddress, dexId: pair.dexId, pairUrl: pair.url, buys5m: buys, sells5m: sells, observedAt },
        });
        health.pairsMatched++;
        health.observationsQueued++;
      }
    }
    const missingMarketData = health.tokensChecked > 0 && health.pairsMatched === 0 && health.observationsQueued === 0;
    health.status = cycleHadError || missingMarketData ? 'DEGRADED' : 'OK';
    if (missingMarketData && !health.lastError) health.lastError = `NO_VERIFIED_MARKET_DATA: checked=${health.tokensChecked}, pairs=${health.pairsMatched}, observations=${health.observationsQueued}`;
    if (!cycleHadError && !missingMarketData) health.lastSuccessAt = new Date().toISOString();
  } catch (error) {
    health.status = 'DEGRADED';
    health.lastError = String(error);
  } finally {
    running = false;
  }
  return marketEnrichmentStatus();
}
