import assert from 'node:assert/strict';
import { V79PaperPortfolioReconciliation, assertV79Safe } from '../src/v79-paper-portfolio-reconciliation.js';
import { db } from '../src/db.js';

assertV79Safe();
for (const t of ['v79_recovery_snapshots']) db.exec(`DELETE FROM ${t}`);
db.exec("DELETE FROM v52_paper_events WHERE mint='MintV79'");
db.exec("DELETE FROM v52_paper_positions WHERE mint='MintV79'");
db.exec("DELETE FROM v77_execution_commits WHERE mint='MintV79'");
db.exec("DELETE FROM v78_exit_commits WHERE mint='MintV79'");

const now=Date.now();
const paper={action:'ENTER_PAPER',position:{id:'p79',mint:'MintV79',quantity:10,entryPrice:1,currentPrice:1,entryNotional:10,fees:.025,openedAt:now,highPrice:1,stopPrice:.92,takeProfitPrice:1.16,trailingPrice:.93,status:'OPEN',realizedPnl:0},cash:9974.975,equity:9984.975,realizedPnl:0,unrealizedPnl:0,liveExecutionEnabled:false};
db.prepare(`INSERT INTO v77_execution_commits(id,ts,mint,commit_key,bridge_id,decision_id,status,action,reason,paper_result_json,supervisor_state,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run('c79',now,'MintV79','entry79','b79','d79','COMMITTED','ENTER_PAPER','PAPER_ENTRY',JSON.stringify(paper),'RUNNING',JSON.stringify({liveExecutionEnabled:false}));

const engine=new V79PaperPortfolioReconciliation();
const before=engine.inspect(now+1); assert.equal(before.state,'DEGRADED'); assert.equal(before.issues[0].action,'RECOVER_ENTRY');
const recovered=engine.recover(now+2); assert.equal(recovered.repaired,1); assert.ok(['RECOVERED','HEALTHY'].includes(recovered.state));
const restored=db.prepare("SELECT * FROM v52_paper_positions WHERE id='p79'").get() as any; assert.equal(restored.status,'OPEN');
assert.equal(recovered.paper.openPositions,1);
assert.ok(recovered.paper.equity>recovered.paper.cash);
assert.equal(recovered.consistency.entryCommitCoverage,100);
assert.equal(recovered.consistency.eventLedgerConsistent,true);
const second=engine.recover(now+3); assert.equal(second.repaired,0); assert.equal(second.issues.length,0);
assert.equal(engine.health().liveExecutionEnabled,false);
console.log('V79 tests passed');
