import crypto from 'node:crypto';
import { db } from './db.js';
import { V52AutonomousPaperLoop } from './v52-autonomous-paper-loop.js';
import type { V77Result } from './v77-paper-execution-commit-layer.js';

export type V79State = 'HEALTHY'|'RECOVERED'|'DEGRADED'|'FAILED';
export type V79Action = 'NONE'|'RECOVER_ENTRY'|'FLAG_EXIT_MISMATCH'|'FLAG_DUPLICATE'|'FLAG_LEDGER_MISMATCH';
export interface V79Issue { code:string; mint?:string; positionId?:string; action:V79Action; safeToRepair:boolean; detail:string; }
export interface V79Report {
  id:string; ts:number; state:V79State; action:V79Action; repaired:number; issues:V79Issue[];
  counts:{v77Committed:number; v78Exits:number; openRows:number; openMints:number; duplicateOpenMints:number; closedRows:number; enterEvents:number; exitEvents:number};
  paper:{cash:number; equity:number; realizedPnl:number; unrealizedPnl:number; openPositions:number};
  consistency:{entryCommitCoverage:number; exitCommitCoverage:number; duplicateFree:boolean; eventLedgerConsistent:boolean};
  stateHash:string; liveExecutionEnabled:false;
}

export const V79_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV79Safe(){if(!V79_SAFETY.shadowOnly||V79_SAFETY.signingEnabled||V79_SAFETY.privateKeyAccess||V79_SAFETY.broadcastEnabled||V79_SAFETY.liveExecutionAllowed||V79_SAFETY.autoPromotion)throw new Error('V79_SAFETY_INVARIANT_FAILED');}

function n(v:any){const x=Number(v);return Number.isFinite(x)?x:0;}
function pct(a:number,b:number){return b>0?Math.round((a/b)*10000)/100:100;}

export class V79PaperPortfolioReconciliation {
  private readonly loop:V52AutonomousPaperLoop;
  constructor(loop?:V52AutonomousPaperLoop){this.loop=loop??new V52AutonomousPaperLoop();this.ensureSchema();assertV79Safe();}

  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v79_recovery_snapshots(
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, state TEXT NOT NULL, action TEXT NOT NULL,
    repaired INTEGER NOT NULL, report_json TEXT NOT NULL, state_hash TEXT NOT NULL
  ); CREATE INDEX IF NOT EXISTS idx_v79_recovery_ts ON v79_recovery_snapshots(ts);`);}

  inspect(now=Date.now()):V79Report{return this.buildReport(now,false);}

  recover(now=Date.now()):V79Report{
    const before=this.buildReport(now,false);
    let repaired=0;
    const safeEntryIssues=before.issues.filter(x=>x.action==='RECOVER_ENTRY'&&x.safeToRepair);
    const tx=db.transaction(()=>{
      for(const issue of safeEntryIssues){
        const commit=db.prepare(`SELECT * FROM v77_execution_commits WHERE mint=? AND status='COMMITTED' ORDER BY ts DESC LIMIT 1`).get(issue.mint) as any;
        if(!commit?.paper_result_json) continue;
        const paper=JSON.parse(commit.paper_result_json);
        const p=paper.position;
        if(!p||p.status!=='OPEN'||!p.id||!p.mint) continue;
        const exists=db.prepare(`SELECT 1 FROM v52_paper_positions WHERE id=? OR (mint=? AND status='OPEN') LIMIT 1`).get(p.id,p.mint);
        if(exists) continue;
        db.prepare(`INSERT INTO v52_paper_positions(id,mint,quantity,entry_price,current_price,entry_notional,fees,opened_at,high_price,stop_price,take_profit_price,trailing_price,status,realized_pnl,exit_price,exit_reason,closed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
          .run(p.id,p.mint,n(p.quantity),n(p.entryPrice),n(p.currentPrice),n(p.entryNotional),n(p.fees),n(p.openedAt),n(p.highPrice),n(p.stopPrice),n(p.takeProfitPrice),n(p.trailingPrice),'OPEN',n(p.realizedPnl),null,null,null);
        const eventExists=db.prepare(`SELECT 1 FROM v52_paper_events WHERE mint=? AND action='ENTER_PAPER' AND ts=? LIMIT 1`).get(p.mint,n(p.openedAt));
        if(!eventExists){
          db.prepare(`INSERT INTO v52_paper_events(id,ts,mint,action,reason,pnl,equity,cash,details_json) VALUES(?,?,?,?,?,?,?,?,?)`)
            .run(crypto.randomUUID(),n(p.openedAt),p.mint,'ENTER_PAPER','V79_RECOVERED_ENTRY',0,n(paper.equity),n(paper.cash),JSON.stringify({liveExecutionEnabled:false,recoveredFrom:'v77_execution_commits',commitId:commit.id}));
        }
        repaired++;
      }
    });
    tx();
    // The recovery transaction writes the durable ledger directly. Refresh the
    // in-memory V52 engine before building the post-recovery report so PAPER
    // state cannot disagree with the recovered V52 position/event ledger.
    if(repaired>0) this.loop.refreshFromLedger();
    const after=this.buildReport(now,true,repaired);
    this.persist(after);
    return after;
  }

  recent(limit=50){const nlim=Math.min(200,Math.max(1,limit));return db.prepare(`SELECT * FROM v79_recovery_snapshots ORDER BY ts DESC LIMIT ?`).all(nlim);}
  health(){const r=db.prepare(`SELECT state,action,repaired,ts FROM v79_recovery_snapshots ORDER BY ts DESC LIMIT 1`).get() as any;return {lastState:r?.state??'UNKNOWN',lastAction:r?.action??'NONE',lastRepaired:n(r?.repaired),lastTs:n(r?.ts),liveExecutionEnabled:false};}

  private buildReport(now:number,afterRecovery:boolean,repaired=0):V79Report{
    const commits=db.prepare(`SELECT * FROM v77_execution_commits WHERE status='COMMITTED'`).all() as any[];
    const exits=db.prepare(`SELECT * FROM v78_exit_commits WHERE status='EXIT_COMMITTED'`).all() as any[];
    const openRows=db.prepare(`SELECT * FROM v52_paper_positions WHERE status='OPEN'`).all() as any[];
    const closedRows=db.prepare(`SELECT * FROM v52_paper_positions WHERE status='CLOSED'`).all() as any[];
    const enterEvents=db.prepare(`SELECT * FROM v52_paper_events WHERE action='ENTER_PAPER'`).all() as any[];
    const exitEvents=db.prepare(`SELECT * FROM v52_paper_events WHERE action='EXIT_PAPER'`).all() as any[];
    const countsByMint=new Map<string,number>(); for(const r of openRows)countsByMint.set(String(r.mint),(countsByMint.get(String(r.mint))??0)+1);
    const duplicateMints=[...countsByMint.entries()].filter(([,c])=>c>1);
    const issues:V79Issue[]=[];

    const openMintSet=new Set(openRows.map(r=>String(r.mint)));
    for(const c of commits){const p=c.paper_result_json?JSON.parse(c.paper_result_json):null;const pm=p?.position?.mint??c.mint;if(p?.action==='ENTER_PAPER'&&!openMintSet.has(String(pm))){
      const alreadyClosed=db.prepare(`SELECT 1 FROM v52_paper_positions WHERE mint=? AND status='CLOSED' AND opened_at>=? LIMIT 1`).get(pm,n(p?.position?.openedAt)-1000);
      if(alreadyClosed) continue;
      issues.push({code:'V77_ENTRY_MISSING_FROM_POSITION_LEDGER',mint:String(pm),positionId:p?.position?.id,action:'RECOVER_ENTRY',safeToRepair:Boolean(p?.position?.status==='OPEN'),detail:'Committed Paper entry has no corresponding OPEN V52 position.'});
    }}
    const openByMint=new Set(openRows.map(r=>String(r.mint)));
    for(const e of exits){if(openByMint.has(String(e.mint)))issues.push({code:'V78_EXIT_WITH_OPEN_POSITION',mint:String(e.mint),positionId:String(e.position_id),action:'FLAG_EXIT_MISMATCH',safeToRepair:false,detail:'Exit commit exists while V52 still reports the position OPEN; no automatic close is performed because exit price is not persisted in V78.'});}
    for(const [mint,c] of duplicateMints)issues.push({code:'DUPLICATE_OPEN_MINT',mint,action:'FLAG_DUPLICATE',safeToRepair:false,detail:`V52 contains ${c} OPEN rows for one mint; automatic deletion would risk losing Paper state.`});
    const eventEnterMints=new Set(enterEvents.map(e=>String(e.mint)));
    for(const r of openRows)if(!eventEnterMints.has(String(r.mint)))issues.push({code:'OPEN_POSITION_WITHOUT_ENTRY_EVENT',mint:String(r.mint),positionId:String(r.id),action:'FLAG_LEDGER_MISMATCH',safeToRepair:false,detail:'OPEN position has no ENTER_PAPER event.'});

    const paperState=this.loop.state();
    const paper={cash:n(paperState.cash),equity:n(paperState.equity),realizedPnl:n(paperState.realizedPnl),unrealizedPnl:n(paperState.unrealizedPnl),openPositions:Array.isArray(paperState.openPositions)?paperState.openPositions.length:n(paperState.openPositions)};
    const realizedEvents=exitEvents.reduce((s,e)=>s+n(e.pnl),0);
    const eventLedgerConsistent=Math.abs(realizedEvents-n(paper.realizedPnl))<1e-6;
    if(!eventLedgerConsistent)issues.push({code:'REALIZED_PNL_EVENT_MISMATCH',action:'FLAG_LEDGER_MISMATCH',safeToRepair:false,detail:`V52 realized P&L ${paper.realizedPnl} differs from EXIT_PAPER event sum ${realizedEvents}.`});

    const uniqueCommittedMints=new Set(commits.map(c=>String(c.mint)));
    const coverage=commits.length?pct(commits.filter(c=>openMintSet.has(String(c.mint))||db.prepare(`SELECT 1 FROM v52_paper_positions WHERE mint=? AND status='CLOSED' LIMIT 1`).get(c.mint)).length,commits.length):100;
    const statePayload={commits:commits.map(c=>[c.id,c.status,c.mint,c.commit_key]),exits:exits.map(e=>[e.id,e.status,e.mint,e.exit_commit_key,e.realized_pnl]),open:openRows.map(r=>[r.id,r.mint,r.quantity,r.entry_price,r.current_price,r.opened_at]),closed:closedRows.map(r=>[r.id,r.mint,r.exit_price,r.realized_pnl,r.closed_at]),events:exitEvents.map(e=>[e.id,e.ts,e.mint,e.pnl]),paper};
    const stateHash=crypto.createHash('sha256').update(JSON.stringify(statePayload)).digest('hex');
    let state:V79State='HEALTHY'; let action:V79Action='NONE';
    // Any detected reconciliation issue makes the pre-recovery report DEGRADED,
    // including issues that are safe to repair automatically. Once the repair
    // has completed and no issues remain, the post-recovery state becomes
    // RECOVERED; unresolved unsafe issues remain DEGRADED.
    if(issues.length>0)state='DEGRADED';
    if(repaired>0 && issues.length===0)state='RECOVERED';
    if(afterRecovery && repaired>0 && issues.some(i=>!i.safeToRepair))state='DEGRADED';
    if(issues.some(i=>i.code==='REALIZED_PNL_EVENT_MISMATCH'))state='FAILED';
    if(repaired>0)action='RECOVER_ENTRY'; else if(issues[0])action=issues[0].action;
    return {id:crypto.randomUUID(),ts:now,state,action,repaired,issues,counts:{v77Committed:commits.length,v78Exits:exits.length,openRows:openRows.length,openMints:uniqueCommittedMints.size?openMintSet.size:openMintSet.size,duplicateOpenMints:duplicateMints.length,closedRows:closedRows.length,enterEvents:enterEvents.length,exitEvents:exitEvents.length},paper,consistency:{entryCommitCoverage:coverage,exitCommitCoverage:exits.length?pct(exits.filter(e=>!openMintSet.has(String(e.mint))).length,exits.length):100,duplicateFree:duplicateMints.length===0,eventLedgerConsistent},stateHash,liveExecutionEnabled:false};
  }

  private persist(report:V79Report){db.prepare(`INSERT INTO v79_recovery_snapshots(id,ts,state,action,repaired,report_json,state_hash) VALUES(?,?,?,?,?,?,?)`).run(report.id,report.ts,report.state,report.action,report.repaired,JSON.stringify(report),report.stateHash);}
}
