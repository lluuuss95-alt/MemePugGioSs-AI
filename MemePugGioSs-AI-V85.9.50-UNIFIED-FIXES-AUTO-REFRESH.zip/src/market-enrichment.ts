import { db } from './db.js';
import { enqueue, ingestQueue } from './ingestion.js';

type DexPair = {
  chainId?: string;
  dexId?: string;
  pairAddress?: string;
  baseToken?: { address?: string; name?: string; symbol?: string };
  priceUsd?: string;
  liquidity?: { usd?: number };
  volume?: { m5?: number };
  txns?: { m5?: { buys?: number; sells?: number } };
  pairCreatedAt?: number;
  url?: string;
};
type PumpCoin = { mint?: string; symbol?: string; name?: string; usd_market_cap?: number | string; market_cap?: number | string; total_supply?: number | string; decimals?: number | string; complete?: boolean; };

// Recheck shortly after startup and often enough to catch tokens that arrive
// just after the first cycle. Provider request budget remains below DexScreener's
// documented 300 requests/minute limit (batch + bounded per-token fallback).
const INTERVAL_MS = 60_000;
const BATCH_SIZE = 30;
const MAX_TOKENS_PER_CYCLE = 200;
const REQUEST_TIMEOUT_MS = 8_000;
// Keep individual probes deliberately low; batch lookup is the primary path.
const FALLBACK_TOKENS_PER_CYCLE = 1;
const RATE_LIMIT_COOLDOWN_MS = 120_000;
let providerCooldownUntil = 0;
let fallbackCursor = 0;
let timer: ReturnType<typeof setInterval> | undefined;
let running = false;
let cycleHadError = false;
function describeFetchError(stage: string, error: unknown): string {
  const e = error as { name?: string; message?: string; cause?: { code?: string; message?: string; name?: string } };
  const parts = [`${stage}: ${e?.name || 'Error'}: ${e?.message || String(error)}`];
  if (e?.cause) parts.push(`cause=${e.cause.code || e.cause.name || 'unknown'}:${e.cause.message || ''}`);
  return parts.join(' | ').slice(0, 500);
}
function recordFetchError(stage: string, error: unknown) {
  cycleHadError = true;
  const e = error as { message?: string; retryAfterMs?: number };
  if (String(e?.message || error).includes('HTTP_429')) {
    const requestedDelay = Number(e?.retryAfterMs ?? 0);
    providerCooldownUntil = Date.now() + Math.max(RATE_LIMIT_COOLDOWN_MS, requestedDelay);
  }
  health.lastError = describeFetchError(stage, error);
}
const health = {
  status: 'IDLE' as 'IDLE' | 'RUNNING' | 'OK' | 'DEGRADED' | 'WAITING_FOR_TOKENS',
  lastRunAt: null as string | null,
  lastSuccessAt: null as string | null,
  lastError: '',
  tokensChecked: 0,
  pairsMatched: 0,
  observationsQueued: 0,
  requests: 0,
  tokensWithoutPair: 0,
  tokensWithoutPrice: 0,
  lastMissingMints: [] as string[],
  pumpFunFallbacks: 0,
  pumpFunPrices: 0,
  dexTokenPairProbes: 0,
  dexTokenPairErrors: 0,
  pumpFunNotFound: 0,
};

export function marketEnrichmentStatus() {
  // Expose the inventory and queue independently from market-provider results.
  // This distinguishes an empty token pipeline from a provider returning no pairs.
  const inventory = db.prepare(`SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN length(mint) >= 32 AND length(mint) <= 44 THEN 1 ELSE 0 END) AS eligible,
    SUM(CASE WHEN source = 'pumpportal-new-token' THEN 1 ELSE 0 END) AS pumpPortal
    FROM tokens`).get() as { total?: number; eligible?: number; pumpPortal?: number };
  return {
    ...health,
    inventoryTokens: Number(inventory.total ?? 0),
    eligibleTokens: Number(inventory.eligible ?? 0),
    pumpPortalTokens: Number(inventory.pumpPortal ?? 0),
    ingestionQueueDepth: ingestQueue.size,
    configured: true,
    provider: 'DexScreener',
    intervalMs: INTERVAL_MS,
  };
}

/** Adds observed market data to the local paper/shadow database. Never trades. */
export function startMarketEnrichment() {
  if (timer) return;
  // Delay the first batch slightly so the HTTP server and primary feed can start.
  setTimeout(() => { void runMarketEnrichment(); }, 3_000);
  timer = setInterval(() => { void runMarketEnrichment(); }, INTERVAL_MS);
}

export async function runMarketEnrichment() {
  if (running) return marketEnrichmentStatus();
  running = true;
  health.status = 'RUNNING';
  health.lastRunAt = new Date().toISOString();
  health.lastError = '';
  cycleHadError = false;
  health.tokensChecked = 0;
  health.pairsMatched = 0;
  health.observationsQueued = 0;
  health.tokensWithoutPair = 0;
  health.tokensWithoutPrice = 0;
  health.lastMissingMints = [];
  health.pumpFunFallbacks = 0;
  health.pumpFunPrices = 0;
  health.dexTokenPairProbes = 0;
  health.dexTokenPairErrors = 0;
  health.pumpFunNotFound = 0;
  try {
    if (Date.now() < providerCooldownUntil) {
      health.status = 'DEGRADED';
      health.lastError = `DEXSCREENER_RATE_LIMIT_COOLDOWN: retry in ${Math.ceil((providerCooldownUntil - Date.now()) / 1000)}s`;
      return marketEnrichmentStatus();
    }
    const tokens = db.prepare(
      `SELECT mint,symbol,name FROM tokens WHERE length(mint)>=32 AND length(mint)<=44 ORDER BY last_seen DESC LIMIT ?`
    ).all(MAX_TOKENS_PER_CYCLE) as Array<{ mint: string; symbol: string | null; name: string | null }>;
    if (tokens.length === 0) {
      health.status = 'WAITING_FOR_TOKENS';
      health.lastError = ingestQueue.size > 0
        ? `WAITING_FOR_INGESTION: queue=${ingestQueue.size}, inventory=${Number((db.prepare('SELECT COUNT(*) AS n FROM tokens').get() as { n?: number }).n ?? 0)}`
        : 'WAITING_FOR_ELIGIBLE_TOKENS: no token mints of 32–44 characters are persisted yet';
      return marketEnrichmentStatus();
    }
    const seenAt = Date.now();
    const fallbackStart = fallbackCursor % Math.max(1, tokens.length);
    fallbackCursor = (fallbackStart + FALLBACK_TOKENS_PER_CYCLE) % Math.max(1, tokens.length);
    for (let offset = 0; offset < tokens.length; offset += BATCH_SIZE) {
      const batch = tokens.slice(offset, offset + BATCH_SIZE);
      if (!batch.length) continue;
      const addresses = batch.map(t => t.mint).join(',');
      health.tokensChecked += batch.length;
      let pairs: DexPair[] = [];
      try {
        health.requests++;
        const response = await fetch(`https://api.dexscreener.com/tokens/v1/solana/${addresses}`, {
          headers: { accept: 'application/json' },
          signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
        });
        if (!response.ok) {
          const retryAfter = Number(response.headers.get('retry-after') ?? 0);
          const err = new Error(`DEXSCREENER_HTTP_${response.status}`) as Error & { retryAfterMs?: number };
          if (response.status === 429 && Number.isFinite(retryAfter) && retryAfter > 0) err.retryAfterMs = retryAfter * 1000;
          throw err;
        }
        const body: unknown = await response.json();
        if (!Array.isArray(body)) throw new Error('DEXSCREENER_INVALID_RESPONSE');
        pairs = body as DexPair[];
      } catch (error) {
        // A failed batch must not abort the cycle: per-token DexScreener and
        // Pump.fun fallback probes below may still work and record the root cause.
        recordFetchError('DexScreener batch request', error);
      }
      const byMint = new Map<string, DexPair>();
      for (const pair of pairs) {
        if (pair.chainId && pair.chainId !== 'solana') continue;
        const mint = pair.baseToken?.address;
        if (!mint || !batch.some(t => t.mint === mint)) continue;
        const current = byMint.get(mint);
        const liquidity = Number(pair.liquidity?.usd ?? 0);
        const currentLiquidity = Number(current?.liquidity?.usd ?? 0);
        if (!current || liquidity > currentLiquidity) byMint.set(mint, pair);
      }
      for (const token of batch) {
        let pair = byMint.get(token.mint);
        if (Date.now() < providerCooldownUntil) {
          health.tokensWithoutPair++;
          health.lastMissingMints.push(token.mint);
          continue;
        }
        const tokenIndex = tokens.findIndex(t => t.mint === token.mint);
        const fallbackOffset = (tokenIndex - fallbackStart + tokens.length) % Math.max(1, tokens.length);
        const shouldProbeFallback = !cycleHadError && fallbackOffset < FALLBACK_TOKENS_PER_CYCLE;
        // Some very new pairs are omitted by the multi-token endpoint; retry a small
        // number individually so discovery can populate prices without flooding the provider.
        if (!pair && shouldProbeFallback) {
          // Use DexScreener's documented per-token market endpoint. Pump.fun's
          // coin-detail endpoint may require a session/JWT and has been returning
          // HTTP 404 in production, so it is not used as a price source here.
          try {
            health.requests++;
            health.dexTokenPairProbes++;
            const single = await fetch(`https://api.dexscreener.com/token-pairs/v1/solana/${encodeURIComponent(token.mint)}`, {
              headers: { accept: 'application/json' },
              signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
            });
            if (!single.ok) {
              const retryAfter = Number(single.headers.get('retry-after') ?? 0);
              const err = new Error(`DEXSCREENER_TOKEN_PAIRS_HTTP_${single.status}`) as Error & { retryAfterMs?: number };
              if (single.status === 429 && Number.isFinite(retryAfter) && retryAfter > 0) err.retryAfterMs = retryAfter * 1000;
              throw err;
            }
            const result: unknown = await single.json();
            const candidates: DexPair[] = Array.isArray(result) ? result as DexPair[] : [];
            pair = candidates
              .filter(p => (!p.chainId || p.chainId === 'solana') && p.baseToken?.address === token.mint)
              .sort((a, b) => Number(b.liquidity?.usd ?? 0) - Number(a.liquidity?.usd ?? 0))[0];
          } catch (error) {
            health.dexTokenPairErrors++;
            recordFetchError('DexScreener token-pairs request', error);
          }
        }
        if (!pair) {
          health.tokensWithoutPair++;
          health.lastMissingMints.push(token.mint);
          // No verified market pair means no defensible market price. Keep the
          // price blank rather than deriving one from an unauthenticated Pump.fun
          // endpoint or inventing a value.
          continue;
        }
        const price = Number(pair.priceUsd);
        const liquidity = Number(pair.liquidity?.usd);
        const volume5m = Number(pair.volume?.m5);
        const buys = Number(pair.txns?.m5?.buys ?? 0);
        const sells = Number(pair.txns?.m5?.sells ?? 0);
        const txTotal = buys + sells;
        const buyPressure = txTotal > 0 ? buys / txTotal : undefined;
        const createdAt = Number(pair.pairCreatedAt);
        const ageSeconds = Number.isFinite(createdAt) && createdAt > 0 ? Math.max(0, Math.floor((seenAt - createdAt) / 1000)) : undefined;
        // Only enqueue genuinely observed, finite positive market values.
        const validPrice = Number.isFinite(price) && price > 0 ? price : undefined;
        if (validPrice === undefined) health.tokensWithoutPrice++;
        const validLiquidity = Number.isFinite(liquidity) && liquidity >= 0 ? liquidity : undefined;
        const validVolume = Number.isFinite(volume5m) && volume5m >= 0 ? volume5m : undefined;
        if (validPrice === undefined && validLiquidity === undefined && validVolume === undefined) continue;
        const observedAt = new Date(seenAt).toISOString();
        enqueue({
          eventId: `dexscreener:${token.mint}:${Math.floor(seenAt / INTERVAL_MS)}`,
          mint: token.mint,
          symbol: pair.baseToken?.symbol || token.symbol || undefined,
          name: pair.baseToken?.name || token.name || undefined,
          source: 'dexscreener-market-observation',
          eventTime: observedAt,
          price: validPrice,
          liquidity: validLiquidity,
          volume5m: validVolume,
          ageSeconds,
          buyPressure,
          raw: { provider: 'DexScreener', pairAddress: pair.pairAddress, dexId: pair.dexId, pairUrl: pair.url, buys5m: buys, sells5m: sells, observedAt },
        });
        health.pairsMatched++;
        health.observationsQueued++;
      }
    }
    const missingMarketData = health.tokensChecked > 0 && health.pairsMatched === 0 && health.observationsQueued === 0;
    health.status = cycleHadError || missingMarketData ? 'DEGRADED' : 'OK';
    if (missingMarketData && !health.lastError) health.lastError = `NO_VERIFIED_MARKET_DATA: checked=${health.tokensChecked}, pairs=${health.pairsMatched}, observations=${health.observationsQueued}`;
    if (!cycleHadError && !missingMarketData) health.lastSuccessAt = new Date().toISOString();
  } catch (error) {
    health.status = 'DEGRADED';
    health.lastError = String(error);
  } finally {
    running = false;
  }
  return marketEnrichmentStatus();
}
