import { db } from './db.js';

export type V86RiskDecision = 'REJECTED' | 'WATCH' | 'CANDIDATE';
export interface V86RiskReview {
  mint: string; symbol: string; name: string; riskScore: number; decision: V86RiskDecision;
  reasons: string[]; checks: Record<string, 'PASS'|'WARN'|'FAIL'|'UNKNOWN'>; checkedAt: string;
  liquidityUsd: number|null; holders: number|null; largestHolderPct: number|null; top10HolderPct: number|null;
  mintAuthorityPresent: boolean|null; freezeAuthorityPresent: boolean|null; marketDataAgeSeconds: number|null;
}

db.exec(`CREATE TABLE IF NOT EXISTS v86_token_risk_reviews(
 mint TEXT PRIMARY KEY, symbol TEXT, name TEXT, risk_score INTEGER NOT NULL, decision TEXT NOT NULL,
 reasons_json TEXT NOT NULL, checks_json TEXT NOT NULL, liquidity_usd REAL, holders INTEGER,
 largest_holder_pct REAL, top10_holder_pct REAL, mint_authority_present INTEGER, freeze_authority_present INTEGER,
 market_data_age_seconds INTEGER, checked_at TEXT NOT NULL
)`);

function finite(value: unknown): number|null { const n=Number(value); return value===null||value===undefined||value===''||!Number.isFinite(n)?null:n; }
function review(row:any): V86RiskReview {
  const now=Date.now(); const observed=Date.parse(String(row.observed_at||''));
  const age=Number.isFinite(observed)?Math.max(0,Math.floor((now-observed)/1000)):null;
  const liq=finite(row.liquidity), holdersRaw=finite(row.holders), largest=finite(row.largest_holder_pct), top10=finite(row.top10_holder_pct);
  const mintAuth=row.mint_authority_present===0||row.mint_authority_present===1?Boolean(row.mint_authority_present):null;
  const freezeAuth=row.freeze_authority_present===0||row.freeze_authority_present===1?Boolean(row.freeze_authority_present):null;
  let score=0; const reasons:string[]=[]; const checks:Record<string,'PASS'|'WARN'|'FAIL'|'UNKNOWN'>={}; let insufficient=false;
  if(mintAuth===null){checks.mintAuthority='UNKNOWN';insufficient=true;reasons.push('Autorità mint non verificata');} else if(mintAuth){score+=20;checks.mintAuthority='WARN';insufficient=true;reasons.push('Mint authority ancora attiva');} else {checks.mintAuthority='PASS';}
  if(freezeAuth===null){checks.freezeAuthority='UNKNOWN';insufficient=true;reasons.push('Autorità freeze non verificata');} else if(freezeAuth){score+=25;checks.freezeAuthority='FAIL';reasons.push('Freeze authority ancora attiva');} else checks.freezeAuthority='PASS';
  if(largest===null){checks.largestHolder='UNKNOWN';insufficient=true;reasons.push('Concentrazione del maggiore holder non verificata');} else if(largest>=25){score+=20;checks.largestHolder='FAIL';reasons.push(`Holder maggiore concentra ${largest.toFixed(1)}%`);} else if(largest>=10){score+=10;checks.largestHolder='WARN';reasons.push(`Concentrazione holder maggiore elevata (${largest.toFixed(1)}%)`);} else checks.largestHolder='PASS';
  if(top10===null){checks.top10Holders='UNKNOWN';insufficient=true;reasons.push('Concentrazione top 10 holder non verificata');} else if(top10>=70){score+=20;checks.top10Holders='FAIL';reasons.push(`Top 10 holder concentrano ${top10.toFixed(1)}%`);} else if(top10>=40){score+=10;checks.top10Holders='WARN';reasons.push(`Concentrazione top 10 holder elevata (${top10.toFixed(1)}%)`);} else checks.top10Holders='PASS';
  if(holdersRaw===null){checks.holders='UNKNOWN';insufficient=true;reasons.push('Numero holder non disponibile');} else if(holdersRaw<20){score+=20;checks.holders='WARN';reasons.push(`Numero holder molto basso (${Math.trunc(holdersRaw)})`);} else if(holdersRaw<100){score+=10;checks.holders='WARN';reasons.push(`Numero holder limitato (${Math.trunc(holdersRaw)})`);} else checks.holders='PASS';
  if(liq===null||liq<=0){checks.liquidity='UNKNOWN';insufficient=true;score+=15;reasons.push('Liquidità verificata non disponibile');} else if(liq<1000){score+=25;checks.liquidity='FAIL';reasons.push(`Liquidità molto bassa ($${Math.round(liq)})`);} else if(liq<5000){score+=15;checks.liquidity='WARN';reasons.push(`Liquidità limitata ($${Math.round(liq)})`);} else checks.liquidity='PASS';
  if(age===null){checks.marketFreshness='UNKNOWN';insufficient=true;reasons.push('Freschezza dati di mercato non verificabile');} else if(age>90){checks.marketFreshness='WARN';insufficient=true;reasons.push(`Dati di mercato non aggiornati (${age}s)`);} else checks.marketFreshness='PASS';
  // LP burn/lock and sellability require pool-specific on-chain evidence. Never infer them from liquidity alone.
  checks.lpLock='UNKNOWN'; checks.sellability='UNKNOWN';
  // Fail closed: a token cannot become CANDIDATE while LP custody/lock and sellability
  // have not been verified with pool-specific on-chain evidence.
  insufficient=true;
  reasons.push('Blocco/burn LP da verificare con dati specifici della pool');
  reasons.push('Vendibilità simulata non verificata da questo controllo');
  score=Math.max(0,Math.min(100,score));
  const critical=checks.freezeAuthority==='FAIL'||checks.largestHolder==='FAIL'||checks.top10Holders==='FAIL'||checks.liquidity==='FAIL';
  const decision:V86RiskDecision=critical||score>=75?'REJECTED':insufficient||score>=35?'WATCH':'CANDIDATE';
  if(!reasons.length)reasons.push('Controlli base superati; restano necessari controlli di pool e vendibilità');
  return {mint:String(row.mint),symbol:String(row.symbol||''),name:String(row.name||''),riskScore:score,decision,reasons,checks,checkedAt:new Date(now).toISOString(),liquidityUsd:liq,holders:holdersRaw===null?null:Math.trunc(holdersRaw),largestHolderPct:largest,top10HolderPct:top10,mintAuthorityPresent:mintAuth,freezeAuthorityPresent:freezeAuth,marketDataAgeSeconds:age};
}

export function scanV86Tokens(limit=250) {
  const safeLimit=Math.max(1,Math.min(1000,Math.trunc(limit)||250));
  const rows=db.prepare(`SELECT t.mint,t.symbol,t.name,i.largest_holder_pct,i.top10_holder_pct,i.mint_authority_present,i.freeze_authority_present,
    (SELECT o.liquidity FROM observations o WHERE o.mint=t.mint AND o.quality='OK' ORDER BY o.observed_at DESC,o.id DESC LIMIT 1) liquidity,
    (SELECT o.holders FROM observations o WHERE o.mint=t.mint AND o.quality='OK' ORDER BY o.observed_at DESC,o.id DESC LIMIT 1) holders,
    (SELECT o.observed_at FROM observations o WHERE o.mint=t.mint AND o.quality='OK' ORDER BY o.observed_at DESC,o.id DESC LIMIT 1) observed_at
    FROM tokens t LEFT JOIN token_intelligence i ON i.mint=t.mint ORDER BY t.last_seen DESC LIMIT ?`).all(safeLimit) as any[];
  const persist=db.prepare(`INSERT INTO v86_token_risk_reviews(mint,symbol,name,risk_score,decision,reasons_json,checks_json,liquidity_usd,holders,largest_holder_pct,top10_holder_pct,mint_authority_present,freeze_authority_present,market_data_age_seconds,checked_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(mint) DO UPDATE SET symbol=excluded.symbol,name=excluded.name,risk_score=excluded.risk_score,decision=excluded.decision,reasons_json=excluded.reasons_json,checks_json=excluded.checks_json,liquidity_usd=excluded.liquidity_usd,holders=excluded.holders,largest_holder_pct=excluded.largest_holder_pct,top10_holder_pct=excluded.top10_holder_pct,mint_authority_present=excluded.mint_authority_present,freeze_authority_present=excluded.freeze_authority_present,market_data_age_seconds=excluded.market_data_age_seconds,checked_at=excluded.checked_at`);
  const tx=db.transaction(()=>rows.map(row=>{const r=review(row);persist.run(r.mint,r.symbol,r.name,r.riskScore,r.decision,JSON.stringify(r.reasons),JSON.stringify(r.checks),r.liquidityUsd,r.holders,r.largestHolderPct,r.top10HolderPct,r.mintAuthorityPresent===null?null:Number(r.mintAuthorityPresent),r.freezeAuthorityPresent===null?null:Number(r.freezeAuthorityPresent),r.marketDataAgeSeconds,r.checkedAt);return r;}));
  const reviews:V86RiskReview[]=tx();
  return {version:'V86.6.28',mode:'PAPER/SHADOW',liveExecutionEnabled:false,scanned:reviews.length,summary:{rejected:reviews.filter((r:V86RiskReview)=>r.decision==='REJECTED').length,watch:reviews.filter((r:V86RiskReview)=>r.decision==='WATCH').length,candidates:reviews.filter((r:V86RiskReview)=>r.decision==='CANDIDATE').length},checkedAt:new Date().toISOString(),reviews};
}
export function listV86Reviews(limit=100,decision?:string) {
 const n=Math.max(1,Math.min(500,Math.trunc(limit)||100)); const valid=['REJECTED','WATCH','CANDIDATE']; const d=valid.includes(String(decision))?String(decision):null;
 const rows:any[]=d?db.prepare('SELECT * FROM v86_token_risk_reviews WHERE decision=? ORDER BY checked_at DESC LIMIT ?').all(d,n):db.prepare('SELECT * FROM v86_token_risk_reviews ORDER BY checked_at DESC LIMIT ?').all(n);
 return rows.map((r:any)=>({...r,reasons:safeJson(r.reasons_json),checks:safeJson(r.checks_json)}));
}
function safeJson(v:string){try{return JSON.parse(v)}catch{return []}}
export function v86RiskSummary(){const rows:any[]=db.prepare('SELECT decision,COUNT(*) count,MAX(checked_at) checked_at FROM v86_token_risk_reviews GROUP BY decision').all();return {version:'V86.6.28',mode:'PAPER/SHADOW',liveExecutionEnabled:false,counts:Object.fromEntries(rows.map(r=>[r.decision,Number(r.count)])),lastCheckedAt:rows.map((r:any)=>r.checked_at).filter(Boolean).sort().slice(-1)[0]||null,method:'Heuristic filter; incomplete checks remain WATCH. Not a guarantee of safety.'};}
