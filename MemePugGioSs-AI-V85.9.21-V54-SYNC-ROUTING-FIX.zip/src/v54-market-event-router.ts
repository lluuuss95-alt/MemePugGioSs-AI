import crypto from 'node:crypto';
import { db } from './db.js';
import type { V48Candidate } from './v48-ultra-discovery.js';
import type { V53Tick, V53Result, V53TradeSupervisor } from './v53-trade-supervisor.js';

export type V54EventType='PUMP_DISCOVERY'|'MARKET_TICK'|'POSITION_HEARTBEAT';
export type V54Priority='CRITICAL'|'HIGH'|'NORMAL'|'LOW';
export interface V54Event<T=unknown>{id:string;type:V54EventType;mint:string;signature?:string;slot?:number;sequence:number;receivedAt:number;priority:V54Priority;payload:T;}
export interface V54Config{maxQueue:number;maxSeen:number;maxPerMint:number;maxEventAgeMs:number;heartbeatIntervalMs:number;}
export interface V54Health{state:'STOPPED'|'RUNNING'|'DEGRADED'|'HALTED';queued:number;inFlight:number;eventsIn:number;eventsRouted:number;duplicates:number;dropped:number;failed:number;lastEventAt:number|null;lastRoutedAt:number|null;lastSlot:number|null;activeMints:number;}
export interface V54Callbacks{onDiscovery?(c:V48Candidate):void|Promise<void>;onMarketTick?(t:V53Tick):V53Result|void|Promise<V53Result|void>;onHeartbeat?(mint:string,now:number):void|Promise<void>;onError?(e:Error,event?:V54Event):void;}

export const defaultV54Config:V54Config=Object.freeze({maxQueue:5000,maxSeen:100000,maxPerMint:100,maxEventAgeMs:15000,heartbeatIntervalMs:1000});

interface QueueItem extends V54Event{}

/**
 * V54 is the deterministic event spine between realtime Solana/Pump.fun feeds and
 * the downstream AI/position layers. It does not decode economics or invent prices.
 * Ordering is enforced per mint, duplicates are suppressed, and bursts are bounded.
 */
export class V54MarketEventRouter{
 private readonly cfg:V54Config; private readonly queue:QueueItem[]=[]; private readonly seen=new Set<string>();
 private readonly seqByMint=new Map<string,number>(); private readonly lastSeqByMint=new Map<string,number>();
 private readonly lastHeartbeat=new Map<string,number>(); private running=false; private draining=false;
 private healthState:V54Health={state:'STOPPED',queued:0,inFlight:0,eventsIn:0,eventsRouted:0,duplicates:0,dropped:0,failed:0,lastEventAt:null,lastRoutedAt:null,lastSlot:null,activeMints:0};
 constructor(private readonly callbacks:V54Callbacks={},cfg:Partial<V54Config>={}){this.cfg={...defaultV54Config,...cfg,maxQueue:Math.max(1,Math.floor(cfg.maxQueue??defaultV54Config.maxQueue)),maxSeen:Math.max(100,Math.floor(cfg.maxSeen??defaultV54Config.maxSeen)),maxPerMint:Math.max(1,Math.floor(cfg.maxPerMint??defaultV54Config.maxPerMint))};this.ensureSchema();}
 private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v54_router_events(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,type TEXT NOT NULL,mint TEXT NOT NULL,signature TEXT,slot INTEGER,sequence INTEGER NOT NULL,priority TEXT NOT NULL,status TEXT NOT NULL,latency_ms INTEGER NOT NULL,details_json TEXT NOT NULL)`);db.exec(`CREATE TABLE IF NOT EXISTS v54_router_cursors(mint TEXT PRIMARY KEY,last_sequence INTEGER NOT NULL,last_slot INTEGER)`);}
 start(){this.running=true;this.setHealth({state:'RUNNING'});void this.drain();}
 stop(){this.running=false;this.queue.length=0;this.setHealth({state:'STOPPED',queued:0});}
 halt(){this.running=false;this.setHealth({state:'HALTED'});}
 health(){return {...this.healthState};}

 enqueue<T>(event:Omit<V54Event<T>,'id'|'sequence'> & {id?:string}):boolean{
  const receivedAt=event.receivedAt||Date.now(); this.healthState.eventsIn++; this.setHealth({eventsIn:this.healthState.eventsIn,lastEventAt:receivedAt});
  if(!event.mint){this.healthState.dropped++;this.setHealth({dropped:this.healthState.dropped});return false;}
  const id=event.id??this.fingerprint(event); if(this.seen.has(id)){this.healthState.duplicates++;this.setHealth({duplicates:this.healthState.duplicates});return false;}
  if(Date.now()-receivedAt>this.cfg.maxEventAgeMs){this.healthState.dropped++;this.setHealth({dropped:this.healthState.dropped});return false;}
  this.remember(this.seen,id);
  const seq=(this.seqByMint.get(event.mint)??0)+1; this.seqByMint.set(event.mint,seq);
  if(this.queue.length>=this.cfg.maxQueue){const idx=this.findDropIndex();this.queue.splice(idx,1);this.healthState.dropped++;}
  this.queue.push({...event,id,sequence:seq,receivedAt});this.healthState.activeMints=this.seqByMint.size;this.setHealth({queued:this.queue.length});
  if(this.running)void this.drain(); return true;
 }
 ingestDiscovery(candidate:V48Candidate){return this.enqueue({type:'PUMP_DISCOVERY',mint:candidate.token.mint,signature:candidate.signature,slot:candidate.slot,receivedAt:candidate.receivedAt,priority:candidate.priority==='P0'?'HIGH':candidate.priority==='P1'?'NORMAL':'LOW',payload:candidate});}
 ingestMarketTick(tick:V53Tick,priority:V54Priority='HIGH'){return this.enqueue({type:'MARKET_TICK',mint:tick.mint,receivedAt:Date.now(),priority,payload:tick});}
 heartbeat(now=Date.now()):number{let n=0;for(const mint of this.seqByMint.keys()){const last=this.lastHeartbeat.get(mint)??0;if(now-last>=this.cfg.heartbeatIntervalMs){this.lastHeartbeat.set(mint,now);this.enqueue({type:'POSITION_HEARTBEAT',mint,receivedAt:now,priority:'CRITICAL',payload:{mint,now}});n++;}}return n;}

 recentEvents(limit=100){return db.prepare(`SELECT * FROM v54_router_events ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}

 private async drain(){if(this.draining)return;this.draining=true;try{while(this.running&&this.queue.length){const item=this.popNext();if(!item)break;this.setHealth({queued:this.queue.length,inFlight:1});await this.route(item);this.setHealth({inFlight:0});}}finally{this.draining=false;}}
 private popNext(){if(!this.queue.length)return undefined;let best=0;for(let i=1;i<this.queue.length;i++){if(this.rank(this.queue[i].priority)>this.rank(this.queue[best].priority))best=i;else if(this.queue[i].priority===this.queue[best].priority&&this.queue[i].sequence<this.queue[best].sequence)best=i;}return this.queue.splice(best,1)[0];}
 private rank(p:V54Priority){return p==='CRITICAL'?4:p==='HIGH'?3:p==='NORMAL'?2:1;}
 private route(e:QueueItem){const now=Date.now();try{const prev=this.lastSeqByMint.get(e.mint)??0;if(e.sequence<=prev){this.healthState.duplicates++;this.persist(e,'DUPLICATE',now-e.receivedAt);this.setHealth({duplicates:this.healthState.duplicates});return;}this.lastSeqByMint.set(e.mint,e.sequence);const prevSlot=this.healthState.lastSlot;if(e.slot!==undefined&&prevSlot!==null&&e.slot<prevSlot){this.persist(e,'OUT_OF_ORDER_SLOT',now-e.receivedAt);this.healthState.dropped++;this.setHealth({dropped:this.healthState.dropped});return;}
   if(e.slot!==undefined)this.healthState.lastSlot=e.slot;
   let result:void|Promise<void>|V53Result|Promise<V53Result|void>;
   if(e.type==='PUMP_DISCOVERY') result=this.callbacks.onDiscovery?.(e.payload as V48Candidate);
   else if(e.type==='MARKET_TICK') result=this.callbacks.onMarketTick?.(e.payload as V53Tick);
   else result=this.callbacks.onHeartbeat?.(e.mint,(e.payload as any).now??now);
   const finish=()=>{this.healthState.eventsRouted++;this.healthState.lastRoutedAt=now;this.setHealth({eventsRouted:this.healthState.eventsRouted,lastRoutedAt:now,state:'RUNNING'});this.persist(e,'ROUTED',now-e.receivedAt);};
   if(result && typeof (result as any).then==='function') return (result as Promise<any>).then(()=>finish());
   finish();this.healthState.lastRoutedAt=now;this.setHealth({eventsRouted:this.healthState.eventsRouted,lastRoutedAt:now,state:'RUNNING'});this.persist(e,'ROUTED',now-e.receivedAt);
  }catch(err){this.healthState.failed++;this.setHealth({failed:this.healthState.failed,state:'DEGRADED'});this.persist(e,'FAILED',now-e.receivedAt);await this.callbacks.onError?.(err instanceof Error?err:new Error(String(err)),e);}}
 private persist(e:QueueItem,status:string,latency:number){db.prepare(`INSERT OR REPLACE INTO v54_router_events(id,ts,type,mint,signature,slot,sequence,priority,status,latency_ms,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(e.id,e.receivedAt,e.type,e.mint,e.signature??null,e.slot??null,e.sequence,e.priority,status,Math.max(0,Math.round(latency)),JSON.stringify({liveExecutionEnabled:false}));}
 private fingerprint(e:any){return crypto.createHash('sha256').update(JSON.stringify([e.type,e.mint,e.signature??'',e.slot??0,e.receivedAt,e.payload?.price??'',e.payload?.id??''])).digest('hex');}
 private remember(set:Set<string>,id:string){set.add(id);while(set.size>this.cfg.maxSeen){const first=set.values().next().value;if(first)set.delete(first);}}
 private findDropIndex(){let idx=0;let rank=this.rank(this.queue[0].priority);for(let i=1;i<this.queue.length;i++){const r=this.rank(this.queue[i].priority);if(r<rank){rank=r;idx=i;}}return idx;}
 private setHealth(p:Partial<V54Health>){this.healthState={...this.healthState,...p};}
}

export const V54_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV54Safe(){if(!V54_SAFETY.shadowOnly||V54_SAFETY.signingEnabled||V54_SAFETY.privateKeyAccess||V54_SAFETY.broadcastEnabled||V54_SAFETY.liveExecutionAllowed)throw new Error('V54_SAFETY_INVARIANT_FAILED');}
