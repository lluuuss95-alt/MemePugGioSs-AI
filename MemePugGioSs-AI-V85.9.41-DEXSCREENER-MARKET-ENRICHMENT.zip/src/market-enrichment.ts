import { db } from './db.js';
import { enqueue } from './ingestion.js';

type DexPair = {
  chainId?: string;
  dexId?: string;
  pairAddress?: string;
  baseToken?: { address?: string; name?: string; symbol?: string };
  priceUsd?: string;
  liquidity?: { usd?: number };
  volume?: { m5?: number };
  txns?: { m5?: { buys?: number; sells?: number } };
  pairCreatedAt?: number;
  url?: string;
};
type PumpCoin = { mint?: string; symbol?: string; name?: string; usd_market_cap?: number | string; market_cap?: number | string; total_supply?: number | string; decimals?: number | string; complete?: boolean; };

const INTERVAL_MS = 60_000;
const BATCH_SIZE = 30;
const MAX_TOKENS_PER_CYCLE = 200;
const REQUEST_TIMEOUT_MS = 8_000;
const FALLBACK_TOKENS_PER_CYCLE = 10;
let fallbackCursor = 0;
let timer: ReturnType<typeof setInterval> | undefined;
let running = false;
let cycleHadError = false;
function describeFetchError(stage: string, error: unknown): string {
  const e = error as { name?: string; message?: string; cause?: { code?: string; message?: string; name?: string } };
  const parts = [`${stage}: ${e?.name || 'Error'}: ${e?.message || String(error)}`];
  if (e?.cause) parts.push(`cause=${e.cause.code || e.cause.name || 'unknown'}:${e.cause.message || ''}`);
  return parts.join(' | ').slice(0, 500);
}
function recordFetchError(stage: string, error: unknown) {
  cycleHadError = true;
  health.lastError = describeFetchError(stage, error);
}
const health = {
  status: 'IDLE' as 'IDLE' | 'RUNNING' | 'OK' | 'DEGRADED',
  lastRunAt: null as string | null,
  lastSuccessAt: null as string | null,
  lastError: '',
  tokensChecked: 0,
  pairsMatched: 0,
  observationsQueued: 0,
  requests: 0,
  tokensWithoutPair: 0,
  tokensWithoutPrice: 0,
  lastMissingMints: [] as string[],
  pumpFunFallbacks: 0,
  pumpFunPrices: 0,
};

export function marketEnrichmentStatus() { return { ...health, configured: true, provider: 'DexScreener', intervalMs: INTERVAL_MS }; }

/** Adds observed market data to the local paper/shadow database. Never trades. */
export function startMarketEnrichment() {
  if (timer) return;
  // Delay the first batch slightly so the HTTP server and primary feed can start.
  setTimeout(() => { void runMarketEnrichment(); }, 8_000);
  timer = setInterval(() => { void runMarketEnrichment(); }, INTERVAL_MS);
}

export async function runMarketEnrichment() {
  if (running) return marketEnrichmentStatus();
  running = true;
  health.status = 'RUNNING';
  health.lastRunAt = new Date().toISOString();
  health.lastError = '';
  cycleHadError = false;
  health.tokensChecked = 0;
  health.pairsMatched = 0;
  health.observationsQueued = 0;
  health.tokensWithoutPair = 0;
  health.tokensWithoutPrice = 0;
  health.lastMissingMints = [];
  health.pumpFunFallbacks = 0;
  health.pumpFunPrices = 0;
  try {
    const tokens = db.prepare(
      `SELECT mint,symbol,name FROM tokens WHERE length(mint)>=32 AND length(mint)<=44 ORDER BY last_seen DESC LIMIT ?`
    ).all(MAX_TOKENS_PER_CYCLE) as Array<{ mint: string; symbol: string | null; name: string | null }>;
    const seenAt = Date.now();
    const fallbackStart = fallbackCursor % Math.max(1, tokens.length);
    fallbackCursor = (fallbackStart + FALLBACK_TOKENS_PER_CYCLE) % Math.max(1, tokens.length);
    for (let offset = 0; offset < tokens.length; offset += BATCH_SIZE) {
      const batch = tokens.slice(offset, offset + BATCH_SIZE);
      if (!batch.length) continue;
      const addresses = batch.map(t => t.mint).join(',');
      health.tokensChecked += batch.length;
      let pairs: DexPair[] = [];
      try {
        health.requests++;
        const response = await fetch(`https://api.dexscreener.com/tokens/v1/solana/${addresses}`, {
          headers: { accept: 'application/json' },
          signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
        });
        if (!response.ok) throw new Error(`DEXSCREENER_HTTP_${response.status}`);
        const body: unknown = await response.json();
        if (!Array.isArray(body)) throw new Error('DEXSCREENER_INVALID_RESPONSE');
        pairs = body as DexPair[];
      } catch (error) {
        // A failed batch must not abort the cycle: per-token DexScreener and
        // Pump.fun fallback probes below may still work and record the root cause.
        recordFetchError('DexScreener batch request', error);
      }
      const byMint = new Map<string, DexPair>();
      for (const pair of pairs) {
        if (pair.chainId && pair.chainId !== 'solana') continue;
        const mint = pair.baseToken?.address;
        if (!mint || !batch.some(t => t.mint === mint)) continue;
        const current = byMint.get(mint);
        const liquidity = Number(pair.liquidity?.usd ?? 0);
        const currentLiquidity = Number(current?.liquidity?.usd ?? 0);
        if (!current || liquidity > currentLiquidity) byMint.set(mint, pair);
      }
      for (const token of batch) {
        let pair = byMint.get(token.mint);
        const tokenIndex = tokens.findIndex(t => t.mint === token.mint);
        const fallbackOffset = (tokenIndex - fallbackStart + tokens.length) % Math.max(1, tokens.length);
        const shouldProbeFallback = fallbackOffset < FALLBACK_TOKENS_PER_CYCLE;
        // Some very new pairs are omitted by the multi-token endpoint; retry a small
        // number individually so discovery can populate prices without flooding the provider.
        if (!pair && shouldProbeFallback) {
          try {
            health.requests++;
            const single = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${encodeURIComponent(token.mint)}`, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS) });
            if (!single.ok) throw new Error(`DEXSCREENER_SINGLE_HTTP_${single.status}`);
            const result: any = await single.json();
            const candidates: DexPair[] = Array.isArray(result?.pairs) ? result.pairs : [];
            pair = candidates.filter(p => (!p.chainId || p.chainId === 'solana') && p.baseToken?.address === token.mint).sort((a,b) => Number(b.liquidity?.usd ?? 0) - Number(a.liquidity?.usd ?? 0))[0];
          } catch (error) { recordFetchError('DexScreener single-token request', error); }
        }
        if (!pair) {
          health.tokensWithoutPair++;
          health.lastMissingMints.push(token.mint);
          // Pump.fun bonding-curve tokens may not have a DexScreener pair yet.
          // Query a small rotating sample and use only a price implied by
          // the provider's USD market cap and reported total supply; never invent 0.
          if (shouldProbeFallback && health.pumpFunFallbacks < FALLBACK_TOKENS_PER_CYCLE) {
            health.pumpFunFallbacks++;
            try {
              const pumpResponse = await fetch(`https://frontend-api-v3.pump.fun/coins/${encodeURIComponent(token.mint)}`, {
                headers: { accept: 'application/json' }, signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
              });
              if (!pumpResponse.ok) throw new Error(`PUMPFUN_HTTP_${pumpResponse.status}`);
              {
                const coin = await pumpResponse.json() as PumpCoin;
                const marketCap = Number(coin.usd_market_cap);
                const rawSupply = Number(coin.total_supply);
                const decimals = Number(coin.decimals ?? 6);
                const supply = Number.isFinite(rawSupply) && rawSupply > 0
                  ? (rawSupply > 1e12 ? rawSupply / Math.pow(10, Number.isFinite(decimals) ? decimals : 6) : rawSupply)
                  : NaN;
                const impliedPrice = marketCap / supply;
                if (Number.isFinite(impliedPrice) && impliedPrice > 0 && Number.isFinite(marketCap) && marketCap > 0) {
                  const observedAt = new Date(seenAt).toISOString();
                  enqueue({
                    eventId: `pumpfun-market-cap:${token.mint}:${Math.floor(seenAt / INTERVAL_MS)}`,
                    mint: token.mint, symbol: coin.symbol || token.symbol || undefined,
                    name: coin.name || token.name || undefined, source: 'pumpfun-market-cap-price',
                    eventTime: observedAt, price: impliedPrice,
                    raw: { provider: 'Pump.fun', field: 'usd_market_cap/total_supply', marketCapUsd: marketCap, totalSupply: supply, complete: coin.complete ?? null, observedAt },
                  });
                  health.pumpFunPrices++;
                  health.observationsQueued++;
                }
              }
            } catch (error) { recordFetchError('Pump.fun fallback request', error); /* keep price blank rather than fabricate it */ }
          }
          continue;
        }
        const price = Number(pair.priceUsd);
        const liquidity = Number(pair.liquidity?.usd);
        const volume5m = Number(pair.volume?.m5);
        const buys = Number(pair.txns?.m5?.buys ?? 0);
        const sells = Number(pair.txns?.m5?.sells ?? 0);
        const txTotal = buys + sells;
        const buyPressure = txTotal > 0 ? buys / txTotal : undefined;
        const createdAt = Number(pair.pairCreatedAt);
        const ageSeconds = Number.isFinite(createdAt) && createdAt > 0 ? Math.max(0, Math.floor((seenAt - createdAt) / 1000)) : undefined;
        // Only enqueue genuinely observed, finite positive market values.
        const validPrice = Number.isFinite(price) && price > 0 ? price : undefined;
        if (validPrice === undefined) health.tokensWithoutPrice++;
        const validLiquidity = Number.isFinite(liquidity) && liquidity >= 0 ? liquidity : undefined;
        const validVolume = Number.isFinite(volume5m) && volume5m >= 0 ? volume5m : undefined;
        if (validPrice === undefined && validLiquidity === undefined && validVolume === undefined) continue;
        const observedAt = new Date(seenAt).toISOString();
        enqueue({
          eventId: `dexscreener:${token.mint}:${Math.floor(seenAt / INTERVAL_MS)}`,
          mint: token.mint,
          symbol: pair.baseToken?.symbol || token.symbol || undefined,
          name: pair.baseToken?.name || token.name || undefined,
          source: 'dexscreener-market-observation',
          eventTime: observedAt,
          price: validPrice,
          liquidity: validLiquidity,
          volume5m: validVolume,
          ageSeconds,
          buyPressure,
          raw: { provider: 'DexScreener', pairAddress: pair.pairAddress, dexId: pair.dexId, pairUrl: pair.url, buys5m: buys, sells5m: sells, observedAt },
        });
        health.pairsMatched++;
        health.observationsQueued++;
      }
    }
    health.status = cycleHadError ? 'DEGRADED' : 'OK';
    if (!cycleHadError) health.lastSuccessAt = new Date().toISOString();
  } catch (error) {
    health.status = 'DEGRADED';
    health.lastError = String(error);
  } finally {
    running = false;
  }
  return marketEnrichmentStatus();
}
