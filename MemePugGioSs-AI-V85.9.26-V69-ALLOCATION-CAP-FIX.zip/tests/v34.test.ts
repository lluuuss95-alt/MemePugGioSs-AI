import { describe,it,expect } from 'vitest';
import { V34TraderDiscovery } from '../src/v34-discovery.js';
import { V34TradeObservation } from '../src/v34-types.js';

describe('V34 trader discovery',()=>{
 it('ingests verified trades and ranks a trader',()=>{
  const d=new V34TraderDiscovery({minTrades:2,minSampleConfidence:50,minConsistency:0,maxRisk:100,minTradeConfidence:.8,maxLatencyMs:5000});
  const base={wallet:'Trader111',signature:'s1',slot:1,mint:'MintA',source:'VERIFIED_PUMP' as const,quoteAmount:10,baseAmount:100,price:.1,observedAt:1000,executedAt:900,verified:true,confidence:.99};
  d.ingestTrade({id:'1',...base,side:'BUY'});
  d.ingestTrade({id:'2',...base,signature:'s2',slot:2,side:'SELL',quoteAmount:12,observedAt:2000,executedAt:1900});
  const p=d.profiles()[0]; expect(p.trades).toBe(2); expect(p.closedTrades).toBe(1); expect(p.realizedPnlQuote).toBeCloseTo(2);
  expect(d.ranking()[0].wallet).toBe('Trader111');
 });
});
