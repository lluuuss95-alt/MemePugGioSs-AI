import assert from 'node:assert/strict';
import { V71_SAFETY, assertV71Safe } from '../src/v71-mobile-gateway.js';

assertV71Safe();
assert.equal(V71_SAFETY.mode,'PAPER');
assert.equal(V71_SAFETY.shadowOnly,true);
assert.equal(V71_SAFETY.signingEnabled,false);
assert.equal(V71_SAFETY.privateKeyAccess,false);
assert.equal(V71_SAFETY.broadcastEnabled,false);
assert.equal(V71_SAFETY.liveExecutionAllowed,false);
assert.equal(V71_SAFETY.autoPromotion,false);
console.log('V71 safety test passed');
