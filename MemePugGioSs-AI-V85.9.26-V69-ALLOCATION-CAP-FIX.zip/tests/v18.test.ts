
import assert from "node:assert/strict";
import { runShadow } from "../src/v18-run.js";
import { V18_SAFETY } from "../src/v18-safety.js";

const strategy={buySellRatio:1.5,smartMoneyShare:.2,riskMax:50,liquidityDeltaMin:0,holderDeltaMin:0};
const ticks=[
 {mint:"M1",ts:1000,price:10,liquidity:100,buySellRatio:2,smartMoneyShare:.3,risk:20,liquidityDelta:5,holderDelta:1},
 {mint:"M1",ts:2000,price:11,liquidity:100,buySellRatio:2,smartMoneyShare:.3,risk:20,liquidityDelta:5,holderDelta:1},
 {mint:"M1",ts:3000,price:12,liquidity:100,buySellRatio:2,smartMoneyShare:.3,risk:20,liquidityDelta:5,holderDelta:1},
];
const r=runShadow(strategy,ticks,{maxRisk:50,maxDataAgeMs:100,feePct:.1,slippagePct:.2,stopLossPct:5,takeProfitPct:5});
assert.equal(r.session.status,"STOPPED");
assert.ok(r.signals.length===3);
assert.ok(r.trades.length===1);
assert.equal(V18_SAFETY.broadcastEnabled,false);
assert.equal(V18_SAFETY.signingEnabled,false);
console.log("V18 tests passed");
