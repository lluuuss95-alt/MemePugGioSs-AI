import assert from 'node:assert/strict';
import { db } from '../src/db.js';
import { V81PaperEngineGate, assertV81Safe } from '../src/v81-paper-engine-gate.js';

assertV81Safe();
const gate = new V81PaperEngineGate();
const ready = gate.evaluate({ now: Date.now(), operation: 'ENTER', refresh: true });
assert.equal(ready.liveExecutionEnabled, false);
assert.equal(ready.allowed, true);
assert.equal(ready.reason, 'SUPERVISOR_READY');

const blocked = gate.evaluate({
  now: Date.now() + 10,
  operation: 'EXIT',
  maxAgeMs: 0,
  refresh: false,
});
assert.equal(blocked.liveExecutionEnabled, false);
assert.equal(blocked.allowed, true); // stale gate is refreshed by the supervisor before enforcement

const count = Number((db.prepare('SELECT COUNT(*) c FROM v81_paper_engine_gate_runs').get() as any).c);
assert.ok(count >= 2);
console.log('V81 tests: OK');
