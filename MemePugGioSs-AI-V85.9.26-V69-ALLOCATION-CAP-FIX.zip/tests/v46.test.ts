import {describe,it,expect} from 'vitest';
import {V46OpportunityAllocator} from '../src/v46-allocator.js';
import {db} from '../src/db.js';

describe('V46 allocator',()=>{
 it('allocates highest priority first and preserves reserve',()=>{
   const a=new V46OpportunityAllocator({capital:10000,reservePct:20,maxTotalExposurePct:35,maxPositionPct:5,maxTokenPct:10,maxTraderPct:12,maxPositions:10,minAllocation:25,highVolatilityMultiplier:.5,neutralMultiplier:.75,favorableMultiplier:1});
   const s=a.allocate([
    {id:'a',mint:'A',source:'AI_SIGNAL',score:90,confidence:90,riskScore:20,liquidityQuote:50000},
    {id:'b',mint:'B',source:'AI_SIGNAL',score:70,confidence:70,riskScore:30,liquidityQuote:50000}
   ],'FAVORABLE');
   expect(s.allocatedQuote).toBeGreaterThan(0); expect(s.remainingQuote).toBeGreaterThanOrEqual(2000); expect(s.liveExecutionEnabled).toBe(false); expect(s.allocations[0].state).toBe('ALLOCATED');
 });
 it('blocks unsafe regimes',()=>{
   const a=new V46OpportunityAllocator();
   const s=a.allocate([{id:'a',mint:'A',source:'AI_SIGNAL',score:99,confidence:99,riskScore:1,liquidityQuote:100000}],'NO_TRADE');
   expect(s.allocations[0].state).toBe('BLOCKED'); expect(s.allocations[0].reasons).toContain('REGIME_BLOCKS_ALLOCATION');
 });
});
