import assert from 'node:assert/strict';
import { V82PaperTransactionJournal, assertV82Safe } from '../src/v82-paper-transaction-journal.js';
assertV82Safe(); const j=new V82PaperTransactionJournal(); const key=`test-v82-${Date.now()}`; j.prepare('ENTER',key,{mint:'TEST'}); assert.equal(j.pending().some(x=>x.correlationKey===key),true); const recovered=j.recoverPending(); assert.equal(recovered.some(x=>x.correlationKey===key&&x.status==='MANUAL_REVIEW'),true); console.log('V82 PASS');
