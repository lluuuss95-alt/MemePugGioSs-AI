import assert from 'node:assert/strict';
import { V85ReleaseReadiness, assertV85Safe } from '../src/v85-release-readiness.js';
assertV85Safe(); const r=new V85ReleaseReadiness().audit(); assert.equal(r.version,'V85'); assert.equal(r.release,'PAPER_SHADOW_RELEASE'); assert.equal(r.safety.liveExecutionEnabled,false); assert.equal(r.safety.signingEnabled,false); console.log('V85 PASS');
