import assert from "node:assert/strict";
import {bondingInvariant,buyFromQuote,bondingMarketCap,pumpSwapEffectiveQuote,pumpSwapMarketCap,progressBps} from "../src/v23-math.js";
import {assertV23Safety} from "../src/v23-safety.js";
const s={mint:"M",virtualTokenReserves:1000n,virtualQuoteReserves:100n,realTokenReserves:900n,realQuoteReserves:0n,tokenTotalSupply:1000n,complete:false,slot:1,observedAt:1};
assert.equal(bondingInvariant(s),100000n);assert.equal(bondingMarketCap(s),100n);assert.equal(progressBps(s),1000n);
const q=buyFromQuote(s,10n);assert.equal(q.valid,true);assert(q.outputTokens>0n);
const ps={mint:"M",baseReserve:1000n,quoteVaultBalance:100n,virtualQuoteReserves:-10n,effectiveQuoteReserves:90n,slot:1,observedAt:1};
assert.equal(pumpSwapEffectiveQuote(ps),90n);assert.equal(pumpSwapMarketCap(ps,1000n),90n);assert.equal(assertV23Safety(),true);
console.log("V23 tests passed");
