import {describe,it,expect} from 'vitest';
import {V47PortfolioCoordinator} from '../src/v47-portfolio-coordinator.js';

describe('V47 Portfolio Coordinator',()=>{
 it('blocks concentration and keeps live execution disabled',()=>{
  const c=new V47PortfolioCoordinator();
  const r=c.coordinate([
   {id:'a',mint:'M1',source:'AI_SIGNAL',score:90,confidence:90,riskScore:20,liquidityQuote:5000,requestedPct:5,correlationGroup:'G1'},
   {id:'b',mint:'M2',source:'AI_SIGNAL',score:89,confidence:89,riskScore:20,liquidityQuote:5000,requestedPct:5,correlationGroup:'G1'},
   {id:'c',mint:'M3',source:'COPY_TRADER',score:88,confidence:88,riskScore:20,liquidityQuote:5000,requestedPct:5,correlationGroup:'G2'}
  ],'FAVORABLE');
  expect(r.liveExecutionEnabled).toBe(false);
  expect(r.allocatedQuote).toBeGreaterThan(0);
  expect(r.allocations.length).toBe(3);
 });
 it('blocks unknown regime through V46',()=>{
  const r=new V47PortfolioCoordinator().coordinate([{id:'a',mint:'M1',source:'AI_SIGNAL',score:90,confidence:90,riskScore:20,liquidityQuote:5000,requestedPct:5}],'UNKNOWN');
  expect(r.allocatedQuote).toBe(0);
  expect(r.allocations[0].state).toBe('BLOCKED');
 });
});
