import assert from 'node:assert/strict';
import { V61PortfolioExecutionCoordinator, assertV61Safe, type V61Candidate } from '../src/v61-portfolio-execution-coordinator.js';

assertV61Safe();
const coordinator=new V61PortfolioExecutionCoordinator({
  capital:10000,reservePct:20,maxTotalExposurePct:35,maxPositionPct:5,maxTokenPct:10,
  maxCorrelationGroupPct:12,maxSourcePct:20,maxTraderPct:12,maxPositions:10,
  warningExposurePct:30,haltExposurePct:35,minAllocation:25,
});
const candidates:V61Candidate[]=[
  {id:'a',mint:'MINT_A',source:'AI_SIGNAL',score:90,confidence:90,riskScore:20,liquidityQuote:10000,requestedPct:5,correlationGroup:'G1',priority:100},
  {id:'b',mint:'MINT_B',source:'COPY_TRADER',score:88,confidence:85,riskScore:22,liquidityQuote:10000,requestedPct:5,correlationGroup:'G1',wallet:'W1',priority:99},
];
const snap=coordinator.coordinate(candidates,[{mint:'OLD',notional:2500,correlationGroup:'G2',source:'AI_SIGNAL'}],'FAVORABLE',1000);
assert.equal(snap.state,'WARNING');
assert.equal(snap.existingExposure,2500);
assert.ok(snap.approvedCount>=1);
assert.ok(snap.totalExposure<=3500);
assert.equal(snap.liveExecutionEnabled,false);
const blocked=coordinator.coordinate([{...candidates[0],id:'c',mint:'OLD'}],[{mint:'OLD',notional:3400,correlationGroup:'G2',source:'AI_SIGNAL'}],'FAVORABLE',2000);
assert.equal(blocked.approvedCount,0);
assert.ok(blocked.blockedCount>=1);
console.log('V61 test passed');
