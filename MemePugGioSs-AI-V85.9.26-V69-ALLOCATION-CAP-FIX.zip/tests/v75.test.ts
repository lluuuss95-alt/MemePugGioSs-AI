import assert from 'node:assert/strict';
import { V75_SAFETY, assertV75Safe } from '../src/v75-reevaluation-capital-loop.js';
import { V63CapitalAllocationOptimizer } from '../src/v63-capital-allocation-optimizer.js';

assertV75Safe();
assert.equal(V75_SAFETY.mode,'PAPER');
assert.equal(V75_SAFETY.liveExecutionAllowed,false);
assert.equal(V75_SAFETY.privateKeyAccess,false);
assert.equal(V75_SAFETY.broadcastEnabled,false);
assert.equal(V75_SAFETY.autoPromotion,false);

const optimizer=new V63CapitalAllocationOptimizer();
const snapshot=optimizer.optimize([{
  id:'test',mint:'mint-test',source:'AI_SIGNAL',score:85,confidence:80,riskScore:20,
  liquidityQuote:50000,requestedPct:5,regime:'FAVORABLE',priority:70,
  correlationGroup:'mint-test',liquidityScore:90,smartMoneyScore:70,strategyQuality:80,
}],[], 'FAVORABLE', Date.now());
assert.equal(snapshot.liveExecutionEnabled,false);
assert.ok(snapshot.allocations.length===1);
assert.ok(snapshot.allocations[0].optimizedQuote<=500);
console.log('V75 invariant tests passed');
