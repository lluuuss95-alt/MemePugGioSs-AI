import {describe,it,expect} from "vitest";
import {InMemoryV27CheckpointStore} from "../src/v27-checkpoint.js";
import {V27GapRecovery} from "../src/v27-recovery.js";
import {V27_SAFETY} from "../src/v27-safety.js";
import {V26DiscoveryStore,V26TokenDiscovery} from "../src/v26-types.js";

class Store implements V26DiscoveryStore{
  m=new Map<string,V26TokenDiscovery>(); has(x:string){return this.m.has(x)} upsert(t:V26TokenDiscovery){this.m.set(t.mint,t)} all(){return [...this.m.values()]}
}

describe("V27 gap recovery",()=>{
  it("stops at checkpoint and persists newest signature",async()=>{
    const store=new Store(); const cp=new InMemoryV27CheckpointStore();
    cp.save({lastSignature:"OLD",lastSlot:10,updatedAt:1});
    const rpc={
      async getSignaturesForAddress(){return [
        {signature:"NEW",slot:12,err:null},{signature:"OLD",slot:10,err:null}
      ]},
      async getTransaction(){return null}
    };
    const recovery=new V27GapRecovery(rpc,store,cp,{},{pageSize:10});
    const result=await recovery.recover();
    expect(result.reachedCheckpoint).toBe(true); expect(cp.load().lastSignature).toBe("NEW"); expect(result.scanned).toBe(2);
  });
  it("never enables live execution",()=>{expect(V27_SAFETY.liveExecutionAllowed).toBe(false);expect(V27_SAFETY.signingEnabled).toBe(false);expect(V27_SAFETY.broadcastEnabled).toBe(false);});
});
