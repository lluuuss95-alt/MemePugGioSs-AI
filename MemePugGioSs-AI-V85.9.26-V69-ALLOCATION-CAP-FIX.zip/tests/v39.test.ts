import {describe,it,expect} from 'vitest';
import {V39CopyAnalytics} from '../src/v39-copy-analytics.js';

describe('V39 Copy Analytics',()=>{
 it('exposes a zero-safe summary before trades',()=>{const a=new V39CopyAnalytics();const s=a.summary();expect(s.startingCapital).toBeGreaterThanOrEqual(0);expect(s.netPnl).toBeDefined();expect(s.winRate).toBeGreaterThanOrEqual(0);});
 it('creates a timestamped equity snapshot without fabricating history',()=>{const a=new V39CopyAnalytics();const p=a.snapshot(123456789);expect(p.ts).toBe(123456789);expect(a.equityCurve(10).some(x=>x.ts===123456789)).toBe(true);a.reset();});
});
