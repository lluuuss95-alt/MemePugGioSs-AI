import assert from "node:assert/strict";
import { analyzeV8 } from "../src/v8-engine.js";

const r=analyzeV8("MintV8",[
 {address:"dev1",mint:"MintV8",role:"DEPLOYER",slot:1,signature:"a",buyVolume:100,relatedWallets:["w1"]},
 {address:"w1",mint:"MintV8",role:"EARLY_BUYER",slot:2,signature:"b",buyVolume:100,relatedWallets:["dev1"]}
]);
assert.equal(r.mint,"MintV8");
assert.equal(r.wallets.size,2);
assert.ok(r.confidence>0);
console.log("V8 tests passed");
