import assert from 'node:assert/strict';
import { V77PaperExecutionCommitLayer, assertV77Safe } from '../src/v77-paper-execution-commit-layer.js';
import { V52AutonomousPaperLoop } from '../src/v52-autonomous-paper-loop.js';
import { db } from '../src/db.js';

assertV77Safe();
db.exec('DELETE FROM v77_execution_commits');
const layer=new V77PaperExecutionCommitLayer(new V52AutonomousPaperLoop({initialCash:10000,reservePct:20,maxExposurePct:35,maxPositionPct:5,entrySlippageBps:30,exitSlippageBps:40,feeBps:25,stopLossPct:8,takeProfitPct:16,trailingStopPct:7,maxHoldingMs:3600000,staleAfterMs:5000,minLiquidity:1000}));
const now=Date.now();
const decision:any={id:'d1',ts:now,mint:'MintV77',signature:'s',action:'ENTER_PAPER',state:'DECIDED',score:90,confidence:90,risk:20,theoreticalAllocationPct:5,reasons:[],blockers:[],invalidationConditions:[],liveExecutionEnabled:false};
const bridge:any={id:'bridge-v77',ts:now,mint:'MintV77',status:'PAPER_ENTRY_READY',allocationQuote:500,calibratedQuote:500,riskProfile:{id:'r',riskMultiplier:1,calibratedRiskPct:20,calibratedPositionPct:5,calibratedTotalExposurePct:35,state:'STABLE'},stages:[],blockers:[],liveExecutionEnabled:false};
const tick={mint:'MintV77',price:1,liquidity:100000,timestamp:now};
const a=layer.commit({bridge,decision,tick,now}); assert.equal(a.status,'COMMITTED'); assert.equal(a.action,'ENTER_PAPER');
const b=layer.commit({bridge,decision,tick,now:now+1}); assert.equal(b.status,'ALREADY_COMMITTED');
const blocked=layer.commit({...({bridge:{...bridge,status:'BLOCKED'},decision,tick,now:now+2})}); assert.equal(blocked.status,'BLOCKED');
assert.equal(layer.health().liveExecutionEnabled,false);
console.log('V77 tests passed');
