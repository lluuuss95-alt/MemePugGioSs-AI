import assert from "node:assert/strict";
import crypto from "node:crypto";
import {PumpAccountDecoder} from "../src/v24-pump-decoder.js";
import {assertV24Safety} from "../src/v24-safety.js";
function u64(x:bigint){const a=new Uint8Array(8);for(let i=0;i<8;i++)a[i]=Number((x>>(8n*BigInt(i)))&255n);return a}
const d=crypto.createHash("sha256").update("account:BondingCurve").digest().subarray(0,8);
const raw=new Uint8Array(8+8*5+1);raw.set(d);let o=8;for(const x of [1000n,100n,900n,0n,1000n]){raw.set(u64(x),o);o+=8}raw[o]=0;
const enc=Buffer.from(raw).toString("base64");const s=new PumpAccountDecoder().decodeBondingCurve(enc,"MINT",1);
assert.equal(s.virtualTokenReserves,1000n);assert.equal(s.virtualQuoteReserves,100n);assert.equal(s.complete,false);assert.equal(assertV24Safety(),true);
console.log("V24 tests passed");