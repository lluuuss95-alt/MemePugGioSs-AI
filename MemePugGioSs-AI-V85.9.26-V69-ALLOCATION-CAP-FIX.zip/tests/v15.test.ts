import assert from "node:assert/strict";
import { generateGrid } from "../src/v15-grid.js";
import { optimize } from "../src/v15-optimizer.js";

const space={buySellRatio:[1,1.5],smartMoneyShare:[.1,.2],riskMax:[40,60],liquidityDeltaMin:[0],holderDeltaMin:[0]};
assert.equal(generateGrid(space,100).length,8);
const rows=Array.from({length:120},(_,i)=>({mint:`M${i%20}`,ts:i,buySellRatio:i%2?2:1,smartMoneyShare:.3,risk:20,liquidityDelta:10,holderDelta:1,futureReturnPct:i%3?4:-1}));
const r=optimize(space,rows.slice(0,60),rows.slice(60,90),rows.slice(90),50);
assert.ok(r.runId.length===64);
assert.ok(r.candidates.length>0);
console.log("V15 tests passed");
