import { describe, expect, it } from "vitest";
import { DeterministicV28SignalEngine } from "../src/v28-signal-engine.js";

describe("V28 signal engine",()=>{
  it("blocks stale/high-risk data",()=>{
    const e=new DeterministicV28SignalEngine();
    const s=e.evaluate({mint:"mint",features:{buyPressure:90,flowMomentum:90,liquidityScore:90,holderScore:80,smartMoneyScore:80,riskScore:90,freshnessScore:20,sampleConfidence:80,priceMomentum:80,graduationProgress:80}});
    expect(s.state).toBe("BLOCKED"); expect(s.action).toBe("NO_ACTION"); expect(s.blockers).toContain("RISK_GATE");
  });
  it("creates a paper candidate only when gates pass",()=>{
    const e=new DeterministicV28SignalEngine();
    const s=e.evaluate({mint:"mint",features:{buyPressure:90,flowMomentum:85,liquidityScore:90,holderScore:80,smartMoneyScore:85,riskScore:20,freshnessScore:95,sampleConfidence:90,priceMomentum:85,graduationProgress:80}});
    expect(["EARLY_ENTRY","CONFIRMED"]).toContain(s.state); expect(s.action).toBe("PAPER_CANDIDATE"); expect(s.score).toBeGreaterThan(55);
  });
  it("does not claim live execution",()=>{
    const e=new DeterministicV28SignalEngine();
    const s=e.evaluate({mint:"mint",features:{buyPressure:50,flowMomentum:50,liquidityScore:50,holderScore:50,smartMoneyScore:50,riskScore:10,freshnessScore:90,sampleConfidence:90,priceMomentum:50,graduationProgress:20}});
    expect(["OBSERVE","PAPER_CANDIDATE","NO_ACTION"]).toContain(s.action);
  });
});
