import assert from 'node:assert/strict';
import { V33_SAFETY, assertV33Safety } from '../src/v33-safety.js';
import { hashState } from '../src/v33-recovery.js';

const state:any = { cash:9000, equity:10100, realizedPnl:100, unrealizedPnl:0, positions:[], decisions:[], generatedAt:123 };
assert.equal(hashState(state).length, 64);
assert.equal(V33_SAFETY.liveTrading, false);
assert.equal(V33_SAFETY.signingEnabled, false);
assert.equal(V33_SAFETY.privateKeyAccess, false);
assert.doesNotThrow(assertV33Safety);
console.log('V33 smoke tests passed');
