import { describe,it,expect } from 'vitest';
import { V35ReputationEngine, defaultV35Config } from '../src/v35-reputation.js';

describe('V35 reputation math',()=>{
  it('keeps scores bounded',()=>{
    const r:any=V35ReputationEngine.prototype;
    expect(typeof r.evaluate).toBe('function');
    expect(defaultV35Config.minReputationScore).toBeGreaterThan(0);
    expect(defaultV35Config.maxRiskScore).toBeLessThanOrEqual(100);
  });
});
