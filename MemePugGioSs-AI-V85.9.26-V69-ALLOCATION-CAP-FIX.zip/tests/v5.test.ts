import {describe,it,expect} from 'vitest';
import {config} from '../src/config.js';
import {opportunities} from '../src/scanner.js';
describe('V5 safety and scoring',()=>{
 it('never enables LIVE',()=>expect(config.mode).not.toBe('LIVE'));
 it('returns an array from the opportunity scanner',()=>expect(Array.isArray(opportunities())).toBe(true));
});
