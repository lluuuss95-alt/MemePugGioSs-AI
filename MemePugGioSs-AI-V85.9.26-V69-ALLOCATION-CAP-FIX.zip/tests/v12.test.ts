import assert from "node:assert/strict";
import { backfillAddress } from "../src/solana-backfill-adapter.js";

const pages=[
 [{signature:"s3",slot:3},{signature:"s2",slot:2}],
 [{signature:"s1",slot:1}]
];
let calls=0;
const client={
 async getSignaturesForAddress(_a:string,_o:any){return pages[calls++]??[];},
 async getTransaction(s:string){return {slot:Number(s.slice(1)),transaction:{signatures:[s]}};}
};
const r=await backfillAddress(client,"Addr",{pageLimit:2,maxPages:5,concurrency:2,minDelayMs:0,maxRetries:0,backoffBaseMs:1});
assert.equal(r.signatures.length,3);
assert.equal(r.transactions.length,3);
assert.equal(r.stats.pages,2);
assert.equal(r.checkpoint.lastSignature,"s1");
console.log("V12 tests passed");
