import assert from 'node:assert/strict';
import { db } from '../src/db.js';
import { V80AutonomousPaperRecoverySupervisor, assertV80Safe } from '../src/v80-autonomous-paper-recovery-supervisor.js';

assertV80Safe();
const s=new V80AutonomousPaperRecoverySupervisor();
const ready=s.tick({now:Date.now()});
assert.equal(ready.state,'READY');
assert.equal(ready.paperExecutionAllowed,true);
assert.equal(ready.liveExecutionEnabled,false);
const blocked=s.tick({now:Date.now()+10,forceRecovery:true});
assert.ok(['READY','DEGRADED','BLOCKED'].includes(blocked.state));
assert.equal(blocked.liveExecutionEnabled,false);
assert.ok(Number((db.prepare(`SELECT COUNT(*) c FROM v80_recovery_supervisor_runs`).get() as any).c)>=2);
console.log('V80 tests: OK');
