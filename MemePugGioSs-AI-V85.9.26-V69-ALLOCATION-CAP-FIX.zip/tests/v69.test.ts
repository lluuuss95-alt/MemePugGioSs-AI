import assert from 'node:assert/strict';
import { V69EndToEndPaperPipeline, V69_SAFETY, assertV69Safe } from '../src/v69-end-to-end-paper-pipeline.js';

assertV69Safe();
assert.equal(V69_SAFETY.liveExecutionAllowed,false);
const now=Date.now();
const pipeline=new V69EndToEndPaperPipeline();
const common:any={
  mint:'MintV69', now,
  decision:{id:'d1',ts:now,mint:'MintV69',action:'ENTER_PAPER',risk:20,blockers:[]},
  allocation:{mint:'MintV69',allocatedQuote:400},
  market:{mint:'MintV69',price:1,liquidity:5000,updatedAt:now,verified:true,risk:20,regime:'FAVORABLE',slippageBps:10},
  portfolio:{exposureQuote:0,capital:10000,reservePct:20,maxExposurePct:35,openPositions:0,maxPositions:10,existingMint:false,allocatedQuote:400},
  pool:{mint:'MintV69',baseReserve:10000,quoteReserve:10000,feeBps:30,updatedAt:now,verified:true},
  quoteAmount:400,maxSlippageBps:150,baselineRiskPct:45,baselinePositionPct:5,baselineTotalExposurePct:35,approvedUpstream:true
};
const r=pipeline.run(common);
assert.equal(r.outcome,'PAPER_ENTRY');
assert.equal(r.guard.decision,'ALLOW_PAPER');
assert.equal(r.simulation?.decision,'EXECUTABLE');
assert.ok(r.stages.some(s=>s.stage==='PRETRADE_GUARD'&&s.status==='PASS'));
const blocked=pipeline.run({...common,approvedUpstream:false});
assert.equal(blocked.outcome,'BLOCKED');
assert.ok(blocked.blockers.includes('UPSTREAM_APPROVAL_MISSING'));
console.log('V69 tests passed');
