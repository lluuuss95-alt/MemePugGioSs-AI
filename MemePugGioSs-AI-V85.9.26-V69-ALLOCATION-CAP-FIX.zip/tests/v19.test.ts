import assert from "node:assert/strict";import {ProtocolAdapterRouter} from "../src/v19-parser.js";import {verifyV19Safety} from "../src/v19-safety.js";
assert.equal(new ProtocolAdapterRouter([]).parse({signature:"x",slot:1,err:null,logs:[],receivedAt:Date.now()} as any),null);assert.equal(verifyV19Safety(),true);console.log("V19 safety/parser tests passed");
