import assert from "node:assert/strict";
import { V29SignalRankingEngine } from "../src/v29-ranking-engine.js";
import { V28Signal } from "../src/v28-types.js";

const base:V28Signal = {
  mint:"MintA", state:"CONFIRMED", action:"PAPER_CANDIDATE", score:88, confidence:80,
  riskScore:30, freshness:90, reasons:["flow momentum positivo"], blockers:[], generatedAt:1_000_000,
  source:"LIVE_STATE", features:{buyPressure:80,flowMomentum:75,liquidityScore:80,holderScore:70,smartMoneyScore:78,riskScore:30,freshnessScore:90,sampleConfidence:80,priceMomentum:75,graduationProgress:50}
};
const blocked:V28Signal = {...base, mint:"MintB", state:"BLOCKED", action:"NO_ACTION", score:90, riskScore:90, blockers:["RISK_GATE"], features:{...base.features,riskScore:90}};
const watch:V28Signal = {...base, mint:"MintC", state:"WATCH", action:"OBSERVE", score:45, confidence:45, features:{...base.features,buyPressure:40,flowMomentum:35}};

const result = new V29SignalRankingEngine().rank([watch,blocked,base],1_000_100);
assert.equal(result.topSignals[0].mint,"MintA");
assert.equal(result.blocked[0].mint,"MintB");
assert.equal(result.watchlist[0].mint,"MintC");
assert.equal(result.ranked[0].rank,1);
console.log("V29 tests passed");
