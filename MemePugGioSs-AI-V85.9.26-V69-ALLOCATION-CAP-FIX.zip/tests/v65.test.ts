import assert from 'node:assert/strict';
import { V65PaperExecutionSimulator, assertV65Safe } from '../src/v65-paper-execution-simulator.js';

assertV65Safe();
const now=1_000_000;
const sim=new V65PaperExecutionSimulator();
const pool={mint:'TEST',baseReserve:100_000,quoteReserve:10_000,feeBps:25,updatedAt:now,verified:true};
const buy=sim.simulate(pool,{side:'BUY',mint:'TEST',quoteAmount:250,maxSlippageBps:500,externalSlippageBps:20,now});
assert.equal(buy.decision,'EXECUTABLE');
assert.ok(buy.outputAmount>0);
assert.ok(buy.priceImpactBps>=0);
assert.equal(buy.liveExecutionEnabled,false);
assert.ok(buy.remainingBaseReserve<pool.baseReserve);

const stale=sim.simulate(pool,{side:'BUY',mint:'TEST',quoteAmount:250,maxSlippageBps:500,now:now+6000});
assert.equal(stale.decision,'BLOCK');
assert.ok(stale.blockers.includes('POOL_STATE_STALE'));

const excessive=sim.simulate(pool,{side:'BUY',mint:'TEST',quoteAmount:9000,maxSlippageBps:50,now});
assert.equal(excessive.decision,'BLOCK');
assert.ok(excessive.blockers.includes('MAX_SLIPPAGE_EXCEEDED') || excessive.blockers.includes('PRICE_IMPACT_TOO_HIGH'));

const unverified=sim.simulate({...pool,verified:false},{side:'SELL',mint:'TEST',baseAmount:100,maxSlippageBps:500,now});
assert.equal(unverified.decision,'BLOCK');
assert.ok(unverified.blockers.includes('POOL_NOT_VERIFIED'));
console.log('V65 test passed');
