import assert from 'node:assert/strict';
import {V41AutonomousOrchestrator} from '../src/v41-orchestrator.js';
// Static contract test: safety decision logic must block weak inputs before any paper action.
const o:any=Object.create(V41AutonomousOrchestrator.prototype);
(o as any).cfg={minScore:65,minConfidence:60,maxRiskScore:45,maxFreshnessMs:30000,minLiquidityQuote:1000,maxDecisionsPerCycle:10,autoPaperExecution:true};
(o as any).save=(d:any)=>d;
const d=o.decide({mint:'MINT',source:'AI_SIGNAL',side:'BUY',score:40,confidence:80,riskScore:20,freshnessMs:1000,liquidityQuote:5000},1);
assert.equal(d.state,'BLOCKED');assert.ok(d.reasons.includes('SCORE_BELOW_THRESHOLD'));
assert.equal(d.liveExecutionEnabled,false);
console.log('V41 safety decision test: OK');
