import assert from "node:assert/strict";
import { analyzeV9 } from "../src/v9-engine.js";
import { simulateExit } from "../src/v9-paper.js";

const now=100000;
const pts=Array.from({length:8},(_,i)=>({ts:now-7000+i*1000,buyVolume:200+i*30,sellVolume:80,
 liquidity:1000+i*20,smartMoneyVolume:100,holders:20+i,risk:20}));
const r=analyzeV9(pts,now);
assert.ok(["EARLY_ENTRY_CANDIDATE","CONFIRMED"].includes(r.signal.state));
assert.equal(r.features.sampleSize,8);
const o=simulateExit({entry:10,quantity:2,stopLoss:9,takeProfit:12},[10.5,11,12]);
assert.equal(o.reason,"TAKE_PROFIT");
assert.equal(o.pnl,4);
console.log("V9 tests passed");
