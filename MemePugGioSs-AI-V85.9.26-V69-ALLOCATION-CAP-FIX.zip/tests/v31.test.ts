import { test, expect } from 'vitest';
import { closeTrade, markPortfolio, performance } from '../src/v31-portfolio.js';
import { PortfolioState } from '../src/v31-types.js';
import { V31_SAFETY, assertV31Safe } from '../src/v31-safety.js';

test('V31 portfolio metrics',()=>{ const s:PortfolioState={cash:900,peakEquity:1000,trades:[{id:'t1',token:'A',side:'LONG',entryPrice:10,quantity:10,notional:100,fees:1,slippage:1,openedAt:1,status:'OPEN'}],snapshots:[]}; markPortfolio(s,{A:12},2); closeTrade(s,'t1',12,'TAKE_PROFIT',3); const snap=markPortfolio(s,{A:12},4); const p=performance(s,1000); expect(snap.equity).toBeGreaterThan(0); expect(p.trades).toBe(1); expect(p.wins).toBe(1); });
test('V31 safety',()=>{ assertV31Safe(); expect(V31_SAFETY.liveTrading).toBe(false); expect(V31_SAFETY.broadcastEnabled).toBe(false); });
