import assert from "node:assert/strict";
import { runBacktest } from "../src/backtester.js";
import { momentumStrategy } from "../src/strategies.js";
import { makeWalkForwardWindows } from "../src/walk-forward.js";

const bars=Array.from({length:12},(_,i)=>({ts:i,price:i<5?100+i:106+(i-5)*2}));
const r=runBacktest(momentumStrategy,bars,{initialCash:1000,feeBps:10,slippageBps:5,maxPositionFraction:0.8});
assert.equal(r.strategyId,"momentum-v1");
assert.ok(Number.isFinite(r.maxDrawdownPct));
assert.ok(r.equityCurve.length===13);
const w=makeWalkForwardWindows(20,10,5,5);
assert.equal(w.length,2);
console.log("V10 tests passed");
