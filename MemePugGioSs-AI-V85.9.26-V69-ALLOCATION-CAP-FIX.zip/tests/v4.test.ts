import {describe,it,expect} from "vitest";
describe("V4 safety",()=>{it("is paper-first",()=>expect(process.env.APP_MODE??"PAPER").not.toBe("LIVE")); it("has bounded defaults",()=>expect(Number(process.env.MAX_INGEST_QUEUE??500)).toBeGreaterThan(0));});
