import assert from "node:assert/strict";
import { ingestHistorical, fingerprint, manifest } from "../src/historical-ingest.js";
import { ReplayCursor, windowUntil } from "../src/replay-dataset.js";

const raw=[
 {id:"b",ts:200,mint:"M",price:2},
 {id:"a",ts:100,mint:"M",price:1},
 {id:"a",ts:100,mint:"M",price:1},
 {id:"bad",ts:"x",mint:"M"},
 {id:"c",ts:300,mint:"M",price:3}
];
const r=ingestHistorical(raw,"test");
assert.equal(r.events.length,3);
assert.equal(r.quarantined.length,1);
assert.equal(r.events[0].ts,100);
assert.equal(r.events[2].ts,300);
assert.equal(fingerprint(r.events),fingerprint(r.events));
const m=manifest(r.events,r.quarantined,"test","1");
assert.equal(m.rows,3);
const cursor=new ReplayCursor(r.events);
assert.equal(cursor.next()?.ts,100);
assert.equal(windowUntil(r.events,200).length,2);
console.log("V11 tests passed");
