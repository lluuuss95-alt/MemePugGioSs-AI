import assert from 'node:assert/strict';
import { V84FinalControlPlane, assertV84Safe } from '../src/v84-final-control-plane.js';
assertV84Safe(); const c=new V84FinalControlPlane(); const r=c.readiness(); assert.equal(r.mode,'PAPER'); assert.equal(r.liveExecutionEnabled,false); assert.equal(r.safety.liveExecutionEnabled,false); console.log('V84 PASS');
