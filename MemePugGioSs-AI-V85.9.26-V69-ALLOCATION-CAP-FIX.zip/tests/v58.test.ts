import assert from 'node:assert/strict';
import { V58AIReevaluationEngine, assertV58Safe } from '../src/v58-ai-reevaluation.js';
import type { V57Change } from '../src/v57-state-change-detector.js';
import type { V56State } from '../src/v56-token-state-fusion.js';

const state:V56State={mint:'V58_TEST',firstSeenAt:1,lastUpdatedAt:100,name:'X',symbol:'X',freshness:'FRESH',sourceCount:3,version:4,blockers:[],reasons:[]};
const change:V57Change={id:'change-1',mint:state.mint,ts:100,type:'SIGNAL_UPGRADE',severity:'HIGH',version:4,previousVersion:3,message:'score changed',before:50,after:70,delta:20,actionable:true};
assertV58Safe();
const e=new V58AIReevaluationEngine({cooldownMs:0});
e.start();
const job=e.submit(change,state,1000); assert.ok(job); assert.equal(job?.priority,'HIGH');
assert.equal(e.submit(change,state,1000),null);
await new Promise(r=>setTimeout(r,80));
const h=e.healthSnapshot(); assert.ok(h.dispatched>=1); assert.ok(h.completed>=1); assert.equal(e.recent(10)[0]?.action,'REEVALUATED');
e.stop();
console.log('V58 test OK');
