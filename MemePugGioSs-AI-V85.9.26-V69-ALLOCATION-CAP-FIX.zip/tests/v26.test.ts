import {describe,expect,it} from "vitest";
import {parsePumpCreateTransaction} from "../src/v26-pump-create-parser.js";
import {InMemoryV26DiscoveryStore} from "../src/v26-discovery-store.js";
import {toV26HomeDiscoveryFeed} from "../src/v26-home-feed.js";
import {V26_SAFETY,assertV26Shadow} from "../src/v26-safety.js";
import {PUMP_PROGRAM_ID} from "../src/v26-types.js";

function encode58(bytes:number[]){let n=0n;for(const x of bytes)n=(n<<8n)+BigInt(x);const a="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";let o="";while(n){const r=Number(n%58n);o=a[Number(n%58n)]+o;n/=58n}let z=0;for(const x of bytes){if(x!==0)break;z++}return "1".repeat(z)+(o||"")||"1";}
function u32(n:number){return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]}
function str(s:string){const d=[...new TextEncoder().encode(s)];return [...u32(d.length),...d]}

it("detects a legacy Pump create instruction and extracts mint/curve",()=>{
  const data=[24,30,200,40,5,28,7,119,...str("Dog"),...str("DOG"),...str("https://x"),...new Array(32).fill(7)];
  const tx={slot:123,blockTime:1,meta:{err:null},transaction:{message:{accountKeys:[PUMP_PROGRAM_ID,"MINT111","AUTH","CURVE111"],instructions:[{programIdIndex:0,accounts:[1,2,3],data:encode58(data)}]}}};
  const r=parsePumpCreateTransaction("sig",tx);expect(r?.mint).toBe("MINT111");expect(r?.bondingCurve).toBe("CURVE111");expect(r?.name).toBe("Dog");expect(r?.symbol).toBe("DOG");expect(r?.createKind).toBe("CREATE");
});

it("deduplicates the discovery store",()=>{const s=new InMemoryV26DiscoveryStore();const t={mint:"M",bondingCurve:"C",signature:"S",slot:1,createKind:"CREATE" as const,detectedAt:1};s.upsert(t);s.upsert({...t,signature:"S2",detectedAt:2});expect(s.all()).toHaveLength(1);expect(s.all()[0].signature).toBe("S2")});

it("maps discovery health to the existing home data boundary",()=>{const f=toV26HomeDiscoveryFeed([], {websocket:"CONNECTED",eventsSeen:3,transactionsFetched:2,candidates:1,discovered:1,duplicates:0,failedFetches:0,parserErrors:0});expect(f.discovery.status).toBe("READY")});

it("keeps V26 shadow-only",()=>{assertV26Shadow();expect(V26_SAFETY.liveTrading).toBe(false);expect(V26_SAFETY.signingEnabled).toBe(false);expect(V26_SAFETY.broadcastEnabled).toBe(false)});
