import assert from 'node:assert/strict';
import { V60AutonomousLoopCoordinator, assertV60Safe } from '../src/v60-autonomous-loop-coordinator.js';
import type { V56State } from '../src/v56-token-state-fusion.js';
import type { V57Change } from '../src/v57-state-change-detector.js';
import type { V58Job } from '../src/v58-ai-reevaluation.js';
import type { V48Candidate } from '../src/v48-ultra-discovery.js';
import type { V49Score } from '../src/v49-instant-scoring.js';

const mint='V60_TEST';
const state:V56State={mint,firstSeenAt:1,lastUpdatedAt:100,freshness:'FRESH',sourceCount:6,version:6,blockers:[],reasons:[],price:1,marketCap:100000,liquidity:5000,buyVolume:1000,sellVolume:400,flowMomentum:60,holders:120,holderConcentration:10,creatorScore:80,smartMoneyScore:80,smartMoneyShare:.4,regime:'FAVORABLE',instantScore:90,instantConfidence:90,deepScore:90,deepConfidence:90,risk:20,freshnessMs:10};
const candidate:V48Candidate={token:{mint,name:'Test',symbol:'TST',creator:'creator',bondingCurve:'curve',uri:'uri',quoteMint:'SOL',mayhemMode:false,holderReward:false},signature:'sig',slot:10,detectedAt:100,verificationLatencyMs:20,priority:'P0',action:'DEEP_ANALYSIS'} as V48Candidate;
const instant:V49Score={id:'i',mint,signature:'sig',score:90,confidence:90,band:'DEEP_ANALYSIS',metadataScore:100,creatorSignal:80,launchQuality:90,freshnessScore:99,reasons:[],blockers:[],generatedAt:100,latencyMs:20,needsDeepAnalysis:true,liveExecutionEnabled:false};
const change:V57Change={id:'c60',mint,ts:100,type:'SIGNAL_UPGRADE',severity:'HIGH',version:6,previousVersion:5,message:'score improved',before:70,after:90,delta:20,actionable:true};
const job:V58Job={id:'j60',mint,priority:'HIGH',reason:'SIGNAL_UPGRADE',severity:'HIGH',changeId:'c60',stateVersion:6,createdAt:100,expiresAt:10000,status:'QUEUED'};

assertV60Safe();
const c=new V60AutonomousLoopCoordinator();
const r=c.process({job,change,state,candidate,instant,currentPrice:1},1000);
assert.equal(r.mint,mint);
assert.equal(r.liveExecutionEnabled,false);
assert.ok(['ENTER_PAPER','BLOCK','HOLD','NO_ACTION'].includes(r.action));
assert.equal(c.status(mint).liveExecutionEnabled,false);
console.log('V60 test OK');
