import assert from 'node:assert/strict';
import { V52AutonomousPaperLoop, defaultV52Config } from '../src/v52-autonomous-paper-loop.js';
import type { V51Decision } from '../src/v51-decision-engine.js';
const mint='V52TESTMINT';
const d:V51Decision={id:'d1',ts:1000,mint,signature:'sig',action:'ENTER_PAPER',state:'DECIDED',score:90,confidence:90,risk:20,theoreticalAllocationPct:5,reasons:[],blockers:[],invalidationConditions:[],liveExecutionEnabled:false};
const loop=new V52AutonomousPaperLoop({...defaultV52Config,initialCash:10000});
let r=loop.evaluate(d,{mint,price:100,liquidity:5000,timestamp:2000},2000); assert.equal(r.action,'ENTER_PAPER'); assert.equal(loop.state().openPositions.length,1);
r=loop.evaluate({...d,action:'EXIT_PAPER',ts:2100},{mint,price:110,liquidity:5000,timestamp:2200},2200); assert.equal(r.action,'EXIT_PAPER'); assert.equal(loop.state().openPositions.length,0); assert.ok(loop.state().realizedPnl>0);
console.log('V52 tests passed');
