import assert from 'node:assert/strict';
import { V83PaperExecutionCoordinator, assertV83Safe } from '../src/v83-paper-execution-coordinator.js';
assertV83Safe(); const c=new V83PaperExecutionCoordinator(); const h=c.health(); assert.equal(h.liveExecutionEnabled,false); assert.equal(h.gate.allowed,false); console.log('V83 PASS');
