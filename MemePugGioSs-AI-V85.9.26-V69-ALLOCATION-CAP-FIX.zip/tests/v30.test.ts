import { describe, expect, it } from 'vitest';
import { V29RankedSignal } from '../src/v29-types.js';
import { V30PaperExecutionEngine, createV30State, V30_DEFAULTS } from '../src/v30-engine.js';
import { assertV30Safety } from '../src/v30-safety.js';

const signal=(overrides:Partial<V29RankedSignal>={}):V29RankedSignal=>({rank:1,mint:'Mint111111111111111111111111111111111111111',state:'CONFIRMED',band:'TOP_SIGNAL',compositeScore:85,signalScore:82,confidence:80,riskScore:25,freshness:95,liquidityScore:70,smartMoneyScore:75,reasons:['flow'],blockers:[],generatedAt:1000,...overrides});

describe('V30 paper execution',()=>{
 it('enters a paper position under exposure limits',()=>{ const e=new V30PaperExecutionEngine(V30_DEFAULTS,createV30State(V30_DEFAULTS)); const r=e.evaluate(signal(),{mint:signal().mint,price:10,timestamp:1000,liquidityUsd:100000},1000); expect(r.decision.decision).toBe('ENTER_PAPER'); expect(r.state.positions.filter(p=>p.status==='OPEN')).toHaveLength(1); expect(r.state.cash).toBeLessThan(10000); });
 it('takes profit and realizes pnl',()=>{ const s=signal(); const e=new V30PaperExecutionEngine(V30_DEFAULTS,createV30State(V30_DEFAULTS)); e.evaluate(s,{mint:s.mint,price:10,timestamp:1000,liquidityUsd:100000},1000); const r=e.evaluate(s,{mint:s.mint,price:12,timestamp:2000,liquidityUsd:100000},2000); expect(r.decision.decision).toBe('EXIT_PAPER'); expect(r.decision.reason).toBe('TAKE_PROFIT'); expect(r.state.realizedPnl).toBeGreaterThan(0); });
 it('blocks stale signals',()=>{ const s=signal(); const e=new V30PaperExecutionEngine(V30_DEFAULTS,createV30State(V30_DEFAULTS)); const r=e.evaluate(s,{mint:s.mint,price:10,timestamp:40000,liquidityUsd:100000},40000); expect(r.decision.decision).toBe('BLOCKED'); expect(r.decision.reason).toBe('STALE_SIGNAL'); });
 it('enforces safety invariants',()=>{ expect(()=>assertV30Safety()).not.toThrow(); });
});
