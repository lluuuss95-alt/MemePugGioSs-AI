import { describe,it,expect } from 'vitest';
import { defaultV36Config, V36CopySignalEngine } from '../src/v36-copy-signal.js';

describe('V36 copy signal safety',()=>{
  it('uses conservative defaults',()=>{
    expect(defaultV36Config.maxTokenExposurePct).toBeLessThanOrEqual(5);
    expect(defaultV36Config.minLiquidityQuote).toBeGreaterThan(0);
    expect(defaultV36Config.maxLatencyMs).toBeLessThanOrEqual(5000);
    expect(typeof V36CopySignalEngine.prototype.evaluate).toBe('function');
  });
});
