import { describe,it,expect } from 'vitest';
import { V51FinalDecisionEngine,assertV51Safe } from '../src/v51-decision-engine.js';
import type { V50Result } from '../src/v50-deep-intelligence.js';
const base:V50Result={id:'x',mint:'Mint111',signature:'Sig111',state:'ANALYZED',score:82,confidence:78,risk:30,opportunity:82,liquidityScore:80,flowScore:72,holderScore:70,creatorScore:65,smartMoneyScore:75,regimeMultiplier:1,reasons:['POSITIVE_FLOW_MOMENTUM'],blockers:[],analyzedAt:1,liveExecutionEnabled:false};
describe('V51 Final Decision Engine',()=>{
 it('enters paper only when all final gates pass',()=>{const d=new V51FinalDecisionEngine().decide({analysis:base,now:100});expect(d.action).toBe('ENTER_PAPER');expect(d.theoreticalAllocationPct).toBeGreaterThan(0);expect(d.liveExecutionEnabled).toBe(false)});
 it('blocks excessive risk',()=>{const d=new V51FinalDecisionEngine().decide({analysis:{...base,risk:70},now:100});expect(d.action).toBe('BLOCK');expect(d.blockers).toContain('FINAL_RISK_ABOVE_THRESHOLD')});
 it('waits for insufficient data',()=>{const d=new V51FinalDecisionEngine().decide({analysis:{...base,state:'INSUFFICIENT_DATA',confidence:40},now:100});expect(d.action).toBe('WAIT');expect(d.state).toBe('INSUFFICIENT_DATA')});
 it('supports paper exits without live execution',()=>{const d=new V51FinalDecisionEngine().decide({analysis:base,side:'SELL',existingPosition:true,now:100});expect(d.action).toBe('EXIT_PAPER');expect(d.liveExecutionEnabled).toBe(false)});
 it('preserves safety invariant',()=>{expect(()=>assertV51Safe()).not.toThrow()});
});
