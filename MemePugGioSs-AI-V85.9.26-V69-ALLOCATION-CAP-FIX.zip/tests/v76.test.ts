import assert from 'node:assert/strict';
import { V76AllocationPretradeSimulationBridge, V76_SAFETY, assertV76Safe } from '../src/v76-allocation-pretrade-simulation-bridge.js';
assertV76Safe();
assert.equal(V76_SAFETY.mode,'PAPER');
assert.equal(V76_SAFETY.liveExecutionAllowed,false);
assert.equal(V76_SAFETY.privateKeyAccess,false);
assert.equal(V76_SAFETY.broadcastEnabled,false);
assert.equal(V76_SAFETY.autoPromotion,false);
const bridge=new V76AllocationPretradeSimulationBridge();
const base=Date.now();
const result=bridge.run({
 decisionResult:{id:'d1',jobId:'j1',mint:'M',ts:base,trigger:'MOMENTUM_CHANGE',triggerSeverity:'WATCH',stateVersion:1,outcome:'ENTER_PAPER',escalation:'NONE',score:90,confidence:90,risk:20,theoreticalAllocationPct:5,deep:{mint:'M',signature:'s',ts:base,state:'READY',score:90,confidence:90,risk:20,regimeMultiplier:1,liquidityScore:90,smartMoneyScore:80,creatorScore:80,flowScore:80,reasons:[],blockers:[],liveExecutionEnabled:false} as any,decision:{id:'v51',ts:base,mint:'M',signature:'s',action:'ENTER_PAPER',state:'DECIDED',score:90,confidence:90,risk:20,theoreticalAllocationPct:5,reasons:[],blockers:[],invalidationConditions:[],liveExecutionEnabled:false},reasons:[],blockers:[],liveExecutionEnabled:false},
 allocationResult:{id:'a1',ts:base,mint:'M',sourceDecisionId:'d1',status:'ALLOCATED',regime:'FAVORABLE',requestedPct:5,optimizedQuote:400,arbitrationState:'SELECTED',reasons:[],allocationSnapshotTs:base,liveExecutionEnabled:false},
 market:{mint:'M',price:1,liquidity:100000,updatedAt:base,verified:true,stale:false,risk:20,regime:'FAVORABLE',slippageBps:5},
 portfolio:{exposureQuote:0,capital:10000,reservePct:20,maxExposurePct:35,openPositions:0,maxPositions:10,existingMint:false,allocatedQuote:400},
 pool:{mint:'M',baseReserve:100000,quoteReserve:100000,feeBps:20,updatedAt:base,verified:true},
 maxSlippageBps:150, baselineRiskPct:20, baselinePositionPct:5, baselineTotalExposurePct:35, now:base
});
assert.equal(result.liveExecutionEnabled,false);
assert.equal(result.allocationQuote,400);
assert.ok(result.stages.some(s=>s.stage==='RISK_CALIBRATION'));
assert.ok(['PAPER_ENTRY_READY','BLOCKED'].includes(result.status));
console.log('V76 invariant tests passed');
