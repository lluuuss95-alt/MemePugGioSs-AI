import assert from 'node:assert/strict';
import { V63CapitalAllocationOptimizer, assertV63Safe, type V63Candidate } from '../src/v63-capital-allocation-optimizer.js';
assertV63Safe();
const o=new V63CapitalAllocationOptimizer();
const c:V63Candidate[]=[
 {id:'a',mint:'A',source:'AI_SIGNAL',strategy:'AI_SIGNAL',score:95,confidence:90,riskScore:20,liquidityQuote:10000,requestedPct:5,priority:100,correlationGroup:'G1',freshnessScore:100,smartMoneyScore:90,strategyQuality:80},
 {id:'b',mint:'B',source:'COPY_TRADER',strategy:'COPY_TRADER',score:80,confidence:80,riskScore:30,liquidityQuote:8000,requestedPct:5,priority:90,correlationGroup:'G2',freshnessScore:90,smartMoneyScore:70,strategyQuality:75},
 {id:'c',mint:'C',source:'AI_SIGNAL',strategy:'SMART_MONEY',score:65,confidence:70,riskScore:45,liquidityQuote:6000,requestedPct:5,priority:80,correlationGroup:'G3',freshnessScore:80,smartMoneyScore:95,strategyQuality:70}
];
const s=o.optimize(c,[], 'FAVORABLE', 1000);
assert.equal(s.liveExecutionEnabled,false);
assert.ok(s.allocatedCount>=1);
assert.ok(s.totalOptimizedQuote<=3500);
assert.ok(s.allocations.every(x=>x.optimizedQuote<=x.approvedCeiling+1e-9));
assert.ok(s.allocations.find(x=>x.candidateId==='a')!.weight>s.allocations.find(x=>x.candidateId==='c')!.weight);
const blocked=o.optimize(c,[], 'NO_TRADE', 2000);
assert.ok(blocked.allocations.every(x=>x.optimizedQuote===0));
console.log('V63 test passed');
