import assert from 'node:assert/strict';
import {V64AutonomousExecutionGuard,assertV64Safe} from '../src/v64-pretrade-guard.js';
import type {V51Decision} from '../src/v51-decision-engine.js';
import type {V63AllocationRow} from '../src/v63-capital-allocation-optimizer.js';

assertV64Safe();
const now=Date.now();
const decision:V51Decision={id:'d1',ts:now,mint:'V64_TEST',signature:'sig',action:'ENTER_PAPER',state:'DECIDED',score:90,confidence:90,risk:20,theoreticalAllocationPct:3,reasons:[],blockers:[],invalidationConditions:[],liveExecutionEnabled:false};
const allocation:V63AllocationRow={id:'a1',candidateId:'c1',mint:'V64_TEST',strategy:'AI_SIGNAL',decision:'ALLOCATE',weight:1,requestedQuote:300,approvedCeiling:300,optimizedQuote:300,reasons:[]};
const guard=new V64AutonomousExecutionGuard();
const ok=guard.validate({decision,allocation,market:{mint:'V64_TEST',price:1,liquidity:5000,updatedAt:now,verified:true,risk:20,regime:'FAVORABLE',slippageBps:30},portfolio:{exposureQuote:0,capital:10000,reservePct:20,maxExposurePct:35,openPositions:0,maxPositions:10,existingMint:false,allocatedQuote:300},now});
assert.equal(ok.decision,'ALLOW_PAPER');
assert.equal(ok.approvedQuote,300);
const bad=guard.validate({decision,market:{mint:'V64_TEST',price:1,liquidity:500,updatedAt:now-10000,verified:false,regime:'NO_TRADE',slippageBps:300},portfolio:{exposureQuote:3500,capital:10000,reservePct:20,maxExposurePct:35,openPositions:10,maxPositions:10,existingMint:true,allocatedQuote:500},now});
assert.equal(bad.decision,'BLOCK');
assert.ok(bad.blockers.length>=5);
console.log('V64 test passed');
