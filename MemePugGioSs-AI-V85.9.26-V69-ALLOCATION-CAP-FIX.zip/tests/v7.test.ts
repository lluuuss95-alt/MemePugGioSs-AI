import assert from "node:assert/strict";
import { AdapterRegistry, GenericUnknownAdapter } from "../src/protocols.js";
import { analyzeV7 } from "../src/v7-engine.js";

const registry = new AdapterRegistry([], new GenericUnknownAdapter());
const result = analyzeV7("Mint111", [
  {slot:1,transaction:{signatures:["s1"]}},
  {slot:2,transaction:{signatures:["s2"]}}
], registry);

assert.equal(result.events.length,2);
assert.equal(result.tradable,false);
console.log("V7 tests passed");
