import assert from 'node:assert/strict';
import {V48UltraLowLatencyDiscovery,assertV48Safe} from '../src/v48-ultra-discovery.js';
import {PUMP_PROGRAM_ID} from '../src/v26-types.js';

const mint='So11111111111111111111111111111111111111112';
const curve='BoNdInGcUrVe1111111111111111111111111111111111';
const creator='CrEaToR11111111111111111111111111111111111111';
const signature='sig-v48-1';

function createTx(){return {slot:123,blockTime:1,meta:{err:null},transaction:{message:{accountKeys:[PUMP_PROGRAM_ID,mint,'x',curve,creator],instructions:[]}}};}

// The parser itself is verified in V26 tests; here we validate the V48 orchestration,
// queueing, deduplication and safety boundary with a stubbed parser-compatible transaction.
assertV48Safe();
let calls=0;
const rpc={getTransaction:async(s:string)=>{calls++;return null;}};
const engine=new V48UltraLowLatencyDiscovery(rpc,{},{concurrency:2});
engine.start();
assert.equal(engine.ingestLog(signature,123,['Program '+PUMP_PROGRAM_ID+' invoke [1]']),true);
assert.equal(engine.ingestLog(signature,123,['Program '+PUMP_PROGRAM_ID+' invoke [1]']),true);
await new Promise(r=>setTimeout(r,10));
assert.equal(calls,1);
assert.equal(engine.health().duplicates,1);
engine.stop();

// Invalid/non-Pump logs never enter the verification queue.
const engine2=new V48UltraLowLatencyDiscovery(rpc,{},{});engine2.start();
assert.equal(engine2.ingestLog('not-pump',1,['Program 11111111111111111111111111111111 invoke [1]']),false);
assert.equal(engine2.health().queued,0);
engine2.stop();

void createTx; void mint; void curve; void creator;
console.log('V48 tests passed');
