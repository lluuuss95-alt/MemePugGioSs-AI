import {describe,it,expect} from 'vitest';
import {V43LearningEngine} from '../src/v43-learning.js';
import {V43_SAFETY} from '../src/v43-safety.js';
describe('V43 learning safety',()=>{it('never enables live execution or auto promotion',()=>{expect(V43_SAFETY).toEqual({liveExecutionEnabled:false,autoPromotion:false,privateKeys:false,signing:false,broadcast:false})});it('starts with insufficient data and bounded policy',()=>{const e=new V43LearningEngine();const s=e.snapshot();expect(s.state).toBe('INSUFFICIENT_DATA');expect(s.liveExecutionEnabled).toBe(false);expect(s.policy.autoPromotion).toBe(false)})});
