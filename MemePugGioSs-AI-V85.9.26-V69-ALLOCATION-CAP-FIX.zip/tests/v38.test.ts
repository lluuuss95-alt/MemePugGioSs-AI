import {describe,it,expect} from 'vitest';
import {defaultV38Config,V38CopyRiskManager} from '../src/v38-risk.js';
import {V37CopyPaperPortfolio} from '../src/v37-copy-paper.js';

describe('V38 copy risk manager',()=>{
  it('uses conservative portfolio limits',()=>{
    expect(defaultV38Config.maxTotalExposurePct).toBeLessThanOrEqual(35);
    expect(defaultV38Config.maxTokenExposurePct).toBeLessThanOrEqual(10);
    expect(defaultV38Config.maxDrawdownPct).toBeLessThanOrEqual(15);
  });
  it('blocks buys when the circuit breaker is already halted',()=>{
    const p=new V37CopyPaperPortfolio();
    const r=new V38CopyRiskManager(p);
    const s=r.snapshot();
    expect(['NORMAL','WARNING','HALTED']).toContain(s.state);
    expect(typeof r.preflight).toBe('function');
  });
});
