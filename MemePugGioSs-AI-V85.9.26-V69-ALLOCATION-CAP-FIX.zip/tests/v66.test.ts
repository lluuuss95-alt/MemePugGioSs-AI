import assert from 'node:assert/strict';
import { V66ExecutionQualityMonitor, assertV66Safe } from '../src/v66-execution-quality-monitor.js';

assertV66Safe();
const monitor=new V66ExecutionQualityMonitor();
const base=1_000_000;
const good=monitor.observe({mint:'TEST',side:'BUY',observedAt:base+500,decisionAt:base,marketPrice:1,simulatedPrice:1.005,paperPrice:1.006,liquidity:10_000,simulatedSlippageBps:40,simulatedPriceImpactBps:60});
assert.equal(good.quality,'GOOD');
assert.equal(good.liveExecutionEnabled,false);
assert.ok(good.simulationDeviationBps<100);

const warning=monitor.observe({mint:'TEST',side:'BUY',observedAt:base+2_000,decisionAt:base,marketPrice:1,simulatedPrice:1.02,paperPrice:1.021,liquidity:10_000});
assert.equal(warning.quality,'WARNING');
assert.ok(warning.warnings.length>0);

const blocked=monitor.observe({mint:'TEST',side:'BUY',observedAt:base+10_000,decisionAt:base,marketPrice:1,simulatedPrice:1.04,paperPrice:1.05,liquidity:500});
assert.equal(blocked.quality,'BLOCKED');
assert.ok(blocked.blockers.includes('SIMULATION_DEVIATION_TOO_HIGH') || blocked.blockers.includes('PAPER_DEVIATION_TOO_HIGH') || blocked.blockers.includes('SIMULATION_LATENCY_TOO_HIGH'));

const summary=monitor.summary('TEST');
assert.equal(summary.samples,3);
assert.equal(summary.liveExecutionEnabled,false);
console.log('V66 test passed');
