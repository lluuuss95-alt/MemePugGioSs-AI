
import assert from "node:assert/strict";
import { makeWindows } from "../src/v17-walkforward.js";
import { v17Lab } from "../src/v17-lab.js";

const rows=Array.from({length:220},(_,i)=>({
 mint:`M${i%20}`,ts:i,buySellRatio:i%5?2:1,smartMoneyShare:.3,risk:20,
 liquidityDelta:10,holderDelta:1,futureReturnPct:i%4?3:-2
}));
const w=makeWindows(rows,60,20,20,20);
assert.ok(w.length>5);
const space={buySellRatio:[1,2],smartMoneyShare:[.2,.3],riskMax:[30,50],liquidityDeltaMin:[0],holderDeltaMin:[0]};
const r=v17Lab(rows,space);
assert.equal(r.runId.length,64);
assert.ok(r.windows.length>0);
assert.ok(["CONSISTENT","REGIME_SENSITIVE","UNSTABLE","INSUFFICIENT_DATA"].includes(r.status));
console.log("V17 tests passed");
