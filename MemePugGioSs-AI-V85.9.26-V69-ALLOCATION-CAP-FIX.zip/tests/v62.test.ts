import assert from 'node:assert/strict';
import { V62OpportunityArbitrator, assertV62Safe, type V62Candidate } from '../src/v62-opportunity-arbitration.js';

assertV62Safe();
const a=new V62OpportunityArbitrator({maxConcurrentOpportunities:3,maxPerStrategy:2,maxStrategyExposurePct:15,maxCorrelationGroupPct:12,maxSameMintCandidates:1,arbitrationReservePct:20,minLiquidityQuote:1000,minScore:50,minConfidence:45});
const candidates:V62Candidate[]=[
 {id:'pump',mint:'M1',source:'AI_SIGNAL',strategy:'PUMP_EARLY',score:95,confidence:90,riskScore:20,liquidityQuote:9000,requestedPct:5,correlationGroup:'G1',priority:100},
 {id:'copy',mint:'M1',source:'COPY_TRADER',strategy:'COPY_TRADER',score:94,confidence:88,riskScore:22,liquidityQuote:9000,requestedPct:5,correlationGroup:'G1',priority:99},
 {id:'smart',mint:'M2',source:'AI_SIGNAL',strategy:'SMART_MONEY',score:90,confidence:85,riskScore:25,liquidityQuote:9000,requestedPct:5,correlationGroup:'G2',priority:98},
 {id:'weak',mint:'M3',source:'AI_SIGNAL',strategy:'AI_SIGNAL',score:30,confidence:30,riskScore:50,liquidityQuote:500,requestedPct:5,priority:1},
];
const snap=a.arbitrate(candidates,[], 'FAVORABLE', 1000);
assert.equal(snap.liveExecutionEnabled,false);
assert.equal(snap.selectedCount,2);
assert.equal(snap.decisions.find(x=>x.candidateId==='copy')?.decision,'BLOCK');
assert.equal(snap.decisions.find(x=>x.candidateId==='weak')?.decision,'DEFER');
assert.ok(snap.conflictCount>=1);
console.log('V62 test passed');
