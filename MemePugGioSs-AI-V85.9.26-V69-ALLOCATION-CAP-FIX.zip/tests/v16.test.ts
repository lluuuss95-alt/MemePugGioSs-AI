
import assert from "node:assert/strict";
import { robustnessLab } from "../src/v16-lab.js";
const rows=Array.from({length:120},(_,i)=>({mint:`M${i%20}`,ts:i,buySellRatio:2,smartMoneyShare:.3,risk:20,liquidityDelta:10,holderDelta:1,futureReturnPct:i%4?3:-2}));
const scenarios=[{name:"HIGH_SLIPPAGE",feeMultiplier:2,slippageMultiplier:3,executionDelayBars:1,liquidityMultiplier:.7,missingDataRate:.05,entryDelayBars:1,exitDelayBars:1}];
const r=robustnessLab(rows,scenarios,100);
assert.equal(r.runId.length,64); assert.ok(r.scenarios.length===1); assert.ok(r.monteCarlo.runs===100);
assert.ok(["ROBUST","SENSITIVE","FRAGILE","INSUFFICIENT_DATA"].includes(r.status));
console.log("V16 tests passed");
