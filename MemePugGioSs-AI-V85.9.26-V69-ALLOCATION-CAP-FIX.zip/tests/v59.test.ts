import assert from 'node:assert/strict';
import { V59DecisionReevaluationEngine, assertV59Safe } from '../src/v59-decision-reevaluation.js';
import type { V58Job } from '../src/v58-ai-reevaluation.js';
import type { V57Change } from '../src/v57-state-change-detector.js';
import type { V56State } from '../src/v56-token-state-fusion.js';
import type { V48Candidate } from '../src/v48-ultra-discovery.js';
import type { V49Score } from '../src/v49-instant-scoring.js';

const mint='V59_TEST';
const state:V56State={mint,firstSeenAt:1,lastUpdatedAt:100,freshness:'FRESH',sourceCount:5,version:5,blockers:[],reasons:[],liquidity:5000,flowMomentum:20,holders:100,holderConcentration:10,creatorScore:70,smartMoneyScore:75,smartMoneyShare:.5,regime:'FAVORABLE',freshnessMs:10};
const candidate:V48Candidate={id:'cand-v59',token:{mint,name:'Test',symbol:'TST',creator:'creator',bondingCurve:'curve',uri:'uri',quoteMint:'SOL',mayhemMode:false,holderReward:false,signature:'sig',slot:10,createKind:'CREATE',detectedAt:100},signature:'sig',slot:10,receivedAt:100,verifiedAt:120,verificationLatencyMs:20,priority:'P0',action:'DEEP_ANALYSIS',reasons:[]};
const instant:V49Score={id:'i',mint,signature:'sig',score:90,confidence:90,band:'DEEP_ANALYSIS',metadataScore:100,creatorSignal:70,launchQuality:80,freshnessScore:99,reasons:[],blockers:[],generatedAt:100,latencyMs:20,needsDeepAnalysis:true,liveExecutionEnabled:false};
const change:V57Change={id:'c',mint,ts:100,type:'SIGNAL_UPGRADE',severity:'HIGH',version:5,previousVersion:4,message:'score improved',before:60,after:80,delta:20,actionable:true};
const job:V58Job={id:'j',mint,priority:'HIGH',reason:'SIGNAL_UPGRADE',severity:'HIGH',changeId:'c',stateVersion:5,createdAt:100,expiresAt:10000,status:'QUEUED'};
assertV59Safe();
const e=new V59DecisionReevaluationEngine({criticalRiskThreshold:90});
const r=e.reevaluate(job,change,state,{candidate,instant},1000);
assert.equal(r.mint,mint); assert.equal(r.outcome,'ENTER_PAPER'); assert.ok(['HIGH','WATCH','NONE'].includes(r.escalation)); assert.equal(r.liveExecutionEnabled,false); assert.equal(e.recent(1)[0]?.jobId,'j');
console.log('V59 test OK');
