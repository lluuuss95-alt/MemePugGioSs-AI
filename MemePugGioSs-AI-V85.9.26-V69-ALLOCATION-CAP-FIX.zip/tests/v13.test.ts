import assert from "node:assert/strict";
import { buildTokenDataset } from "../src/token-dataset-factory.js";

const e=[
 {id:"1",mint:"M",ts:0,price:1,buyVolume:10,liquidity:100,holders:10,smartMoneyVolume:5},
 {id:"2",mint:"M",ts:60_000,price:1.1,buyVolume:20,liquidity:120,holders:12,smartMoneyVolume:10},
 {id:"3",mint:"M",ts:120_000,price:1.2,sellVolume:5,liquidity:130,holders:13,smartMoneyVolume:2},
 {id:"3",mint:"M",ts:120_000,price:1.2,sellVolume:5}
];
const r=buildTokenDataset(e,60_000);
assert.equal(r.quality.tokens,1);
assert.ok(r.snapshots.length>0);
assert.ok(r.fingerprint.length===64);
assert.ok(r.labels.some(x=>x.futureReturnPct!==undefined));
console.log("V13 tests passed");
