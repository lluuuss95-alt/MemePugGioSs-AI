import assert from 'node:assert/strict';
import { V55OpportunityScheduler, assertV55Safe } from '../src/v55-opportunity-scheduler.js';
import type { V48Candidate } from '../src/v48-ultra-discovery.js';
import type { V49Score } from '../src/v49-instant-scoring.js';
assertV55Safe();
const base=Date.now();
const c=(mint:string):V48Candidate=>({token:{mint,name:'Test',symbol:'T',uri:'u',creator:'c',bondingCurve:'b'},signature:'sig-'+mint,slot:1,detectedAt:base,receivedAt:base,verificationLatencyMs:10,priority:'P0',action:'DEEP_ANALYSIS'} as any);
const i=(mint:string):V49Score=>({id:'i-'+mint,mint,signature:'sig-'+mint,score:90,confidence:90,band:'DEEP_ANALYSIS',metadataScore:90,creatorSignal:70,launchQuality:80,freshnessScore:100,reasons:[],blockers:[],generatedAt:base,latencyMs:10,needsDeepAnalysis:true,liveExecutionEnabled:false});
const seen:string[]=[];
const s=new V55OpportunityScheduler({onDeepAnalysis:async j=>{seen.push(j.mint)}} ,{maxInFlight:2,maxJobsPerMintPerWindow:2,windowMs:1000});
s.start();
assert.ok(s.enqueue(c('a'),i('a'))); assert.ok(s.enqueue(c('b'),i('b'))); assert.ok(s.enqueue(c('a'),i('a'))===null); // same fingerprint
await new Promise(r=>setTimeout(r,30)); s.stop();
assert.ok(seen.includes('a')); assert.ok(seen.includes('b')); assert.ok(s.health().dispatched>=2);
console.log('V55 tests passed');
