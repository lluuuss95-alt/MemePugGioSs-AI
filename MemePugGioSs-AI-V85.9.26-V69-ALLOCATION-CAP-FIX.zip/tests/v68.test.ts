import assert from 'node:assert/strict';
import { V68AdaptivePaperRiskCalibration, V68_SAFETY, assertV68Safe } from '../src/v68-adaptive-paper-risk-calibration.js';
assertV68Safe(); assert.equal(V68_SAFETY.liveExecutionAllowed,false);
const engine=new V68AdaptivePaperRiskCalibration();
const r=engine.calibrate({baselineRiskPct:65,baselinePositionPct:5,baselineTotalExposurePct:35,now:Date.now()});
assert.equal(r.state,'INSUFFICIENT_DATA');
assert.equal(r.riskMultiplier,1);
assert.ok(r.calibratedRiskPct<=65);
console.log('V68 test passed');
