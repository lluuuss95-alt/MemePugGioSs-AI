import assert from "node:assert/strict";
import {V22MarketIntelligence} from "../src/v22-intelligence.js";
import {assertV22Safety} from "../src/v22-safety.js";
const i=new V22MarketIntelligence();
const e={id:"1",signature:"s",slot:1,venue:"PUMP_BONDING_CURVE",type:"SWAP",side:"BUY",mint:"M",trader:"T",quoteAmount:1,confidence:1,verified:true,observedAt:1} as any;
const x=i.apply(e)!;assert.equal(x.lifecycle,"BONDING_CURVE");assert.equal(x.netFlow,1);assert.equal(x.tradable,true);assert.equal(assertV22Safety(),true);
console.log("V22 tests passed");
