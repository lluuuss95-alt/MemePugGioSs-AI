# MemePugGioSs AI V41 Release

V41 introduces the AI Autonomous Trading Orchestrator. It is an explainable coordination layer over the existing signal, Copy Trading and risk engines.

## Runtime contract
- PAPER/SHADOW only
- live execution disabled
- signing disabled
- broadcast disabled
- no automatic promotion to LIVE

## New endpoints
- GET `/api/v41/assistant`
- GET `/api/v41/decisions`
- POST `/api/v41/decide`
- POST `/api/v41/cycle`

The cycle evaluates current V28 PAPER candidates and V36 eligible Copy Signals. Copy candidates pass through V38 risk preflight before any Paper execution adapter is considered.

V41 deliberately does not invent prices or execute a Paper trade without valid market execution context.
