# V85.9 — CI Certification Hardening

V85.9 does not claim local runtime certification. It makes the release pipeline self-verifying after a clean online CI run.

## Required CI evidence
- generated `package-lock.json`
- clean `npm ci`
- TypeScript build and test/typecheck
- Paper/Shadow safety and E2E validation
- runtime Paper validation
- final certification report
- Android debug APK build
- final artifact-presence gate

`npm run validate:ci-artifacts` intentionally fails locally when the clean CI artifacts do not exist. This prevents a local source-only archive from being mistaken for a runtime-certified release.

Live execution remains disabled: no signing, private-key access, broadcast, live execution or automatic promotion.
