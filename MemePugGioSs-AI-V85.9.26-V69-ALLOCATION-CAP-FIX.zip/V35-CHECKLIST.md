# V35 checklist

- [x] Rolling 7D/30D/90D/ALL windows
- [x] Closed-trade P&L reconstruction
- [x] Drawdown reconstruction
- [x] Consistency score
- [x] Sample quality score
- [x] Token concentration flag
- [x] Pump/PumpSwap specialization score
- [x] Deterministic reputation score and state
- [x] REST endpoints `/api/v35/traders`, `/api/v35/traders/:wallet/reputation`, `/api/v35/recalculate`
- [x] Assistant status endpoint `/api/v35/assistant`
- [x] WebSocket V35 reputation + assistant snapshot
- [x] Live trading/signing/broadcast safety gates
- [x] Android architecture docs updated to V35

Runtime build verification depends on installing the Node dependencies in the target environment; no claim of a production Android APK is made here.
