# V29 Checklist
- [x] Composite ranking over V28 signals
- [x] Risk/confidence/liquidity gates
- [x] Freshness time decay
- [x] Deterministic tie breaking
- [x] Home feed adapter
- [x] Unit test
- [x] Shadow/PAPER only
- [ ] Validate against long-run real Mainnet dataset
- [ ] Calibrate weights with out-of-sample evaluation
