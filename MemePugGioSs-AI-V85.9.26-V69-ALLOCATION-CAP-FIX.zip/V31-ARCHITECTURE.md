# V31 — Paper Portfolio & Performance Analytics

V30 decisions/execution feed a persistent portfolio accounting layer. V31 tracks cash, exposure, open/closed paper trades, realized/unrealized P&L, equity snapshots, peak equity and drawdown, plus aggregate metrics and token-level attribution.

Pipeline: Signal -> Decision -> Paper Execution -> Portfolio Ledger -> Analytics -> Android Home.

Safety remains PAPER only. No signing, private keys, broadcast, live trading, or automatic promotion.
