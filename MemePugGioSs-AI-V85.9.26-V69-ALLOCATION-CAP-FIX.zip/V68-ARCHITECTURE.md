# V68 — Adaptive Paper Risk Calibration

V68 derives a conservative PAPER-only risk profile from V66 execution-quality observations.
It never increases baseline risk and never changes live execution permissions.

Flow: V66 observations -> rolling quality statistics -> bounded risk multiplier -> V68 profile -> downstream risk/allocation consumers.

Safety invariants: PAPER/SHADOW only, no private keys, signing, broadcast, live execution or auto-promotion.

Default controls: minimum 20 observations; 200-row window; multiplier 0.50..1.00; maximum step 0.10 per calibration; high block/deviation/latency conditions reduce risk ceilings.

V68 emits recommendations/profile values. Existing hard caps in V46/V47/V61/V63/V64 remain authoritative and are never relaxed by V68.
