# V43 — AI Learning & Strategy Adaptation

V43 consumes outcome feedback from V41 decisions (and later V42 position exits) to measure win/loss rate, average return and sample confidence. After a configurable minimum sample size it makes small bounded policy-weight adjustments; this is deterministic online adaptation, not a claim of predictive ML.

## Safety
- PAPER/SHADOW only
- no private keys, signing or broadcast
- auto-promotion permanently disabled
- bounded weights and minimum sample gate
- insufficient data => no adaptation
- no fabricated market outcomes

## Flow
V41 decision -> position outcome feedback -> V43 ledger -> statistics -> bounded policy adaptation -> next V41 cycle.

V43 does not rewrite historical trades and does not infer missing outcomes.
