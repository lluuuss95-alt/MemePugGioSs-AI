# V39 — Copy Trading Analytics

V39 adds an analytics layer on top of V35–V38.

Flow:
V34 observed trader history -> V35 reputation -> V36 copy signals -> V38 risk -> V37 paper portfolio -> V39 analytics.

## Metrics
- starting capital and current equity
- realized, unrealized and net P&L
- cumulative return from Copy Trading start
- win rate and trade count
- fees and simulated slippage
- drawdown from recorded equity snapshots
- per-trader copy vs observed realized P&L
- average signal latency
- eligible and blocked signal counts

## Equity curve
V39 stores time-stamped portfolio snapshots. Historical points are only populated from the moment V39 is enabled; it never fabricates prior equity observations. Realized P&L can still be reconstructed from the V37 ledger.

## Safety
Analytics is read-only and PAPER/SHADOW only. It does not sign, broadcast, promote, or access private keys.
