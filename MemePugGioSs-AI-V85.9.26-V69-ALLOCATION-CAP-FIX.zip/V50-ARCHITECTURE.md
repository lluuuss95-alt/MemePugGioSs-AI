# MemePugGioSs AI — V50 Deep Token Intelligence

V50 consumes only candidates selected for DEEP_ANALYSIS by V49. It combines explicitly supplied verified observations from the existing on-chain/market intelligence layers: liquidity, flow/momentum, holder distribution, creator intelligence, smart-money activity and market regime.

Pipeline: Pump.fun WebSocket -> V48 verification/triage -> V49 instant score -> V50 deep intelligence -> V41 orchestrator/V46 allocator/V47 portfolio -> Paper execution.

Missing observations reduce confidence or block the candidate; V50 never invents prices, liquidity, holder data, creator history or smart-money activity. Names/symbols are not treated as economic signals.

Safety invariant: PAPER/SHADOW only. No private-key access, signing, transaction broadcast, live execution or automatic promotion.
