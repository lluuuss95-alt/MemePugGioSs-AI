# MemePugGioSs AI Android - no custom shrinking rules yet.
