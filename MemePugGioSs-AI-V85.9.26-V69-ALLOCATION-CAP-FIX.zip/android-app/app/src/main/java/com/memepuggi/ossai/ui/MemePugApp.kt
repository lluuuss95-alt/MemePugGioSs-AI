package com.memepuggi.ossai.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08050F); private val Panel = Color(0xFF120B20); private val Panel2 = Color(0xFF171027)
private val Purple = Color(0xFF8A4DFF); private val Cyan = Color(0xFF32E6FF); private val Text = Color(0xFFF2ECFF); private val Muted = Color(0xFF9C91B5); private val Green = Color(0xFF4DFFB2); private val Red = Color(0xFFFF5878)

@Composable fun MemePugApp(vm: MemePugViewModel) { if (vm.state.token == null) LoginScreen(vm) else MainScreen(vm) }

@Composable private fun LoginScreen(vm: MemePugViewModel) {
    Box(Modifier.fillMaxSize().background(Bg).padding(24.dp), contentAlignment = Alignment.Center) {
        Card(colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.widthIn(max = 430.dp).fillMaxWidth()) {
            Column(Modifier.padding(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("MemePugGioSs AI", color = Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Android Control Center • V85", color = Cyan, fontSize = 13.sp)
                OutlinedTextField(vm.state.serverUrl, vm::setServer, label={Text("Backend URL")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                OutlinedTextField(vm.state.username, vm::setUser, label={Text("Username")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                OutlinedTextField(vm.state.password, vm::setPassword, label={Text("Password")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                Button(onClick=vm::login, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Purple)) { Text("CONNETTI") }
                vm.state.lastError?.let { Text(it, color=Red, fontSize=12.sp) }
                Text("PAPER MODE • COPY PAPER • LIVE disabilitato", color=Muted, fontSize=12.sp)
            }
        }
    }
}

@Composable private fun MainScreen(vm: MemePugViewModel) {
    LaunchedEffect(Unit) { while (true) { vm.refresh(); vm.refreshMobileSnapshot(); kotlinx.coroutines.delay(3000) } }
    Row(Modifier.fillMaxSize().background(Bg)) {
        NavigationRail(Modifier.width(92.dp).fillMaxHeight().background(Color(0xFF0C0715))) {
            Spacer(Modifier.height(12.dp)); Text("🐶", fontSize=27.sp, modifier=Modifier.padding(12.dp))
            NavItem("⌂", "Home", vm.state.screen == Screen.HOME) { vm.setScreen(Screen.HOME) }
            NavItem("◉", "AI", vm.state.screen == Screen.AI) { vm.setScreen(Screen.AI) }
            NavItem("☆", "Pump", false) {}
            NavItem("◈", "Monitor", false) {}
            NavItem("↯", "Copy", vm.state.screen == Screen.COPY) { vm.setScreen(Screen.COPY) }
            NavItem("▣", "Portfolio", false) {}
            NavItem("⚙", "Settings", false) {}
        }
        when (vm.state.screen) { Screen.HOME -> HomeScreen(vm); Screen.COPY -> CopyTradingScreen(vm); Screen.AI -> AssistantScreen(vm) }
    }
}

@Composable private fun NavItem(icon:String, label:String, selected:Boolean, onClick:()->Unit) {
    TextButton(onClick=onClick, modifier=Modifier.fillMaxWidth().padding(horizontal=4.dp), colors=ButtonDefaults.textButtonColors(contentColor=if(selected) Cyan else Muted)) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) { Text(icon, fontSize=21.sp); Text(label, fontSize=9.sp, fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal) }
    }
}

@Composable private fun HomeScreen(vm:MemePugViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Header(vm)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) { Kpi("CAPITALE",vm.state.portfolioCash); Kpi("P&L",vm.state.realizedPnl); Kpi("TOKEN MONITORATI",vm.state.tokens.toString()); Kpi("SEGNALI AI",vm.state.opportunities.toString()) }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(14.dp)) { PanelCard("Mercato Solana Meme Coins (Live)",Modifier.weight(1f).height(230.dp)){ChartPlaceholder()}; PanelCard("Top Segnali AI (Live)",Modifier.weight(1f).height(230.dp)){SignalList(vm.state.topSignals)} }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(14.dp)) { PanelCard("Nuovi Token da Pump.fun (Live)",Modifier.weight(1f).height(190.dp)){TokenFeed(vm.state.marketTokens)}; PanelCard("Performance (Paper Trading)",Modifier.weight(1f).height(190.dp)){Performance(vm)} }
        Spacer(Modifier.height(14.dp)); PanelCard("Copy Trading — riepilogo",Modifier.fillMaxWidth().height(150.dp)){CopyMini(vm)}
        Spacer(Modifier.height(14.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(14.dp)){PanelCard("Trade Recenti (Paper)",Modifier.weight(1f).height(170.dp)){Text("PAPER/SHADOW • nessun broadcast",color=Muted,fontSize=12.sp)};PanelCard("Stato Sistema",Modifier.weight(1f).height(170.dp)){SystemStatus(vm)};PanelCard("Allocazione & Rischio",Modifier.weight(1f).height(170.dp)){RiskBlock(vm)}}
    }
}

@Composable private fun Header(vm:MemePugViewModel){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("MemePugGioSs AI",color=Text,fontSize=24.sp,fontWeight=FontWeight.Bold);Text("SOLANA MEME COIN INTELLIGENCE",color=Muted,fontSize=11.sp)};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Badge("PAPER MODE",Purple);Badge("SOLANA MAINNET",Cyan)}}}
@Composable private fun CopyTradingScreen(vm:MemePugViewModel){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){Header(vm);Spacer(Modifier.height(16.dp));Text("Copy Trading",color=Text,fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Analisi e replica simulata dei trader osservati",color=Muted,fontSize=12.sp);Spacer(Modifier.height(14.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Kpi("COPY P&L",vm.state.copyPnl);Kpi("EQUITY COPY",vm.state.copyEquity);Kpi("RENDIMENTO",vm.state.copyReturn);Kpi("DRAWDOWN",vm.state.copyDrawdown)};Spacer(Modifier.height(14.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(14.dp)){PanelCard("Equity Copy Trading — dall'inizio",Modifier.weight(1f).height(290.dp)){EquityChart(vm.state.equity)};PanelCard("Risk Status",Modifier.weight(1f).height(290.dp)){RiskCopy(vm)}};Spacer(Modifier.height(14.dp));PanelCard("Trader monitorati",Modifier.fillMaxWidth().height(230.dp)){TraderTable(vm)};Spacer(Modifier.height(14.dp));PanelCard("Ultimi Copy Signal",Modifier.fillMaxWidth().height(170.dp)){Text("Eligible: ${vm.state.copyEligible} • Bloccati: ${vm.state.copyBlocked}",color=Text,fontSize=13.sp);Text("Ogni blocco conserva il motivo del Risk Manager.",color=Muted,fontSize=11.sp);Text("PAPER EXECUTION • LIVE OFF",color=Green,fontSize=11.sp)}}}
@Composable private fun AssistantScreen(vm:MemePugViewModel){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){Header(vm);Spacer(Modifier.height(16.dp));PanelCard("Assistente AI — Autonomous Research",Modifier.fillMaxWidth().height(220.dp)){Text("STATO: PAPER AUTONOMOUS",color=Green,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text("Studia mercato, segnali, trader e rischio; genera decisioni Paper senza chiavi private, firma o broadcast.",color=Text,fontSize=13.sp);Spacer(Modifier.height(12.dp));Text("Segnali qualificati: ${vm.state.copyEligible}",color=Cyan,fontSize=12.sp);Text("Risk gate: ${vm.state.copyRisk}",color=Muted,fontSize=12.sp)}}}

@Composable private fun EquityChart(points:List<Double>){Box(Modifier.fillMaxSize().background(Panel2,RoundedCornerShape(12.dp)).padding(12.dp)){Canvas(Modifier.fillMaxSize()){if(points.size>1){val min=points.minOrNull()?:0.0;val max=points.maxOrNull()?:1.0;val range=(max-min).takeIf{it>0}?:1.0;val path=Path();points.forEachIndexed{i,v->val x=size.width*i.toFloat()/(points.lastIndex);val y=size.height-((v-min)/range).toFloat()*size.height;if(i==0)path.moveTo(x,y)else path.lineTo(x,y)};drawPath(path,color=Cyan,style=androidx.compose.ui.graphics.drawscope.Stroke(width=4f))}};if(points.isEmpty())Text("In attesa del primo snapshot",color=Muted,fontSize=12.sp,modifier=Modifier.align(Alignment.Center))}}
@Composable private fun TraderTable(vm:MemePugViewModel){Column(verticalArrangement=Arrangement.spacedBy(7.dp)){vm.copyTraders.forEach{t->Row(Modifier.fillMaxWidth().background(Panel2,RoundedCornerShape(8.dp)).padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(t.first,color=Text,fontSize=12.sp);Text(t.second,color=Cyan,fontSize=11.sp);Text(t.third,color=if(t.third.startsWith("-") ) Red else Green,fontSize=11.sp)}};if(vm.copyTraders.isEmpty())Text("Nessun trader disponibile nel feed.",color=Muted,fontSize=12.sp)}}
@Composable private fun RiskCopy(vm:MemePugViewModel){Column(verticalArrangement=Arrangement.spacedBy(9.dp)){Text(vm.state.copyRisk,color=if(vm.state.copyRisk=="NORMAL")Green else if(vm.state.copyRisk=="WARNING")Color(0xFFFFC857) else Red,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Trader qualificati ${vm.state.copyTradersCount} • Seguiti ${vm.state.copyFollowing}",color=Muted,fontSize=12.sp);Text("Win rate ${vm.state.copyWinRate} • Operazioni ${vm.state.copyTrades}",color=Muted,fontSize=12.sp);Text("Slippage medio ${vm.state.copySlippage}",color=Muted,fontSize=12.sp)}}
@Composable private fun CopyMini(vm:MemePugViewModel){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("P&L ${vm.state.copyPnl}",color=Text);Text("Trader ${vm.state.copyTradersCount}",color=Cyan);Text("Risk ${vm.state.copyRisk}",color=Green);Text("COPY PAPER",color=Purple,fontWeight=FontWeight.Bold)}}
@Composable private fun Badge(t:String,c:Color){Surface(color=c.copy(alpha=.13f),shape=RoundedCornerShape(20.dp)){Text(t,color=c,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=10.dp,vertical=7.dp))}}
@Composable private fun Kpi(a:String,b:String){Card(colors=CardDefaults.cardColors(Panel),shape=RoundedCornerShape(14.dp),modifier=Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text(a,color=Muted,fontSize=10.sp);Text(b,color=Text,fontSize=19.sp,fontWeight=FontWeight.Bold)}}}
@Composable private fun PanelCard(title:String,modifier:Modifier,content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(Panel),shape=RoundedCornerShape(16.dp),modifier=modifier){Column(Modifier.padding(16.dp)){Text(title,color=Text,fontSize=14.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(10.dp));content()}}}
@Composable private fun ChartPlaceholder(){Box(Modifier.fillMaxSize().background(Panel2,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Text("LIVE PRICE / LIQUIDITY • BACKEND FEED",color=Cyan,fontSize=12.sp)}}
@Composable private fun SignalList(items:List<SignalUi>){Column(verticalArrangement=Arrangement.spacedBy(6.dp)){items.take(4).forEach{Row(Modifier.fillMaxWidth().background(Panel2,RoundedCornerShape(9.dp)).padding(8.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(it.mint.take(10),color=Text,fontSize=11.sp);Text("${it.state} • ${it.action}",color=Muted,fontSize=9.sp)};Text(String.format("%.1f",it.score),color=Cyan,fontSize=12.sp,fontWeight=FontWeight.Bold)}};if(items.isEmpty())Text("In attesa di segnali verificati…",color=Muted,fontSize=12.sp)}}
@Composable private fun TokenFeed(items:List<MarketTokenUi>){Column(verticalArrangement=Arrangement.spacedBy(5.dp)){items.take(4).forEach{Row(Modifier.fillMaxWidth().background(Panel2,RoundedCornerShape(8.dp)).padding(7.dp),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(if(it.symbol.isBlank())it.name else "${it.symbol} • ${it.name}",color=Text,fontSize=10.sp);Text("Score %.1f • Risk %.1f".format(it.score,it.risk),color=Muted,fontSize=8.sp)};Text(if(it.tradable)"TRADABLE" else if(it.signal=="—")"WATCH" else it.signal,color=if(it.tradable)Green else Cyan,fontSize=9.sp,fontWeight=FontWeight.Bold)}};if(items.isEmpty())Text("In attesa di nuovi token Pump.fun…",color=Muted,fontSize=12.sp);Text("V85 • verified backend feed • PAPER/SHADOW ONLY",color=Green,fontSize=9.sp)}}
@Composable private fun Performance(vm:MemePugViewModel){Text("Equity",color=Muted,fontSize=11.sp);Text(vm.state.portfolioEquity,color=Green,fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Realizzato ${vm.state.realizedPnl} • Non realizzato ${vm.state.unrealizedPnl}",color=Muted,fontSize=11.sp);Text("Drawdown ${vm.state.drawdown} • Posizioni ${vm.state.openPositions}",color=Muted,fontSize=11.sp)}
@Composable private fun SystemStatus(vm:MemePugViewModel){Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text("● API ${if(vm.state.connected)"ONLINE" else "OFFLINE"}",color=if(vm.state.connected)Green else Red,fontSize=12.sp);Text("RPC ${vm.state.rpc}",color=Muted,fontSize=11.sp);Text("Engine ${vm.state.engine}",color=Muted,fontSize=11.sp);Text("Health ${vm.state.healthState}",color=if(vm.state.healthState=="RUNNING") Green else Red,fontSize=11.sp);Text("Paper Safe ${if(vm.state.safeToRunPaper) "YES" else "NO"}",color=if(vm.state.safeToRunPaper) Green else Red,fontSize=11.sp);Text("Realtime ${vm.state.realtime}",color=Cyan,fontSize=11.sp);Text("Release ${vm.state.releaseState}",color=if(vm.state.releaseState=="READY") Green else Red,fontSize=11.sp)}}
@Composable private fun RiskBlock(vm:MemePugViewModel){Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text("PAPER ALLOCATION",color=Muted,fontSize=11.sp);Text("Cash ${vm.state.portfolioCash}",color=Text,fontSize=15.sp,fontWeight=FontWeight.Bold);Text("Exposure / rischio aggiornati realtime",color=Muted,fontSize=11.sp);Text("Risk gate attivo • LIVE OFF",color=Green,fontSize=11.sp);Text("Pipeline ${vm.state.pipelineOutcome} • Quality ${vm.state.executionQuality}",color=Muted,fontSize=10.sp);Text("Calibration ${vm.state.calibrationState}",color=Muted,fontSize=10.sp)}}
