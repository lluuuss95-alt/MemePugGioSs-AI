package com.memepuggi.ossai.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val Dark = darkColorScheme(primary=Color(0xFF8A4DFF),secondary=Color(0xFF32E6FF),background=Color(0xFF08050F),surface=Color(0xFF120B20),onSurface=Color(0xFFF2ECFF))
@Composable fun MemePugTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=Dark,content=content)}
