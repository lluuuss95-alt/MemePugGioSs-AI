package com.memepuggi.ossai.realtime

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class RealtimeClient(private val scope: CoroutineScope) {
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private var socket: WebSocket? = null
    private var reconnectJob: Job? = null
    private var endpoint: String = ""
    private var token: String = ""
    private var stopped = true
    var onState: ((JSONObject) -> Unit)? = null
    var onStatus: ((String) -> Unit)? = null

    fun start(serverUrl: String, jwt: String) {
        stop(); stopped = false; token = jwt
        endpoint = serverUrl.trimEnd('/').replaceFirst("http://", "ws://").replaceFirst("https://", "wss://") + "/ws?token=" + jwt
        connect()
    }

    fun stop() { stopped = true; reconnectJob?.cancel(); reconnectJob = null; socket?.close(1000, "stop"); socket = null }

    private fun connect() {
        if (stopped) return
        onStatus?.invoke("CONNECTING")
        val request = Request.Builder().url(endpoint).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { onStatus?.invoke("CONNECTED") }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try { val obj = JSONObject(text); if (obj.optString("type") == "state") onState?.invoke(obj) } catch (_: Exception) {}
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus?.invoke("RECONNECTING"); scheduleReconnect()
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (!stopped) { onStatus?.invoke("RECONNECTING"); scheduleReconnect() } }
        })
    }

    private fun scheduleReconnect() {
        if (stopped || reconnectJob?.isActive == true) return
        reconnectJob = scope.launch(Dispatchers.IO) { delay(1500); if (!stopped) connect() }
    }
}
