package com.memepuggi.ossai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.memepuggi.ossai.ui.MemePugViewModel
import com.memepuggi.ossai.ui.MemePugApp
import com.memepuggi.ossai.ui.theme.MemePugTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MemePugTheme { MemePugApp(viewModel()) }
        }
    }
}
