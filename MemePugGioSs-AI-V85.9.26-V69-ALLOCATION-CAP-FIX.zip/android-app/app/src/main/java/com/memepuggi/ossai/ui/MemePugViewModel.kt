package com.memepuggi.ossai.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import com.memepuggi.ossai.realtime.RealtimeClient

enum class Screen { HOME, COPY, AI }
data class MarketTokenUi(val symbol:String,val name:String,val price:Double,val liquidity:Double,val score:Double,val risk:Double,val signal:String,val action:String,val tradable:Boolean)
data class SignalUi(val mint:String,val state:String,val action:String,val score:Double,val confidence:Double,val risk:Double)
data class HomeState(
    val serverUrl:String="http://10.0.2.2:8787", val username:String="admin", val password:String="", val token:String?=null,
    val rpc:String="—", val engine:String="—", val opportunities:Int=0, val tokens:Int=0, val lastError:String?=null, val connected:Boolean=false, val realtime:String="OFFLINE",
    val portfolioEquity:String="€0.00", val portfolioCash:String="€0.00", val realizedPnl:String="€0.00", val unrealizedPnl:String="€0.00", val drawdown:String="0.0%", val openPositions:Int=0,
    val copyTradersCount:Int=0, val copyFollowing:Int=0, val copyPnl:String="€0.00", val copyEquity:String="€0.00", val copyReturn:String="0.00%", val copyDrawdown:String="0.00%",
    val copyRisk:String="NORMAL", val copyWinRate:String="0.00%", val copyTrades:Int=0, val copySlippage:String="0.00%", val copyEligible:Int=0, val copyBlocked:Int=0,
    val equity:List<Double> = emptyList(), val marketTokens:List<MarketTokenUi> = emptyList(), val topSignals:List<SignalUi> = emptyList(), val priceHistory:List<Double> = emptyList(), val copyTraders:List<Triple<String,String,String>> = emptyList(), val healthState:String="UNKNOWN", val safeToRunPaper:Boolean=false, val pipelineOutcome:String="—", val executionQuality:String="—", val calibrationState:String="—", val releaseState:String="UNKNOWN", val screen:Screen=Screen.HOME
)
class MemePugViewModel:ViewModel(){
    private val realtimeClient=RealtimeClient(viewModelScope); var state by mutableStateOf(HomeState()); private set
    fun setServer(v:String){state=state.copy(serverUrl=v.trimEnd('/'))}; fun setUser(v:String){state=state.copy(username=v)}; fun setPassword(v:String){state=state.copy(password=v)}; fun setScreen(s:Screen){state=state.copy(screen=s)}
    fun refreshMobileSnapshot()=viewModelScope.launch {
        val t=state.token?:return@launch
        try {
            val o=request("GET","/api/v71/mobile/snapshot",null,t)
            val sys=o.optJSONObject("system"); val auto=o.optJSONObject("autonomous")
            val pipeline=auto?.optJSONObject("latestPipeline"); val quality=auto?.optJSONObject("latestQuality"); val calibration=auto?.optJSONObject("latestCalibration")
            state=state.copy(healthState=sys?.optString("state",state.healthState)?:state.healthState, safeToRunPaper=sys?.optBoolean("safeToRunPaper",false)?:false, pipelineOutcome=pipeline?.optString("outcome",state.pipelineOutcome)?:state.pipelineOutcome, executionQuality=quality?.optString("state",quality?.optString("decision",state.executionQuality)?:state.executionQuality)?:state.executionQuality, calibrationState=calibration?.optString("state",state.calibrationState)?:state.calibrationState)
            val feed=request("GET","/api/v72/mobile/market-feed?limit=50",null,t)
            val ts=mutableListOf<MarketTokenUi>(); val arr=feed.optJSONArray("tokens")
            if(arr!=null) for(i in 0 until arr.length()){val x=arr.optJSONObject(i)?:continue; ts+=MarketTokenUi(x.optString("symbol"),x.optString("name"),x.optDouble("price"),x.optDouble("liquidity"),x.optDouble("score"),x.optDouble("riskScore"),x.optString("signalState","—"),x.optString("signalAction","—"),x.optBoolean("tradable"))}
            val ss=mutableListOf<SignalUi>(); val sa=feed.optJSONArray("signals")
            if(sa!=null) for(i in 0 until minOf(sa.length(),20)){val x=sa.optJSONObject(i)?:continue; ss+=SignalUi(x.optString("mint"),x.optString("state"),x.optString("action"),x.optDouble("score"),x.optDouble("confidence"),x.optDouble("riskScore"))}
            state=state.copy(tokens=ts.size,opportunities=ss.size,marketTokens=ts,topSignals=ss)
            val release=request("GET","/api/v85/release-readiness",null,t)
            state=state.copy(releaseState=release.optString("state","UNKNOWN"))
        } catch(e:Exception) { state=state.copy(lastError=e.message?:"Market feed error") }
    }
    fun login()=viewModelScope.launch{try{val body=JSONObject().put("username",state.username).put("password",state.password).toString();val result=request("POST","/api/login",body,null);state=state.copy(token=result.getString("token"),connected=true,lastError=null);realtimeClient.onStatus={s->state=state.copy(realtime=s)};realtimeClient.onState={o->applyRealtime(o)};realtimeClient.start(state.serverUrl,state.token!!);refresh()}catch(e:Exception){state=state.copy(connected=false,lastError=e.message?:"Connection error")}}
    private fun applyRealtime(o:JSONObject){val pf=o.optJSONObject("portfolio");val ca=o.optJSONObject("copyAnalytics");val cs=o.optJSONObject("copyRisk");val copyTraders=o.optJSONArray("copyTraders");val following=o.optJSONArray("following");val signals=o.optJSONArray("copySignals");val eq=ca?.optJSONArray("equity")?.toDoubleList()?:state.equity;val rows=mutableListOf<Triple<String,String,String>>();if(copyTraders!=null)for(i in 0 until copyTraders.length()){val x=copyTraders.optJSONObject(i)?:continue;rows+=Triple(x.optString("wallet",x.optString("address","Trader ${i+1}")).take(10),String.format("Score %.1f",x.optDouble("score",0.0)),String.format("%.2f%%",x.optDouble("pnlPct",0.0)))};state=state.copy(portfolioEquity=euro(pf?.optDouble("equity",0.0)),portfolioCash=euro(pf?.optDouble("cash",0.0)),realizedPnl=euro(pf?.optDouble("realizedPnl",0.0)),unrealizedPnl=euro(pf?.optDouble("unrealizedPnl",0.0)),drawdown=pct(pf?.optDouble("drawdownPct",0.0)),openPositions=pf?.optInt("openPositions",0)?:0,copyTradersCount=copyTraders?.length()?:state.copyTradersCount,copyFollowing=following?.length()?:state.copyFollowing,copyPnl=euro(ca?.optDouble("netPnl",0.0)),copyEquity=euro(ca?.optDouble("equity",0.0)),copyReturn=pct(ca?.optDouble("returnPct",0.0)),copyDrawdown=pct(ca?.optDouble("maxDrawdownPct",0.0)),copyRisk=cs?.optString("state",state.copyRisk)?:state.copyRisk,copyWinRate=pct(ca?.optDouble("winRatePct",0.0)),copyTrades=ca?.optInt("trades",0)?:0,copySlippage=pct(ca?.optDouble("avgSlippagePct",0.0)),copyEligible=signals?.length()?:state.copyEligible,equity=eq,copyTraders=rows,realtime="CONNECTED")}
    fun refresh()=viewModelScope.launch{val t=state.token?:return@launch;try{val home=request("GET","/api/state",null,t);val opp=home.optJSONArray("opportunities");val eng=home.optJSONObject("engine");state=state.copy(opportunities=opp?.length()?:0,engine=eng?.optString("status","RUNNING")?:"RUNNING",connected=true,lastError=null);val portfolio=request("GET","/api/v32/portfolio",null,t).optJSONObject("summary");state=state.copy(portfolioEquity=euro(portfolio?.optDouble("equity",0.0)),portfolioCash=euro(portfolio?.optDouble("cash",0.0)),realizedPnl=euro(portfolio?.optDouble("realizedPnl",0.0)),unrealizedPnl=euro(portfolio?.optDouble("unrealizedPnl",0.0)),drawdown=pct(portfolio?.optDouble("drawdownPct",0.0)),openPositions=portfolio?.optInt("openPositions",0)?:0);val tokens=request("GET","/api/tokens",null,t);state=state.copy(tokens=JSONArray(tokens.toString()).length());val ca=request("GET","/api/v39/copy/analytics",null,t);val cs=request("GET","/api/v39/copy/analytics/summary",null,t);val eq=request("GET","/api/v39/copy/analytics/equity?limit=300",null,t);val traders=request("GET","/api/v39/copy/analytics/traders?limit=20",null,t);state=state.copy(copyPnl=euro(ca.optDouble("netPnl",cs.optDouble("netPnl",0.0))),copyEquity=euro(ca.optDouble("equity",cs.optDouble("equity",0.0))),copyReturn=pct(ca.optDouble("returnPct",cs.optDouble("returnPct",0.0))),copyDrawdown=pct(ca.optDouble("maxDrawdownPct",cs.optDouble("maxDrawdownPct",0.0))),copyWinRate=pct(ca.optDouble("winRatePct",cs.optDouble("winRatePct",0.0))),copyTrades=ca.optInt("trades",cs.optInt("trades",0)),copySlippage=pct(ca.optDouble("avgSlippagePct",0.0)),equity=eq.optJSONArray("points")?.toDoubleList()?:state.equity,copyTraders=traders.optJSONArray("traders")?.toTraderList()?:state.copyTraders,copyTradersCount=traders.optJSONArray("traders")?.length()?:state.copyTradersCount); refreshMobileSnapshot()}catch(e:Exception){state=state.copy(connected=false,lastError=e.message?:"Refresh error")}}
    override fun onCleared(){realtimeClient.stop();super.onCleared()}
    private suspend fun request(method:String,path:String,body:String?,token:String?):JSONObject=withContext(Dispatchers.IO){val c=URL(state.serverUrl+path).openConnection() as HttpURLConnection;c.requestMethod=method;c.connectTimeout=5000;c.readTimeout=7000;c.setRequestProperty("Content-Type","application/json");if(token!=null)c.setRequestProperty("Authorization","Bearer $token");if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body.toByteArray())}};val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val text=stream?.bufferedReader()?.use{it.readText()}?:"{}";if(code !in 200..299)throw IllegalStateException("HTTP $code: $text");JSONObject(text)}
    private fun euro(v:Double?)="€"+String.format("%.2f",v?:0.0);private fun pct(v:Double?)=String.format("%.2f%%",v?:0.0)
}
private fun JSONArray.toDoubleList():List<Double>{val out=mutableListOf<Double>();for(i in 0 until length()){val x=optJSONObject(i);out+=x?.optDouble("equity",x.optDouble("value",Double.NaN))?:optDouble(i,Double.NaN)};return out.filter{!it.isNaN()}}
private fun JSONArray.toTraderList():List<Triple<String,String,String>>{val out=mutableListOf<Triple<String,String,String>>();for(i in 0 until length()){val x=optJSONObject(i)?:continue;out+=Triple(x.optString("wallet",x.optString("address","Trader ${i+1}")).take(10),String.format("Score %.1f",x.optDouble("score",0.0)),String.format("%.2f%%",x.optDouble("pnlPct",0.0)))};return out}
