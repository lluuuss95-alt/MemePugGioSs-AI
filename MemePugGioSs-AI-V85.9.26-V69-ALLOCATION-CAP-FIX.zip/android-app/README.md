# MemePugGioSs AI — Android App V35

Native Android client built with Kotlin + Jetpack Compose. The app is the mobile shell for the existing V26/V25 backend engines.

Architecture:
Android Compose UI -> authenticated REST API -> Node/TypeScript engine -> Solana RPC/WebSocket -> V24/V25/V26 intelligence.

The mobile client does not contain private keys and does not sign or broadcast transactions. Default operation is PAPER/SHADOW.

Open `android-app` in Android Studio and run the `app` configuration. Set the backend URL on the login screen (emulator example: `http://10.0.2.2:8787`).

V35 adds a recovery-aware portfolio status surface; the Android client remains a UI/client layer and never stores private keys or signs transactions.


V35 adds native Home navigation targets for Assistente AI and Copy Trading, plus the cumulative performance surface. The client remains PAPER/SHADOW and contains no private keys.

## V71
Adds authenticated `GET /api/v71/mobile/snapshot` integration for a consolidated read-only operator snapshot. Android remains PAPER/SHADOW and does not store private keys or sign/broadcast transactions.
