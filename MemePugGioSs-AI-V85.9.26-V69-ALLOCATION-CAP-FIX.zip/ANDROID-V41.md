# Android V41 Integration

The Android client should consume `/api/v41/assistant`, `/api/v41/decisions`, and the WebSocket `assistantV41` / `v41Decisions` fields.

Suggested Home card:
- AI Assistant state
- last decision
- reason
- Paper actions today
- blocked decisions
- live execution: OFF

The Copy Trading screen can display the V41 decision state alongside V38 risk state and V39 analytics.
