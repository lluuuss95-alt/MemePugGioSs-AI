# V71 — Android ↔ Backend Complete Integration

V71 adds a single authenticated mobile gateway endpoint:
`GET /api/v71/mobile/snapshot`

The endpoint exposes a consolidated PAPER/SHADOW snapshot for the Android operator console: system health, engine state, portfolio, AI opportunities/signals, Pump.fun token feed, Copy Trading, and the latest V69/V66/V67/V68 telemetry.

The gateway is read-only. It does not sign, broadcast, access private keys, or enable live execution.

Flow:
Android Compose -> authenticated V71 mobile snapshot -> existing backend engines -> Solana/Pump.fun data.

The existing WebSocket remains available for realtime state. V71 does not replace existing APIs; it reduces Android-side fan-out and gives the UI one consistent contract.
