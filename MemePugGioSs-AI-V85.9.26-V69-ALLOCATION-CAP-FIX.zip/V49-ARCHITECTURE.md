# V49 — Instant AI Scoring

V49 adds the first-pass AI triage immediately after V48 verified Pump.fun discovery.

Flow:
`Pump.fun WebSocket -> V48 verify/dedup -> V49 instant score -> DEEP_ANALYSIS/WATCH/REJECTED -> V28/V29 deep intelligence`

## Design goals
- score every verified discovery with bounded CPU work;
- prioritize complete, fresh, low-latency discoveries for deeper analysis;
- never infer profitability or future price direction from names/symbols;
- economic/risk features remain downstream and must be verified on-chain/market data;
- preserve deterministic behavior and explicit reasons/blockers.

## Bands
- `DEEP_ANALYSIS`: send immediately to the expensive intelligence pipeline;
- `WATCH`: retain for monitoring and later enrichment;
- `REJECTED`: do not consume deep-analysis resources unless reprocessed by a later recovery/enrichment stage.

V49 is a triage score, not a trading recommendation. Live signing, private-key access, broadcast and auto-promotion remain disabled.
