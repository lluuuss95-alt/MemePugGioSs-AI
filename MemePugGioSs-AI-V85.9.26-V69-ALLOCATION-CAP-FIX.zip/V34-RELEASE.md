# V34 Release

Version: 34.0.0-shadow

V34 adds Trader Discovery Engine for public Solana wallets. It profiles verified Pump.fun/PumpSwap trade observations and prepares copy candidates. It does not execute real trades.
