# V14 Checklist

- [x] Signal lab record model
- [x] Point-in-time signal evaluation
- [x] Forward outcome join
- [x] Token-grouped dataset split
- [x] Chronological split
- [x] Train/validation/test report
- [x] Sample-size gates
- [x] Mean/median outcome
- [x] Win rate
- [x] MFE / MAE aggregation
- [x] Bootstrap confidence interval hook
- [x] Multiple-testing metadata
- [x] Deterministic run fingerprint
- [x] Strategy comparison hook
- [x] Unit tests
- [x] PAPER/research-only
