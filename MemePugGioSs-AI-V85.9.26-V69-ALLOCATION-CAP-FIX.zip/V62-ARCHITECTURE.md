# V62 — Opportunity Arbitration

## Goal
Resolve competition among AI Signals, Pump.fun Early Entry, Smart Money and Copy Trading before the final V61 portfolio gate.

## Flow
Pump.fun/Solana -> V48 -> V49 -> V55 -> V50 -> V56 -> V57 -> V58 -> V59 -> V60 -> V62 Arbitration -> V61 Portfolio Gate -> V52 Paper -> V53 Monitor.

## Controls
- deterministic priority ordering
- one winner per mint per arbitration cycle
- per-strategy opportunity cap
- per-strategy exposure cap
- correlation-group exposure cap
- global opportunity cap
- capital reserve protection
- minimum liquidity/score/confidence gates
- V61 remains the final portfolio exposure gate
- persistent decision/snapshot audit

## Safety
PAPER/SHADOW only. No private keys, signing, broadcast, live execution or auto-promotion.
