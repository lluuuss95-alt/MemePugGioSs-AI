# V37 Release
MemePugGioSs AI V37 adds an isolated Copy Trading Paper Portfolio. V36 eligible signals can be simulated with configurable paper fees/slippage, per-trader allocations, positions and performance analytics. The system remains non-custodial and PAPER/SHADOW only.
