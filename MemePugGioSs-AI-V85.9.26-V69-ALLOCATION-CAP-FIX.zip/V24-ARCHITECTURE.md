# V24 — Official Pump Account Decoder & Live State

V24 attaches the V23 math engine to real Pump program account data.

## Verified layouts
- Pump `BondingCurve` account
- PumpSwap `Pool` account

## BondingCurve
Decodes:
- virtual token reserves
- virtual SOL/quote reserves
- real token reserves
- real SOL/quote reserves
- token total supply
- complete
- appended creator / quote / fee / feature fields when present

Shorter legacy accounts are accepted and missing trailing fields remain absent/default.

## PumpSwap Pool
Decodes:
- pool bump/index
- creator
- base/quote mint
- LP mint
- base/quote token accounts
- LP supply
- coin creator
- mayhem/cashback flags
- signed i128 virtual quote reserves
- appended fee/holder-reward fields

## Safety
This is read-only intelligence. No account mutation, signing, key access or order broadcast is introduced.
