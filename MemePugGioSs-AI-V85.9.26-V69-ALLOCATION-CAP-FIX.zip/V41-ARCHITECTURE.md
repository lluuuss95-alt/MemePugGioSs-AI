# V41 — AI Autonomous Trading Orchestrator

V41 unifies the existing signal, Copy Trading and risk layers into one explainable decision orchestrator.

Flow:
`Market/AI signals + V36 Copy Signals -> V41 decision gates -> V38 risk preflight (copy path) -> Paper action`

Safety: PAPER/SHADOW only. No private keys, signing, broadcast or live promotion. V41 never invents a market price; a Paper execution requires a valid market context in a later execution adapter.

Decision gates: score, confidence, risk, freshness, liquidity, required mint/side, then portfolio risk for Copy Trading.

States: READY, EXECUTED_PAPER, BLOCKED, NO_OPPORTUNITY.
