# MemePugGioSs AI — V73 Architecture

## Real-Time AI Live Token Intelligence & Alert Layer

V73 adds a database-backed alert layer between persisted market observations/AI signals and the Android realtime dashboard.

Flow:
OBSERVATIONS + AI SIGNALS → V73 CHANGE DETECTION → DEDUPLICATED ALERTS → Android `/api/v73/mobile/intelligence-alerts`

### Alert classes
- NEW_TOKEN
- PRICE_ACCELERATION
- LIQUIDITY_CHANGE
- BUY_PRESSURE_CHANGE
- AI_SCORE_CHANGE
- RISK_ESCALATION
- STALE_DATA

### Guarantees
- Only persisted observations and persisted AI signals are used.
- No synthetic market values are generated.
- Alerts are deduplicated by mint/type/time bucket.
- Alert history is persisted in `v73_intelligence_alerts` and bounded in memory.
- Stale data is surfaced rather than treated as current.
- Mobile API is read-only with respect to trading execution.

### Safety
PAPER/SHADOW only. No private keys, signing, broadcast, live execution or auto-promotion.
