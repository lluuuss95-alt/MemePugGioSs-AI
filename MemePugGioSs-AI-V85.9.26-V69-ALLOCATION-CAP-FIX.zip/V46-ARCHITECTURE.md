# V46 — AI Opportunity Allocator

V46 converts qualified opportunities into a bounded PAPER capital allocation proposal. It does not execute orders.

Pipeline:
Market Regime (V45) -> V41 Decision -> V46 Allocation -> V38 Risk -> V42 Position Manager.

## Guarantees
- PAPER/SHADOW only.
- `liveExecutionEnabled=false` is hard-coded in the snapshot.
- Reserve capital is never allocated.
- Global exposure, per-position, per-token and per-trader limits are enforced.
- `NO_TRADE`, `STRESSED` and unknown regimes block allocation.
- Allocation is deterministic for the same inputs.
- Every allocation/block is persisted with reasons.

## API
- `POST /api/v46/allocate`
- `GET /api/v46/allocations`

V46 accepts a `regime` field so it can consume the V45 Market Regime Engine without duplicating regime logic.
