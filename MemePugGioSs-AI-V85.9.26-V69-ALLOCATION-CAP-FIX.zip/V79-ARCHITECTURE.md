# V79 — Paper Portfolio Reconciliation & Recovery Engine

V79 closes the Paper-state integrity loop after V77 entry commits and V78 exit commits.

## Flow

V77 Paper Entry Commit + V78 Exit Commit + V52 persistent positions/events
→ V79 reconciliation snapshot
→ consistency checks
→ safe deterministic recovery where the source data is sufficient
→ HEALTHY / RECOVERED / DEGRADED / FAILED.

## Source-of-truth rules

- V52 `v52_paper_positions` and `v52_paper_events` remain the Paper ledger.
- V77 commits prove that an entry passed the downstream Paper commit layer.
- V78 commits prove that an exit was committed by the lifecycle layer.
- V79 never invents a market price or P&L.
- V79 never automatically closes a position when an exit commit and OPEN row disagree because V78 does not persist enough exit execution detail to reconstruct the exact close safely.

## Safe recovery

If a V77 `COMMITTED` entry contains a complete OPEN `paperResult.position`, but the corresponding V52 OPEN row is missing, V79 can deterministically restore that position. If the matching ENTER event is also missing, V79 restores a Paper audit event marked `V79_RECOVERED_ENTRY` using the persisted Paper result cash/equity.

No destructive recovery is performed for duplicate OPEN rows, exit mismatches, or realized-P&L ledger mismatches; those states are surfaced as DEGRADED/FAILED for inspection.

## Integrity checks

- V77 committed-entry coverage
- V78 exit vs V52 OPEN mismatch
- duplicate OPEN rows per mint
- OPEN positions without entry events
- realized P&L vs EXIT_PAPER event ledger
- deterministic SHA-256 state hash

## Persistence

Table: `v79_recovery_snapshots`.

## Endpoints

- `GET /api/v79/recovery` — latest reconciliation status and recent snapshots
- `POST /api/v79/recovery/run` — execute safe deterministic recovery + reconciliation
- `GET /api/v79/mobile/recovery` — mobile-safe status

## Safety

PAPER / SHADOW only. No private keys, signing, broadcast, live execution or auto-promotion.
