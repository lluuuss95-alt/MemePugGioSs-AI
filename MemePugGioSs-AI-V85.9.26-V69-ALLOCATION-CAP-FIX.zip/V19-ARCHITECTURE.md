# V19 — Real Market Feed + Long-Run Shadow

Real-time Solana WebSocket PubSub boundary using `logsSubscribe`, commitment selection, optional single-address `mentions`, reconnect/backoff and health tracking. Raw logs are never assumed to contain price or DEX semantics: only verified protocol adapters may create market ticks. V18 remains the execution layer and stays SHADOW-only.
