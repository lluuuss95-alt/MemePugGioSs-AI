# V36 — AI Copy Signal Engine

V36 connects the V34 public-wallet trade stream with V35 trader reputation and produces a deterministic **copy signal** before any paper execution.

Pipeline:

`Verified wallet trade -> Follow/Copy-Paper gate -> V35 reputation -> latency/confidence -> market liquidity/volume/risk/freshness -> copy signal -> Paper/Shadow consumer`

## Signal states
- `ELIGIBLE`: all configured gates pass; a Paper copy action may be proposed.
- `BLOCKED`: at least one gate fails; reasons are retained.
- `PROPOSED`, `EXPIRED`, `EXECUTED_PAPER` are reserved for the downstream orchestration layer.

## Gates
- followed trader with `copy_paper=1`
- V35 `QUALIFIED` reputation
- minimum reputation and sample confidence
- trader risk ceiling
- verified trade and trade confidence
- maximum observation latency
- minimum quote liquidity and 5-minute volume
- market freshness
- optional tradability flag
- per-wallet/token cooldown
- hard copy exposure cap

## Safety
V36 remains PAPER/SHADOW-only. It never requests private keys, signs transactions, broadcasts transactions, or promotes itself to live trading. A signal is an analytical decision artifact, not a blockchain order.

## API
- `GET /api/v36/copy-signals`
- `GET /api/v36/copy-signals/eligible`
- `POST /api/v36/evaluate-copy`

`POST /api/v36/evaluate-copy` accepts `{ trade, market }` and returns the complete signal plus blocking reasons.
