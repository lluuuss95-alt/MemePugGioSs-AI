import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const required = [
  'src/v81-paper-engine-gate.ts','src/v82-paper-transaction-journal.ts','src/v83-paper-execution-coordinator.ts',
  'src/v84-final-control-plane.ts','src/v85-release-readiness.ts','src/server.ts',
  'tests/v82.test.ts','tests/v83.test.ts','tests/v84.test.ts','tests/v85.test.ts'
];
const forbidden = ['liveExecutionAllowed:true','signingEnabled:true','broadcastEnabled:true','privateKeyAccess:true','autoPromotion:true'];
const missing = required.filter(f=>!fs.existsSync(path.join(root,f)));
const hits = [];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(e.name==='node_modules'||e.name==='.git')continue;const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(/\.(ts|tsx|kt|kts|json)$/.test(e.name)){const s=fs.readFileSync(p,'utf8');for(const x of forbidden)if(s.includes(x))hits.push(`${path.relative(root,p)} -> ${x}`)}}}
walk(root);
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const scripts=['test:v82','test:v83','test:v84','test:v85'];
const missingScripts=scripts.filter(s=>!pkg.scripts?.[s]);
const report={timestamp:new Date().toISOString(),requiredMissing:missing,forbiddenHits:hits,missingScripts,packageVersion:pkg.version,status:missing.length||hits.length||missingScripts.length?'FAIL':'PASS'};
fs.writeFileSync(path.join(root,'CI-PAPER-SHADOW-VALIDATION.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=report.status==='PASS'?0:1;
