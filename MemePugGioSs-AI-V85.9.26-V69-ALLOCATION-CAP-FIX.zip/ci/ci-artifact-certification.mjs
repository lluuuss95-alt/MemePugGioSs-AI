import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const checks = [];
const upstreamValidated = process.env.CI_UPSTREAM_VALIDATED === 'true';
const exists = (p) => fs.existsSync(path.join(root, p));
const check = (name, condition, detail='') => checks.push({name, status: condition ? 'PASS' : 'FAIL', ...(condition ? {} : {detail})});

check('package-lock', exists('package-lock.json'), 'CI must generate package-lock.json before npm ci.');
check('node-modules', upstreamValidated || exists('node_modules'), upstreamValidated ? '' : 'Dependencies must be installed before certification.');
check('dist', exists('dist'), 'TypeScript build output dist/ is required.');
check('server-build', exists('dist/server.js'), 'dist/server.js is required after npm run build.');
check('final-readiness-source', exists('src/v85-release-readiness.ts'), 'Final release readiness source is missing.');
check('paper-safety-source', exists('ci/validate-paper-shadow.mjs'), 'Paper safety validator is missing.');
check('android-project', exists('android-app/app/build.gradle.kts'), 'Android project is missing.');

const apkDir = path.join(root, 'android-app', 'app', 'build', 'outputs', 'apk');
let apkFiles = [];
if (fs.existsSync(apkDir)) {
  const walk = (dir) => {
    for (const ent of fs.readdirSync(dir, {withFileTypes:true})) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(p);
      else if (ent.isFile() && ent.name.endsWith('.apk')) apkFiles.push(path.relative(root,p));
    }
  };
  walk(apkDir);
}
check('android-apk', apkFiles.length > 0, 'Android validation job must produce at least one APK.');
if (upstreamValidated) check('upstream-node-validation', true);

const report = {
  timestamp: new Date().toISOString(),
  version: JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).version,
  checks,
  apkFiles,
  status: checks.every(x => x.status === 'PASS') ? 'CERTIFIED_ARTIFACTS_PRESENT' : 'WAITING_FOR_CI_ARTIFACTS'
};
fs.writeFileSync(path.join(root,'CI-ARTIFACT-CERTIFICATION.json'), JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode = report.status === 'CERTIFIED_ARTIFACTS_PRESENT' ? 0 : 1;
