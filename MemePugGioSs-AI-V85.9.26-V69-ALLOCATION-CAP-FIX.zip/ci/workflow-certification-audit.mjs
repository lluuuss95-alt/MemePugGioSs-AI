import fs from 'node:fs';
const p='.github/workflows/paper-validation.yml';
const s=fs.readFileSync(p,'utf8');
const required=[
  'npm install --package-lock-only', 'npm ci', 'npm run build', 'npm test',
  'gradle --no-daemon assembleDebug', 'actions/upload-artifact@v4',
  'needs: [node-paper-validation, android-validation]',
  'if: always()', 'CI_UPSTREAM_VALIDATED:'
];
const missing=required.filter(x=>!s.includes(x));
const report={file:p,requiredChecks:required.length,missing,status:missing.length?'BLOCKED':'PASS'};
fs.writeFileSync('WORKFLOW-CERTIFICATION-AUDIT.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=missing.length?1:0;
