import fs from 'node:fs';
const hasLock = fs.existsSync('package-lock.json') || fs.existsSync('npm-shrinkwrap.json');
console.log(`DEPENDENCY_LOCK_PRESENT=${hasLock}`);
console.log('CI_BOOTSTRAP_MODE=npm-install');
if (hasLock) console.log('LOCKFILE_CAN_RETURN_TO_NPM_CI=true');
