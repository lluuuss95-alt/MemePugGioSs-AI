import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const files = [
  '.github/workflows/paper-validation.yml',
  'package.json',
  'ci/runtime-certification-execution.mjs',
  'ci/artifact-provenance.mjs',
  'ci/ci-artifact-certification.mjs',
  'ci/release-evidence-attestation.mjs',
];
const entries = files.map(path => {
  if (!existsSync(path)) return { path, present:false, sha256:null };
  const data = readFileSync(path);
  return { path, present:true, sha256:createHash('sha256').update(data).digest('hex') };
});
const manifest = {
  schemaVersion: 1,
  candidate: 'V85.9.12',
  mode: 'PAPER_SHADOW',
  generatedAt: new Date().toISOString(),
  workflowManualDispatch: readFileSync('.github/workflows/paper-validation.yml','utf8').includes('workflow_dispatch:'),
  safety: { liveExecutionEnabled:false, signingEnabled:false, broadcastEnabled:false, privateKeyAccess:false, autoPromotion:false },
  files: entries,
};
manifest.ok = manifest.workflowManualDispatch && entries.every(x=>x.present) && Object.values(manifest.safety).every(v=>v===false);
writeFileSync('CERTIFICATION-RUN-MANIFEST.json', JSON.stringify(manifest,null,2)+'\n');
if (!manifest.ok) process.exit(1);
console.log(JSON.stringify(manifest,null,2));
