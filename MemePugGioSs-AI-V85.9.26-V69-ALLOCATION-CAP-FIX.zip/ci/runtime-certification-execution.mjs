import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const startedAt = new Date().toISOString();
const env = { ...process.env,
  MEMEPUGGIOSS_MODE:'PAPER', LIVE_EXECUTION_ENABLED:'false', SIGNING_ENABLED:'false',
  BROADCAST_ENABLED:'false', PRIVATE_KEY_ACCESS:'false', AUTO_PROMOTION:'false'
};
const steps = [
  ['build','npm',['run','build']],
  ['test-typecheck','npm',['run','typecheck:tests']],
  ['paper-shadow','npm',['run','validate:paper-shadow']],
  ['paper-e2e','npm',['run','e2e:paper']],
  ['full-tests','npm',['test']],
  ['runtime-paper','npm',['run','validate:runtime-paper']],
  ['final-certification','npm',['run','validate:final']],
];
const results=[];
for (const [name,cmd,args] of steps) {
  const r=spawnSync(cmd,args,{stdio:'inherit',shell:false,env});
  results.push({name,status:r.status,signal:r.signal ?? null,ok:r.status===0});
  if (r.status!==0) break;
}
const report={
  schemaVersion:1,
  startedAt,
  finishedAt:new Date().toISOString(),
  mode:'PAPER_SHADOW',
  safety:{liveExecutionEnabled:false,signingEnabled:false,broadcastEnabled:false,privateKeyAccess:false,autoPromotion:false},
  executed:true,
  overall:results.length===steps.length && results.every(x=>x.ok)?'PASS':'BLOCKED',
  steps:results,
  note: results.length===steps.length && results.every(x=>x.ok)
    ? 'Runtime certification commands completed successfully in the execution environment.'
    : 'Runtime certification was not fully completed; the first failing/unavailable step is recorded above.'
};
writeFileSync('RUNTIME-CERTIFICATION-EXECUTION.json',JSON.stringify(report,null,2)+'\n');
if(report.overall!=='PASS') process.exit(1);
