import fs from "node:fs";
import path from "node:path";
const root=process.cwd();
const required=["src/v82-paper-transaction-journal.ts","src/v83-paper-execution-coordinator.ts","src/v84-final-control-plane.ts","src/v85-release-readiness.ts","src/server.ts","tests/v77.test.ts","tests/v78.test.ts","tests/v79.test.ts","tests/v80.test.ts","tests/v81.test.ts","tests/v82.test.ts","tests/v83.test.ts","tests/v84.test.ts","tests/v85.test.ts"];
for(const f of required) if(!fs.existsSync(path.join(root,f))) throw new Error(`MISSING:${f}`);
const files=fs.readdirSync(path.join(root,"src")).filter(f=>f.endsWith(".ts"));
const text=files.map(f=>fs.readFileSync(path.join(root,"src",f),"utf8")).join("\n");
const forbidden=["liveExecutionAllowed:true","liveExecutionEnabled:true","signingEnabled:true","privateKeyAccess:true","broadcastEnabled:true","autoPromotion:true"];
const hits=forbidden.filter(x=>text.includes(x));
if(hits.length) throw new Error(`SAFETY_FLAGS:${hits.join(",")}`);
const checks=[
 ["journal",/v82-paper-transaction-journal/],
 ["coordinator",/V83PaperExecutionCoordinator/],
 ["control-plane",/V84FinalControlPlane/],
 ["release",/V85ReleaseReadiness/],
 ["server-routes",/api\/v85\/release-readiness/]
];
for(const [name,re] of checks) if(!re.test(text)) throw new Error(`MISSING_CONTROL:${name}`);
console.log(JSON.stringify({status:"PASS",mode:"PAPER_SHADOW",filesChecked:files.length,safety:"LOCKED_OFF",controls:checks.map(x=>x[0])},null,2));
