import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const run = (cmd, args=[]) => { try { return execFileSync(cmd,args,{encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim(); } catch { return null; } };
const packageJson = JSON.parse(readFileSync('package.json','utf8'));
const checks = {
  node: run('node',['--version']),
  npm: run('npm',['--version']),
  packageJson: existsSync('package.json'),
  packageLock: existsSync('package-lock.json'),
  gradleWrapper: existsSync('android-app/gradlew') || existsSync('android-app/gradlew.bat'),
  androidProject: existsSync('android-app/settings.gradle.kts'),
  workflow: existsSync('.github/workflows/paper-validation.yml'),
  liveExecutionFlags: false
};
const text = ['src','android-app'].filter(existsSync).map(d=>run('grep',['-RInE','liveExecutionAllowed:true|signingEnabled:true|broadcastEnabled:true|privateKeyAccess:true|autoPromotion:true',d])||'').join('\n');
checks.liveExecutionFlags = text.length === 0;
let lockSha = null;
if (checks.packageLock) lockSha = createHash('sha256').update(readFileSync('package-lock.json')).digest('hex');
const report = {
  schema: 'memepuggioss.environment-preflight.v1',
  version: packageJson.version,
  generatedAt: new Date().toISOString(),
  checks,
  packageLockSha256: lockSha,
  runtimeCertification: checks.packageLock && checks.liveExecutionFlags ? 'READY_FOR_CI_EXECUTION' : 'ENVIRONMENT_PRECHECK_REQUIRED',
  note: 'This preflight never treats static validation as runtime certification.'
};
writeFileSync('ENVIRONMENT-PREFLIGHT.json', JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
