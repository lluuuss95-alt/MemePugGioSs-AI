import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('src');
let files = 0, bad = [];
function walk(dir){
  for(const name of fs.readdirSync(dir)){
    const p=path.join(dir,name), st=fs.statSync(p);
    if(st.isDirectory()) walk(p); else if(p.endsWith('.ts')){
      files++;
      const s=fs.readFileSync(p,'utf8');
      const re=/(?:from\s+|import\s*\(\s*|import\s+)(['\"])(\.[^'\"]+)\1/g;
      let m;
      while((m=re.exec(s))) if(!/\.(?:js|json|ts|mjs|cjs)$/.test(m[2])) bad.push(`${path.relative(process.cwd(),p)}:${m[2]}`);
    }
  }
}
walk(root);
if(bad.length){ console.error(JSON.stringify({ok:false,files,extensionlessRelativeImports:bad},null,2)); process.exit(1); }
console.log(JSON.stringify({ok:true,files,extensionlessRelativeImports:0,mode:'NodeNext source gate'},null,2));
