import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const required = [
  'CI-ARTIFACT-CERTIFICATION.json',
  'ARTIFACT-PROVENANCE-MANIFEST.json',
  'RUNTIME-CERTIFICATION-EXECUTION.json',
  'REPRODUCIBILITY-MANIFEST.json',
  'RELEASE-ENVIRONMENT-REPORT.json',
  'ENVIRONMENT-PREFLIGHT.json',
];
const checks = [];
const add = (name, ok, detail='') => checks.push({name, status: ok ? 'PASS' : 'FAIL', ...(ok ? {} : {detail})});
const readJson = (file) => {
  try { return JSON.parse(fs.readFileSync(path.join(root,file),'utf8')); }
  catch { return null; }
};
const sha256 = (file) => crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex');

for (const file of required) add(`evidence:${file}`, fs.existsSync(path.join(root,file)), 'Required certification evidence is missing.');

const runtime = readJson('RUNTIME-CERTIFICATION-EXECUTION.json');
const artifacts = readJson('CI-ARTIFACT-CERTIFICATION.json');
const provenance = readJson('ARTIFACT-PROVENANCE-MANIFEST.json');
const pkg = readJson('package.json');

add('runtime-overall-pass', runtime?.overall === 'PASS', 'Runtime certification must report PASS.');
add('runtime-complete', Array.isArray(runtime?.steps) && runtime.steps.length > 0 && runtime.steps.every(s => s.ok === true), 'Every runtime certification step must pass.');
add('artifact-certified', artifacts?.status === 'CERTIFIED_ARTIFACTS_PRESENT', 'CI artifact certification must report certified artifacts.');
add('provenance-present', Boolean(provenance), 'Artifact provenance manifest is required.');
add('package-version', pkg?.version === '85.9.12-release-gate-hardened', 'Unexpected package version.');
add('safety-paper', runtime?.safety?.liveExecutionEnabled === false && runtime?.safety?.signingEnabled === false && runtime?.safety?.broadcastEnabled === false && runtime?.safety?.privateKeyAccess === false && runtime?.safety?.autoPromotion === false, 'All live execution controls must remain disabled.');

const artifactHashes = {};
for (const file of ['package-lock.json','dist/server.js']) {
  if (fs.existsSync(path.join(root,file))) artifactHashes[file] = sha256(file);
}
const report = {
  schemaVersion: 1,
  attestation: 'PAPER_SHADOW_RELEASE_EVIDENCE',
  generatedAt: new Date().toISOString(),
  packageVersion: pkg?.version ?? null,
  status: checks.every(c => c.status === 'PASS') ? 'CERTIFIED' : 'BLOCKED',
  checks,
  artifactHashes,
  requiredEvidence: required,
  rule: 'This attestation is valid only when generated inside the CI release-gate workspace after upstream Node and Android jobs succeed.'
};
fs.writeFileSync(path.join(root,'RELEASE-EVIDENCE-ATTESTATION.json'), JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if (report.status !== 'CERTIFIED') process.exit(1);
