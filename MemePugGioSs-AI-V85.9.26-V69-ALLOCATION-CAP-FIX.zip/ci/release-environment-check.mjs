import fs from 'node:fs';
import { execFileSync } from 'node:child_process';

const checks=[];
const run=(name,cmd,args)=>{try{execFileSync(cmd,args,{stdio:'pipe'});checks.push({name,status:'PASS'});}catch(e){checks.push({name,status:'FAIL',detail:String(e.stdout||e.stderr||e.message).slice(-1200)});}};
run('node-version',process.execPath,['--version']);
run('npm-version','npm',['--version']);
run('source-gate',process.execPath,['ci/build-source-validation.mjs']);
run('paper-safety',process.execPath,['ci/validate-paper-shadow.mjs']);
run('paper-e2e-static',process.execPath,['ci/paper-e2e-static.mjs']);
const report={timestamp:new Date().toISOString(),checks,packageLock:fs.existsSync('package-lock.json'),androidWrapper:fs.existsSync('android-app/gradlew'),nodeModules:fs.existsSync('node_modules')};
fs.writeFileSync('RELEASE-ENVIRONMENT-REPORT.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=checks.some(x=>x.status==='FAIL')?1:0;
