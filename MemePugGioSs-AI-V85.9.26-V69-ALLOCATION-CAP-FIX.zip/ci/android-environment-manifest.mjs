import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
const run=(cmd,args)=>{try{return execFileSync(cmd,args,{encoding:'utf8'}).trim()}catch(e){return `UNAVAILABLE:${e.status ?? 'error'}`}};
const report={
 timestamp:new Date().toISOString(),
 java:run('java',['-version']),
 gradle:run('gradle',['--version']),
 androidSdkRoot:process.env.ANDROID_SDK_ROOT||process.env.ANDROID_HOME||null,
 project:'android-app',
 compileSdk:35,
 targetSdk:35,
 mode:'CI_ANDROID_BUILD'
};
fs.writeFileSync('ANDROID-ENVIRONMENT-MANIFEST.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
