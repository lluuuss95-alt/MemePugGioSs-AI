import fs from 'node:fs';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const hash = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const run = (cmd,args) => execFileSync(cmd,args,{encoding:'utf8'}).trim();
const report = {
  timestamp: new Date().toISOString(),
  node: run('node',['--version']),
  npm: run('npm',['--version']),
  packageJsonSha256: hash('package.json'),
  packageLockSha256: hash('package-lock.json'),
  lockfileVersion: JSON.parse(fs.readFileSync('package-lock.json','utf8')).lockfileVersion,
  nodeModulesPresent: fs.existsSync('node_modules'),
  mode: 'CI_REPRODUCIBLE_INSTALL'
};
fs.writeFileSync('REPRODUCIBILITY-MANIFEST.json', JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
