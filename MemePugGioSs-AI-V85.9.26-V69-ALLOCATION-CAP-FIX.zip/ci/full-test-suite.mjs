import {spawnSync} from "node:child_process";
import {readFileSync, readdirSync} from "node:fs";
import {join} from "node:path";

const root = process.cwd();
const testDir = join(root, "tests");
const files = readdirSync(testDir).filter(f => /^v\d+\.test\.ts$/.test(f)).sort((a,b) => {
  const na=Number(a.match(/v(\d+)/)[1]), nb=Number(b.match(/v(\d+)/)[1]);
  return na-nb;
});
const direct=[];
const vitest=[];
for (const file of files) {
  const source=readFileSync(join(testDir,file),"utf8");
  if (/\b(?:describe|it|test)\s*\(/.test(source)) vitest.push(file);
  else direct.push(file);
}

function run(cmd,args,label){
  console.log(`\n=== ${label} ===`);
  const r=spawnSync(cmd,args,{stdio:"inherit",env:process.env});
  if(r.status!==0) process.exit(r.status ?? 1);
}

for (const file of direct) run(process.execPath,["--import","tsx",join("tests",file)],`direct ${file}`);
if (vitest.length) run("npx",["vitest","run",...vitest.map(f=>join("tests",f))],`vitest suites (${vitest.length})`);
console.log(`\nFULL TEST SUITE PASS: ${files.length} test files (${direct.length} direct + ${vitest.length} Vitest suites).`);
