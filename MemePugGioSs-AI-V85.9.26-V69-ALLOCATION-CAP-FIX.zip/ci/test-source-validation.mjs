import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('tests');
const bad=[]; let files=0;
function walk(dir){
  for(const name of fs.readdirSync(dir,{withFileTypes:true})){
    const p=path.join(dir,name.name);
    if(name.isDirectory()) walk(p);
    else if(name.isFile() && name.name.endsWith('.ts')){
      files++; const s=fs.readFileSync(p,'utf8');
      const re=/(?:from\s+|import\s*\(?\s*)['\"](\.{1,2}\/[^'\"]+)['\"]/g; let m;
      while((m=re.exec(s))) if(!/\.(?:js|json|mjs|cjs)$/.test(m[1])) bad.push({file:p,import:m[1]});
    }
  }
}
walk(root);
const report={ok:bad.length===0,files,extensionlessRelativeImports:bad.length,issues:bad,mode:'NodeNext test source gate'};
console.log(JSON.stringify(report,null,2));
if(bad.length) process.exit(1);
