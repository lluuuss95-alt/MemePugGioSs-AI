import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root=process.cwd();
const required=['src/server.ts','src/v82-paper-transaction-journal.ts','src/v83-paper-execution-coordinator.ts','src/v84-final-control-plane.ts','src/v85-release-readiness.ts','ci/validate-paper-shadow.mjs','ci/paper-e2e-static.mjs'];
const forbidden=[/liveExecutionAllowed\s*:\s*true/gi,/signingEnabled\s*:\s*true/gi,/privateKeyAccess\s*:\s*true/gi,/broadcastEnabled\s*:\s*true/gi,/autoPromotion\s*:\s*true/gi];
const missing=required.filter(f=>!fs.existsSync(path.join(root,f)));
const files=[]; function walk(dir){for(const n of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,n.name);if(n.isDirectory()&&!['node_modules','.git','dist'].includes(n.name))walk(p);else if(n.isFile()&&p.endsWith('.ts'))files.push(p);}}
walk(path.join(root,'src')); walk(path.join(root,'tests'));
let forbiddenHits=[]; for(const f of files){const s=fs.readFileSync(f,'utf8'); for(const re of forbidden){ re.lastIndex=0; if(re.test(s)) forbiddenHits.push(f); re.lastIndex=0; }}
let checks=[]; for(const script of ['ci/validate-paper-shadow.mjs','ci/paper-e2e-static.mjs','ci/build-source-validation.mjs']){try{execFileSync(process.execPath,[script],{cwd:root,stdio:'pipe'});checks.push([script,'PASS']);}catch(e){checks.push([script,'FAIL']);}}
const report={timestamp:new Date().toISOString(),version:JSON.parse(fs.readFileSync('package.json','utf8')).version,sourceTsFiles:files.length,requiredMissing:missing,forbiddenHits:[...new Set(forbiddenHits)],staticChecks:checks,dependencyLock:fs.existsSync('package-lock.json')?'PRESENT':'MISSING',runtimeDependenciesInstalled:fs.existsSync('node_modules')?'PRESENT':'ABSENT',androidGradleWrapper:fs.existsSync('android-app/gradlew')?'PRESENT':'MISSING',status:missing.length||forbiddenHits.length||checks.some(x=>x[1]!=='PASS')?'BLOCKED':'PAPER_RELEASE_CANDIDATE', certificationRequirements:{packageLock:fs.existsSync('package-lock.json'),runtimeDependenciesInstalled:fs.existsSync('node_modules'),androidApk:fs.existsSync('android-app/app/build/outputs/apk')}};
fs.writeFileSync('FINAL-CERTIFICATION-REPORT.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=report.status==='BLOCKED'?1:0;
