import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const sha256 = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const files = [];
function walk(dir) {
  if (!fs.existsSync(dir)) return;
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p);
    else if (ent.isFile()) files.push(p);
  }
}
function addTree(dir, prefix) {
  const before = files.length;
  walk(dir);
  for (let i = before; i < files.length; i++) files[i] = path.relative(root, files[i]);
}

const candidates = [];
if (fs.existsSync('package.json')) candidates.push('package.json');
if (fs.existsSync('package-lock.json')) candidates.push('package-lock.json');
if (fs.existsSync('FINAL-CERTIFICATION-REPORT.json')) candidates.push('FINAL-CERTIFICATION-REPORT.json');
if (fs.existsSync('RELEASE-ENVIRONMENT-REPORT.json')) candidates.push('RELEASE-ENVIRONMENT-REPORT.json');
if (fs.existsSync('ENVIRONMENT-PREFLIGHT.json')) candidates.push('ENVIRONMENT-PREFLIGHT.json');
if (fs.existsSync('REPRODUCIBILITY-MANIFEST.json')) candidates.push('REPRODUCIBILITY-MANIFEST.json');
addTree('dist', 'dist');
addTree('android-app/app/build/outputs/apk', 'android-app/app/build/outputs/apk');

const artifacts = [...new Set(files)].sort().map((relative) => {
  const absolute = path.join(root, relative);
  const stat = fs.statSync(absolute);
  return { path: relative, bytes: stat.size, sha256: sha256(absolute) };
});

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const androidGradle = fs.existsSync('android-app/app/build.gradle.kts')
  ? fs.readFileSync('android-app/app/build.gradle.kts', 'utf8') : '';
const versionCode = Number(androidGradle.match(/versionCode\s*=\s*(\d+)/)?.[1] ?? NaN);
const versionName = androidGradle.match(/versionName\s*=\s*"([^"]+)"/)?.[1] ?? null;
const apkArtifacts = artifacts.filter((a) => a.path.endsWith('.apk'));
const required = {
  packageJson: candidates.includes('package.json'),
  packageLock: candidates.includes('package-lock.json'),
  distServer: artifacts.some((a) => a.path === 'dist/server.js'),
  androidApk: apkArtifacts.length > 0,
  androidVersionCode: versionCode === 85,
  androidVersionName: versionName === '1.0-v85-paper',
};
const report = {
  schema: 'memepuggioss.artifact-provenance.v1',
  generatedAt: new Date().toISOString(),
  packageVersion: pkg.version,
  nodeArtifactContract: 'dist/server.js + certification manifests',
  androidArtifactContract: 'debug APK, versionCode 85, versionName 1.0-v85-paper',
  android: { versionCode, versionName },
  required,
  artifacts,
  status: Object.values(required).every(Boolean) ? 'PASS' : 'BLOCKED',
  note: 'Hashes describe artifacts present in the certification workspace; this manifest does not claim runtime certification by itself.'
};
fs.writeFileSync('ARTIFACT-PROVENANCE-MANIFEST.json', JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
process.exitCode = report.status === 'PASS' ? 0 : 1;
