import { spawnSync } from 'node:child_process';
const commands = [
  ['npm',['run','build']],
  ['npm',['run','typecheck:tests']],
  ['npm',['run','validate:paper-shadow']],
  ['npm',['run','e2e:paper']],
  ['npm',['test']],
];
for (const [cmd,args] of commands) {
  const r = spawnSync(cmd,args,{stdio:'inherit',shell:false,env:{...process.env,MEMEPUGGIOSS_MODE:'PAPER',LIVE_EXECUTION_ENABLED:'false',SIGNING_ENABLED:'false',BROADCAST_ENABLED:'false',PRIVATE_KEY_ACCESS:'false',AUTO_PROMOTION:'false'}});
  if (r.status !== 0) process.exit(r.status ?? 1);
}
console.log('RUNTIME_PAPER_VALIDATION=PASS');
