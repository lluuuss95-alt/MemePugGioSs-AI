# V21 — Verified Solana Protocol Intelligence

V21 adds a second verification layer after V20 normalization:

logs/account/program event -> signature -> `getTransaction` -> transaction structure -> verified program classification -> protocol observation.

## Rules
- Failed transactions are not treated as trading observations.
- Missing transactions return no observation.
- Known Solana programs can be classified deterministically.
- Unknown/custom programs remain `CUSTOM_PROGRAM` with low confidence.
- No DEX/Pump.fun buy/sell semantics are inferred until a verified protocol adapter exists.
- All output remains Shadow/Paper research data.

This layer is designed to feed the later DEX/Pump.fun adapter without contaminating the model with guessed semantics.
