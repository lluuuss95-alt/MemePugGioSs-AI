# V43 Release
Version 43.0.0-shadow. Adds AI Learning & Strategy Adaptation. V43 remains PAPER/SHADOW and cannot promote itself to live trading.
