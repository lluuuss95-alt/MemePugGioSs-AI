# V82 — Paper Transaction Journal
Append-only journal for Paper ENTER/EXIT operations. PREPARE is written before execution; COMMIT/CONFIRM are written after deterministic completion. Unfinished PREPARE records become MANUAL_REVIEW during recovery instead of being replayed blindly.
