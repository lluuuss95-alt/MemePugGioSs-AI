# MemePugGioSs AI V8 — Wallet & Dev Intelligence

V8 adds behavioral intelligence for deployers, traders, early buyers and wallet clusters.

Pipeline:
On-chain events -> wallet extraction -> wallet profiles -> token relationships
-> cluster graph -> behavioral features -> reputation/risk scores -> opportunity gate.

Principles:
- Scores describe observed behavior, not identity or intent.
- Weak correlations remain low-confidence signals.
- Missing history reduces confidence and never becomes a positive signal.
- No automatic blacklisting based on a single wallet or transaction.
- PAPER-only execution remains enforced.

Core scores:
- Dev Reputation Score: historical observed token/project behavior.
- Wallet Risk Score: concentration, rapid exits, repeated high-risk patterns.
- Smart Money Score: historical risk-adjusted participation, sample-size gated.
- Cluster Risk Score: correlated wallet behavior, confidence-weighted.
