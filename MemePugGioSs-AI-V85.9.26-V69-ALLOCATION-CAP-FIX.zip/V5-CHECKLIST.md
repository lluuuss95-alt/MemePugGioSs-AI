# V5 checklist

- [x] Solana JSON-RPC token supply inspection
- [x] Largest token-account concentration signal
- [x] Mint/freeze authority risk signals
- [x] RPC WebSocket logs stream with reconnect
- [x] Opportunity score separated from token risk score
- [x] Tradability gate requires fresh data + opportunity threshold + risk threshold
- [x] Persistent token intelligence table
- [x] PAPER execution remains default
- [x] LIVE configuration rejected
- [x] Authenticated realtime dashboard
- [x] No private-key or signing path
- [ ] Authorized pump.fun launch/indexer adapter (provider credentials/API contract required)
- [ ] V6: deeper transaction/instruction decoding and wallet-behavior graph
