# V9 Checklist

- [x] Time-window feature engine
- [x] Buy/sell momentum
- [x] Smart-money participation
- [x] Liquidity trend
- [x] Holder concentration delta hook
- [x] Lifecycle-aware signal
- [x] Freshness and data-quality gates
- [x] Future-leakage guard
- [x] Early-entry signal state machine
- [x] Simulated entry/exit model
- [x] Stop-loss / take-profit simulation
- [x] Outcome attribution
- [x] Confidence calibration hooks
- [x] Explainable signal reasons
- [x] PAPER-only safety
- [x] Unit tests
