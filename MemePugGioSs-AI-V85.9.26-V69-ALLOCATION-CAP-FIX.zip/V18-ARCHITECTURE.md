# V18 — Shadow Trading Engine

V18 executes qualified strategies against realtime-style market ticks without sending
transactions to Solana.

Flow:
market tick -> freshness/risk gate -> strategy signal -> virtual entry/exit
-> simulated fees/slippage -> PnL -> shadow session metrics.

Tracked:
- signal latency
- data age
- blocked signals
- virtual positions
- simulated slippage
- simulated fees
- trade PnL
- max drawdown
- session status

Hard safety invariants:
- SHADOW mode only
- no private-key access
- signing disabled
- broadcast disabled
- live execution disabled

V18 is a measurement environment, not a guarantee of future trading performance.
