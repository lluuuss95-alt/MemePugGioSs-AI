# Android V72

The existing official Home layout is preserved. Placeholder signal/token content is now backed by the authenticated V72 market feed.

The Home screen displays verified backend-derived:
- top AI signal state/action/score;
- Pump.fun discovery token symbol/name;
- opportunity score and risk score;
- tradability state;
- PAPER-only status.

No private keys, signing or transaction broadcast are added to the Android client.
