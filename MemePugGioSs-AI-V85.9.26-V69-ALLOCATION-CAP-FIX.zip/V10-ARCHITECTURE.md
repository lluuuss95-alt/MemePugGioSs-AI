# MemePugGioSs AI V10 — Backtesting & Strategy Evolution Engine

V10 is a quantitative research layer for evaluating MemePugGioSs strategies before any LIVE consideration.

Design:
historical event stream -> chronological replay -> strategy signal -> simulated execution
-> portfolio accounting -> risk metrics -> walk-forward evaluation -> strategy comparison.

Anti-leakage:
- events are sorted chronologically;
- signal at time T only sees data <= T;
- execution occurs after the signal timestamp;
- strategy parameters are not optimized on the test segment;
- train/validation/test windows are separated.

Metrics:
- total return
- win rate
- expectancy
- profit factor
- max drawdown
- Sharpe-like risk-adjusted return
- Sortino-like downside-adjusted return
- trade count
- average win/loss
- exposure
- turnover

V10 is research-only and PAPER-only.
