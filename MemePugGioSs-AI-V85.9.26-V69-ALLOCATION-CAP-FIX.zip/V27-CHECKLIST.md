# V27 checklist

- [x] Cursor-based Pump Program history recovery
- [x] Persisted discovery checkpoint
- [x] Gap recovery on demand
- [x] Failed transaction accounting
- [x] V26 parser reuse
- [x] Reconciliation state
- [x] Android realtime WebSocket client scaffold
- [x] PAPER/SHADOW safety invariants
- [x] V27 unit tests
- [ ] Full Mainnet soak test with production RPC provider
- [ ] APK release signing and Play deployment
- [x] Reconnect-to-recovery bridge for V26
