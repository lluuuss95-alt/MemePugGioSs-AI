# MemePugGioSs AI — V25 Architecture

## Live Account State Engine

V25 turns the verified V24 account decoder into a live, stateful account layer.

Pipeline:

`Solana HTTP RPC -> initial account/vault/supply snapshot -> V24 decoder -> V23 math -> coherent live state -> Home data contract`

and, for changes:

`Solana WebSocket accountSubscribe -> accountNotification -> state refresh/reconcile -> Home data contract`

### Covered state

- Pump BondingCurve account state
- PumpSwap Pool metadata
- PumpSwap base vault balance
- PumpSwap quote vault balance
- SPL token total supply
- price, market cap, liquidity and graduation progress
- slot spread / state coherence
- stale-state detection
- reconnecting WebSocket subscription layer

### Important implementation detail

Solana `accountSubscribe` notifications provide the account data and context slot. V25 uses `getTokenAccountBalance` for authoritative token-vault amounts during hydration and refreshes, while subscribing to the vault accounts for low-latency change detection. The pool's signed virtual quote reserve is retained from V24 and combined with the live quote-vault amount.

### Home screen

The official Home UI is not redesigned. V25 only supplies data to its existing panels. The canonical reference remains the user-provided screenshot. `src/v25-home-feed.ts` is a data contract, not a UI replacement.

### Safety

V25 is Shadow/Paper only:

- no private keys
- no signing
- no transaction broadcast
- no live trading
- no automatic promotion
