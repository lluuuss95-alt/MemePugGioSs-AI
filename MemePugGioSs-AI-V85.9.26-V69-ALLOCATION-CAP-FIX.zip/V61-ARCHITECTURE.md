# V61 — Portfolio-Level Autonomous Execution Coordinator

V61 is the portfolio-level gate between per-token autonomous loops and Paper execution.

## Flow

Pump.fun/Solana → V48 → V49 → V50/V56/V57/V58/V59 → V60 per-token loop → **V61 portfolio coordinator** → V52 Paper execution / V53 supervision.

V61 can also be evaluated directly from a batch of candidates before a new Paper entry is accepted.

## Responsibilities

- evaluate all current opportunities together;
- account for already-open exposure;
- preserve capital reserve;
- enforce total exposure, position count and per-token limits;
- enforce correlation-group concentration;
- enforce source concentration (AI Signal vs Copy Trader);
- enforce trader/wallet concentration for Copy Trading;
- produce APPROVE_PAPER / REDUCE_PAPER / BLOCK / HOLD decisions;
- persist auditable portfolio snapshots and allocation decisions;
- provide NORMAL / WARNING / HALTED portfolio state.

## Safety

V61 is PAPER/SHADOW only. It has no private-key access, signing, transaction broadcast, live execution or automatic promotion capability.

## Design note

V47 remains the deterministic upstream allocation baseline. V61 adds the missing current-portfolio context so allocations are not evaluated as if the portfolio were empty.
