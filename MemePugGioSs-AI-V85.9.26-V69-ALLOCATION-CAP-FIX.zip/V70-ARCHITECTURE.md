# V70 — Real-Time System Health & Recovery

V70 is the central health supervisor for the Paper/Shadow system. It evaluates heartbeats and component state for Solana feed, Pump.fun discovery, AI pipeline, database, scheduler, Paper execution and WebSocket infrastructure.

States:
- RUNNING: all required components healthy and within operating limits; Paper execution may proceed.
- DEGRADED: stale/unknown components, high error rate or queue pressure; Paper execution is blocked.
- RECOVERING: a previously degraded/halted system has healthy inputs again; recovery is explicit and remains fail-closed until the supervisor observes stable RUNNING conditions.
- HALTED: critical component failure/staleness, saturated queue or repeated recovery failures; Paper execution is blocked.

The supervisor never bypasses V64, V65 or V69. It is an additional fail-closed gate: `safeToRunPaper` is true only in RUNNING. Health snapshots are persisted in `v70_health_snapshots` for audit and recovery analysis.

Safety invariants remain PAPER/SHADOW only: no private keys, signing, broadcast, live execution or auto-promotion.
