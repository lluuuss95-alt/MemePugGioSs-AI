# V35 — Trader Ranking & Reputation Engine

V35 adds a deterministic reputation layer on top of V34 public-wallet discovery.

## Pipeline
`Verified trade observations -> rolling windows -> closed-trade reconstruction -> drawdown -> consistency -> sample quality -> specialization -> reputation -> state`

Windows: 7D, 30D, 90D, ALL.

## Metrics
- realized P&L, gross profit/loss
- win rate and profit factor
- reconstructed closed-trade max drawdown
- average holding time
- unique-token count and top-token concentration
- Pump/PumpSwap specialization share
- sample confidence
- cross-window consistency

## States
- `QUALIFIED`: meets configured reputation/risk/sample gates
- `WATCH`: usable for monitoring but one or more gates are not met
- `BLOCKED`: risk/drawdown pattern exceeds the hard safety gate
- `INSUFFICIENT_DATA`: not enough observations

Flags describe observed statistical patterns only; they do not infer intent or identity.

## AI Assistant integration
The Home sidebar now exposes **Assistente AI**. V35 exposes `/api/v35/assistant` as the assistant runtime status. It is explicitly PAPER-only and does not sign, broadcast, or place live orders.

## Safety
No private keys are stored or requested. No live trading, signing, or transaction broadcast is enabled by V35.
