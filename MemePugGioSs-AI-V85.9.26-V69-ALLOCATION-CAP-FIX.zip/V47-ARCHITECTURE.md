# V47 — AI Portfolio Coordinator

V47 coordinates the complete Paper portfolio instead of treating candidates independently.

Flow:
Market/Pump.fun/AI Signals/Smart Money/Copy Trading -> V45 Regime -> V46 Allocation -> V47 Portfolio Coordination -> V38 Risk -> V42 Position Manager.

Controls:
- portfolio exposure cap
- reserve capital
- correlation-group concentration
- source concentration (AI_SIGNAL, COPY_TRADER, etc.)
- per-candidate liquidity gate
- deterministic allocation ordering inherited from V46
- explicit block reasons
- persistent allocation ledger

Pump.fun continuous discovery remains upstream: V26/V27 discovery feeds new verified tokens into the signal pipeline. V47 does not claim that every token is processed literally every second; it is designed for continuous low-latency ingestion and bounded evaluation so bursts do not bypass risk controls.

Safety: liveExecutionEnabled is always false. V47 produces allocation decisions only and cannot sign or broadcast transactions.
