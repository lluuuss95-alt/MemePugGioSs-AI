# V41 Checklist

- [x] Unified V28 AI candidate inputs
- [x] Unified V36 Copy Signals
- [x] Score/confidence/risk/freshness gates
- [x] Liquidity gate for Copy Trading path
- [x] V38 portfolio-risk preflight for Copy Trading
- [x] Explainable decision reasons
- [x] Persistent decision ledger
- [x] REST assistant snapshot / decisions / decide / cycle endpoints
- [x] WebSocket assistant V41 state
- [x] PAPER/SHADOW safety assertion
- [x] No private keys, signing, broadcast or live promotion
- [x] No invented market prices
- [ ] Full dependency installation/build (environment dependencies unavailable)
- [ ] Full runtime integration test against live Solana RPC
