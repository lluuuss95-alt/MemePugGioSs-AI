# V13 Checklist

- [x] Token-centric timeline
- [x] Fixed window aggregation
- [x] 1m / 5m / 15m / 1h / 6h / 24h windows
- [x] OHLC-like price features
- [x] Buy/sell volume features
- [x] Liquidity delta
- [x] Holder delta
- [x] Smart-money delta
- [x] Forward return labels
- [x] MFE / MAE labels
- [x] Feature/label temporal separation
- [x] Dataset quality summary
- [x] Deterministic dataset fingerprint
- [x] Unit tests
- [x] Research/PAPER-only
