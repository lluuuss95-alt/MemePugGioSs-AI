# V74 — AI Alert → Automatic Re-Evaluation Bridge

V74 connects the V73 material-alert layer to the existing event-driven AI re-evaluation chain without enabling live execution.

## Flow

V73 alert → V57-compatible change → V58 bounded queue → verified V56 state → V49 instant score → V59 deep intelligence + final decision → persisted V74 run.

V74 deliberately skips non-actionable/FRESH alerts and blocks when verified token context is unavailable. It does not invent missing market fields.

## Safety

- PAPER/SHADOW only
- no private keys
- no signing
- no broadcast
- no live execution
- no auto-promotion
- V58/V59 safety assertions are required

## Persistence

`v74_reevaluation_runs` stores trigger status, V58 job id, V59 outcome/escalation, reasons, and safety state.

## Scope

V74 does not replace V52/V53 paper execution. It only creates a fresh AI decision context after a material V73 alert.
