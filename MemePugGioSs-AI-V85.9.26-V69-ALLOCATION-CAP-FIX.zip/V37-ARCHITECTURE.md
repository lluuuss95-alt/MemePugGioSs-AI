# V37 — Copy Paper Portfolio
V37 consumes V36 `ELIGIBLE` copy signals and simulates their execution in an isolated paper ledger.
Pipeline: `V36 eligible signal -> paper capital allocation -> simulated execution -> fee/slippage -> per-trader position -> P&L -> aggregate Copy Trading portfolio`.
Separate virtual sub-account per followed trader; allocation capped by `maxTraderAllocationPct`. BUY consumes virtual cash; SELL closes the copied paper position. Fees/slippage are recorded separately. V37 remains PAPER/SHADOW only and never handles private keys, signing or broadcast.
API: `GET /api/v37/copy/portfolio`, `GET /api/v37/copy/accounts`, `GET /api/v37/copy/trades`, `POST /api/v37/copy/execute`, `POST /api/v37/copy/reset`.
