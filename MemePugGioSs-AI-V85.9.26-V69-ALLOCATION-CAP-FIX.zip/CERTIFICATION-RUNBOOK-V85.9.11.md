# MemePugGioSs AI — V85.9.12 Certification Runbook

This package is the CI-ready certification candidate. It is intentionally PAPER/SHADOW only.

## Required certification

Run `.github/workflows/paper-validation.yml` in an online GitHub Actions runner.
The workflow can be started by push, pull request, or `workflow_dispatch`.

The release is certified only if:
- Node validation job succeeds;
- Android validation job succeeds;
- the Node artifact contains `dist/server.js`, `package-lock.json`, and runtime certification evidence;
- the Android artifact contains the debug APK;
- artifact provenance and CI artifact certification pass;
- the final release gate succeeds.

## Safety contract

The release must remain:
- `MEMEPUGGIOSS_MODE=PAPER`
- live execution disabled
- signing disabled
- broadcast disabled
- private-key access disabled
- auto-promotion disabled

## Important

A local archive, static check, or generated report is not an APK certification. The APK becomes certified only after the hosted CI run produces and verifies the artifact and all fail-closed release gates pass.
