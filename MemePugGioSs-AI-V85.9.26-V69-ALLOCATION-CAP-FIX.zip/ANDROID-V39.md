# Android V39 — Copy Analytics

The Android client consumes the existing authenticated WebSocket `copyAnalytics` payload and REST endpoints:
- GET `/api/v39/copy/analytics`
- GET `/api/v39/copy/analytics/summary`
- GET `/api/v39/copy/analytics/equity`
- GET `/api/v39/copy/analytics/traders`

Recommended Home/Copy Trading cards:
- Totale Copy P&L dall'inizio
- Equity Copy Trading
- Rendimento cumulativo
- Drawdown
- Win Rate
- Grafico equity cumulativo
- Confronto trader osservato vs copia

The UI must continue to show PAPER MODE and must not expose private keys or signing controls.
