# MemePugGioSs AI V12 — Real Historical Backfill Engine

V12 adds resumable historical collection on top of V11.

Official Solana RPC flow:
getSignaturesForAddress -> cursor pagination -> getTransaction -> V11 normalization.

Features:
- cursor-based pagination
- before/until support
- checkpoint/resume
- bounded concurrency
- rate limiting
- exponential backoff
- retryable vs terminal errors
- transaction fetch deduplication
- provider adapter boundary
- checkpoint fingerprint
- audit metadata
- no live signing/broadcast

Production note:
Public Solana RPC endpoints are rate-limited and have no SLA; a dedicated RPC provider should be configured for production.
