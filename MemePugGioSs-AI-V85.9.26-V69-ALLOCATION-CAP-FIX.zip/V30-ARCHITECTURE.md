# V30 — AI Decision & Paper Execution Engine

Pipeline: V25 Live State -> V26 Discovery -> V27 Gap Recovery -> V28 Signal -> V29 Ranking -> V30 Decision/Paper Execution -> Home/Android.

V30 converts a V29 ranked signal into a deterministic PAPER decision. It applies freshness, blocker, score, confidence and risk gates; computes bounded paper position size; simulates entry/exit slippage and fees; manages stop loss, take profit, maximum holding time and signal invalidation; and maintains cash/equity/P&L state.

Safety: PAPER only. No private-key access, signing or broadcast exists in the V30 engine. V30 is not a live trading engine and does not imply profitability.
