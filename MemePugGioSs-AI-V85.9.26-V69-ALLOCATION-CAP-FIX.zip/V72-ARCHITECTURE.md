# V72 — Real-Time Pump.fun & Market Dashboard Feed

V72 adds a read-only market feed contract for the Android operator console.

## Flow

SOLANA/Pump.fun verified backend state → existing observation/token/signal stores → `buildV72MarketFeed()` → `GET /api/v72/mobile/market-feed` → Android UI.

The feed exposes only data already present in the backend; it does not fabricate market values. It combines the latest ranked opportunities with V28 AI signal state and a bounded historical price/liquidity series for the first tokens in the feed.

## Data

- token mint/name/symbol
- latest observed price
- liquidity and 5m volume
- holders and buy pressure
- opportunity score/risk score
- tradable/stale state
- AI signal state/action/score
- bounded recent observation history
- source/freshness metadata

## Safety

V72 remains PAPER/SHADOW only. No wallet keys, signing, transaction broadcast, live execution or automatic promotion are introduced.

## Endpoint

`GET /api/v72/mobile/market-feed?limit=50`

Requires the existing authenticated Bearer token.
