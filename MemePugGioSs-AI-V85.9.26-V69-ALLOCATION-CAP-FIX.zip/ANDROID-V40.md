# Android V40 — Copy Trading UI

V40 promotes Copy Trading from a summary card to a native Android screen while preserving the official MemePugGioSs visual language.

## UI
- Sidebar: Home, Assistente AI, Pump.fun, Live Monitor, Copy Trading, Portfolio, Settings.
- Copy Trading screen with cumulative equity curve, Copy P&L from start, equity, return, drawdown, risk state, win rate, trade count and average slippage.
- Trader table and Copy Signal status.
- Assistente AI screen explicitly shows autonomous PAPER research status.

## Data
REST:
- GET `/api/v39/copy/analytics`
- GET `/api/v39/copy/analytics/summary`
- GET `/api/v39/copy/analytics/equity?limit=300`
- GET `/api/v39/copy/analytics/traders?limit=20`

Realtime:
- authenticated WebSocket `copyAnalytics`, `copyRisk`, `copySignals`, `copyTraders`, `following`.

## Safety
V40 remains PAPER/SHADOW. The Android app stores no private keys and contains no signing or broadcast controls.
