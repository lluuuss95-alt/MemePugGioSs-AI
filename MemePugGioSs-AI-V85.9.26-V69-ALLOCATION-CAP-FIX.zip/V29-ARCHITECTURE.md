# V29 — AI Signal Fusion & Ranking Engine

Pipeline: V25 Live State + V26 Discovery + V27 Recovery + V28 Signal Engine -> V29 ranking -> Home/Android.

V29 ranks already-generated V28 signals. It does not invent market facts and does not execute trades.

Ranking inputs: signal score, confidence, liquidity, smart-money score, graduation progress, risk and signal age.
A time-decay factor reduces the influence of stale signals. Safety gates exclude blocked/high-risk/low-liquidity candidates from TOP_SIGNAL.

Outputs: TOP_SIGNAL, WATCHLIST, BLOCKED, EXCLUDED. Ranking is deterministic for identical inputs and timestamp.

No live signing, private-key access, transaction broadcast, or automatic promotion.
