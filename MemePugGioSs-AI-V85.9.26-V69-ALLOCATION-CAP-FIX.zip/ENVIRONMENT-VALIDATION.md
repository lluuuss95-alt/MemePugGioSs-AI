# Runtime Validation Environment

The project now contains a reproducible Node 22 CI/Docker path for real dependency installation and runtime tests.

Required commands:
- `npm ci`
- `npm run build`
- `npm run typecheck:tests`
- `npm run validate:paper-shadow`
- `npm run e2e:paper`
- `npm test`

Safety defaults are explicitly PAPER-only in Docker/CI. Live execution, signing, broadcast, private-key access and auto-promotion are disabled.

Android build remains environment-dependent on the Android SDK/Gradle toolchain and is intentionally not represented as passed by this package.
