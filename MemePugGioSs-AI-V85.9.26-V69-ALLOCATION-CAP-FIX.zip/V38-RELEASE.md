# V38 Release

MemePugGioSs AI V38 adds the Copy Trading Risk Manager. V36 eligible copy signals are now checked against portfolio-level exposure, concentration, daily loss, drawdown and circuit-breaker rules before V37 paper execution. V38 remains PAPER/SHADOW only and is non-custodial.

The official V37 copy execution route is now guarded by a V38 preflight; a blocked risk decision prevents the paper copy from being created.
