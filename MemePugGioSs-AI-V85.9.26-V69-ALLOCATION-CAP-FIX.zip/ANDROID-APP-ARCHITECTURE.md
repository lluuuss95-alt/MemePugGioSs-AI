# Android App Architecture — V26

MemePugGioSs AI is being converted into a real Android application without moving the sensitive trading engine into the phone.

## Layers
1. Android UI: Kotlin + Jetpack Compose, official Home layout preserved as the visual contract.
2. Mobile data client: authenticated REST polling for the current V26 state.
3. Backend engine: existing Node/TypeScript V1-V26 stack.
4. Solana layer: RPC + WebSocket discovery/state engines.
5. Safety layer: PAPER/SHADOW only; signing, private-key access and broadcast remain disabled.

## Why this split
The Android app is the operator console. The backend remains the source of truth for discovery, state reconciliation, intelligence, persistence and future execution controls. This follows Android's recommended separation of UI and data layers and single source of truth approach.

## Next Android milestones
- V27: authenticated WebSocket/mobile realtime channel
- V28: encrypted local session/token storage
- V29: wallet connection boundary using Solana Mobile Wallet Adapter, still with explicit confirmation and no automatic live trading
- V30: Play-release hardening, crash reporting, offline cache and adaptive tablet UI
