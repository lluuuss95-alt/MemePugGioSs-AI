# V38 Checklist

- [x] Portfolio-level exposure gate
- [x] Token concentration gate
- [x] Trader concentration gate
- [x] Daily loss limit
- [x] Drawdown warning/halt
- [x] Circuit breaker state
- [x] Concurrent trader limit
- [x] Shared-token concentration check
- [x] Persistent risk events
- [x] REST risk snapshot endpoint
- [x] REST preflight endpoint
- [x] WebSocket copyRisk snapshot
- [x] Live trading remains blocked
- [x] Signing remains blocked
- [x] Broadcast remains blocked
