# MemePugGioSs AI — V7 DEX & Pump Intelligence

V7 adds a provider-agnostic DEX/Pump intelligence layer on top of V6.

Pipeline:
Solana stream/RPC -> transaction normalization -> protocol adapter -> lifecycle events
-> market microstructure -> deployer/holder behavior -> risk delta -> opportunity gate -> PAPER.

Safety:
- PAPER is the only execution mode enabled by default.
- No private keys, signing, or broadcast endpoints are introduced.
- Unknown protocol semantics are marked UNKNOWN rather than guessed.
- Pump.fun-specific ingestion is an adapter boundary; no undocumented/private endpoint is assumed.

Lifecycle states:
CREATED -> LIQUIDITY_BOOTSTRAP -> ACTIVE_TRADING -> DISTRIBUTION -> EXIT_RISK
with UNKNOWN when evidence is insufficient.

V7 event types:
TOKEN_CREATED, LIQUIDITY_ADD, LIQUIDITY_REMOVE, SWAP_BUY, SWAP_SELL,
TRANSFER, AUTHORITY_CHANGE, LARGE_HOLDER_MOVE, UNKNOWN_PROTOCOL_EVENT.

All events carry confidence, source transaction signature, slot and evidence.
