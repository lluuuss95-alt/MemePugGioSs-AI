# MemePugGioSs AI V11 — Historical Data & Real Replay Engine

V11 provides the historical-data layer for V10.

Pipeline:
raw provider records -> schema normalization -> timestamp validation -> deduplication
-> chronological dataset -> dataset fingerprint/version -> deterministic replay -> V10.

Rules:
- provider data is normalized into a canonical event format;
- records with invalid timestamps are quarantined;
- duplicate records are removed deterministically;
- events are ordered by timestamp, slot and stable ID;
- dataset manifests contain source, version, row counts and SHA-256 fingerprint;
- replay is deterministic;
- no future data is exposed to the strategy;
- missing observations remain missing rather than being fabricated.

V11 supports CSV/JSON ingestion locally and leaves provider-specific network ingestion behind an adapter boundary.
