# Android V38 — Copy Risk

The Android operator console can consume `copyRisk` from the WebSocket and `/api/v38/copy/risk` plus `/api/v38/copy/risk/events` and `/api/v38/copy/risk/preflight`.

Suggested Home/Copy Trading indicators:
- Risk state: NORMAL / WARNING / HALTED
- total exposure
- token concentration
- trader concentration
- daily loss
- drawdown
- circuit breaker reason

V38 remains PAPER/SHADOW only. No private keys or signing are stored in Android.
