# V17 — Walk-Forward & Market Regime Detection

V17 evaluates strategy parameters repeatedly through rolling chronological windows.

For each window:
1. optimize only on train;
2. select on validation;
3. evaluate once on subsequent untouched test;
4. record the test regime;
5. measure degradation and consistency.

No future test data is used to choose parameters.

Regime detection uses observable dataset features:
- volatility
- liquidity proxy
- momentum proxy

Regimes:
LOW_VOL, NORMAL, HIGH_VOL, LOW_LIQUIDITY, HIGH_MOMENTUM, MIXED.

Outputs include regime coverage, per-regime performance, walk-forward consistency,
test degradation and a deterministic run fingerprint.

Research/PAPER only. Status labels are diagnostics, not forecasts or profit guarantees.
