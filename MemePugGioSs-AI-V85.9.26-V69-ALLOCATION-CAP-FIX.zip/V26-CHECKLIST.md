# V26 Checklist

- [x] Pump program ID pinned to the documented mainnet/devnet program
- [x] logsSubscribe mention filter
- [x] getTransaction verification
- [x] legacy `create` discriminator
- [x] `create_v2` discriminator
- [x] mint and bonding curve taken from instruction accounts
- [x] optional metadata argument decoding
- [x] signature deduplication
- [x] mint deduplication
- [x] V25 auto-tracking handoff
- [x] Home data contract
- [x] reconnect/backoff boundary
- [x] Shadow-only safety
- [ ] live mainnet soak test
- [ ] provider-specific throughput benchmark
- [ ] persistent discovery cursor/backfill for websocket gaps
