# V10 Checklist

- [x] Deterministic chronological replay
- [x] Future-leakage guard
- [x] Strategy interface
- [x] Simulated execution with fee and slippage
- [x] Portfolio accounting
- [x] Equity curve
- [x] Return / drawdown metrics
- [x] Win rate / expectancy / profit factor
- [x] Sharpe-like and Sortino-like metrics
- [x] Walk-forward window framework
- [x] Strategy comparison
- [x] Parameter evaluation hooks
- [x] Deterministic run manifest
- [x] Unit tests
- [x] No LIVE execution
