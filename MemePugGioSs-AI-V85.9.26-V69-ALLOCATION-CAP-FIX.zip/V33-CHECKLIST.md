# V33 Checklist

- [x] Persistent state load from V32
- [x] Deterministic state hashing
- [x] Durable checkpoints
- [x] Duplicate/invalid state checks
- [x] Recovery status report
- [x] Safety invariants
- [x] Smoke test
- [ ] Full Android/Node release build in a provisioned build environment
- [ ] Mainnet long-run soak test
