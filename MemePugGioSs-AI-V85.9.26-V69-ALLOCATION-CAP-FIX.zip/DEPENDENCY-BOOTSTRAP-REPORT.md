# V85.5 — Dependency / CI Bootstrap Report

## Finding
The V85.4 repository did not contain `package-lock.json`. Therefore `npm ci` could not run in a clean environment; this was verified directly with npm 10.9.2.

## Correction
The CI workflow and Dockerfile now use `npm install --no-audit --no-fund` so the validation environment can bootstrap from `package.json` when the repository is first built.

## Important limitation
This is a bootstrap correction, not a claim of deterministic dependency pinning. A production-grade release should commit a generated `package-lock.json` after a successful dependency resolution in an environment with registry access, then switch CI/Docker back to `npm ci`.

## Safety
Paper/Shadow remains mandatory. No live execution, signing, private-key access, broadcast, or auto-promotion is enabled.
