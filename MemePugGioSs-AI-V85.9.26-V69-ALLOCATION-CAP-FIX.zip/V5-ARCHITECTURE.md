# MemePugGioSs AI — V5 Architecture

V5 is a PAPER-first Solana intelligence layer. It adds token intelligence, risk scoring, RPC log streaming, richer RPC reads, and opportunity gates while keeping transaction signing/broadcast disabled.

## Flow

Solana RPC / authorized market feed -> ingestion queue -> validation/deduplication -> SQLite -> market scanner -> token intelligence -> opportunity/risk gates -> paper execution -> portfolio/PnL -> REST/WebSocket dashboard.

## Token intelligence

For configured mints, V5 can query token supply, largest token accounts and parsed mint account metadata. The resulting risk score considers mint authority, freeze authority and top-holder concentration when the RPC exposes those values. Missing data is explicitly flagged rather than treated as safe.

## Chain stream

V5 can optionally use a Solana WebSocket `logsSubscribe` stream. The stream is observational only and reconnects with bounded backoff. It does not sign or broadcast transactions.

## Pump.fun boundary

The market feed remains provider-agnostic. Do not hard-code undocumented/private endpoints. A future adapter may consume an authorized launch/indexer feed and normalize it into the same MarketEvent contract.

## Safety

- PAPER is the default.
- LIVE is rejected at configuration level.
- No private-key storage.
- No signing endpoint.
- No transaction broadcast path.
- An opportunity score never authorizes a live trade.
