# V64 — Autonomous Execution Guard & Pre-Trade Validation

V64 is the final deterministic gate immediately before V52 Paper execution.

Flow:
V63 Capital Allocation -> V64 Pre-Trade Guard -> V52 Paper Execution -> V53 Supervisor

Checks include decision/action, mint consistency, decision freshness, market-state freshness, price validity, liquidity, verified data, risk, regime, slippage, open-position duplication, position count, portfolio exposure, reserve protection and capital allocation.

A failed critical check produces BLOCK and approvedQuote=0. Passing checks produce ALLOW_PAPER; warnings may mark the result WARNING without blocking.

V64 never signs, broadcasts, accesses private keys or enables live execution.
