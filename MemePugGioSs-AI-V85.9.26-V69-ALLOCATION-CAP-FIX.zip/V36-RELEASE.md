# MemePugGioSs AI V36 — Release

V36 adds the AI Copy Signal Engine. The system now converts observed verified trader activity into an explainable copy/no-copy decision using trader reputation, latency, market quality, freshness, and exposure constraints.

This release is still PAPER/SHADOW-only. No private keys, signing, transaction construction, broadcast, or automatic live promotion is enabled.
