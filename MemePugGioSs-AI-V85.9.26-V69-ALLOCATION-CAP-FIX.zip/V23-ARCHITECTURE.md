# V23 — Pump Bonding Curve State & Market Math

V23 turns verified protocol observations into quantitative market state.

## Bonding curve
Tracks:
- virtual token reserves
- virtual quote reserves
- real token reserves
- real quote reserves
- total supply
- completion/graduation state

All financial calculations use `bigint`; no JavaScript floating-point `number` is used for monetary quantities.

## PumpSwap
Uses:
`effectiveQuoteReserves = quoteVaultBalance + virtualQuoteReserves`

The virtual quote reserve is signed, so the implementation supports negative values while rejecting a negative effective reserve.

## Outputs
- spot price as numerator/denominator
- constant-product invariant
- exact integer quote
- market-cap quote
- bonding-curve progress
- PumpSwap market-cap quote

V23 intentionally separates math from protocol decoding. Raw account bytes are not decoded until a verified deployed layout/IDL decoder is attached.
