# Android V36 integration

The Android operator console should consume the V36 endpoints through the existing authenticated REST/WebSocket layer.

Home additions:
- Assistente AI status card
- cumulative P&L since first paper operation
- eligible Copy Signals feed
- blocked copy signals with human-readable reasons

Copy Trading screen:
- followed traders
- V35 reputation
- latest observed trade
- V36 eligibility state
- latency, liquidity, volume and freshness gates
- proposed paper size

The Android app never stores or handles private keys for V36.
