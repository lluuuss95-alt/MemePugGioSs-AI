# V28 — Real-Time Signal Engine

V28 connects verified live/discovered market state to a deterministic signal layer for the Home dashboard.

Pipeline:

V25 Live State + V26 Discovery + V27 Recovery
→ feature adapter
→ risk/freshness/sample gates
→ deterministic signal score
→ WATCH / EARLY_ENTRY / CONFIRMED / INVALIDATED / BLOCKED
→ PAPER candidate only
→ Home + Android realtime feed

This is not a claim of predictive accuracy or profitability. The current implementation is a transparent deterministic model, not an LLM and not a trained production ML model.

Safety invariants remain: PAPER/SHADOW only, no private-key access, no signing, no broadcast, no automatic promotion.
