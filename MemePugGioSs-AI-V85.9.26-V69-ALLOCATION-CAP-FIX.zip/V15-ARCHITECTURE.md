# MemePugGioSs AI V15 — Strategy Discovery & Parameter Optimization

V15 searches strategy parameter configurations while reducing overfitting risk.

Pipeline:
candidate parameter grid -> train evaluation -> validation evaluation -> stability/complexity penalty
-> shortlist -> untouched test evaluation -> optimization manifest.

Guardrails:
- test set is never used to choose parameters;
- minimum sample size;
- parameter complexity penalty;
- train/validation performance gap penalty;
- minimum validation confidence;
- deterministic candidate ordering;
- max candidate budget;
- no automatic deployment.

Objective:
maximize validation-adjusted score, not raw training return.

Each candidate stores parameters, train metrics, validation metrics, stability gap, complexity,
adjusted score and eligibility.
