# MemePugGioSs AI — V26 Release

## Live Token Discovery + Pump.fun Auto-Tracking

V26 detects new Pump token creation transactions from Solana program logs, verifies the Pump instruction with `getTransaction`, registers the mint and bonding curve, and hands the token to the V25 live state engine.

### New modules
- `src/v26-pump-create-parser.ts`
- `src/v26-discovery-feed.ts`
- `src/v26-discovery-store.ts`
- `src/v26-sqlite-store.ts`
- `src/v26-home-feed.ts`
- `src/v26-types.ts`
- `src/v26-base58.ts`
- `src/v26-safety.ts`
- `tests/v26.test.ts`

### Safety
V26 is SHADOW/PAPER only. It discovers and monitors tokens; it does not sign, submit, or broadcast trades.

### Limitation
A websocket stream can miss events during provider outages. V26 therefore treats websocket discovery as the live path; a future backfill/reconciliation stage should use signature pagination to close gaps after reconnects.

## Android application integration
V26 now includes a native Android client under `android-app/`. It is a Kotlin + Jetpack Compose operator app that connects to the existing backend API. The Android client does not hold private keys and does not sign/broadcast transactions. The official Home dashboard is preserved as the visual contract while data is supplied by the V26/V25 engines.
