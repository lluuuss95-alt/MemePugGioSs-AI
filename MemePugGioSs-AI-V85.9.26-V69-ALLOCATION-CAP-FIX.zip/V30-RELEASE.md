# MemePugGioSs AI V30 Release
Version: 1.0.0-v30-shadow

V30 introduces the deterministic AI Decision & Paper Execution Engine. It is intentionally PAPER/SHADOW only.

The Android client remains a UI/control layer; no private keys or signing capability are included.

The official Home layout is preserved as the product reference. V30 adds data plumbing for paper positions, P&L and decision state rather than redesigning the Home.
