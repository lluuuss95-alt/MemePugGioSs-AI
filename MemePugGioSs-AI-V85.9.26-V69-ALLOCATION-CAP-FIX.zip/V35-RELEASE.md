# V35 release notes

MemePugGioSs AI V35 extends V34 with a rolling-window trader reputation engine and the first assistant runtime surface.

The official Home remains PAPER MODE. The performance chart is treated as cumulative from the beginning of the paper ledger, with total P&L surfaced explicitly.
