# V34 — Trader Discovery Engine

V34 introduces a public-wallet trader profiling layer for Pump.fun/PumpSwap copy-trading research.

Pipeline:
`wallet history -> verified transaction boundary -> normalized trade observations -> trader profile -> ranking -> copy candidate`

Important: V34 does not guess DEX semantics from arbitrary instructions. A trade must arrive as a verified `V34TradeObservation` from a trusted/verified protocol adapter. Raw wallet transactions are not automatically treated as BUY/SELL.

RPC support uses Solana `getSignaturesForAddress` for history and `getTransaction` for transaction details. Realtime discovery can later subscribe to `logsSubscribe` per followed wallet/program.

Copy execution is PAPER/SHADOW only. No private keys, signing, broadcast, or LIVE copy trading are enabled.
