# V7 Checklist

- [x] Generic DEX protocol adapter contract
- [x] Pump lifecycle state machine
- [x] Swap/liquidity event normalization
- [x] Buy/sell flow aggregation
- [x] Liquidity delta tracking
- [x] Deploy/holder behavior hooks
- [x] Protocol confidence and UNKNOWN handling
- [x] Risk delta calculation
- [x] Opportunity gate integration
- [x] PAPER-only safety boundary
- [x] V7 unit tests
