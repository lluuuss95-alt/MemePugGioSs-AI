# V63 — AI Capital Allocation Optimizer

V63 sits after V62 arbitration and redistributes only capital ceilings already approved by the upstream V61 portfolio gate. It uses deterministic bounded weights from score, confidence, inverse risk, liquidity, freshness, Smart Money and strategy quality. Regime multipliers can reduce or block allocation.

Flow: Pump.fun/Solana -> V48/V49/V50 -> V56/V57/V58/V59 -> V60 -> V62 Arbitration -> V61 Portfolio Gate -> V63 Capital Allocation -> V52 Paper Execution -> V53 Monitoring.

Safety: PAPER/SHADOW only. No private keys, signing, broadcast, live execution or auto-promotion.
