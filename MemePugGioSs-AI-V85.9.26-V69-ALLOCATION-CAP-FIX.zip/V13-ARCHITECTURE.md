# MemePugGioSs AI V13 — Solana Data Collector & Dataset Factory

V13 converts V11/V12 historical events into token-centric research datasets.

Pipeline:
raw Solana events -> canonical events -> token timeline -> fixed windows
-> OHLC/flow/liquidity/holder/smart-money features -> forward outcome labels
-> dataset manifest -> V10/V9 replay.

Window sizes:
1m, 5m, 15m, 1h, 6h, 24h.

Anti-leakage:
- features are computed only from events <= window end;
- forward labels are stored separately and never exposed to signal generation;
- windows are immutable after fingerprinting;
- duplicate events are removed before aggregation.

Outputs:
- token timeline
- window snapshots
- forward return / MFE / MAE labels
- liquidity and flow deltas
- holder and smart-money deltas
- dataset quality statistics
