# V66 — Real-Time Execution Quality Monitor

V66 measures the quality of the Paper Trading execution model after V65.

## Flow

V64 pre-trade guard → V65 execution simulation → V52 Paper execution → **V66 quality observation**.

V66 compares:
- market/reference price;
- V65 simulated execution price;
- V52 Paper execution price when available;
- simulation/paper deviation in basis points;
- decision-to-observation latency;
- liquidity at observation;
- simulated slippage and price impact.

## Quality states

- GOOD: within configured tolerances;
- WARNING: degradation approaching configured limits;
- POOR is reserved for future aggregation/analytics; individual observations use BLOCKED when a hard quality gate is exceeded;
- BLOCKED: hard deviation or latency threshold exceeded, or invalid price data.

Every observation is persisted in `v66_execution_quality` and can be aggregated per token or globally.

## Safety

V66 is strictly PAPER/SHADOW. It never signs, broadcasts, submits, promotes, or accesses private keys.
