# V55 — AI Opportunity Queue & Priority Scheduler

V55 is the bounded scheduling layer between V54 realtime events/V49 instant scoring and V50 deep intelligence. It prioritizes verified candidates without predicting profitability and without executing trades.

## Flow
`Pump.fun/Solana -> V48 Discovery -> V54 Router -> V49 Instant Score -> V55 Scheduler -> V50 Deep Intelligence -> V51 Decision -> V46/V47 Allocation -> V52/V53 Paper`

## Scheduling
- `DEEP_ANALYSIS` receives HIGH/CRITICAL priority based on score.
- `WATCH` receives NORMAL priority.
- `REJECTED` is audited and never enters the deep-analysis queue.
- bounded queue and per-mint queue caps prevent one token from consuming the whole budget.
- per-mint dispatch quotas prevent a single mint from monopolizing compute during bursts.
- aging/fairness prevents low-priority jobs from starving indefinitely.
- TTL expires stale jobs before deep analysis.
- configurable concurrency provides a deterministic compute budget.
- all queue decisions are persisted in `v55_scheduler_events`.

## Safety
V55 is PAPER/SHADOW only. It has no private-key access, signing, transaction broadcast, live execution, or auto-promotion.
