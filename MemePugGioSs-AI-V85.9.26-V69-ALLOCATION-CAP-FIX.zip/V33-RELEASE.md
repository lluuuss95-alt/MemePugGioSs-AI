# V33 Release

Version: 33.0.0-shadow
Mode: PAPER/SHADOW

V33 adds persistent replay/recovery around the V32 ledger. It is not a live execution release.
