import { V28Features, V28Signal } from "./v28-types.js";
import { defaultV28Engine } from "./v28-signal-engine.js";

export interface V28LiveTokenInput {
  mint: string;
  buyPressure?: number;
  flowMomentum?: number;
  liquidityScore?: number;
  holderScore?: number;
  smartMoneyScore?: number;
  riskScore?: number;
  freshnessScore?: number;
  sampleConfidence?: number;
  priceMomentum?: number;
  graduationProgress?: number;
  source?: V28Signal["source"];
}

export function signalFromLiveState(t: V28LiveTokenInput): V28Signal {
  const features:V28Features = {
    buyPressure: clamp(t.buyPressure ?? 50), flowMomentum: clamp(t.flowMomentum ?? 50),
    liquidityScore: clamp(t.liquidityScore ?? 0), holderScore: clamp(t.holderScore ?? 0),
    smartMoneyScore: clamp(t.smartMoneyScore ?? 0), riskScore: clamp(t.riskScore ?? 50),
    freshnessScore: clamp(t.freshnessScore ?? 0), sampleConfidence: clamp(t.sampleConfidence ?? 0),
    priceMomentum: clamp(t.priceMomentum ?? 50), graduationProgress: clamp(t.graduationProgress ?? 0)
  };
  return defaultV28Engine().evaluate({mint:t.mint,features,source:t.source});
}
function clamp(v:number){return Math.max(0,Math.min(100,v));}
