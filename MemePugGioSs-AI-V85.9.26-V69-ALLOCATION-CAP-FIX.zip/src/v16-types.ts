
export interface StressScenario {
  name:string;
  feeMultiplier:number;
  slippageMultiplier:number;
  executionDelayBars:number;
  liquidityMultiplier:number;
  missingDataRate:number;
  entryDelayBars:number;
  exitDelayBars:number;
}
export interface StressMetrics {
  scenario:string;
  samples:number;
  meanReturn:number;
  medianReturn:number;
  winRate:number;
  maxDrawdown:number;
  worstTrade:number;
  profitFactor:number;
  totalReturn:number;
}
export interface MonteCarloSummary {
  runs:number;
  seed:number;
  meanReturn:number;
  p05:number;
  p50:number;
  p95:number;
  probabilityPositive:number;
  worstDrawdownP95:number;
}
export interface RobustnessReport {
  runId:string;
  baseline:StressMetrics;
  scenarios:StressMetrics[];
  monteCarlo:MonteCarloSummary;
  bootstrapCI:{lower:number;upper:number;confidence:number};
  fragilityScore:number;
  status:"ROBUST"|"SENSITIVE"|"FRAGILE"|"INSUFFICIENT_DATA";
}
