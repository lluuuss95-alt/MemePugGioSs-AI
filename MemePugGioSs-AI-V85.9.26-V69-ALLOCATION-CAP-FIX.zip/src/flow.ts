import { NormalizedDexEvent } from "./protocols.js";

export interface FlowSnapshot {
  buys:number;
  sells:number;
  buyVolume:number;
  sellVolume:number;
  netFlow:number;
  buyRatio:number;
  liquidityDelta:number;
  uniqueTraders:number;
}

export function aggregateFlow(events: NormalizedDexEvent[]): FlowSnapshot {
  let buys=0,sells=0,buyVolume=0,sellVolume=0,liq=0;
  const traders=new Set<string>();
  for (const e of events) {
    if (e.type==="SWAP_BUY") { buys++; buyVolume += e.quoteAmount ?? 0; if(e.trader) traders.add(e.trader); }
    if (e.type==="SWAP_SELL") { sells++; sellVolume += e.quoteAmount ?? 0; if(e.trader) traders.add(e.trader); }
    if (e.type==="LIQUIDITY_ADD") liq += e.quoteDelta ?? 0;
    if (e.type==="LIQUIDITY_REMOVE") liq -= e.quoteDelta ?? 0;
  }
  const total=buyVolume+sellVolume;
  return { buys,sells,buyVolume,sellVolume,netFlow:buyVolume-sellVolume,buyRatio:total?buyVolume/total:0,liquidityDelta:liq,uniqueTraders:traders.size };
}
