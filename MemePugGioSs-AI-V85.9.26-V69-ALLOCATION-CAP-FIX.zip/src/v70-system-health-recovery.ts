import crypto from 'node:crypto';
import { db } from './db.js';

export type V70State='RUNNING'|'DEGRADED'|'RECOVERING'|'HALTED';
export type V70Component='SOLANA_FEED'|'PUMPFUN_DISCOVERY'|'AI_PIPELINE'|'DATABASE'|'SCHEDULER'|'PAPER_EXECUTION'|'WEBSOCKET';
export type V70ComponentState='HEALTHY'|'STALE'|'FAILED'|'UNKNOWN';
export type V70Action='NONE'|'DEGRADE'|'RECOVER'|'HALT';

export interface V70ComponentStatus {
  component:V70Component;
  state:V70ComponentState;
  lastHeartbeat:number;
  latencyMs?:number;
  detail?:string;
}
export interface V70Input {
  now?:number;
  components:V70ComponentStatus[];
  queueDepth?:number;
  maxQueueDepth?:number;
  errorRatePct?:number;
  maxErrorRatePct?:number;
  consecutiveRecoveryFailures?:number;
}
export interface V70Result {
  id:string; ts:number; state:V70State; previousState:V70State; action:V70Action;
  components:V70ComponentStatus[]; staleComponents:string[]; failedComponents:string[];
  reasons:string[]; heartbeatAgeMaxMs:number; queueDepth:number; errorRatePct:number;
  safeToRunPaper:boolean; liveExecutionEnabled:false;
}
export interface V70Config {
  heartbeatTimeoutMs:number;
  degradedQueueRatio:number;
  maxErrorRatePct:number;
  haltOnComponents:V70Component[];
  recoveryFailureHaltThreshold:number;
}
export const defaultV70Config:V70Config={
  heartbeatTimeoutMs:5000,
  degradedQueueRatio:0.8,
  maxErrorRatePct:10,
  haltOnComponents:['DATABASE','SOLANA_FEED','PAPER_EXECUTION'] as V70Component[],
  recoveryFailureHaltThreshold:3
};

export class V70SystemHealthRecovery {
  private state:V70State='RUNNING';
  constructor(private readonly cfg:V70Config=defaultV70Config){this.ensureSchema();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v70_health_snapshots(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,state TEXT NOT NULL,previous_state TEXT NOT NULL,action TEXT NOT NULL,components_json TEXT NOT NULL,reasons_json TEXT NOT NULL,safe_to_run_paper INTEGER NOT NULL,details_json TEXT NOT NULL)`);}
  evaluate(input:V70Input):V70Result{
    const now=input.now??Date.now();
    const statuses=input.components??[];
    const stale=statuses.filter(c=>c.state==='STALE'||now-c.lastHeartbeat>this.cfg.heartbeatTimeoutMs).map(c=>c.component);
    const failed=statuses.filter(c=>c.state==='FAILED').map(c=>c.component);
    const unknown=statuses.filter(c=>c.state==='UNKNOWN').map(c=>c.component);
    const ages=statuses.map(c=>Math.max(0,now-c.lastHeartbeat));
    const heartbeatAgeMaxMs=ages.length?Math.max(...ages):Number.POSITIVE_INFINITY;
    const queueDepth=Math.max(0,input.queueDepth??0);
    const maxQueueDepth=Math.max(1,input.maxQueueDepth??10000);
    const errorRatePct=Math.max(0,input.errorRatePct??0);
    const recoveryFailures=Math.max(0,input.consecutiveRecoveryFailures??0);
    const reasons:string[]=[];
    const criticalFailed=failed.filter(c=>this.cfg.haltOnComponents.includes(c));
    const criticalStale=stale.filter(c=>this.cfg.haltOnComponents.includes(c));
    if(criticalFailed.length) reasons.push(`CRITICAL_COMPONENT_FAILED:${criticalFailed.join(',')}`);
    if(criticalStale.length) reasons.push(`CRITICAL_COMPONENT_STALE:${criticalStale.join(',')}`);
    if(errorRatePct>Math.max(this.cfg.maxErrorRatePct,input.maxErrorRatePct??this.cfg.maxErrorRatePct)) reasons.push('ERROR_RATE_HIGH');
    if(queueDepth/maxQueueDepth>=1) reasons.push('QUEUE_SATURATED');
    else if(queueDepth/maxQueueDepth>=this.cfg.degradedQueueRatio) reasons.push('QUEUE_NEAR_LIMIT');
    if(unknown.length) reasons.push(`COMPONENT_UNKNOWN:${unknown.join(',')}`);
    if(!statuses.length) reasons.push('NO_COMPONENT_HEARTBEATS');
    const previousState=this.state;
    let next:V70State='RUNNING'; let action:V70Action='NONE';
    if(criticalFailed.length || criticalStale.length || queueDepth>=maxQueueDepth || recoveryFailures>=this.cfg.recoveryFailureHaltThreshold){next='HALTED';action='HALT';}
    else if(reasons.includes('NO_COMPONENT_HEARTBEATS') || errorRatePct>this.cfg.maxErrorRatePct || queueDepth/maxQueueDepth>=this.cfg.degradedQueueRatio || stale.length || unknown.length){next='DEGRADED';action='DEGRADE';}
    else if(previousState==='HALTED' || previousState==='DEGRADED' || previousState==='RECOVERING'){next='RECOVERING';action='RECOVER';}
    this.state=next;
    const safeToRunPaper=next==='RUNNING';
    const result:V70Result={id:crypto.randomUUID(),ts:now,state:next,previousState,action,components:statuses,staleComponents:stale,failedComponents:failed,reasons,heartbeatAgeMaxMs,queueDepth,errorRatePct,safeToRunPaper,liveExecutionEnabled:false};
    db.prepare(`INSERT INTO v70_health_snapshots VALUES(?,?,?,?,?,?,?,?,?)`).run(result.id,now,next,previousState,action,JSON.stringify(statuses),JSON.stringify(reasons),safeToRunPaper?1:0,JSON.stringify({queueDepth,maxQueueDepth,recoveryFailures,liveExecutionEnabled:false}));
    return result;
  }
  forceRecovery(){if(this.state==='HALTED') this.state='RECOVERING'; return this.state;}
  currentState(){return this.state;}
  recent(limit=100){return db.prepare(`SELECT * FROM v70_health_snapshots ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}
}
export const V70_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV70Safe(){if(!V70_SAFETY.shadowOnly||V70_SAFETY.signingEnabled||V70_SAFETY.privateKeyAccess||V70_SAFETY.broadcastEnabled||V70_SAFETY.liveExecutionAllowed||V70_SAFETY.autoPromotion)throw new Error('V70_SAFETY_INVARIANT_FAILED');}
