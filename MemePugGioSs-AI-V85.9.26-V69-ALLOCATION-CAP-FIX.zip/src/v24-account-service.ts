import {PumpAccountDecoder} from "./v24-pump-decoder.js";
export interface AccountRpc{getAccountInfo(address:string):Promise<any>}
export class PumpAccountService{
 constructor(private rpc:AccountRpc,private decoder=new PumpAccountDecoder()){}
 async bondingCurve(address:string,mint:string,slot=0){const r=await this.rpc.getAccountInfo(address);if(!r?.value)return null;return this.decoder.decodeBondingCurve(r.value.data,mint,slot)}
 async pool(address:string,slot=0){const r=await this.rpc.getAccountInfo(address);if(!r?.value)return null;return this.decoder.decodePool(r.value.data,slot)}
}