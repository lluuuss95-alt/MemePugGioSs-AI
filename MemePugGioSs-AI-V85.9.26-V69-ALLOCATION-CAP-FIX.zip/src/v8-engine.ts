import { buildWalletProfiles, scoreWallet, WalletObservation } from "./wallet-intelligence.js";
import { buildClusters } from "./cluster-intelligence.js";
import { scoreDeveloper } from "./dev-reputation.js";

export interface V8Analysis {
  mint:string;
  wallets:ReturnType<typeof buildWalletProfiles>;
  walletScores:ReturnType<typeof scoreWallet>[];
  clusters:ReturnType<typeof buildClusters>;
  deployers:ReturnType<typeof scoreDeveloper>[];
  riskDelta:number;
  opportunityDelta:number;
  confidence:number;
  blocked:boolean;
}

export function analyzeV8(mint:string, observations:WalletObservation[]):V8Analysis {
  const wallets=buildWalletProfiles(observations);
  const walletScores=[...wallets.values()].map(scoreWallet);
  const clusters=buildClusters(observations);
  const deployers=observations.filter(x=>x.role==="DEPLOYER")
    .map(x=>wallets.get(x.address))
    .filter((x): x is NonNullable<typeof x> => !!x)
    .map(p=>scoreDeveloper(p,scoreWallet(p)));

  const maxRisk=Math.max(0,...walletScores.map(x=>x.risk));
  const clusterRisk=Math.max(0,...clusters.map(x=>x.risk));
  const riskDelta=Math.min(50,Math.round(maxRisk*0.45+clusterRisk*0.55));
  const smart=walletScores.filter(x=>x.smartMoney>=20).length;
  const opportunityDelta=Math.min(30,smart*5);
  const confidence=observations.length ? Math.min(1,observations.length/30) : 0;
  const blocked=riskDelta>=40 || confidence<0.15;
  return {mint,wallets,walletScores,clusters,deployers,riskDelta,opportunityDelta,confidence,blocked};
}
