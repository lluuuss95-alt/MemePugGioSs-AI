import {db} from './db.js';
import {V39AnalyticsReport,V39AnalyticsSummary,V39EquityPoint,V39TraderAnalytics} from './v39-types.js';

const n=(v:unknown,d=0)=>Number.isFinite(Number(v))?Number(v):d;

export class V39CopyAnalytics {
  constructor(){this.ensureSchema()}
  private ensureSchema(){db.exec(`
    CREATE TABLE IF NOT EXISTS v39_copy_equity_snapshots(
      ts INTEGER PRIMARY KEY, equity REAL NOT NULL, pnl REAL NOT NULL, return_pct REAL NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_v39_equity_ts ON v39_copy_equity_snapshots(ts);
  `)}
  private portfolio(){
    const accounts=db.prepare(`SELECT COALESCE(SUM(allocated_cash),0) starting,COALESCE(SUM(equity),0) equity,COALESCE(SUM(realized_pnl),0) realized,COALESCE(SUM(unrealized_pnl),0) unrealized,COALESCE(SUM(fees),0) fees,COALESCE(SUM(slippage_cost),0) slippage,COALESCE(SUM(trades),0) trades,COALESCE(SUM(wins),0) wins,COALESCE(SUM(losses),0) losses,COUNT(*) active FROM v37_copy_accounts`).get() as any;
    const starting=n(accounts?.starting),equity=n(accounts?.equity),realized=n(accounts?.realized),unrealized=n(accounts?.unrealized),fees=n(accounts?.fees),slippage=n(accounts?.slippage);
    const net=realized+unrealized-fees;
    return {starting,equity,realized,unrealized,fees,slippage,trades:n(accounts?.trades),wins:n(accounts?.wins),losses:n(accounts?.losses),active:n(accounts?.active),net};
  }
  snapshot(now=Date.now()):V39EquityPoint{
    const p=this.portfolio(); const ret=p.starting>0?p.net/p.starting*100:0;
    const row=db.prepare(`SELECT COALESCE(MAX(equity),?) peak FROM v39_copy_equity_snapshots`).get(p.equity) as any;
    const peak=Math.max(p.equity,n(row?.peak));
    const point={ts:now,equity:p.equity,pnl:p.net,returnPct:ret};
    db.prepare(`INSERT OR REPLACE INTO v39_copy_equity_snapshots(ts,equity,pnl,return_pct) VALUES(?,?,?,?)`).run(point.ts,point.equity,point.pnl,point.returnPct);
    return point;
  }
  private drawdown(){
    const rows=db.prepare(`SELECT equity FROM v39_copy_equity_snapshots ORDER BY ts ASC`).all() as any[];
    let peak=0,max=0; for(const r of rows){const e=n(r.equity);peak=Math.max(peak,e);if(peak>0)max=Math.max(max,(peak-e)/peak*100)} return max;
  }
  summary():V39AnalyticsSummary{
    const p=this.portfolio(); const drawdown=this.drawdown();
    return {startingCapital:p.starting,currentEquity:p.equity,realizedPnl:p.realized,unrealizedPnl:p.unrealized,netPnl:p.net,returnPct:p.starting>0?p.net/p.starting*100:0,drawdownPct:drawdown,trades:p.trades,wins:p.wins,losses:p.losses,winRate:p.trades?p.wins/p.trades*100:0,fees:p.fees,slippageCost:p.slippage,activeTraders:p.active,updatedAt:Date.now()};
  }
  equityCurve(limit=500):V39EquityPoint[]{
    const rows=db.prepare(`SELECT ts,equity,pnl,return_pct returnPct FROM v39_copy_equity_snapshots ORDER BY ts ASC LIMIT ?`).all(Math.min(2000,Math.max(1,limit))) as any[];
    return rows.map(r=>({ts:n(r.ts),equity:n(r.equity),pnl:n(r.pnl),returnPct:n(r.returnPct)}));
  }
  private originalPnl(wallet:string){
    const rows=db.prepare(`SELECT mint,side,quote_amount quoteAmount,base_amount baseAmount,executed_at executedAt FROM v34_trades WHERE wallet=? ORDER BY executed_at ASC`).all(wallet) as any[];
    const lots=new Map<string,{qty:number,cost:number}>(); let pnl=0;
    for(const r of rows){const q=Math.abs(n(r.baseAmount)),quote=Math.abs(n(r.quoteAmount)); if(q<=0)continue;
      if(r.side==='BUY'){const x=lots.get(r.mint)||{qty:0,cost:0};x.qty+=q;x.cost+=quote;lots.set(r.mint,x)}
      else if(r.side==='SELL'){const x=lots.get(r.mint);if(!x||x.qty<=0)continue;const sold=Math.min(x.qty,q);const avg=x.cost/x.qty;pnl+=(quote*(sold/q))-avg*sold;x.qty-=sold;x.cost-=avg*sold;if(x.qty<=1e-12)lots.delete(r.mint)}
    } return pnl;
  }
  traders(limit=100):V39TraderAnalytics[]{
    const rows=db.prepare(`SELECT wallet,allocated_cash startingCapital,equity currentEquity,realized_pnl realizedPnl,unrealized_pnl unrealizedPnl,fees,slippage_cost slippageCost,trades,wins,losses FROM v37_copy_accounts ORDER BY equity DESC LIMIT ?`).all(Math.min(100,Math.max(1,limit))) as any[];
    return rows.map(r=>{
      const wallet=String(r.wallet); const sig=db.prepare(`SELECT COUNT(*) n,AVG(latency_ms) avg FROM v36_copy_signals WHERE wallet=? AND state='ELIGIBLE'`).get(wallet) as any;
      const blocked=db.prepare(`SELECT COUNT(*) n FROM v36_copy_signals WHERE wallet=? AND state='BLOCKED'`).get(wallet) as any;
      const starting=n(r.startingCapital),net=n(r.realizedPnl)+n(r.unrealizedPnl)-n(r.fees);
      const equity=n(r.currentEquity); const peakRow=db.prepare(`SELECT MAX(equity) peak FROM v37_copy_accounts WHERE wallet=?`).get(wallet) as any;
      const drawdown=starting>0?Math.max(0,(starting-equity)/starting*100):0;
      return {wallet,startingCapital:starting,currentEquity:equity,netPnl:net,returnPct:starting>0?net/starting*100:0,originalRealizedPnl:this.originalPnl(wallet),copyRealizedPnl:n(r.realizedPnl),copyUnrealizedPnl:n(r.unrealizedPnl),trades:n(r.trades),wins:n(r.wins),losses:n(r.losses),winRate:n(r.trades)>0?n(r.wins)/n(r.trades)*100:0,drawdownPct:Math.max(drawdown,n(peakRow?.peak)>0?Math.max(0,(n(peakRow.peak)-equity)/n(peakRow.peak)*100):0),fees:n(r.fees),slippageCost:n(r.slippageCost),avgLatencyMs:n(sig?.avg),copiedSignals:n(sig?.n),blockedSignals:n(blocked?.n)};
    });
  }
  report():V39AnalyticsReport{this.snapshot();return {summary:this.summary(),equityCurve:this.equityCurve(),traders:this.traders(),generatedAt:Date.now()};}
  reset(){db.exec(`DELETE FROM v39_copy_equity_snapshots`)}
}
