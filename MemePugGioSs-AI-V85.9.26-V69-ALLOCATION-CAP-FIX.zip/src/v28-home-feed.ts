import { V28Signal } from "./v28-types.js";

export interface V28HomeSignal {
  mint:string; state:V28Signal["state"]; action:V28Signal["action"]; score:number; confidence:number; riskScore:number; reasons:string[];
}
export function toV28HomeSignals(signals:V28Signal[]):V28HomeSignal[]{
  return signals.slice(0,20).map(s=>({mint:s.mint,state:s.state,action:s.action,score:s.score,confidence:s.confidence,riskScore:s.riskScore,reasons:s.reasons}));
}
