import WebSocket from "ws";
import {V25AccountKind, V25Snapshot, V25Health} from "./v25-types.js";
import {tokenBalanceFromNotification} from "./v25-token-account.js";

export interface AccountSubscriptionSpec { address: string; kind: V25AccountKind; }
export interface AccountSubscriptionCallbacks {
  onSnapshot(snapshot: V25Snapshot): void | Promise<void>;
  onHealth?(health: V25Health): void;
  onError?(error: Error): void;
}

interface Pending { id: number; spec: AccountSubscriptionSpec; }

export class V25AccountSubscriber {
  private ws: WebSocket | null = null;
  private nextId = 1;
  private readonly pending = new Map<number, Pending>();
  private readonly specs = new Map<string, AccountSubscriptionSpec>();
  private readonly subscriptionToSpec = new Map<number, AccountSubscriptionSpec>();
  private reconnectTimer: ReturnType<typeof setTimeout> | undefined;
  private stopped = false;
  private reconnects = 0;
  private errors = 0;
  private lastNotificationAt: number | undefined;
  private state: V25Health["websocket"] = "DISCONNECTED";

  constructor(
    private readonly endpoint: string,
    private readonly callbacks: AccountSubscriptionCallbacks,
    private readonly options: { commitment?: "processed"|"confirmed"|"finalized"; reconnectBaseMs?: number; reconnectMaxMs?: number } = {},
  ) {}

  subscribe(spec: AccountSubscriptionSpec) {
    this.specs.set(`${spec.kind}:${spec.address}`, spec);
    if (this.ws?.readyState === WebSocket.OPEN) this.sendSubscribe(spec);
  }

  subscribeMany(specs: AccountSubscriptionSpec[]) { for (const spec of specs) this.subscribe(spec); }

  start() {
    this.stopped = false;
    this.connect();
  }

  stop() {
    this.stopped = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = undefined;
    this.subscriptionToSpec.clear();
    this.pending.clear();
    this.ws?.close();
    this.ws = null;
    this.setState("DISCONNECTED");
  }

  health(): V25Health {
    return {
      websocket: this.state,
      subscriptions: this.subscriptionToSpec.size,
      lastNotificationAt: this.lastNotificationAt,
      staleAccounts: 0,
      errors: this.errors,
      reconnects: this.reconnects,
    };
  }

  private setState(state: V25Health["websocket"]) {
    this.state = state;
    this.callbacks.onHealth?.(this.health());
  }

  private connect() {
    if (this.stopped) return;
    this.setState(this.reconnects ? "RECONNECTING" : "CONNECTING");
    const ws = new WebSocket(this.endpoint);
    this.ws = ws;
    ws.on("open", () => {
      this.setState("CONNECTED");
      for (const spec of this.specs.values()) this.sendSubscribe(spec);
    });
    ws.on("message", data => this.onMessage(data.toString()));
    ws.on("error", error => {
      this.errors++;
      this.callbacks.onError?.(error instanceof Error ? error : new Error(String(error)));
    });
    ws.on("close", () => {
      this.subscriptionToSpec.clear();
      this.pending.clear();
      if (this.stopped) return;
      this.scheduleReconnect();
    });
  }

  private scheduleReconnect() {
    if (this.reconnectTimer || this.stopped) return;
    this.reconnects++;
    const base = this.options.reconnectBaseMs ?? 500;
    const max = this.options.reconnectMaxMs ?? 15_000;
    const delay = Math.min(max, base * 2 ** Math.min(this.reconnects - 1, 6));
    this.setState("RECONNECTING");
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      this.connect();
    }, delay);
  }

  private sendSubscribe(spec: AccountSubscriptionSpec) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const id = this.nextId++;
    this.pending.set(id, {id, spec});
    this.ws.send(JSON.stringify({jsonrpc:"2.0", id, method:"accountSubscribe", params:[spec.address, {encoding: spec.kind === "POOL_BASE_VAULT" || spec.kind === "POOL_QUOTE_VAULT" ? "jsonParsed" : "base64", commitment:this.options.commitment ?? "finalized"}]}));
  }

  private async onMessage(raw: string) {
    let message: any;
    try { message = JSON.parse(raw); } catch { return; }
    if (typeof message.id === "number" && message.result !== undefined) {
      const pending = this.pending.get(message.id);
      if (pending && typeof message.result === "number") this.subscriptionToSpec.set(message.result, pending.spec);
      this.pending.delete(message.id);
      return;
    }
    if (message.method !== "accountNotification") return;
    const subscription = Number(message.params?.subscription);
    const spec = this.subscriptionToSpec.get(subscription);
    if (!spec) return;
    const result = message.params?.result;
    const slot = Number(result?.context?.slot ?? 0);
    this.lastNotificationAt = Date.now();
    const data = result?.value?.data;
    const snapshot: V25Snapshot = {
      key: `${spec.kind}:${spec.address}`,
      kind: spec.kind,
      address: spec.address,
      slot,
      observedAt: Date.now(),
      data: (spec.kind === "POOL_BASE_VAULT" || spec.kind === "POOL_QUOTE_VAULT")
        ? tokenBalanceFromNotification(spec.address, message)
        : data,
    };
    await this.callbacks.onSnapshot(snapshot);
    this.callbacks.onHealth?.(this.health());
  }
}
