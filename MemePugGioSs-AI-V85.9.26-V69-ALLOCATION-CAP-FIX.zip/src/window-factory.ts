import crypto from "node:crypto";
import { TokenEvent, WindowSnapshot, ForwardLabel, DatasetQuality } from "./v13-types.js";

export const HORIZONS = {
  "1m":60_000,"5m":300_000,"15m":900_000,
  "1h":3_600_000,"6h":21_600_000,"24h":86_400_000
} as const;

export function dedupeEvents(events:TokenEvent[]){
  const map=new Map<string,TokenEvent>();
  for(const e of events) if(!map.has(e.id)) map.set(e.id,e);
  return [...map.values()].sort((a,b)=>a.ts-b.ts||a.id.localeCompare(b.id));
}

export function buildSnapshot(events:TokenEvent[],startTs:number,endTs:number):WindowSnapshot {
  const xs=events.filter(e=>e.ts>=startTs&&e.ts<=endTs);
  const prices=xs.map(e=>e.price).filter((x):x is number=>Number.isFinite(x));
  const buy=xs.reduce((s,e)=>s+(e.buyVolume??0),0);
  const sell=xs.reduce((s,e)=>s+(e.sellVolume??0),0);
  const liq=xs.filter(e=>Number.isFinite(e.liquidity));
  const holders=xs.filter(e=>Number.isFinite(e.holders));
  const smart=xs.map(e=>e.smartMoneyVolume??0);
  return {
    mint:events[0]?.mint??"",startTs,endTs,durationMs:endTs-startTs,
    open:prices[0],high:prices.length?Math.max(...prices):undefined,
    low:prices.length?Math.min(...prices):undefined,close:prices.at(-1),
    buyVolume:buy,sellVolume:sell,netFlow:buy-sell,
    liquidityStart:liq[0]?.liquidity,liquidityEnd:liq.at(-1)?.liquidity,
    liquidityDelta:liq.length>=2?liq.at(-1)!.liquidity!-liq[0].liquidity!:undefined,
    holdersStart:holders[0]?.holders,holdersEnd:holders.at(-1)?.holders,
    holderDelta:holders.length>=2?holders.at(-1)!.holders!-holders[0].holders!:undefined,
    smartMoneyStart:smart[0]??0,smartMoneyEnd:smart.at(-1)??0,
    smartMoneyDelta:(smart.at(-1)??0)-(smart[0]??0),eventCount:xs.length
  };
}

export function buildForwardLabel(events:TokenEvent[],startTs:number,horizonMs:number):ForwardLabel {
  const base=events.filter(e=>e.ts<=startTs&&Number.isFinite(e.price)).at(-1)?.price;
  const future=events.filter(e=>e.ts>startTs&&e.ts<=startTs+horizonMs&&Number.isFinite(e.price));
  if(base===undefined||!future.length) return {mint:events[0]?.mint??"",startTs,horizonMs,futureEvents:future.length};
  const ps=future.map(e=>e.price!);
  const futureReturnPct=(ps.at(-1)!/base-1)*100;
  const mfePct=(Math.max(...ps)/base-1)*100;
  const maePct=(Math.min(...ps)/base-1)*100;
  return {mint:events[0]?.mint??"",startTs,horizonMs,futureReturnPct,mfePct,maePct,futureEvents:future.length};
}

export function fingerprint(snapshots:WindowSnapshot[],labels:ForwardLabel[]){
  return crypto.createHash("sha256").update(JSON.stringify({snapshots,labels})).digest("hex");
}

export function quality(events:TokenEvent[],snapshots:WindowSnapshot[],labels:ForwardLabel[]):DatasetQuality {
  const unique=new Set(events.map(e=>e.id));
  return {rows:snapshots.length,tokens:new Set(events.map(e=>e.mint)).size,
    duplicateEvents:events.length-unique.size,
    missingPriceWindows:snapshots.filter(x=>x.close===undefined).length,
    missingFutureLabels:labels.filter(x=>x.futureReturnPct===undefined).length};
}
