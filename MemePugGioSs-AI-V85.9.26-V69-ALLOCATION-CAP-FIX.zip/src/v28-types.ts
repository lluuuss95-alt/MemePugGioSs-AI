export type V28SignalState = "WATCH" | "EARLY_ENTRY" | "CONFIRMED" | "INVALIDATED" | "BLOCKED";
export type V28Action = "OBSERVE" | "PAPER_CANDIDATE" | "NO_ACTION";

export interface V28Features {
  buyPressure: number;
  flowMomentum: number;
  liquidityScore: number;
  holderScore: number;
  smartMoneyScore: number;
  riskScore: number;
  freshnessScore: number;
  sampleConfidence: number;
  priceMomentum: number;
  graduationProgress: number;
}

export interface V28Signal {
  mint: string;
  state: V28SignalState;
  action: V28Action;
  score: number;
  confidence: number;
  riskScore: number;
  freshness: number;
  reasons: string[];
  blockers: string[];
  features: V28Features;
  generatedAt: number;
  source: "LIVE_STATE" | "DISCOVERY";
}

export interface V28SignalConfig {
  minScore: number;
  confirmedScore: number;
  maxRiskScore: number;
  minFreshness: number;
  minConfidence: number;
  minLiquidityScore: number;
}

export interface V28SignalEngine {
  evaluate(input: V28EvaluationInput): V28Signal;
}

export interface V28EvaluationInput {
  mint: string;
  features: V28Features;
  source?: V28Signal["source"];
}
