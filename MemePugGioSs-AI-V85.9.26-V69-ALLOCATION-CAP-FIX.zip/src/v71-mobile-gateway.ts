import { db } from './db.js';

export interface V71MobileSnapshot {
  version:'V71';
  ts:number;
  mode:'PAPER';
  liveExecutionEnabled:false;
  system:{state:string; safeToRunPaper:boolean; source:string; updatedAt:number|null};
  engine:any;
  portfolio:any;
  opportunities:any[];
  signals:any[];
  tokens:any[];
  copy:{analytics:any; risk:any; traders:any[]; following:any[]; signals:any[]};
  autonomous:{assistant:any; latestPipeline:any; latestQuality:any; latestCalibration:any; latestRiskCalibration:any};
}

function latest(table:string){
  try { return db.prepare(`SELECT * FROM ${table} ORDER BY ts DESC LIMIT 1`).get() ?? null; }
  catch { return null; }
}
function rows(table:string, limit:number){
  try { return db.prepare(`SELECT * FROM ${table} ORDER BY rowid DESC LIMIT ?`).all(Math.min(limit,200)); }
  catch { return []; }
}

export function buildV71MobileSnapshot(input:any):V71MobileSnapshot {
  const health=latest('v70_health_snapshots') as any;
  const pipeline=latest('v69_pipeline_runs') as any;
  const quality=latest('v66_execution_quality') as any;
  const calibration=latest('v67_execution_calibration') as any;
  const riskCalibration=latest('v68_risk_calibrations') as any;
  return {
    version:'V71', ts:Date.now(), mode:'PAPER', liveExecutionEnabled:false,
    system:{
      state:health?.state ?? 'UNKNOWN',
      safeToRunPaper:Boolean(health?.safe_to_run_paper),
      source:health ? 'V70_HEALTH_SNAPSHOT' : 'NO_V70_SNAPSHOT',
      updatedAt:health?.ts ?? null
    },
    engine:input.engine,
    portfolio:input.portfolio,
    opportunities:input.opportunities ?? [],
    signals:input.signals ?? [],
    tokens:input.tokens ?? [],
    copy:{analytics:input.copyAnalytics,risk:input.copyRisk,traders:input.copyTraders??[],following:input.following??[],signals:input.copySignals??[]},
    autonomous:{assistant:input.assistant,latestPipeline:pipeline,latestQuality:quality,latestCalibration:calibration,latestRiskCalibration:riskCalibration}
  };
}

export const V71_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV71Safe(){
  if(!V71_SAFETY.shadowOnly||V71_SAFETY.signingEnabled||V71_SAFETY.privateKeyAccess||V71_SAFETY.broadcastEnabled||V71_SAFETY.liveExecutionAllowed||V71_SAFETY.autoPromotion) throw new Error('V71_SAFETY_INVARIANT_FAILED');
}
