import crypto from 'node:crypto';
import { db } from './db.js';
import { V30PaperState } from './v30-types.js';
import { V32PersistentLedger } from './v32-ledger.js';
import { V33Checkpoint, V33RecoveredState, V33RecoveryReport } from './v33-types.js';

function hashState(state: V30PaperState): string {
  const canonical = JSON.stringify({
    cash: state.cash, equity: state.equity, realizedPnl: state.realizedPnl,
    unrealizedPnl: state.unrealizedPnl,
    positions: [...state.positions].sort((a,b)=>a.id.localeCompare(b.id)),
    decisions: [...state.decisions].sort((a,b)=>a.timestamp-b.timestamp || a.mint.localeCompare(b.mint))
  });
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

export class V33RecoveryEngine {
  constructor(private readonly ledger = new V32PersistentLedger()) { this.ensureSchema(); }

  private ensureSchema() {
    db.exec(`CREATE TABLE IF NOT EXISTS v33_checkpoints (
      id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL,
      state_hash TEXT NOT NULL, source_version INTEGER NOT NULL, last_event_at INTEGER NOT NULL
    ); CREATE INDEX IF NOT EXISTS idx_v33_checkpoint_time ON v33_checkpoints(created_at);`);
  }

  checkpoint(state: V30PaperState, now=Date.now()): V33Checkpoint {
    const cp = db.prepare(`INSERT INTO v33_checkpoints(created_at,state_hash,source_version,last_event_at) VALUES(?,?,?,?) RETURNING id,created_at as createdAt,state_hash as stateHash,source_version as sourceVersion,last_event_at as lastEventAt`)
      .get(now, hashState(state), 33, state.generatedAt) as V33Checkpoint;
    return cp;
  }

  latestCheckpoint(): V33Checkpoint | null {
    return (db.prepare(`SELECT id,created_at as createdAt,state_hash as stateHash,source_version as sourceVersion,last_event_at as lastEventAt FROM v33_checkpoints ORDER BY id DESC LIMIT 1`).get() as V33Checkpoint | undefined) ?? null;
  }

  recover(now=Date.now()): V33RecoveredState {
    const errors: string[] = [];
    const loaded = this.ledger.load();
    const state = loaded.state;
    const ids = new Set<string>();
    for (const p of state.positions) {
      if (ids.has(p.id)) errors.push(`duplicate-position:${p.id}`);
      ids.add(p.id);
      if (!Number.isFinite(p.currentPrice) || !Number.isFinite(p.quantity)) errors.push(`invalid-position:${p.id}`);
    }
    if (!Number.isFinite(state.cash) || !Number.isFinite(state.equity)) errors.push('invalid-portfolio-numbers');
    const cp = this.latestCheckpoint();
    const actualHash = hashState(state);
    if (cp && cp.stateHash !== actualHash) errors.push('checkpoint-hash-mismatch');
    const report: V33RecoveryReport = {
      status: errors.length ? 'DEGRADED' : 'HEALTHY', checkpointId: cp?.id ?? null,
      replayedEvents: state.positions.length + state.decisions.length,
      restoredPositions: state.positions.length, restoredDecisions: state.decisions.length,
      consistencyErrors: errors, recoveredAt: now
    };
    return { state, checkpoint: cp, report };
  }

  verifyAndCheckpoint(state: V30PaperState, now=Date.now()): V33RecoveredState {
    const cp = this.checkpoint(state, now);
    const recovered = this.recover(now);
    return { ...recovered, checkpoint: cp };
  }
}

export { hashState };
