export interface V25HttpRpc {
  getAccountInfo(address: string, commitment?: string): Promise<any>;
  getTokenAccountBalance(address: string, commitment?: string): Promise<any>;
  getTokenSupply(address: string, commitment?: string): Promise<any>;
  getTransaction(signature: string, commitment?: string): Promise<any>;
}

export class JsonRpcHttpClient implements V25HttpRpc {
  private nextId = 1;
  constructor(private readonly endpoint: string, private readonly fetchImpl: typeof fetch = fetch) {}

  private async call(method: string, params: unknown[]): Promise<any> {
    const response = await this.fetchImpl(this.endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: this.nextId++, method, params }),
    });
    if (!response.ok) throw new Error(`RPC_HTTP_${response.status}`);
    const body = await response.json() as any;
    if (body.error) throw new Error(`RPC_${body.error.code ?? "ERROR"}:${body.error.message ?? "UNKNOWN"}`);
    return body.result;
  }

  getAccountInfo(address: string, commitment = "finalized") {
    return this.call("getAccountInfo", [address, { encoding: "base64", commitment }]);
  }
  getTokenAccountBalance(address: string, commitment = "finalized") {
    return this.call("getTokenAccountBalance", [address, { commitment }]);
  }
  getTokenSupply(address: string, commitment = "finalized") {
    return this.call("getTokenSupply", [address, { commitment }]);
  }
  getTransaction(signature: string, commitment = "confirmed") {
    return this.call("getTransaction", [signature, { commitment, encoding: "json", maxSupportedTransactionVersion: 0 }]);
  }
}
