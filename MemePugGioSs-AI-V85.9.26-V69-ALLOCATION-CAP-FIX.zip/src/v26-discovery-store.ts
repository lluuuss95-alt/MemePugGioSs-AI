import {V26DiscoveryStore, V26TokenDiscovery} from "./v26-types.js";

export class InMemoryV26DiscoveryStore implements V26DiscoveryStore {
  private readonly map = new Map<string,V26TokenDiscovery>();
  has(mint:string){return this.map.has(mint)}
  upsert(token:V26TokenDiscovery){this.map.set(token.mint, token)}
  all(){return [...this.map.values()].sort((a,b)=>b.detectedAt-a.detectedAt)}
}
