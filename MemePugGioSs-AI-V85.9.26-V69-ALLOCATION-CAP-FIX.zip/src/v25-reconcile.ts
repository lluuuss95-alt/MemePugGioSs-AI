import {PumpAccountDecoder, DecodedBondingCurve, DecodedPool} from "./v24-pump-decoder.js";
import {PumpAccountService} from "./v24-account-service.js";
import {bondingMarketCap, pumpSwapEffectiveQuote, pumpSwapMarketCap, progressBps, spotPrice} from "./v23-math.js";
import {BondingCurveState, PumpSwapState} from "./v23-types.js";
import {V25LiveState, V25TokenBalance} from "./v25-types.js";

export interface V25ReconcileConfig { staleAfterMs?: number; maxSlotSkew?: number; }

export function buildBondingCurveLiveState(s: DecodedBondingCurve, cfg: V25ReconcileConfig = {}): V25LiveState {
  const now = Date.now();
  const p = spotPrice(s);
  const stale = now - s.observedAt > (cfg.staleAfterMs ?? 10_000);
  return {
    mint: s.mint,
    venue: "BONDING_CURVE",
    slot: s.slot,
    observedAt: s.observedAt,
    stale,
    coherent: !stale,
    slotSpread: 0,
    priceQuotePerBaseUnit: {numerator: p.numerator, denominator: p.denominator},
    marketCapQuote: bondingMarketCap(s),
    liquidityQuote: s.virtualQuoteReserves,
    graduationProgressBps: progressBps(s),
    complete: s.complete,
    baseReserve: s.virtualTokenReserves,
    quoteReserve: s.virtualQuoteReserves,
    virtualQuoteReserves: s.virtualQuoteReserves,
    effectiveQuoteReserves: s.virtualQuoteReserves,
    supply: s.tokenTotalSupply,
    confidence: stale ? 0 : 1,
  };
}

export interface PumpSwapInputs {
  pool: DecodedPool;
  baseVault: V25TokenBalance;
  quoteVault: V25TokenBalance;
  totalSupply: bigint;
  supplyDecimals: number;
  now?: number;
}

export function buildPumpSwapLiveState(i: PumpSwapInputs, cfg: V25ReconcileConfig = {}): V25LiveState {
  const now = i.now ?? Date.now();
  const maxSkew = cfg.maxSlotSkew ?? 2;
  const slots = [i.pool.slot, i.baseVault.slot, i.quoteVault.slot].filter(x => x > 0);
  const maxSlot = slots.length ? Math.max(...slots) : 0;
  const minSlot = slots.length ? Math.min(...slots) : 0;
  const slotSpread = maxSlot - minSlot;
  const staleAfter = cfg.staleAfterMs ?? 10_000;
  const stale = [i.pool.observedAt, i.baseVault.observedAt, i.quoteVault.observedAt].some(t => now - t > staleAfter);
  const coherent = !stale && slotSpread <= maxSkew;
  const baseReserve = i.baseVault.amount;
  const quoteReserve = i.quoteVault.amount;
  const state: PumpSwapState = {
    mint: i.pool.baseMint,
    baseReserve,
    quoteVaultBalance: quoteReserve,
    virtualQuoteReserves: i.pool.virtualQuoteReserves,
    effectiveQuoteReserves: quoteReserve + i.pool.virtualQuoteReserves,
    slot: maxSlot,
    observedAt: Math.min(i.pool.observedAt, i.baseVault.observedAt, i.quoteVault.observedAt),
  };
  const effective = pumpSwapEffectiveQuote(state);
  return {
    mint: i.pool.baseMint,
    venue: "PUMPSWAP",
    slot: maxSlot,
    observedAt: state.observedAt,
    stale,
    coherent,
    slotSpread,
    priceQuotePerBaseUnit: {numerator: effective, denominator: baseReserve},
    marketCapQuote: pumpSwapMarketCap(state, i.totalSupply),
    liquidityQuote: effective,
    complete: true,
    baseReserve,
    quoteReserve,
    virtualQuoteReserves: i.pool.virtualQuoteReserves,
    effectiveQuoteReserves: effective,
    supply: i.totalSupply,
    supplyDecimals: i.supplyDecimals,
    confidence: coherent ? 1 : stale ? 0 : 0.5,
  };
}

export class V25StateReconciler {
  readonly decoder = new PumpAccountDecoder();
  constructor(private readonly cfg: V25ReconcileConfig = {}) {}

  bondingFromData(data: unknown, mint: string, slot: number) {
    return buildBondingCurveLiveState(this.decoder.decodeBondingCurve(data, mint, slot), this.cfg);
  }
}
