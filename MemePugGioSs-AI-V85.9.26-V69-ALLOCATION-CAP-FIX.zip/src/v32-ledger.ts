import { db } from './db.js';
import { V30PaperState } from './v30-types.js';
import { V32LedgerState, V32PortfolioSummary } from './v32-types.js';

function ensureSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS v32_portfolio (
      id INTEGER PRIMARY KEY CHECK(id=1), starting_capital REAL NOT NULL,
      cash REAL NOT NULL, equity REAL NOT NULL, realized_pnl REAL NOT NULL,
      unrealized_pnl REAL NOT NULL, peak_equity REAL NOT NULL, updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS v32_positions (
      id TEXT PRIMARY KEY, mint TEXT NOT NULL, status TEXT NOT NULL, payload_json TEXT NOT NULL,
      opened_at INTEGER NOT NULL, closed_at INTEGER, updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS v32_decisions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT NOT NULL, decision TEXT NOT NULL,
      reason TEXT NOT NULL, score REAL NOT NULL, confidence REAL NOT NULL, risk_score REAL NOT NULL,
      timestamp INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS v32_snapshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp INTEGER NOT NULL, cash REAL NOT NULL,
      equity REAL NOT NULL, realized_pnl REAL NOT NULL, unrealized_pnl REAL NOT NULL,
      exposure REAL NOT NULL, drawdown_pct REAL NOT NULL, open_positions INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_v32_snapshots_time ON v32_snapshots(timestamp);
    CREATE INDEX IF NOT EXISTS idx_v32_decisions_time ON v32_decisions(timestamp);
  `);
  const snapshotColumns = new Set((db.prepare('PRAGMA table_info(v32_snapshots)').all() as any[]).map(c=>c.name));
  if (!snapshotColumns.has('peak_equity')) db.exec('ALTER TABLE v32_snapshots ADD COLUMN peak_equity REAL NOT NULL DEFAULT 0');
}
ensureSchema();

export class V32PersistentLedger {
  constructor(private readonly startingCapital = 10000) {
    const row = db.prepare('SELECT id FROM v32_portfolio WHERE id=1').get() as any;
    if (!row) db.prepare(`INSERT INTO v32_portfolio(id,starting_capital,cash,equity,realized_pnl,unrealized_pnl,peak_equity,updated_at) VALUES(1,?,?,?,?,?,?,?)`)
      .run(startingCapital, startingCapital, startingCapital, 0, 0, startingCapital, Date.now());
  }

  load(): V32LedgerState {
    const p = db.prepare('SELECT * FROM v32_portfolio WHERE id=1').get() as any;
    const positions = db.prepare('SELECT payload_json FROM v32_positions ORDER BY opened_at').all().map((r:any)=>JSON.parse(r.payload_json));
    const decisions = db.prepare('SELECT mint,decision,reason,score,confidence,risk_score,timestamp FROM v32_decisions ORDER BY id DESC LIMIT 500').all().reverse() as V30PaperState['decisions'];
    const snapshots = db.prepare('SELECT timestamp,cash,equity,unrealized_pnl as unrealizedPnl,realized_pnl as realizedPnl,exposure,drawdown_pct as drawdown,peak_equity as peakEquity,open_positions as openPositions FROM v32_snapshots ORDER BY id DESC LIMIT 500').all().reverse();
    const state: V30PaperState = { cash:p.cash, equity:p.equity, realizedPnl:p.realized_pnl, unrealizedPnl:p.unrealized_pnl, positions, decisions, generatedAt:p.updated_at };
    return { version:32, startingCapital:p.starting_capital, state, summary:this.summary(state,p.starting_capital) };
  }

  persist(state: V30PaperState, now=Date.now()): V32LedgerState {
    const summary = this.summary(state, this.startingCapital);
    const tx = db.transaction(() => {
      db.prepare(`UPDATE v32_portfolio SET cash=?,equity=?,realized_pnl=?,unrealized_pnl=?,peak_equity=?,updated_at=? WHERE id=1`)
        .run(state.cash,state.equity,state.realizedPnl,state.unrealizedPnl,Math.max(this.startingCapital,state.equity),now);
      for (const p of state.positions) db.prepare(`INSERT INTO v32_positions(id,mint,status,payload_json,opened_at,closed_at,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,payload_json=excluded.payload_json,closed_at=excluded.closed_at,updated_at=excluded.updated_at`)
        .run(p.id,p.mint,p.status,JSON.stringify(p),p.openedAt,p.closedAt??null,now);
      const last = state.decisions[state.decisions.length-1];
      if (last) {
        const exists = db.prepare('SELECT id FROM v32_decisions WHERE mint=? AND decision=? AND timestamp=?').get(last.mint,last.decision,last.timestamp);
        if (!exists) db.prepare(`INSERT INTO v32_decisions(mint,decision,reason,score,confidence,risk_score,timestamp) VALUES(?,?,?,?,?,?,?)`).run(last.mint,last.decision,last.reason,last.score,last.confidence,last.riskScore,last.timestamp);
      }
      db.prepare(`INSERT INTO v32_snapshots(timestamp,cash,equity,realized_pnl,unrealized_pnl,exposure,drawdown_pct,peak_equity,open_positions) VALUES(?,?,?,?,?,?,?,?,?)`)
        .run(now,state.cash,state.equity,state.realizedPnl,state.unrealizedPnl,summary.exposure,summary.drawdownPct,summary.peakEquity,summary.openPositions);
    });
    tx();
    return { version:32, startingCapital:this.startingCapital, state:structuredClone(state), summary };
  }

  summary(state: V30PaperState, startingCapital=this.startingCapital): V32PortfolioSummary {
    const open = state.positions.filter(p=>p.status==='OPEN');
    const exposure = open.reduce((s,p)=>s+p.currentPrice*p.quantity,0);
    const peak = Math.max(startingCapital,state.equity);
    return { startingCapital, cash:state.cash, equity:state.equity, realizedPnl:state.realizedPnl, unrealizedPnl:state.unrealizedPnl,
      peakEquity:peak, drawdownPct:peak>0?((peak-state.equity)/peak)*100:0, exposure, openPositions:open.length,
      totalTrades:state.positions.length, lastUpdated:state.generatedAt };
  }

  reset() {
    const tx=db.transaction(()=>{ db.prepare('DELETE FROM v32_positions').run(); db.prepare('DELETE FROM v32_decisions').run(); db.prepare('DELETE FROM v32_snapshots').run(); db.prepare('UPDATE v32_portfolio SET starting_capital=?,cash=?,equity=?,realized_pnl=0,unrealized_pnl=0,peak_equity=?,updated_at=? WHERE id=1').run(this.startingCapital,this.startingCapital,this.startingCapital, this.startingCapital, Date.now()); }); tx();
  }
}
