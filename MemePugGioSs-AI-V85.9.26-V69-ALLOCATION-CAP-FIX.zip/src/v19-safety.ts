export const V19_SAFETY=Object.freeze({mode:"SHADOW",liveTrading:false,signing:false,privateKeys:false,broadcast:false,autoPromotion:false});
export function verifyV19Safety(){if(V19_SAFETY.liveTrading||V19_SAFETY.signing||V19_SAFETY.privateKeys||V19_SAFETY.broadcast||V19_SAFETY.autoPromotion)throw new Error("V19 safety invariant failed");return true}
