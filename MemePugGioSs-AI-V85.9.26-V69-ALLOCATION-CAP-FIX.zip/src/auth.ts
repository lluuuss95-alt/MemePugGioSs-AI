import crypto from "node:crypto"; import jwt from "jsonwebtoken"; import {config} from "./config.js"; import {db} from "./db.js";
function hash(p:string){return crypto.scryptSync(p,config.jwtSecret,32).toString("hex")}
export function ensureAdmin(){const u:any=db.prepare("SELECT id FROM users WHERE username=?").get(config.adminUser); if(!u)db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)").run(config.adminUser,hash(config.adminPassword),"admin");}
export function login(username:string,password:string){const u:any=db.prepare("SELECT * FROM users WHERE username=?").get(username);if(!u||u.password_hash!==hash(password))throw new Error("INVALID_CREDENTIALS");return jwt.sign({sub:u.id,username:u.username,role:u.role},config.jwtSecret,{expiresIn:"8h"});}
export function verify(token:string){return jwt.verify(token,config.jwtSecret) as any}
