import { StrategyParams } from "./v15-types.js";

export function generateGrid(space:Record<keyof StrategyParams,number[]> , maxCandidates=1000):StrategyParams[] {
  const keys=(Object.keys(space) as (keyof StrategyParams)[]);
  const out:StrategyParams[]=[];
  function walk(i:number,current:any){
    if(out.length>=maxCandidates)return;
    if(i===keys.length){out.push({...current});return;}
    for(const v of space[keys[i]]){current[keys[i]]=v;walk(i+1,current);if(out.length>=maxCandidates)break;}
  }
  walk(0,{});
  return out;
}
