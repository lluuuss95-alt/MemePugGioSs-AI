export const V20_SAFETY=Object.freeze({
 mode:"SHADOW",liveTrading:false,signing:false,privateKeys:false,broadcast:false,autoPromotion:false
});
export function assertV20Safety(){
 if(V20_SAFETY.mode!=="SHADOW"||V20_SAFETY.liveTrading||V20_SAFETY.signing||V20_SAFETY.privateKeys||V20_SAFETY.broadcast||V20_SAFETY.autoPromotion)
   throw new Error("V20 safety invariant failed");
 return true;
}
