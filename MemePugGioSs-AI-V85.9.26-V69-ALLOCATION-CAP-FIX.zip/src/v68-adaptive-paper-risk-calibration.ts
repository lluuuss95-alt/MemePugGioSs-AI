import crypto from 'node:crypto';
import { db } from './db.js';

export type V68State='INSUFFICIENT_DATA'|'STABLE'|'CAUTIOUS'|'DEGRADED';
export interface V68Config {
  minSamples:number; windowSamples:number;
  minMultiplier:number; maxMultiplier:number; maxStep:number;
  warningBlockRate:number; criticalBlockRate:number;
  warningDeviationBps:number; warningLatencyMs:number;
}
export interface V68Input {
  mint?:string; now?:number;
  baselineRiskPct:number; baselinePositionPct:number; baselineTotalExposurePct:number;
}
export interface V68Profile {
  id:string; ts:number; scope:string; state:V68State; samples:number;
  riskMultiplier:number; calibratedRiskPct:number; calibratedPositionPct:number; calibratedTotalExposurePct:number;
  confidence:number; reasons:string[];
  safety:{liveExecutionEnabled:false};
}

export const defaultV68Config:V68Config=Object.freeze({
  minSamples:20, windowSamples:200, minMultiplier:0.50, maxMultiplier:1.00, maxStep:0.10,
  warningBlockRate:0.15, criticalBlockRate:0.30, warningDeviationBps:150, warningLatencyMs:1500,
});
const finite=(v:unknown)=>Number.isFinite(Number(v))?Number(v):NaN;
const clamp=(x:number,a:number,b:number)=>Math.max(a,Math.min(b,x));

export class V68AdaptivePaperRiskCalibration {
  constructor(private readonly cfg:V68Config=defaultV68Config){this.ensureSchema();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v68_risk_calibrations(
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, scope TEXT NOT NULL, state TEXT NOT NULL, samples INTEGER NOT NULL,
    risk_multiplier REAL NOT NULL, calibrated_risk_pct REAL NOT NULL, calibrated_position_pct REAL NOT NULL,
    calibrated_total_exposure_pct REAL NOT NULL, confidence REAL NOT NULL, reasons_json TEXT NOT NULL, details_json TEXT NOT NULL
  )`);}

  calibrate(input:V68Input):V68Profile{
    const now=input.now??Date.now(), scope=input.mint??'GLOBAL';
    const rows=(input.mint
      ? db.prepare(`SELECT * FROM v66_execution_quality WHERE mint=? ORDER BY ts DESC LIMIT ?`).all(input.mint,this.cfg.windowSamples)
      : db.prepare(`SELECT * FROM v66_execution_quality ORDER BY ts DESC LIMIT ?`).all(this.cfg.windowSamples)) as any[];
    const samples=rows.length, reasons:string[]=[];
    const blocked=samples?rows.filter(r=>r.quality==='BLOCKED').length/samples:0;
    const warning=samples?rows.filter(r=>r.quality==='WARNING').length/samples:0;
    const deviations=rows.map(r=>finite(r.paper_deviation_bps)).filter(Number.isFinite);
    const latencies=rows.map(r=>finite(r.paper_latency_ms)).filter(Number.isFinite);
    if(samples<this.cfg.minSamples){
      reasons.push('INSUFFICIENT_SAMPLES');
      return this.persist({id:crypto.randomUUID(),ts:now,scope,state:'INSUFFICIENT_DATA',samples,riskMultiplier:1,calibratedRiskPct:input.baselineRiskPct,calibratedPositionPct:input.baselinePositionPct,calibratedTotalExposurePct:input.baselineTotalExposurePct,confidence:clamp(samples/this.cfg.minSamples,0,1)*0.5,reasons,safety:{liveExecutionEnabled:false}});
    }
    const avgDev=deviations.length?deviations.reduce((a,b)=>a+b,0)/deviations.length:0;
    const avgLat=latencies.length?latencies.reduce((a,b)=>a+b,0)/latencies.length:0;
    let pressure=0;
    if(blocked>=this.cfg.criticalBlockRate) pressure+=0.55;
    else if(blocked>=this.cfg.warningBlockRate) pressure+=0.30;
    if(warning>=0.30) pressure+=0.15;
    if(avgDev>this.cfg.warningDeviationBps) pressure+=0.15;
    if(avgLat>this.cfg.warningLatencyMs) pressure+=0.10;
    pressure=clamp(pressure,0,0.90);
    const multiplier=clamp(1-Math.min(this.cfg.maxStep,pressure),this.cfg.minMultiplier,this.cfg.maxMultiplier);
    if(multiplier<0.999) reasons.push('PAPER_EXECUTION_QUALITY_REQUIRES_CAUTION');
    if(blocked>=this.cfg.criticalBlockRate) reasons.push('HIGH_BLOCK_RATE');
    if(avgDev>this.cfg.warningDeviationBps) reasons.push('HIGH_EXECUTION_DEVIATION');
    if(avgLat>this.cfg.warningLatencyMs) reasons.push('HIGH_LATENCY');
    if(!reasons.length) reasons.push('RISK_PROFILE_STABLE');
    const confidence=clamp(Math.min(1,samples/100)*(1-Math.min(0.8,blocked)),0,1);
    const state:V68State=blocked>=this.cfg.criticalBlockRate||confidence<0.4?'DEGRADED':multiplier<1?'CAUTIOUS':'STABLE';
    return this.persist({id:crypto.randomUUID(),ts:now,scope,state,samples,riskMultiplier:multiplier,calibratedRiskPct:input.baselineRiskPct*multiplier,calibratedPositionPct:input.baselinePositionPct*multiplier,calibratedTotalExposurePct:input.baselineTotalExposurePct*multiplier,confidence,reasons,safety:{liveExecutionEnabled:false}});
  }
  private persist(p:V68Profile){db.prepare(`INSERT INTO v68_risk_calibrations VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(p.id,p.ts,p.scope,p.state,p.samples,p.riskMultiplier,p.calibratedRiskPct,p.calibratedPositionPct,p.calibratedTotalExposurePct,p.confidence,JSON.stringify(p.reasons),JSON.stringify(p));return p;}
  latest(scope?:string){return scope?db.prepare(`SELECT * FROM v68_risk_calibrations WHERE scope=? ORDER BY ts DESC LIMIT 1`).get(scope):db.prepare(`SELECT * FROM v68_risk_calibrations ORDER BY ts DESC LIMIT 1`).get();}
}
export const V68_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV68Safe(){if(!V68_SAFETY.shadowOnly||V68_SAFETY.signingEnabled||V68_SAFETY.privateKeyAccess||V68_SAFETY.broadcastEnabled||V68_SAFETY.liveExecutionAllowed||V68_SAFETY.autoPromotion)throw new Error('V68_SAFETY_INVARIANT_FAILED');}
