import { V28Signal } from "./v28-types.js";

export type V29RankBand = "TOP_SIGNAL" | "WATCHLIST" | "BLOCKED" | "EXCLUDED";

export interface V29RankedSignal {
  rank: number;
  mint: string;
  state: V28Signal["state"];
  band: V29RankBand;
  compositeScore: number;
  signalScore: number;
  confidence: number;
  riskScore: number;
  freshness: number;
  liquidityScore: number;
  smartMoneyScore: number;
  reasons: string[];
  blockers: string[];
  generatedAt: number;
}

export interface V29RankingConfig {
  maxResults: number;
  minTopScore: number;
  minConfidence: number;
  maxRiskScore: number;
  minLiquidityScore: number;
  freshnessHalfLifeMs: number;
  diversityPenalty: number;
}

export interface V29RankingResult {
  ranked: V29RankedSignal[];
  topSignals: V29RankedSignal[];
  watchlist: V29RankedSignal[];
  blocked: V29RankedSignal[];
  excluded: V29RankedSignal[];
  generatedAt: number;
}
