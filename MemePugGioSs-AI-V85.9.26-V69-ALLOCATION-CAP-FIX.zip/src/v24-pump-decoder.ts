import crypto from "node:crypto";
import {Cursor} from "./v24-borsh.js";
import {base58} from "./v24-base58.js";
import {BondingCurveState,PumpSwapState} from "./v23-types.js";

const PUMP_PROGRAM="6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P";
const PUMPSWAP_PROGRAM="pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA";

function disc(name:string){return crypto.createHash("sha256").update(name).digest().subarray(0,8)}
const BC_DISC=disc("account:BondingCurve");
const POOL_DISC=disc("account:Pool");

function bytesToBase64(x:unknown):Uint8Array{
 if(x instanceof Uint8Array)return x;
 if(typeof x==="string")return Uint8Array.from(Buffer.from(x,"base64"));
 if(Array.isArray(x)&&typeof x[0]==="string")return Uint8Array.from(Buffer.from(x[0],"base64"));
 if(Array.isArray(x))return Uint8Array.from(x);
 throw new Error("UNSUPPORTED_ACCOUNT_DATA");
}

export interface DecodedBondingCurve extends BondingCurveState{
 creator?:string;isMayhemMode?:boolean;isCashbackCoin?:boolean;quoteMint?:string;creatorFeeBps?:bigint;isHolderReward?:boolean;
}
export interface DecodedPool extends PumpSwapState{
 poolBump:number;index:number;creator:string;baseMint:string;quoteMint:string;lpMint:string;
 poolBaseTokenAccount:string;poolQuoteTokenAccount:string;lpSupply:bigint;coinCreator:string;
 isMayhemMode:boolean;isCashbackCoin:boolean;creatorFeeBps:bigint;isHolderReward:boolean;
}

export class PumpAccountDecoder{
 decodeBondingCurve(data:unknown,mint:string,slot:number):DecodedBondingCurve{
  const b=bytesToBase64(data),c=new Cursor(b);for(const x of BC_DISC)if(c.u8()!==x)throw new Error("INVALID_BONDING_CURVE_DISCRIMINATOR");
  const s:any={mint,virtualTokenReserves:c.u64(),virtualQuoteReserves:c.u64(),realTokenReserves:c.u64(),realQuoteReserves:c.u64(),tokenTotalSupply:c.u64(),complete:c.bool(),slot,observedAt:Date.now()};
  if(c.remaining()>=32)s.creator=base58(c.pubkey());
  if(c.remaining()>=1)s.isMayhemMode=c.bool();
  if(c.remaining()>=1)s.isCashbackCoin=c.bool();
  if(c.remaining()>=32)s.quoteMint=base58(c.pubkey());
  if(c.remaining()>=8)s.creatorFeeBps=c.u64();
  if(c.remaining()>=1)c.bool(); // reserved can_edit_creator_fee
  if(c.remaining()>=1)s.isHolderReward=c.bool();
  return s;
 }
 decodePool(data:unknown,slot:number):DecodedPool{
  const b=bytesToBase64(data),c=new Cursor(b);for(const x of POOL_DISC)if(c.u8()!==x)throw new Error("INVALID_POOL_DISCRIMINATOR");
  const r:any={poolBump:c.u8(),index:c.u16(),creator:base58(c.pubkey()),baseMint:base58(c.pubkey()),quoteMint:base58(c.pubkey()),lpMint:base58(c.pubkey()),poolBaseTokenAccount:base58(c.pubkey()),poolQuoteTokenAccount:base58(c.pubkey()),lpSupply:c.u64(),coinCreator:base58(c.pubkey()),isMayhemMode:c.bool(),isCashbackCoin:c.bool(),virtualQuoteReserves:c.i128(),slot,observedAt:Date.now()};
  r.creatorFeeBps=c.remaining()>=8?c.u64():0n;
  if(c.remaining()>=1)c.bool();
  r.isHolderReward=c.remaining()>=1?c.bool():false;
  return r;
 }
}
export const VERIFIED_PROGRAMS={pump:PUMP_PROGRAM,pumpSwap:PUMPSWAP_PROGRAM};