import crypto from 'node:crypto';
import { db } from './db.js';
import { V77PaperExecutionCommitLayer } from './v77-paper-execution-commit-layer.js';
import type { V53Result, V53Tick } from './v53-trade-supervisor.js';

export type V78Status='EXIT_COMMITTED'|'ALREADY_COMMITTED'|'NO_ACTIVE_POSITION'|'BLOCKED'|'INVALID';
export interface V78Result { id:string; ts:number; mint:string; positionId?:string; status:V78Status; action:V53Result['action']|'NO_ACTION'; reason:string; exitReason?:string; realizedPnl:number; supervisorState?:V53Result['supervisorState']; exitCommitKey:string; liveExecutionEnabled:false; }
export interface V78Input { tick:V53Tick; now?:number; idempotencyKey?:string; signalInvalidated?:boolean; risk?:number; }

export const V78_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV78Safe(){if(!V78_SAFETY.shadowOnly||V78_SAFETY.signingEnabled||V78_SAFETY.privateKeyAccess||V78_SAFETY.broadcastEnabled||V78_SAFETY.liveExecutionAllowed||V78_SAFETY.autoPromotion)throw new Error('V78_SAFETY_INVARIANT_FAILED');}

export class V78PaperPositionLifecycle {
  constructor(private readonly v77=new V77PaperExecutionCommitLayer()){this.ensureSchema();assertV78Safe();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v78_exit_commits(
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, mint TEXT NOT NULL, position_id TEXT NOT NULL,
    exit_commit_key TEXT NOT NULL UNIQUE, action TEXT NOT NULL, status TEXT NOT NULL,
    reason TEXT NOT NULL, exit_reason TEXT, realized_pnl REAL NOT NULL, supervisor_state TEXT,
    details_json TEXT NOT NULL
  ); CREATE INDEX IF NOT EXISTS idx_v78_exit_ts ON v78_exit_commits(ts); CREATE INDEX IF NOT EXISTS idx_v78_exit_mint ON v78_exit_commits(mint); CREATE INDEX IF NOT EXISTS idx_v78_exit_position ON v78_exit_commits(position_id);`);}

  monitor(input:V78Input):V78Result{
    const now=input.now??Date.now(); const tick=input.tick; const key=input.idempotencyKey??`EXIT:${tick.mint}:${tick.timestamp}`;
    const existing=db.prepare(`SELECT * FROM v78_exit_commits WHERE exit_commit_key=?`).get(key) as any;
    if(existing)return {id:existing.id,ts:existing.ts,mint:existing.mint,positionId:existing.position_id,status:'ALREADY_COMMITTED',action:'EXIT_PAPER',reason:'IDEMPOTENT_EXIT_REPLAY_IGNORED',exitReason:existing.exit_reason??undefined,realizedPnl:Number(existing.realized_pnl||0),supervisorState:existing.supervisor_state??undefined,exitCommitKey:key,liveExecutionEnabled:false};

    if(!tick.mint||!Number.isFinite(tick.price)||tick.price<=0||!Number.isFinite(tick.liquidity)||tick.liquidity<0||!Number.isFinite(tick.timestamp)||tick.timestamp<=0||now<tick.timestamp){
      return this.persist({id:crypto.randomUUID(),ts:now,mint:tick.mint||'UNKNOWN',status:'INVALID',action:'BLOCKED',reason:'INVALID_MARKET_TICK',realizedPnl:0,exitCommitKey:key,liveExecutionEnabled:false},undefined);
    }
    const state=this.v77.health().paper;
    const position=state.openPositions.find(p=>p.mint===tick.mint);
    if(!position){
      const prior=db.prepare(`SELECT * FROM v78_exit_commits WHERE mint=? ORDER BY ts DESC LIMIT 1`).get(tick.mint) as any;
      if(prior && now-prior.ts<5*60_000){
        return {id:prior.id,ts:prior.ts,mint:tick.mint,positionId:prior.position_id,status:'ALREADY_COMMITTED',action:'EXIT_PAPER',reason:'POSITION_ALREADY_CLOSED',exitReason:prior.exit_reason??undefined,realizedPnl:Number(prior.realized_pnl||0),supervisorState:prior.supervisor_state??undefined,exitCommitKey:key,liveExecutionEnabled:false};
      }
      return {id:crypto.randomUUID(),ts:now,mint:tick.mint,status:'NO_ACTIVE_POSITION',action:'NO_ACTION',reason:'NO_ACTIVE_PAPER_POSITION',realizedPnl:0,exitCommitKey:key,liveExecutionEnabled:false};
    }

    const result=this.v77.monitor({...tick,signalInvalidated:input.signalInvalidated??tick.signalInvalidated,risk:input.risk??tick.risk},now);
    if(result.action==='EXIT_PAPER'){
      return this.persist({id:crypto.randomUUID(),ts:now,mint:tick.mint,positionId:position.id,status:'EXIT_COMMITTED',action:'EXIT_PAPER',reason:'PAPER_EXIT_COMMITTED',exitReason:result.reason,realizedPnl:result.realizedPnl,supervisorState:result.supervisorState,exitCommitKey:key,liveExecutionEnabled:false},position.id);
    }
    return {id:crypto.randomUUID(),ts:now,mint:tick.mint,positionId:position.id,status:'NO_ACTIVE_POSITION',action:result.action,reason:result.reason,realizedPnl:result.realizedPnl,supervisorState:result.supervisorState,exitCommitKey:key,liveExecutionEnabled:false};
  }

  reconcile(mint?:string){
    const paper=this.v77.health().paper;
    const rows=db.prepare(`SELECT * FROM v78_exit_commits ${mint?'WHERE mint=?':''} ORDER BY ts DESC LIMIT 500`).all(...(mint?[mint]:[])) as any[];
    return {openPositions:mint?paper.openPositions.filter(p=>p.mint===mint):paper.openPositions,exitCommits:rows,liveExecutionEnabled:false};
  }
  recent(limit=100,mint?:string){const n=Math.min(500,Math.max(1,limit));return db.prepare(`SELECT * FROM v78_exit_commits ${mint?'WHERE mint=?':''} ORDER BY ts DESC LIMIT ?`).all(...(mint?[mint,n]:[n]));}
  health(){const r=db.prepare(`SELECT COUNT(*) c, SUM(CASE WHEN status='EXIT_COMMITTED' THEN 1 ELSE 0 END) committed FROM v78_exit_commits`).get() as any;return {exitCommits:Number(r?.c||0),committed:Number(r?.committed||0),paper:this.v77.health().paper,supervisor:this.v77.health().state,liveExecutionEnabled:false};}

  private persist(r:V78Result,positionId?:string){
    if(r.status==='NO_ACTIVE_POSITION'||r.status==='INVALID')return r;
    db.prepare(`INSERT INTO v78_exit_commits(id,ts,mint,position_id,exit_commit_key,action,status,reason,exit_reason,realized_pnl,supervisor_state,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(r.id,r.ts,r.mint,positionId??'UNKNOWN',r.exitCommitKey,r.action,r.status,r.reason,r.exitReason??null,r.realizedPnl,r.supervisorState??null,JSON.stringify({liveExecutionEnabled:false}));
    return r;
  }
}
