import {config} from './config.js';
export function assertV41Safety(){
  if(config.mode!=='PAPER' && config.mode!=='SHADOW') throw new Error('V41 requires PAPER or SHADOW mode');
  if((config as any).liveTrading===true) throw new Error('V41 live trading is disabled');
  return true;
}
