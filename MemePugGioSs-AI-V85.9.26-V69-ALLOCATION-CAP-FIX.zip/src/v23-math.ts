import {BondingCurveState,CurveQuote,MarketState,PumpSwapState} from "./v23-types.js";

function assertPos(x:bigint,name:string){if(x<=0n)throw new Error(`${name}_MUST_BE_POSITIVE`)}
export function bondingInvariant(s:BondingCurveState){return s.virtualTokenReserves*s.virtualQuoteReserves}

export function spotPrice(s:BondingCurveState){
 assertPos(s.virtualTokenReserves,"virtualTokenReserves");
 return {numerator:s.virtualQuoteReserves,denominator:s.virtualTokenReserves};
}

export function bondingMarketCap(s:BondingCurveState){
 assertPos(s.virtualTokenReserves,"virtualTokenReserves");
 return (s.virtualQuoteReserves*s.tokenTotalSupply)/s.virtualTokenReserves;
}

/*
 Exact integer constant-product quote for the reserve transition.
 Fees are intentionally NOT guessed here: the caller supplies the net quote
 entering the curve. This keeps fee policy separate from curve mathematics.
*/
export function buyFromQuote(s:BondingCurveState,netQuoteIn:bigint):CurveQuote{
 assertPos(netQuoteIn,"netQuoteIn");assertPos(s.virtualTokenReserves,"virtualTokenReserves");
 const k=bondingInvariant(s);
 const newQuote=s.virtualQuoteReserves+netQuoteIn;
 const newTokens=k/newQuote;
 const out=s.virtualTokenReserves-newTokens;
 if(out<=0n)return {side:"BUY",inputQuote:netQuoteIn,outputTokens:0n,priceNumerator:0n,priceDenominator:1n,priceImpactBps:0n,invariant:k,valid:false,reason:"ZERO_OUTPUT"};
 if(out>s.realTokenReserves)return {side:"BUY",inputQuote:netQuoteIn,outputTokens:0n,priceNumerator:0n,priceDenominator:1n,priceImpactBps:0n,invariant:k,valid:false,reason:"REAL_RESERVE_LIMIT"};
 return {side:"BUY",inputQuote:netQuoteIn,outputTokens:out,priceNumerator:netQuoteIn,priceDenominator:out,priceImpactBps:0n,invariant:k,valid:true,reason:"OK"};
}

export function sellForTokens(s:BondingCurveState,tokensIn:bigint):CurveQuote{
 assertPos(tokensIn,"tokensIn");assertPos(s.virtualTokenReserves,"virtualTokenReserves");
 if(tokensIn>s.virtualTokenReserves-s.virtualTokenReserves%1n)return {side:"SELL",inputQuote:tokensIn,outputTokens:0n,priceNumerator:0n,priceDenominator:1n,priceImpactBps:0n,invariant:bondingInvariant(s),valid:false,reason:"TOKEN_RESERVE_LIMIT"};
 const k=bondingInvariant(s);const newTokens=s.virtualTokenReserves+tokensIn;
 const newQuote=k/newTokens;const out=s.virtualQuoteReserves-newQuote;
 if(out<=0n)return {side:"SELL",inputQuote:tokensIn,outputTokens:0n,priceNumerator:0n,priceDenominator:1n,priceImpactBps:0n,invariant:k,valid:false,reason:"ZERO_QUOTE_OUTPUT"};
 return {side:"SELL",inputQuote:tokensIn,outputTokens:out,priceNumerator:out,priceDenominator:tokensIn,priceImpactBps:0n,invariant:k,valid:true,reason:"OK"};
}

export function pumpSwapEffectiveQuote(s:PumpSwapState){
 const effective=s.quoteVaultBalance+s.virtualQuoteReserves;
 if(effective<0n)throw new Error("EFFECTIVE_QUOTE_RESERVES_NEGATIVE");
 return effective;
}

export function pumpSwapMarketCap(s:PumpSwapState,totalSupply:bigint){
 assertPos(s.baseReserve,"baseReserve");return (pumpSwapEffectiveQuote(s)*totalSupply)/s.baseReserve;
}

export function progressBps(s:BondingCurveState){
 if(s.realTokenReserves<=0n)return 10000n;
 const sold=s.tokenTotalSupply-s.realTokenReserves;
 if(s.tokenTotalSupply<=0n)return 0n;
 const p=(sold*10000n)/s.tokenTotalSupply;return p>10000n?10000n:p;
}
