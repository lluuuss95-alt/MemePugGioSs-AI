import {db} from './db.js';
import {V37CopyPaperPortfolio} from './v37-copy-paper.js';
import {V38Config,V38CopyRiskInput,V38RiskDecision,V38RiskSnapshot,V38RiskState} from './v38-types.js';

export const defaultV38Config:V38Config={
  maxTotalExposurePct:35,
  maxTokenExposurePct:10,
  maxTraderExposurePct:12,
  maxDailyLossPct:5,
  maxDrawdownPct:15,
  warningDrawdownPct:10,
  maxConcurrentTraders:8,
  maxSharedTokenTraders:3,
  circuitBreakerLossPct:7.5,
  minAccountEquity:1
};

const num=(v:unknown,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const clamp=(v:number,min=0,max=100)=>Math.max(min,Math.min(max,v));

export class V38CopyRiskManager{
  constructor(private portfolio:V37CopyPaperPortfolio,private cfg:V38Config=defaultV38Config){this.ensureSchema()}
  private ensureSchema(){db.exec(`
    CREATE TABLE IF NOT EXISTS v38_risk_events(
      id INTEGER PRIMARY KEY AUTOINCREMENT,decision TEXT NOT NULL,state TEXT NOT NULL,wallet TEXT NOT NULL,mint TEXT NOT NULL,
      quote_amount REAL NOT NULL,reasons_json TEXT NOT NULL,created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_v38_risk_time ON v38_risk_events(created_at DESC);
    CREATE TABLE IF NOT EXISTS v38_risk_config(key TEXT PRIMARY KEY,value REAL NOT NULL);
  `)}

  private rows(){return this.portfolio.accounts(1000)}
  private positions(){return db.prepare(`SELECT wallet,mint,quantity,avg_entry FROM v37_copy_positions WHERE quantity>0`).all() as Array<{wallet:string,mint:string,quantity:number,avg_entry:number}>}

  snapshot(now=Date.now()):V38RiskSnapshot{
    const accounts=this.rows(),positions=this.positions();
    const totalAllocated=accounts.reduce((s,a)=>s+a.allocatedCash,0);
    const totalEquity=accounts.reduce((s,a)=>s+a.equity,0);
    const totalExposure=positions.reduce((s,p)=>s+p.quantity*p.avg_entry,0);
    const totalExposurePct=totalAllocated>0?totalExposure/totalAllocated*100:0;
    const dayStart=now-24*60*60*1000;
    const dayRows=db.prepare(`SELECT COALESCE(SUM(pnl),0) pnl,COALESCE(SUM(fee),0) fees FROM v37_copy_trades WHERE executed_at>=? AND state='EXECUTED'`).get(dayStart) as any;
    const dailyPnl=num(dayRows?.pnl)-num(dayRows?.fees);
    const dailyLossPct=totalAllocated>0?Math.max(0,-dailyPnl)/totalAllocated*100:0;
    const drawdownPct=totalAllocated>0?Math.max(0,(totalAllocated-totalEquity)/totalAllocated*100):0;
    const activeTraders=new Set(positions.map(p=>p.wallet)).size;
    const activePositions=positions.length;
    const byToken=new Map<string,number>();
    const byTrader=new Map<string,number>();
    for(const p of positions){const value=p.quantity*p.avg_entry;byToken.set(p.mint,(byToken.get(p.mint)||0)+value);byTrader.set(p.wallet,(byTrader.get(p.wallet)||0)+value)}
    let maxTokenExposurePct=0,maxTraderExposurePct=0;
    for(const v of byToken.values())maxTokenExposurePct=Math.max(maxTokenExposurePct,totalAllocated>0?v/totalAllocated*100:0);
    for(const v of byTrader.values())maxTraderExposurePct=Math.max(maxTraderExposurePct,totalAllocated>0?v/totalAllocated*100:0);
    const state:V38RiskState=dailyLossPct>=this.cfg.circuitBreakerLossPct||drawdownPct>=this.cfg.maxDrawdownPct?'HALTED':drawdownPct>=this.cfg.warningDrawdownPct||dailyLossPct>=this.cfg.maxDailyLossPct?'WARNING':'NORMAL';
    return {state,totalAllocated,totalEquity,totalExposure,totalExposurePct,dailyPnl,dailyLossPct,drawdownPct,activeTraders,activePositions,maxTokenExposurePct,maxTraderExposurePct,evaluatedAt:now};
  }

  preflight(input:V38CopyRiskInput):V38RiskDecision{
    const now=input.now??Date.now(),snapshot=this.snapshot(now),reasons:string[]=[];
    const accounts=this.rows();
    const account=accounts.find(a=>a.wallet===input.wallet);
    const positions=this.positions();
    const tokenExposure=positions.filter(p=>p.mint===input.mint).reduce((s,p)=>s+p.quantity*p.avg_entry,0);
    const traderExposure=positions.filter(p=>p.wallet===input.wallet).reduce((s,p)=>s+p.quantity*p.avg_entry,0);
    const requested=Math.max(0,num(input.quoteAmount));
    const tokenAfter=tokenExposure+(input.side==='BUY'?requested:0);
    const traderAfter=traderExposure+(input.side==='BUY'?requested:0);
    const tokenExposureBefore=snapshot.totalAllocated>0?tokenExposure/snapshot.totalAllocated*100:0;
    const tokenExposureAfter=snapshot.totalAllocated>0?tokenAfter/snapshot.totalAllocated*100:0;
    const traderExposureBefore=snapshot.totalAllocated>0?traderExposure/snapshot.totalAllocated*100:0;
    const traderExposureAfter=snapshot.totalAllocated>0?traderAfter/snapshot.totalAllocated*100:0;
    const projectedTotalExposurePct=snapshot.totalAllocated>0?(snapshot.totalExposure+(input.side==='BUY'?requested:0))/snapshot.totalAllocated*100:0;
    const sharedTokenTraders=new Set(positions.filter(p=>p.mint===input.mint).map(p=>p.wallet));
    if(snapshot.state==='HALTED')reasons.push('CIRCUIT_BREAKER_HALTED');
    if(snapshot.totalEquity<this.cfg.minAccountEquity)reasons.push('EQUITY_BELOW_MINIMUM');
    if(snapshot.dailyLossPct>=this.cfg.maxDailyLossPct)reasons.push('DAILY_LOSS_LIMIT');
    if(projectedTotalExposurePct>this.cfg.maxTotalExposurePct&&input.side==='BUY')reasons.push('TOTAL_EXPOSURE_LIMIT');
    if(tokenExposureAfter>this.cfg.maxTokenExposurePct&&input.side==='BUY')reasons.push('TOKEN_CONCENTRATION_LIMIT');
    if(traderExposureAfter>this.cfg.maxTraderExposurePct&&input.side==='BUY')reasons.push('TRADER_EXPOSURE_LIMIT');
    if(snapshot.activeTraders>=this.cfg.maxConcurrentTraders&&!sharedTokenTraders.has(input.wallet)&&input.side==='BUY')reasons.push('CONCURRENT_TRADER_LIMIT');
    if(sharedTokenTraders.size>=this.cfg.maxSharedTokenTraders&&!sharedTokenTraders.has(input.wallet)&&input.side==='BUY')reasons.push('SHARED_TOKEN_TRADER_LIMIT');
    if(account&&account.equity<=0)reasons.push('TRADER_ACCOUNT_DEPLETED');
    const decision:V38RiskDecision={decision:reasons.length?'BLOCK':'ALLOW',state:snapshot.state,reasons,snapshot,requestedQuote:requested,tokenExposureBefore,tokenExposureAfter,traderExposureBefore,traderExposureAfter,concentrationPct:Math.max(tokenExposureAfter,traderExposureAfter),checkedAt:now};
    db.prepare(`INSERT INTO v38_risk_events(decision,state,wallet,mint,quote_amount,reasons_json,created_at) VALUES(?,?,?,?,?,?,?)`).run(decision.decision,decision.state,input.wallet,input.mint,requested,JSON.stringify(reasons),now);
    return decision;
  }

  events(limit=100){return db.prepare(`SELECT id,decision,state,wallet,mint,quote_amount quoteAmount,reasons_json reasons,created_at createdAt FROM v38_risk_events ORDER BY created_at DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit))).map((r:any)=>({...r,reasons:JSON.parse(r.reasons||'[]')}))}
}
