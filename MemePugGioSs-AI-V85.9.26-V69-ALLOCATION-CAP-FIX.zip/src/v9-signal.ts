import { V9Features } from "./v9-features.js";

export type SignalState="WATCH"|"EARLY_ENTRY_CANDIDATE"|"CONFIRMED"|"INVALIDATED"|"BLOCKED";

export interface V9Signal {
  state:SignalState;
  score:number;
  confidence:number;
  reasons:string[];
}

export function generateV9Signal(f:V9Features, maxAgeMs=30000):V9Signal {
  const reasons:string[]=[]; let score=0;
  if(f.sampleSize<5){return {state:"WATCH",score:0,confidence:0.1,reasons:["insufficient time-window sample"]};}
  if(f.freshnessMs>maxAgeMs){return {state:"BLOCKED",score:0,confidence:0.2,reasons:["stale market data"]};}
  if(f.risk>=60){return {state:"BLOCKED",score:0,confidence:0.8,reasons:["risk gate blocked"]};}
  if(f.buySellRatio>=1.5){score+=30;reasons.push("buy flow dominates sell flow");}
  if(f.flowMomentum>0){score+=20;reasons.push("positive flow momentum");}
  if(f.smartMoneyShare>=0.25){score+=25;reasons.push("meaningful smart-money participation");}
  if(f.liquidityDelta>0){score+=10;reasons.push("liquidity increasing");}
  if(f.holderDelta>0){score+=10;reasons.push("holder count increasing");}
  score=Math.min(100,score);
  const confidence=Math.min(1,0.2+f.sampleSize/20);
  const state=score>=75?"CONFIRMED":score>=50?"EARLY_ENTRY_CANDIDATE":"WATCH";
  return {state,score,confidence,reasons};
}
