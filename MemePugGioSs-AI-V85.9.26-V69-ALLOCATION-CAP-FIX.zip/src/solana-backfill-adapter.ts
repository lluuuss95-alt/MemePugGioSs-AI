import { BackfillConfig, BackfillCheckpoint, SignatureRecord, BackfillStats } from "./backfill-types.js";
import { RateLimiter } from "./rate-limit.js";
import { withRetry } from "./retry.js";
import crypto from "node:crypto";

export interface SolanaBackfillClient {
  getSignaturesForAddress(address:string, opts:{limit:number;before?:string;until?:string;commitment:"finalized"|"confirmed"}):Promise<SignatureRecord[]>;
  getTransaction(signature:string):Promise<any|null>;
}

export interface BackfillResult {
  transactions:any[];
  signatures:SignatureRecord[];
  checkpoint:BackfillCheckpoint;
  stats:BackfillStats;
}

export async function backfillAddress(client:SolanaBackfillClient,address:string,cfg:BackfillConfig,checkpoint?:BackfillCheckpoint):Promise<BackfillResult>{
  let before=checkpoint?.before, pages=0, sigs:SignatureRecord[]=[];
  const startedAt=Date.now(), limiter=new RateLimiter(cfg.minDelayMs);
  let retries=0;
  while(pages<cfg.maxPages){
    await limiter.wait();
    const page=await withRetry(
      ()=>client.getSignaturesForAddress(address,{limit:cfg.pageLimit,before,commitment:"finalized"}),
      cfg.maxRetries,cfg.backoffBaseMs,()=>retries++
    );
    pages++;
    if(!page.length) break;
    sigs.push(...page);
    const last=page.at(-1)!;
    before=last.signature;
    if(page.length<cfg.pageLimit) break;
  }

  const unique=[...new Map(sigs.map(s=>[s.signature,s])).values()];
  const transactions:any[]=[];
  let missing=0;
  for(let i=0;i<unique.length;i+=Math.max(1,cfg.concurrency)){
    const batch=unique.slice(i,i+Math.max(1,cfg.concurrency));
    await Promise.all(batch.map(async s=>{
      const tx=await withRetry(()=>client.getTransaction(s.signature),cfg.maxRetries,cfg.backoffBaseMs,()=>retries++);
      if(tx) transactions.push(tx); else missing++;
    }));
  }

  transactions.sort((a,b)=>Number(a?.slot??0)-Number(b?.slot??0));
  const lastSig=unique.at(-1);
  const raw=`${address}|${before??""}|${unique.length}|${lastSig?.signature??""}`;
  const fingerprint=crypto.createHash("sha256").update(raw).digest("hex");
  const finishedAt=Date.now();
  const cp:BackfillCheckpoint={address,before,fetchedSignatures:(checkpoint?.fetchedSignatures??0)+unique.length,
    fetchedTransactions:(checkpoint?.fetchedTransactions??0)+transactions.length,lastSignature:lastSig?.signature,
    lastSlot:lastSig?.slot,updatedAt:finishedAt,fingerprint};
  return {transactions,signatures:unique,checkpoint:cp,
    stats:{pages,signatures:unique.length,transactions:transactions.length,missingTransactions:missing,retries,startedAt,finishedAt}};
}
