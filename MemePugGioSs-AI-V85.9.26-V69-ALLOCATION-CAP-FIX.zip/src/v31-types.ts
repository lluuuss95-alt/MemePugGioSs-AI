export type TradeSide = 'LONG';
export type PositionStatus = 'OPEN' | 'CLOSED';
export type CloseReason = 'TAKE_PROFIT' | 'STOP_LOSS' | 'SIGNAL_INVALIDATED' | 'TIMEOUT' | 'MANUAL' | 'RISK_GATE';

export interface PaperTrade {
  id: string; token: string; side: TradeSide; entryPrice: number; exitPrice?: number;
  quantity: number; notional: number; fees: number; slippage: number;
  realizedPnl?: number; openedAt: number; closedAt?: number; status: PositionStatus; closeReason?: CloseReason;
}
export interface PortfolioSnapshot {
  timestamp: number; cash: number; equity: number; unrealizedPnl: number; realizedPnl: number;
  exposure: number; drawdown: number; peakEquity: number; openPositions: number;
}
export interface PerformanceMetrics {
  startingCapital: number; currentEquity: number; totalReturnPct: number; realizedPnl: number;
  unrealizedPnl: number; maxDrawdownPct: number; winRatePct: number; profitFactor: number;
  averageWin: number; averageLoss: number; expectancy: number; trades: number; wins: number; losses: number;
}
export interface PortfolioState { cash: number; peakEquity: number; trades: PaperTrade[]; snapshots: PortfolioSnapshot[]; }
