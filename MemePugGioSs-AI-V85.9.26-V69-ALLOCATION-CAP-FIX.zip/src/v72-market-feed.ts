import { db } from './db.js';
import { opportunities } from './scanner.js';
import { V28SignalStore } from './v28-store.js';
import { toV28HomeSignals } from './v28-home-feed.js';

export interface V72MarketToken {
  mint:string; symbol:string; name:string; price:number; liquidity:number; volume5m:number;
  holders:number; buyPressure:number; score:number; riskScore:number; tradable:boolean; stale:boolean;
  observedAt:string|null; signalState:string|null; signalAction:string|null; signalScore:number|null;
}

function safeRows(sql:string, params:any[]=[]):any[]{
  try { return db.prepare(sql).all(...params) as any[]; } catch { return []; }
}

export function buildV72MarketFeed(limit=50){
  const capped=Math.max(1,Math.min(100,Math.floor(limit)));
  const opp=opportunities();
  const signalStore=new V28SignalStore();
  const signals=toV28HomeSignals(signalStore.top(Math.min(100,capped*2)));
  const signalByMint=new Map(signals.map(s=>[s.mint,s]));
  const selected=opp.slice(0,capped);
  const tokens:V72MarketToken[]=selected.map((o:any)=>{
    const s=signalByMint.get(o.mint);
    return {
      mint:String(o.mint), symbol:String(o.symbol??''), name:String(o.name??''), price:Number(o.price??0),
      liquidity:Number(o.liquidity??0), volume5m:Number(o.volume5m??0), holders:Number(o.holders??0),
      buyPressure:Number(o.buyPressure??o.buy_pressure??0), score:Number(o.score??0), riskScore:Number(o.riskScore??0),
      tradable:Boolean(o.tradable), stale:Boolean(o.stale), observedAt:o.observed_at?String(o.observed_at):null,
      signalState:s?.state??null, signalAction:s?.action??null, signalScore:s?.score??null
    };
  });
  const mints=tokens.slice(0,8).map(t=>t.mint);
  const history=mints.length ? safeRows(`SELECT mint,observed_at,price,liquidity,volume5m,buy_pressure FROM observations WHERE mint IN (${mints.map(()=>'?').join(',')}) ORDER BY observed_at ASC`,mints) : [];
  const byMint:any={};
  for(const r of history){const arr=byMint[r.mint]??(byMint[r.mint]=[]);if(arr.length<60)arr.push({ts:r.observed_at,price:Number(r.price??0),liquidity:Number(r.liquidity??0),volume5m:Number(r.volume5m??0),buyPressure:Number(r.buy_pressure??0)});}
  return {version:'V72',ts:Date.now(),mode:'PAPER',liveExecutionEnabled:false,tokens,signals,history:byMint,source:'SOLANA/PUMPFUN_BACKEND_FEED',freshness:{latestObservation:tokens[0]?.observedAt??null,tokenCount:tokens.length}};
}

export const V72_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV72Safe(){if(!V72_SAFETY.shadowOnly||V72_SAFETY.signingEnabled||V72_SAFETY.privateKeyAccess||V72_SAFETY.broadcastEnabled||V72_SAFETY.liveExecutionAllowed||V72_SAFETY.autoPromotion)throw new Error('V72_SAFETY_INVARIANT_FAILED');}
