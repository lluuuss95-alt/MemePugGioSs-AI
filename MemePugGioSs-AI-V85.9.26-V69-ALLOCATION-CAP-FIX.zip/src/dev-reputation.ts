import { WalletProfile, WalletScore } from "./wallet-intelligence.js";

export interface DevReputation {
  address:string;
  score:number;
  confidence:number;
  sampleSize:number;
  reasons:string[];
}

export function scoreDeveloper(p:WalletProfile, walletScore:WalletScore):DevReputation {
  const sample=p.deployerTokens;
  let score=50; const reasons:string[]=[];
  if(sample>=3 && p.exits===0) { score+=15; reasons.push("no observed exits in sampled deployer history"); }
  if(p.exits>=3) { score-=25; reasons.push("repeated observed exits"); }
  if(p.sellVolume>p.buyVolume*2 && p.sellVolume>0) { score-=15; reasons.push("observed sell-heavy behavior"); }
  score=Math.max(0,Math.min(100,score));
  const confidence=Math.min(1,sample/10);
  return {address:p.address,score,confidence,sampleSize:sample,reasons};
}
