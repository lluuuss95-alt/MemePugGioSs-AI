import { HistoricalEvent } from "./historical-types.js";

export function summarize(events:HistoricalEvent[]){
  const mints=new Set(events.map(e=>e.mint));
  const prices=events.map(e=>e.price).filter((x):x is number=>Number.isFinite(x));
  const liquidity=events.map(e=>e.liquidity).filter((x):x is number=>Number.isFinite(x));
  return {
    rows:events.length,
    tokens:mints.size,
    firstTs:events[0]?.ts,
    lastTs:events.at(-1)?.ts,
    priceMin:prices.length?Math.min(...prices):undefined,
    priceMax:prices.length?Math.max(...prices):undefined,
    liquidityMin:liquidity.length?Math.min(...liquidity):undefined,
    liquidityMax:liquidity.length?Math.max(...liquidity):undefined
  };
}
