export type V34TraderStatus = 'DISCOVERED' | 'QUALIFIED' | 'WATCH' | 'BLOCKED';
export type V34TradeSide = 'BUY' | 'SELL' | 'UNKNOWN';
export type V34TradeSource = 'VERIFIED_PUMP' | 'VERIFIED_PUMPSWAP' | 'UNKNOWN';

export interface V34TraderProfile {
  wallet: string;
  status: V34TraderStatus;
  firstSeenAt: number;
  lastSeenAt: number;
  trades: number;
  buys: number;
  sells: number;
  closedTrades: number;
  wins: number;
  losses: number;
  realizedPnlQuote: number;
  grossProfitQuote: number;
  grossLossQuote: number;
  maxDrawdownPct: number;
  avgHoldMs: number;
  uniqueTokens: number;
  pumpTrades: number;
  pumpSwapTrades: number;
  consistencyScore: number;
  riskScore: number;
  sampleConfidence: number;
  lastTradeAt: number;
}

export interface V34TradeObservation {
  id: string;
  wallet: string;
  signature: string;
  slot: number;
  mint: string;
  side: V34TradeSide;
  source: V34TradeSource;
  quoteAmount: number;
  baseAmount: number;
  price: number;
  observedAt: number;
  executedAt: number;
  verified: boolean;
  confidence: number;
}

export interface V34TraderScore {
  wallet: string;
  consistency: number;
  risk: number;
  sampleConfidence: number;
  quality: number;
  rank: number;
  reasons: string[];
}

export interface V34CopyCandidate {
  wallet: string;
  signature: string;
  mint: string;
  side: V34TradeSide;
  source: V34TradeSource;
  detectedAt: number;
  latencyMs: number;
  confidence: number;
  eligible: boolean;
  blockedReason?: string;
}

export interface V34DiscoveryConfig {
  minTrades: number;
  minSampleConfidence: number;
  minConsistency: number;
  maxRisk: number;
  minTradeConfidence: number;
  maxLatencyMs: number;
}
