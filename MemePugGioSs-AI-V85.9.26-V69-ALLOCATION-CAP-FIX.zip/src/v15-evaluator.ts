import { CandidateResult, DatasetRow, StrategyParams } from "./v15-types.js";

function mean(xs:number[]){return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:0;}

export function evaluate(params:StrategyParams,rows:DatasetRow[],minSamples=20):CandidateResult {
  const selected=rows.filter(r=>r.buySellRatio>=params.buySellRatio &&
    r.smartMoneyShare>=params.smartMoneyShare &&
    r.risk<=params.riskMax &&
    r.liquidityDelta>=params.liquidityDeltaMin &&
    r.holderDelta>=params.holderDeltaMin);
  const returns=selected.map(x=>x.futureReturnPct);
  const positive=returns.filter(x=>x>0).length;
  const trainMean=mean(returns);
  const complexity=Object.values(params).reduce((s,x)=>s+Math.abs(Number(x)),0)/100;
  const confidence=Math.min(1,returns.length/minSamples);
  return {params,trainSamples:returns.length,validationSamples:0,trainMean,
    validationMean:0,validationWinRate:0,gap:0,complexity,confidence,
    adjustedScore:trainMean-complexity,eligible:returns.length>=minSamples};
}

export function evaluateSplit(params:StrategyParams,train:DatasetRow[],validation:DatasetRow[],minSamples=20):CandidateResult{
  const a=evaluate(params,train,minSamples), b=evaluate(params,validation,minSamples);
  const gap=Math.abs(a.trainMean-b.trainMean);
  const validationWinRate=b.trainSamples?validation.filter(r=>
    r.buySellRatio>=params.buySellRatio&&r.smartMoneyShare>=params.smartMoneyShare&&r.risk<=params.riskMax&&
    r.liquidityDelta>=params.liquidityDeltaMin&&r.holderDelta>=params.holderDeltaMin&&r.futureReturnPct>0).length/b.trainSamples*100:0;
  const adjusted=b.trainSamples>=minSamples && b.confidence>=0.5
    ? b.trainMean - gap*0.5 - a.complexity : -Infinity;
  return {...a,validationSamples:b.trainSamples,validationMean:b.trainMean,
    validationWinRate,gap,confidence:b.confidence,adjustedScore:adjusted,
    eligible:a.eligible&&b.eligible&&b.confidence>=0.5};
}
