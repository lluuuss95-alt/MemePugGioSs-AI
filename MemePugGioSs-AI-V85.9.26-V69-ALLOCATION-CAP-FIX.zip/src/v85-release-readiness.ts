import crypto from 'node:crypto';
import { db } from './db.js';
import { V84FinalControlPlane, assertV84Safe } from './v84-final-control-plane.js';

export interface V85Report { version:'V85'; release:'PAPER_SHADOW_RELEASE'; state:'READY'|'BLOCKED'|'DEGRADED'; safety:{mode:'PAPER';signingEnabled:false;privateKeyAccess:false;broadcastEnabled:false;liveExecutionEnabled:false;autoPromotion:false}; checks:Record<string,{ok:boolean;detail:string}>; fingerprint:string; ts:number; }
export const V85_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV85Safe(){assertV84Safe();if(!V85_SAFETY.shadowOnly||V85_SAFETY.signingEnabled||V85_SAFETY.privateKeyAccess||V85_SAFETY.broadcastEnabled||V85_SAFETY.liveExecutionAllowed||V85_SAFETY.autoPromotion)throw new Error('V85_SAFETY_INVARIANT_FAILED');}

export class V85ReleaseReadiness {
  constructor(private readonly control=new V84FinalControlPlane()){db.exec(`CREATE TABLE IF NOT EXISTS v85_release_checks(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,state TEXT NOT NULL,fingerprint TEXT NOT NULL,result_json TEXT NOT NULL)`);assertV85Safe();}
  audit(now=Date.now()):V85Report{
    const checks:Record<string,{ok:boolean;detail:string}>={};
    const r=this.control.readiness(now); checks.controlPlane={ok:r.state==='READY',detail:`controlPlane=${r.state}`};
    checks.safety={ok:true,detail:'All runtime execution paths remain PAPER/SHADOW and cannot sign, access keys or broadcast'};
    checks.reconciliation={ok:r.checks.reconciliation.ok,detail:r.checks.reconciliation.detail};
    checks.gate={ok:r.checks.paperGate.ok,detail:r.checks.paperGate.detail};
    checks.journal={ok:r.checks.transactionJournal.ok,detail:r.checks.transactionJournal.detail};
    checks.recovery={ok:r.checks.recoverySupervisor.ok,detail:r.checks.recoverySupervisor.detail};
    checks.noLiveFlag={ok:V85_SAFETY.liveExecutionAllowed===false,detail:'liveExecutionAllowed=false'};
    const state:'READY'|'DEGRADED'|'BLOCKED'=Object.values(checks).every(x=>x.ok)?'READY':Object.values(checks).some(x=>x.ok)?'DEGRADED':'BLOCKED';
    const base={version:'V85' as const,release:'PAPER_SHADOW_RELEASE' as const,state,safety:{mode:'PAPER' as const,signingEnabled:false as const,privateKeyAccess:false as const,broadcastEnabled:false as const,liveExecutionEnabled:false as const,autoPromotion:false as const},checks,ts:now};
    const fingerprint=crypto.createHash('sha256').update(JSON.stringify(base)).digest('hex'); const report={...base,fingerprint};
    db.prepare(`INSERT INTO v85_release_checks VALUES(?,?,?,?,?)`).run(crypto.randomUUID(),now,state,fingerprint,JSON.stringify(report)); return report;
  }
  recent(limit=20){return db.prepare(`SELECT * FROM v85_release_checks ORDER BY ts DESC LIMIT ?`).all(Math.min(100,Math.max(1,limit)));}
}
export const v85ReleaseReadiness=new V85ReleaseReadiness();
