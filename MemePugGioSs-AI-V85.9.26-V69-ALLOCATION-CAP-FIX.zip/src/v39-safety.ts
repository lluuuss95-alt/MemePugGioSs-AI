export function assertV39Safety(){
  if(process.env.MEMEPUGGIOSS_LIVE_TRADING==='true') throw new Error('V39_ANALYTICS_ONLY_LIVE_DISABLED');
  return true;
}
