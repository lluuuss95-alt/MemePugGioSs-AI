import { TimedPoint, buildV9Features } from "./v9-features.js";
import { generateV9Signal } from "./v9-signal.js";

export function analyzeV9(points:TimedPoint[], now=Date.now()){
  const features=buildV9Features(points,now);
  const signal=generateV9Signal(features);
  return {features,signal};
}
