import { MarketBar, Strategy } from "./backtest-types.js";
import { runBacktest } from "./backtester.js";

export interface WalkForwardWindow {trainStart:number;trainEnd:number;testStart:number;testEnd:number;}
export function makeWalkForwardWindows(n:number,train:number,test:number,step:number):WalkForwardWindow[]{
  const out:WalkForwardWindow[]=[];
  for(let s=0;s+train+test<=n;s+=step) out.push({trainStart:s,trainEnd:s+train,testStart:s+train,testEnd:s+train+test});
  return out;
}
export function evaluateWalkForward(strategy:Strategy,bars:MarketBar[],windows:WalkForwardWindow[],cfg:any){
  return windows.map(w=>runBacktest(strategy,bars.slice(w.testStart,w.testEnd),cfg));
}
