export interface MarketBar {
  ts:number;
  price:number;
  signal?:number;
}

export interface StrategyContext {
  index:number;
  bars:MarketBar[];
  cash:number;
  position:number;
  equity:number;
}

export interface StrategyAction {
  side:"BUY"|"SELL"|"HOLD";
  fraction:number;
  reason:string;
}

export interface Strategy {
  id:string;
  decide(ctx:StrategyContext):StrategyAction;
}

export interface BacktestConfig {
  initialCash:number;
  feeBps:number;
  slippageBps:number;
  maxPositionFraction:number;
}

export interface Trade {
  ts:number;
  side:"BUY"|"SELL";
  price:number;
  quantity:number;
  fee:number;
  reason:string;
  pnl?:number;
}

export interface BacktestResult {
  strategyId:string;
  initialCash:number;
  finalEquity:number;
  totalReturnPct:number;
  maxDrawdownPct:number;
  winRatePct:number;
  expectancy:number;
  profitFactor:number;
  sharpe:number;
  sortino:number;
  trades:Trade[];
  equityCurve:number[];
}
