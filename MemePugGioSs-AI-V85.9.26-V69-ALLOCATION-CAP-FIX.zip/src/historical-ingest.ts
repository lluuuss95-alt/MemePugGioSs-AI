import crypto from "node:crypto";
import { HistoricalEvent, QuarantinedRecord, DatasetManifest } from "./historical-types.js";

export function normalizeRecord(raw:any, index:number, source:string): {event?:HistoricalEvent; quarantine?:QuarantinedRecord} {
  const ts=Number(raw.ts ?? raw.timestamp ?? raw.time);
  const mint=String(raw.mint ?? "");
  if(!Number.isFinite(ts) || ts<=0) return {quarantine:{raw,reason:"invalid timestamp"}};
  if(!mint) return {quarantine:{raw,reason:"missing mint"}};
  const id=String(raw.id ?? `${source}:${mint}:${raw.slot ?? ""}:${ts}:${index}`);
  return {event:{id,ts,slot:raw.slot===undefined?undefined:Number(raw.slot),mint,
    price:raw.price===undefined?undefined:Number(raw.price),
    buyVolume:raw.buyVolume===undefined?undefined:Number(raw.buyVolume),
    sellVolume:raw.sellVolume===undefined?undefined:Number(raw.sellVolume),
    liquidity:raw.liquidity===undefined?undefined:Number(raw.liquidity),
    smartMoneyVolume:raw.smartMoneyVolume===undefined?undefined:Number(raw.smartMoneyVolume),
    holders:raw.holders===undefined?undefined:Number(raw.holders),
    risk:raw.risk===undefined?undefined:Number(raw.risk),source,sourceVersion:raw.sourceVersion}};
}

export function ingestHistorical(raws:any[],source="unknown"){
  const events:HistoricalEvent[]=[]; const quarantined:QuarantinedRecord[]=[];
  for(let i=0;i<raws.length;i++){const r=normalizeRecord(raws[i],i,source); if(r.event) events.push(r.event); else quarantined.push(r.quarantine!);}
  const map=new Map<string,HistoricalEvent>();
  for(const e of events) if(!map.has(e.id)) map.set(e.id,e);
  const sorted=[...map.values()].sort((a,b)=>a.ts-b.ts || (a.slot??0)-(b.slot??0) || a.id.localeCompare(b.id));
  return {events:sorted,quarantined};
}

export function fingerprint(events:HistoricalEvent[]):string {
  const canonical=events.map(e=>JSON.stringify(e)).join("\\n");
  return crypto.createHash("sha256").update(canonical).digest("hex");
}

export function manifest(events:HistoricalEvent[],quarantined:QuarantinedRecord[],source="unknown",sourceVersion?:string):DatasetManifest{
  return {datasetId:`ds-${fingerprint(events).slice(0,16)}`,version:"1.0.0",source,sourceVersion,
    createdAt:Date.now(),rows:events.length,quarantined:quarantined.length,
    firstTs:events[0]?.ts,lastTs:events.at(-1)?.ts,sha256:fingerprint(events)};
}
