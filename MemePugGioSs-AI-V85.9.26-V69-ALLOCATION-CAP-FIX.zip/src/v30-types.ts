import { V29RankedSignal } from './v29-types.js';

export type V30Decision = 'ENTER_PAPER' | 'HOLD' | 'EXIT_PAPER' | 'BLOCKED' | 'NO_ACTION';
export type V30PositionStatus = 'OPEN' | 'CLOSED';

export interface V30ExecutionConfig {
  initialCash: number;
  maxPortfolioExposurePct: number;
  maxPositionPct: number;
  minCompositeScore: number;
  minConfidence: number;
  maxRiskScore: number;
  entrySlippageBps: number;
  exitSlippageBps: number;
  feeBps: number;
  stopLossPct: number;
  takeProfitPct: number;
  maxHoldingMs: number;
  staleAfterMs: number;
}

export interface V30MarketTick {
  mint: string;
  price: number;
  timestamp: number;
  liquidityUsd: number;
}

export interface V30DecisionRecord {
  mint: string;
  decision: V30Decision;
  reason: string;
  score: number;
  confidence: number;
  riskScore: number;
  timestamp: number;
}

export interface V30Position {
  id: string;
  mint: string;
  status: V30PositionStatus;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  entryNotional: number;
  exitNotional: number;
  unrealizedPnl: number;
  realizedPnl: number;
  openedAt: number;
  closedAt?: number;
  stopPrice: number;
  takeProfitPrice: number;
  exitReason?: string;
}

export interface V30PaperState {
  cash: number;
  equity: number;
  realizedPnl: number;
  unrealizedPnl: number;
  positions: V30Position[];
  decisions: V30DecisionRecord[];
  generatedAt: number;
}

export interface V30EvaluationResult {
  decision: V30DecisionRecord;
  state: V30PaperState;
}
