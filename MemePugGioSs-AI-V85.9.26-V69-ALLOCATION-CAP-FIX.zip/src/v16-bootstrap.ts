
export function bootstrapCI(values:number[],runs=2000,seed=17,confidence=.95){
  if(!values.length)return {lower:0,upper:0,confidence};
  let s=seed>>>0; const rnd=()=>{s=(1664525*s+1013904223)>>>0;return s/4294967296;};
  const means:number[]=[];
  for(let i=0;i<runs;i++){let sum=0;for(let j=0;j<values.length;j++)sum+=values[Math.floor(rnd()*values.length)];means.push(sum/values.length);}
  means.sort((a,b)=>a-b);
  const alpha=(1-confidence)/2;
  return {lower:means[Math.floor(alpha*means.length)],upper:means[Math.floor((1-alpha)*means.length)-1],confidence};
}
