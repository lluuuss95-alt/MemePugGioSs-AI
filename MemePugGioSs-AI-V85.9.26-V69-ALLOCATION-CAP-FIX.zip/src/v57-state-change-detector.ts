import crypto from 'node:crypto';
import { db } from './db.js';
import type { V56State } from './v56-token-state-fusion.js';

export type V57ChangeType='SIGNAL_UPGRADE'|'SIGNAL_DOWNGRADE'|'RISK_ESCALATION'|'LIQUIDITY_CHANGE'|'SMART_MONEY_CHANGE'|'MOMENTUM_CHANGE'|'REGIME_CHANGE'|'STALE_DATA'|'FRESH_DATA'|'GRADUATION_CHANGE'|'HOLDER_CONCENTRATION_CHANGE';
export type V57Severity='INFO'|'WATCH'|'HIGH'|'CRITICAL';
export interface V57Change { id:string; mint:string; ts:number; type:V57ChangeType; severity:V57Severity; version:number; previousVersion:number; message:string; before?:number|string; after?:number|string; delta?:number; actionable:boolean; }
export interface V57Config { minRelativeChange:number; minAbsoluteLiquidityChange:number; minAbsoluteMomentumChange:number; minRiskDelta:number; minScoreDelta:number; minSmartMoneyDelta:number; minGraduationDelta:number; minHolderConcentrationDelta:number; maxEventsPerMint:number; maxEvents:number; }
export const defaultV57Config:V57Config=Object.freeze({minRelativeChange:.10,minAbsoluteLiquidityChange:250,minAbsoluteMomentumChange:5,minRiskDelta:8,minScoreDelta:8,minSmartMoneyDelta:8,minGraduationDelta:5,minHolderConcentrationDelta:5,maxEventsPerMint:100,maxEvents:100000});
export interface V57Health { state:'STOPPED'|'RUNNING'|'DEGRADED'|'HALTED'; comparisons:number; changes:number; ignored:number; lastChangeAt:number|null; }
const finite=(n:unknown):n is number=>typeof n==='number'&&Number.isFinite(n);
const rel=(a:number,b:number)=>Math.abs(a-b)/Math.max(Math.abs(a),1);
const id=(mint:string,type:string,version:number,ts:number)=>crypto.createHash('sha256').update(`${mint}:${type}:${version}:${ts}`).digest('hex');

/** Compares consecutive verified V56 snapshots. It emits events only for material, observed changes. */
export class V57StateChangeDetector {
  private readonly cfg:V57Config; private readonly previous=new Map<string,V56State>(); private readonly events:V57Change[]=[];
  private health:V57Health={state:'STOPPED',comparisons:0,changes:0,ignored:0,lastChangeAt:null};
  constructor(cfg:Partial<V57Config>={}){this.cfg={...defaultV57Config,...cfg};this.ensureSchema();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v57_change_events(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,type TEXT NOT NULL,severity TEXT NOT NULL,version INTEGER NOT NULL,previous_version INTEGER NOT NULL,event_json TEXT NOT NULL)`);}
  start(){this.health={...this.health,state:'RUNNING'};} stop(){this.health={...this.health,state:'STOPPED'};} halt(){this.health={...this.health,state:'HALTED'};}
  healthSnapshot(){return {...this.health,changes:this.events.length};}
  ingest(next:V56State,now=Date.now()):V57Change[]{
    const prev=this.previous.get(next.mint); this.previous.set(next.mint,{...next});
    if(!prev){this.health.ignored++;return [];} this.health.comparisons++;
    const out:V57Change[]=[];
    const emit=(type:V57ChangeType,severity:V57Severity,message:string,before?:number|string,after?:number|string,delta?:number,actionable=severity!=='INFO')=>out.push({id:id(next.mint,type,next.version,now),mint:next.mint,ts:now,type,severity,version:next.version,previousVersion:prev.version,message,before,after,delta,actionable});
    const scoreDelta=(next.deepScore??next.instantScore??0)-(prev.deepScore??prev.instantScore??0);
    if(finite(next.deepScore)&&finite(prev.deepScore)&&Math.abs(scoreDelta)>=this.cfg.minScoreDelta) emit(scoreDelta>0?'SIGNAL_UPGRADE':'SIGNAL_DOWNGRADE',Math.abs(scoreDelta)>=this.cfg.minScoreDelta*2?'HIGH':'WATCH',`AI score changed by ${scoreDelta.toFixed(2)}`,prev.deepScore,next.deepScore,scoreDelta);
    if(finite(next.risk)&&finite(prev.risk)&&next.risk-prev.risk>=this.cfg.minRiskDelta) emit('RISK_ESCALATION',next.risk-prev.risk>=this.cfg.minRiskDelta*2?'CRITICAL':'HIGH',`Risk increased by ${(next.risk-prev.risk).toFixed(2)}`,prev.risk,next.risk,next.risk-prev.risk);
    if(finite(next.liquidity)&&finite(prev.liquidity)&&Math.abs(next.liquidity-prev.liquidity)>=this.cfg.minAbsoluteLiquidityChange&&rel(prev.liquidity,next.liquidity)>=this.cfg.minRelativeChange) emit('LIQUIDITY_CHANGE',next.liquidity<prev.liquidity?'HIGH':'WATCH',`Liquidity ${next.liquidity<prev.liquidity?'decreased':'increased'} materially`,prev.liquidity,next.liquidity,next.liquidity-prev.liquidity,next.liquidity<prev.liquidity);
    if(finite(next.smartMoneyScore)&&finite(prev.smartMoneyScore)&&Math.abs(next.smartMoneyScore-prev.smartMoneyScore)>=this.cfg.minSmartMoneyDelta) emit('SMART_MONEY_CHANGE',next.smartMoneyScore<prev.smartMoneyScore?'HIGH':'WATCH',`Smart Money score changed materially`,prev.smartMoneyScore,next.smartMoneyScore,next.smartMoneyScore-prev.smartMoneyScore);
    if(finite(next.flowMomentum)&&finite(prev.flowMomentum)&&Math.abs(next.flowMomentum-prev.flowMomentum)>=this.cfg.minAbsoluteMomentumChange) emit('MOMENTUM_CHANGE',Math.abs(next.flowMomentum-prev.flowMomentum)>=this.cfg.minAbsoluteMomentumChange*2?'HIGH':'WATCH',`Flow momentum changed materially`,prev.flowMomentum,next.flowMomentum,next.flowMomentum-prev.flowMomentum);
    if(next.regime&&prev.regime&&next.regime!==prev.regime) emit('REGIME_CHANGE',next.regime==='STRESSED'||next.regime==='NO_TRADE'?'CRITICAL':'HIGH',`Market regime changed`,prev.regime,next.regime);
    if(finite(next.graduationProgress)&&finite(prev.graduationProgress)&&Math.abs(next.graduationProgress-prev.graduationProgress)>=this.cfg.minGraduationDelta) emit('GRADUATION_CHANGE',next.graduationProgress<prev.graduationProgress?'WATCH':'INFO',`Graduation progress changed`,prev.graduationProgress,next.graduationProgress,next.graduationProgress-prev.graduationProgress,false);
    if(finite(next.holderConcentration)&&finite(prev.holderConcentration)&&Math.abs(next.holderConcentration-prev.holderConcentration)>=this.cfg.minHolderConcentrationDelta) emit('HOLDER_CONCENTRATION_CHANGE',next.holderConcentration>prev.holderConcentration?'HIGH':'WATCH',`Holder concentration changed materially`,prev.holderConcentration,next.holderConcentration,next.holderConcentration-prev.holderConcentration);
    if(prev.freshness!=='STALE'&&next.freshness==='STALE') emit('STALE_DATA','HIGH','Token state became stale',prev.freshness,next.freshness,undefined,true);
    if(prev.freshness==='STALE'&&next.freshness==='FRESH') emit('FRESH_DATA','INFO','Token state became fresh',prev.freshness,next.freshness,undefined,false);
    for(const e of out)this.record(e);
    this.health.ignored += out.length===0?1:0; return out;
  }
  recent(limit=100,mint?:string){return this.events.filter(e=>!mint||e.mint===mint).slice(-Math.min(500,Math.max(1,limit)));}
  private record(e:V57Change){if(this.events.length>=this.cfg.maxEvents)this.events.shift();this.events.push(e);this.health.changes++;this.health.lastChangeAt=e.ts;db.prepare(`INSERT OR REPLACE INTO v57_change_events(id,ts,mint,type,severity,version,previous_version,event_json) VALUES(?,?,?,?,?,?,?,?)`).run(e.id,e.ts,e.mint,e.type,e.severity,e.version,e.previousVersion,JSON.stringify(e));}
}
export const V57_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV57Safe(){if(!V57_SAFETY.shadowOnly||V57_SAFETY.signingEnabled||V57_SAFETY.privateKeyAccess||V57_SAFETY.broadcastEnabled||V57_SAFETY.liveExecutionAllowed||V57_SAFETY.autoPromotion)throw new Error('V57_SAFETY_INVARIANT_FAILED');}
