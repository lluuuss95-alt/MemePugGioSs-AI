import fs from "node:fs/promises";
import path from "node:path";
import { BackfillCheckpoint } from "./backfill-types.js";

export async function saveCheckpoint(file:string,cp:BackfillCheckpoint){
  await fs.mkdir(path.dirname(file),{recursive:true});
  const tmp=`${file}.tmp`;
  await fs.writeFile(tmp,JSON.stringify(cp,null,2),"utf8");
  await fs.rename(tmp,file);
}
export async function loadCheckpoint(file:string):Promise<BackfillCheckpoint|undefined>{
  try{return JSON.parse(await fs.readFile(file,"utf8"));}
  catch{return undefined;}
}
