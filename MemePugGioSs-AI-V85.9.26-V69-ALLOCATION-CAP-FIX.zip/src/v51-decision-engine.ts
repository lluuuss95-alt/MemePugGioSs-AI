import crypto from 'node:crypto';
import { db } from './db.js';
import { V50Result } from './v50-deep-intelligence.js';

export type V51Action='ENTER_PAPER'|'WATCH'|'WAIT'|'EXIT_PAPER'|'BLOCK';
export type V51State='DECIDED'|'BLOCKED'|'INSUFFICIENT_DATA';
export interface V51Config {
  minScore:number; minConfidence:number; maxRisk:number; maxFreshnessMs:number;
  minLiquidity:number; maxPositionPct:number; reservePct:number;
}
export interface V51Input {
  analysis:V50Result;
  side?:'BUY'|'SELL';
  existingPosition?:boolean;
  currentPrice?:number;
  entryPrice?:number;
  now?:number;
}
export interface V51Decision {
  id:string; ts:number; mint:string; signature:string; action:V51Action; state:V51State;
  score:number; confidence:number; risk:number; theoreticalAllocationPct:number;
  reasons:string[]; blockers:string[]; invalidationConditions:string[];
  liveExecutionEnabled:false;
}

export const defaultV51Config:V51Config=Object.freeze({
  minScore:70,minConfidence:65,maxRisk:45,maxFreshnessMs:5000,
  minLiquidity:1000,maxPositionPct:5,reservePct:20
});
const clamp=(n:number,a=0,b=100)=>Math.max(a,Math.min(b,n));

export class V51FinalDecisionEngine {
  constructor(private readonly cfg=defaultV51Config){this.ensureSchema()}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v51_decisions(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,signature TEXT NOT NULL,action TEXT NOT NULL,state TEXT NOT NULL,score REAL NOT NULL,confidence REAL NOT NULL,risk REAL NOT NULL,theoretical_allocation_pct REAL NOT NULL,reasons_json TEXT NOT NULL,blockers_json TEXT NOT NULL,invalidation_json TEXT NOT NULL,live_execution_enabled INTEGER NOT NULL)`)}
  decide(input:V51Input):V51Decision {
    const a=input.analysis; const now=input.now??Date.now(); const reasons:string[]=[]; const blockers:string[]=[];
    if(a.state==='BLOCKED') blockers.push(...a.blockers);
    if(a.state==='INSUFFICIENT_DATA') blockers.push('DEEP_ANALYSIS_INSUFFICIENT_DATA');
    if(a.score<this.cfg.minScore) blockers.push('FINAL_SCORE_BELOW_THRESHOLD');
    if(a.confidence<this.cfg.minConfidence) blockers.push('FINAL_CONFIDENCE_BELOW_THRESHOLD');
    if(a.risk>this.cfg.maxRisk) blockers.push('FINAL_RISK_ABOVE_THRESHOLD');
    const fresh=a.reasons.includes('MARKET_DATA_STALE');
    if(fresh) blockers.push('MARKET_DATA_STALE');
    if(a.liquidityScore<=0) blockers.push('LIQUIDITY_UNVERIFIED');
    if(input.existingPosition && input.side==='SELL'){
      const action:V51Action='EXIT_PAPER';
      reasons.push('EXISTING_POSITION_EXIT_REQUEST');
      return this.save({id:crypto.randomUUID(),ts:now,mint:a.mint,signature:a.signature,action,state:'DECIDED',score:a.score,confidence:a.confidence,risk:a.risk,theoreticalAllocationPct:0,reasons,blockers:[],invalidationConditions:['MARKET_DATA_INVALID','LIQUIDITY_LOST'],liveExecutionEnabled:false});
    }
    if(blockers.length){
      const action:V51Action = a.state==='INSUFFICIENT_DATA' ? 'WAIT' : 'BLOCK';
      if(action==='WAIT') reasons.push('WAIT_FOR_VERIFIED_DATA');
      const d={id:crypto.randomUUID(),ts:now,mint:a.mint,signature:a.signature,action,state:a.state==='INSUFFICIENT_DATA'?'INSUFFICIENT_DATA':'BLOCKED',score:a.score,confidence:a.confidence,risk:a.risk,theoreticalAllocationPct:0,reasons,blockers,invalidationConditions:['MARKET_DATA_INVALID','LIQUIDITY_LOST','RISK_LIMIT_BREACHED'],liveExecutionEnabled:false} as V51Decision;
      return this.save(d);
    }
    if(a.regimeMultiplier===0){
      reasons.push('NO_POSITIVE_REGIME_MULTIPLIER');
      const d:V51Decision={id:crypto.randomUUID(),ts:now,mint:a.mint,signature:a.signature,action:'WAIT',state:'DECIDED',score:a.score,confidence:a.confidence,risk:a.risk,theoreticalAllocationPct:0,reasons,blockers:[],invalidationConditions:['REGIME_NOT_SUPPORTIVE','MARKET_DATA_INVALID'],liveExecutionEnabled:false};
      return this.save(d);
    }
    const allocation=clamp((a.score-50)/50*this.cfg.maxPositionPct,0,this.cfg.maxPositionPct);
    reasons.push('ALL_FINAL_GATES_PASSED');
    if(a.smartMoneyScore>=60) reasons.push('SMART_MONEY_SUPPORT');
    if(a.flowScore>=60) reasons.push('POSITIVE_FLOW_SUPPORT');
    const d:V51Decision={id:crypto.randomUUID(),ts:now,mint:a.mint,signature:a.signature,action:'ENTER_PAPER',state:'DECIDED',score:a.score,confidence:a.confidence,risk:a.risk,theoreticalAllocationPct:Math.round(allocation*100)/100,reasons,blockers:[],invalidationConditions:['RISK_ABOVE_LIMIT','LIQUIDITY_BELOW_MINIMUM','MARKET_DATA_STALE','REGIME_BLOCKED','SIGNAL_INVALIDATED'],liveExecutionEnabled:false};
    return this.save(d);
  }
  private save(d:V51Decision){db.prepare(`INSERT OR REPLACE INTO v51_decisions(id,ts,mint,signature,action,state,score,confidence,risk,theoretical_allocation_pct,reasons_json,blockers_json,invalidation_json,live_execution_enabled) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(d.id,d.ts,d.mint,d.signature,d.action,d.state,d.score,d.confidence,d.risk,d.theoreticalAllocationPct,JSON.stringify(d.reasons),JSON.stringify(d.blockers),JSON.stringify(d.invalidationConditions),0);return d;}
  recent(limit=50):V51Decision[]{return db.prepare(`SELECT id,ts,mint,signature,action,state,score,confidence,risk,theoretical_allocation_pct theoreticalAllocationPct,reasons_json reasons,blockers_json blockers,invalidation_json invalidationConditions,live_execution_enabled liveExecutionEnabled FROM v51_decisions ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit))).map((r:any)=>({...r,reasons:JSON.parse(r.reasons||'[]'),blockers:JSON.parse(r.blockers||'[]'),invalidationConditions:JSON.parse(r.invalidationConditions||'[]'),liveExecutionEnabled:false})) as V51Decision[]}
}
export const V51_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV51Safe(){if(!V51_SAFETY.shadowOnly||V51_SAFETY.signingEnabled||V51_SAFETY.privateKeyAccess||V51_SAFETY.broadcastEnabled||V51_SAFETY.liveExecutionAllowed) throw new Error('V51_SAFETY_INVARIANT_FAILED')}
