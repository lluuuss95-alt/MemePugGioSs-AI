import crypto from 'node:crypto';
import { db } from './db.js';
import { V68AdaptivePaperRiskCalibration, type V68Profile } from './v68-adaptive-paper-risk-calibration.js';
import { V64AutonomousExecutionGuard, type V64Result, type V64MarketState, type V64PortfolioState } from './v64-pretrade-guard.js';
import { V65PaperExecutionSimulator, type V65PoolState, type V65ExecutionResult } from './v65-paper-execution-simulator.js';
import { V69EndToEndPaperPipeline, type V69Result } from './v69-end-to-end-paper-pipeline.js';
import type { V59Result } from './v59-decision-reevaluation.js';
import type { V75Run } from './v75-reevaluation-capital-loop.js';
import type { V63AllocationRow } from './v63-capital-allocation-optimizer.js';
import { assertV64Safe } from './v64-pretrade-guard.js';
import { assertV65Safe } from './v65-paper-execution-simulator.js';
import { assertV68Safe } from './v68-adaptive-paper-risk-calibration.js';
import { assertV69Safe } from './v69-end-to-end-paper-pipeline.js';
import { assertV75Safe } from './v75-reevaluation-capital-loop.js';

export type V76Status='PAPER_ENTRY_READY'|'BLOCKED'|'INSUFFICIENT_CONTEXT';
export interface V76Input {
  decisionResult: V59Result;
  allocationResult: V75Run;
  market: V64MarketState;
  portfolio: V64PortfolioState;
  pool: V65PoolState;
  maxSlippageBps:number;
  baselineRiskPct?:number;
  baselinePositionPct?:number;
  baselineTotalExposurePct?:number;
  now?:number;
}
export interface V76Result {
  id:string; ts:number; mint:string; status:V76Status;
  stages:Array<{stage:'ALLOCATION'|'RISK_CALIBRATION'|'PRETRADE_GUARD'|'EXECUTION_SIMULATION'|'END_TO_END_PIPELINE';status:'PASS'|'BLOCK'|'SKIP';reason:string}>;
  allocationQuote:number; calibratedQuote:number;
  riskProfile:V68Profile; guard?:V64Result; simulation?:V65ExecutionResult; pipeline?:V69Result;
  blockers:string[]; liveExecutionEnabled:false;
}

export const V76_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV76Safe(){assertV64Safe();assertV65Safe();assertV68Safe();assertV69Safe();assertV75Safe();if(!V76_SAFETY.shadowOnly||V76_SAFETY.signingEnabled||V76_SAFETY.privateKeyAccess||V76_SAFETY.broadcastEnabled||V76_SAFETY.liveExecutionAllowed||V76_SAFETY.autoPromotion)throw new Error('V76_SAFETY_INVARIANT_FAILED');}

const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
const finite=(n:unknown)=>Number.isFinite(Number(n))?Number(n):NaN;

export class V76AllocationPretradeSimulationBridge {
  private readonly risk=new V68AdaptivePaperRiskCalibration();
  private readonly guard=new V64AutonomousExecutionGuard();
  private readonly simulator=new V65PaperExecutionSimulator();
  private readonly pipeline=new V69EndToEndPaperPipeline();
  constructor(){this.ensureSchema();assertV76Safe();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v76_allocation_bridge_runs(
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, mint TEXT NOT NULL, status TEXT NOT NULL,
    allocation_quote REAL NOT NULL, calibrated_quote REAL NOT NULL, risk_id TEXT NOT NULL,
    guard_id TEXT, simulation_id TEXT, pipeline_id TEXT, stages_json TEXT NOT NULL,
    blockers_json TEXT NOT NULL, details_json TEXT NOT NULL
  ); CREATE INDEX IF NOT EXISTS idx_v76_bridge_ts ON v76_allocation_bridge_runs(ts);`);}

  run(input:V76Input):V76Result{
    const now=input.now??Date.now(), d=input.decisionResult, a=input.allocationResult, blockers:string[]=[];
    const stages:V76Result['stages']=[];
    if(d.mint!==a.mint||d.mint!==input.market.mint||d.mint!==input.pool.mint){
      const risk=this.risk.calibrate({mint:d.mint,now,baselineRiskPct:input.baselineRiskPct??d.risk,baselinePositionPct:input.baselinePositionPct??d.theoreticalAllocationPct,baselineTotalExposurePct:input.baselineTotalExposurePct??35});
      return this.persist({id:crypto.randomUUID(),ts:now,mint:d.mint,status:'BLOCKED',stages:[{stage:'ALLOCATION',status:'BLOCK',reason:'MINT_CONTEXT_MISMATCH'}],allocationQuote:0,calibratedQuote:0,riskProfile:risk,blockers:['MINT_CONTEXT_MISMATCH'],liveExecutionEnabled:false});
    }
    if(a.status!=='ALLOCATED'||a.optimizedQuote<=0){
      const risk=this.risk.calibrate({mint:d.mint,now,baselineRiskPct:input.baselineRiskPct??d.risk,baselinePositionPct:input.baselinePositionPct??d.theoreticalAllocationPct,baselineTotalExposurePct:input.baselineTotalExposurePct??35});
      return this.persist({id:crypto.randomUUID(),ts:now,mint:d.mint,status:'BLOCKED',stages:[{stage:'ALLOCATION',status:'BLOCK',reason:'V75_ALLOCATION_NOT_APPROVED'}],allocationQuote:Math.max(0,a.optimizedQuote),calibratedQuote:0,riskProfile:risk,blockers:['V75_ALLOCATION_NOT_APPROVED'],liveExecutionEnabled:false});
    }
    const allocationQuote=Math.max(0,finite(a.optimizedQuote));
    stages.push({stage:'ALLOCATION',status:'PASS',reason:'V75_ALLOCATION_APPROVED'});
    const riskProfile=this.risk.calibrate({mint:d.mint,now,baselineRiskPct:input.baselineRiskPct??d.risk,baselinePositionPct:input.baselinePositionPct??d.theoreticalAllocationPct,baselineTotalExposurePct:input.baselineTotalExposurePct??35});
    const pctBase=Math.max(0,finite(input.baselinePositionPct??d.theoreticalAllocationPct));
    const calibratedPct=Math.min(pctBase,riskProfile.calibratedPositionPct);
    const capital=Math.max(0,finite(input.portfolio.capital));
    const calibratedQuote=Math.min(allocationQuote,capital*calibratedPct/100);
    if(calibratedQuote<=0){blockers.push('RISK_CALIBRATION_REDUCED_ALLOCATION_TO_ZERO');stages.push({stage:'RISK_CALIBRATION',status:'BLOCK',reason:'CALIBRATED_QUOTE_ZERO'});return this.persist({id:crypto.randomUUID(),ts:now,mint:d.mint,status:'BLOCKED',stages,allocationQuote,calibratedQuote,riskProfile,blockers,liveExecutionEnabled:false});}
    stages.push({stage:'RISK_CALIBRATION',status:'PASS',reason:`V68_${riskProfile.state}_MULTIPLIER_${riskProfile.riskMultiplier.toFixed(3)}`});
    const allocation:V63AllocationRow={id:a.sourceDecisionId,candidateId:a.sourceDecisionId,mint:d.mint,strategy:'AI_SIGNAL',decision:'ALLOCATE',weight:1,requestedQuote:allocationQuote,approvedCeiling:allocationQuote,optimizedQuote:calibratedQuote,reasons:['V75_APPROVED','V68_CALIBRATED']};
    const portfolio={...input.portfolio,allocatedQuote:calibratedQuote};
    const guard=this.guard.validate({decision:d.decision,allocation,market:{...input.market,risk:Math.min(input.market.risk??d.risk,riskProfile.calibratedRiskPct)},portfolio,now});
    stages.push({stage:'PRETRADE_GUARD',status:guard.decision==='ALLOW_PAPER'?'PASS':'BLOCK',reason:guard.decision==='ALLOW_PAPER'?'ALL_PRETRADE_CHECKS_PASSED':guard.blockers.join('|')});
    if(guard.decision==='BLOCK')blockers.push(...guard.blockers);
    let simulation:V65ExecutionResult|undefined;
    if(guard.decision==='ALLOW_PAPER'){
      simulation=this.simulator.simulate(input.pool,{side:'BUY',mint:d.mint,quoteAmount:Math.min(calibratedQuote,guard.approvedQuote),maxSlippageBps:input.maxSlippageBps,externalSlippageBps:input.market.slippageBps??0,now});
      stages.push({stage:'EXECUTION_SIMULATION',status:simulation.decision==='EXECUTABLE'?'PASS':'BLOCK',reason:simulation.decision==='EXECUTABLE'?'SIMULATION_EXECUTABLE':simulation.blockers.join('|')});
      if(simulation.decision!=='EXECUTABLE')blockers.push(...simulation.blockers);
    } else stages.push({stage:'EXECUTION_SIMULATION',status:'SKIP',reason:'PRETRADE_GUARD_BLOCKED'});
    let pipeline:V69Result|undefined;
    if(!blockers.length){
      pipeline=this.pipeline.run({mint:d.mint,now,decision:d.decision,allocation,market:{...input.market,risk:Math.min(input.market.risk??d.risk,riskProfile.calibratedRiskPct)},portfolio,pool:input.pool,quoteAmount:Math.min(calibratedQuote,guard!.approvedQuote),maxSlippageBps:input.maxSlippageBps,baselineRiskPct:riskProfile.calibratedRiskPct,baselinePositionPct:calibratedPct,baselineTotalExposurePct:riskProfile.calibratedTotalExposurePct,calibrationMint:d.mint,approvedUpstream:true});
      stages.push({stage:'END_TO_END_PIPELINE',status:pipeline.outcome==='PAPER_ENTRY'?'PASS':'BLOCK',reason:pipeline.outcome==='PAPER_ENTRY'?'V69_PAPER_ENTRY_READY':pipeline.blockers.join('|')});
      if(pipeline.outcome!=='PAPER_ENTRY')blockers.push(...pipeline.blockers);
    } else stages.push({stage:'END_TO_END_PIPELINE',status:'SKIP',reason:'UPSTREAM_BRIDGE_BLOCKED'});
    const status:V76Status=blockers.length?'BLOCKED':'PAPER_ENTRY_READY';
    return this.persist({id:crypto.randomUUID(),ts:now,mint:d.mint,status,stages,allocationQuote,calibratedQuote,riskProfile,guard,simulation,pipeline,blockers:[...new Set(blockers)],liveExecutionEnabled:false});
  }
  recent(limit=100,mint?:string){const n=Math.min(500,Math.max(1,limit));return db.prepare(`SELECT * FROM v76_allocation_bridge_runs ${mint?'WHERE mint=?':''} ORDER BY ts DESC LIMIT ?`).all(...(mint?[mint,n]:[n]));}
  health(){const r=db.prepare(`SELECT COUNT(*) c,SUM(CASE WHEN status='PAPER_ENTRY_READY' THEN 1 ELSE 0 END) ready,SUM(CASE WHEN status='BLOCKED' THEN 1 ELSE 0 END) blocked FROM v76_allocation_bridge_runs`).get() as any;return {state:'RUNNING',runs:Number(r?.c||0),paperEntryReady:Number(r?.ready||0),blocked:Number(r?.blocked||0),liveExecutionEnabled:false};}
  private persist(r:V76Result){db.prepare(`INSERT INTO v76_allocation_bridge_runs VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(r.id,r.ts,r.mint,r.status,r.allocationQuote,r.calibratedQuote,r.riskProfile.id,r.guard?.id??null,r.simulation?.id??null,r.pipeline?.id??null,JSON.stringify(r.stages),JSON.stringify(r.blockers),JSON.stringify(r));return r;}
}
