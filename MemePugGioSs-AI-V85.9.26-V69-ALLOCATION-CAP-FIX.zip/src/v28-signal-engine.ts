import { V28EvaluationInput, V28Signal, V28SignalConfig, V28SignalEngine } from "./v28-types.js";

const DEFAULTS: V28SignalConfig = {
  minScore: 55,
  confirmedScore: 72,
  maxRiskScore: 65,
  minFreshness: 55,
  minConfidence: 50,
  minLiquidityScore: 20,
};

function clamp(v:number){ return Math.max(0, Math.min(100, v)); }
function round(v:number){ return Math.round(v * 100) / 100; }

export class DeterministicV28SignalEngine implements V28SignalEngine {
  constructor(private readonly cfg: V28SignalConfig = DEFAULTS) {}

  evaluate(input: V28EvaluationInput): V28Signal {
    const f = input.features;
    const blockers:string[] = [];
    const reasons:string[] = [];
    const score = round(clamp(
      f.buyPressure * .18 + f.flowMomentum * .16 + f.liquidityScore * .14 +
      f.holderScore * .10 + f.smartMoneyScore * .12 + f.freshnessScore * .10 +
      f.sampleConfidence * .08 + f.priceMomentum * .07 + f.graduationProgress * .05 - f.riskScore * .20
    ));
    const confidence = round(clamp(f.sampleConfidence * .45 + f.freshnessScore * .25 + f.liquidityScore * .15 + (100 - f.riskScore) * .15));

    if (f.riskScore > this.cfg.maxRiskScore) blockers.push("RISK_GATE");
    if (f.freshnessScore < this.cfg.minFreshness) blockers.push("STALE_DATA");
    if (f.sampleConfidence < this.cfg.minConfidence) blockers.push("LOW_SAMPLE_CONFIDENCE");
    if (f.liquidityScore < this.cfg.minLiquidityScore) blockers.push("LOW_LIQUIDITY");

    if (f.buyPressure >= 65) reasons.push("buy pressure positivo");
    if (f.flowMomentum >= 60) reasons.push("flow momentum positivo");
    if (f.smartMoneyScore >= 60) reasons.push("smart-money activity osservabile");
    if (f.graduationProgress >= 70) reasons.push("progressione bonding curve elevata");
    if (f.priceMomentum >= 60) reasons.push("momentum prezzo positivo");

    let state: V28Signal["state"] = "WATCH";
    let action: V28Signal["action"] = "OBSERVE";
    if (blockers.length) { state = "BLOCKED"; action = "NO_ACTION"; }
    else if (score >= this.cfg.confirmedScore && confidence >= this.cfg.minConfidence) { state = "CONFIRMED"; action = "PAPER_CANDIDATE"; }
    else if (score >= this.cfg.minScore) { state = "EARLY_ENTRY"; action = "PAPER_CANDIDATE"; }
    else if (score < 35) { state = "INVALIDATED"; action = "NO_ACTION"; }

    return { mint: input.mint, state, action, score, confidence, riskScore: round(clamp(f.riskScore)), freshness: round(clamp(f.freshnessScore)), reasons, blockers, features: f, generatedAt: Date.now(), source: input.source ?? "LIVE_STATE" };
  }
}

export function defaultV28Engine(){ return new DeterministicV28SignalEngine(); }
