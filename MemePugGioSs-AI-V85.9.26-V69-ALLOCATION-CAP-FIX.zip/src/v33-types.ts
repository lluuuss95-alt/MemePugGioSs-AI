import { V30PaperState } from './v30-types.js';

export type V33RecoveryStatus = 'HEALTHY' | 'RECOVERING' | 'DEGRADED' | 'FAILED';
export type V33ReplayKind = 'SNAPSHOT' | 'POSITION' | 'DECISION';

export interface V33Checkpoint {
  id: number;
  createdAt: number;
  stateHash: string;
  sourceVersion: number;
  lastEventAt: number;
}

export interface V33RecoveryReport {
  status: V33RecoveryStatus;
  checkpointId: number | null;
  replayedEvents: number;
  restoredPositions: number;
  restoredDecisions: number;
  consistencyErrors: string[];
  recoveredAt: number;
}

export interface V33RecoveredState {
  state: V30PaperState;
  checkpoint: V33Checkpoint | null;
  report: V33RecoveryReport;
}
