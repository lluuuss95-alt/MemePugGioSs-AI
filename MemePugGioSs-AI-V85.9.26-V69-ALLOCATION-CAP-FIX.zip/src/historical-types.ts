export interface HistoricalEvent {
  id:string;
  ts:number;
  slot?:number;
  mint:string;
  price?:number;
  buyVolume?:number;
  sellVolume?:number;
  liquidity?:number;
  smartMoneyVolume?:number;
  holders?:number;
  risk?:number;
  source:string;
  sourceVersion?:string;
}

export interface QuarantinedRecord {
  raw:any;
  reason:string;
}

export interface DatasetManifest {
  datasetId:string;
  version:string;
  source:string;
  sourceVersion?:string;
  createdAt:number;
  rows:number;
  quarantined:number;
  firstTs?:number;
  lastTs?:number;
  sha256:string;
}
