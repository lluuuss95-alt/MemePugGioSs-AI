import {V26DiscoveryStore} from "./v26-types.js";
import {V27GapRecovery} from "./v27-recovery.js";

export interface V27ReconcileState { mode:"STREAMING"|"RECOVERING"|"READY"|"DEGRADED"; lastSignature?:string; lastSlot?:number; recovered:number; }

export class V27DiscoveryReconciler {
  private state:V27ReconcileState={mode:"READY",recovered:0};
  constructor(private readonly recovery:V27GapRecovery, private readonly store:V26DiscoveryStore){}
  async reconcile(){
    this.state={...this.state,mode:"RECOVERING"};
    try{
      const result=await this.recovery.recover();
      this.state={mode:result.failedTransactions?"DEGRADED":"READY",lastSignature:result.newestSignature,lastSlot:result.newestSlot,recovered:this.state.recovered+result.recovered};
      return result;
    }catch(error){this.state={...this.state,mode:"DEGRADED"};throw error;}
  }
  getState(){return {...this.state};}
  tokenCount(){return this.store.all().length;}
}
