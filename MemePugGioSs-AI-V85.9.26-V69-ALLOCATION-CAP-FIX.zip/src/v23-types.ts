export interface BondingCurveState{
 mint:string;virtualTokenReserves:bigint;virtualQuoteReserves:bigint;
 realTokenReserves:bigint;realQuoteReserves:bigint;tokenTotalSupply:bigint;
 complete:boolean;slot:number;observedAt:number;
}
export interface CurveQuote{
 side:"BUY"|"SELL";inputQuote:bigint;outputTokens:bigint;
 priceNumerator:bigint;priceDenominator:bigint;priceImpactBps:bigint;
 invariant:bigint;valid:boolean;reason:string;
}
export interface PumpSwapState{
 mint:string;baseReserve:bigint;quoteVaultBalance:bigint;
 virtualQuoteReserves:bigint;effectiveQuoteReserves:bigint;
 slot:number;observedAt:number;
}
export interface MarketState{
 mint:string;venue:"BONDING_CURVE"|"PUMPSWAP"|"UNKNOWN";
 priceQuotePerToken?:bigint;priceScale?:bigint;marketCapQuote?:bigint;
 graduationProgressBps?:bigint;complete:boolean;confidence:number;
}
