import WebSocket from 'ws'; import { config } from './config.js'; import { audit } from './db.js'; import { enqueue } from './ingestion.js';
export class SolanaLogStream{
 private ws?:WebSocket; private reqId=1; private subId?:number; private closed=false; private reconnect=0;
 constructor(private readonly mention?:string){}
 start(){if(!config.rpcWs)return {enabled:false}; this.connect(); return {enabled:true};}
 stop(){this.closed=true; this.ws?.close();}
 private connect(){if(this.closed)return; this.ws=new WebSocket(config.rpcWs!); this.ws.on('open',()=>{this.reconnect=0; const params=this.mention?[{mentions:[this.mention]},{commitment:'confirmed'}]:['all',{commitment:'confirmed'}]; this.ws?.send(JSON.stringify({jsonrpc:'2.0',id:this.reqId++,method:'logsSubscribe',params}));}); this.ws.on('message',(raw)=>this.handle(String(raw))); this.ws.on('close',()=>this.retry()); this.ws.on('error',()=>{});}
 private handle(raw:string){try{const j:any=JSON.parse(raw); if(typeof j.result==='number'&&j.id){this.subId=j.result;return;} if(j.method!=='logsNotification')return; const v=j.params?.result?.value; const slot=j.params?.result?.context?.slot; const signature=v?.signature; if(!signature)return; if(this.mention) enqueue({eventId:`solana:${signature}`,mint:this.mention,source:'solana-rpc-logs',eventTime:new Date().toISOString(),slot,raw:{signature,err:v.err,logs:v.logs}}); audit(`chain:${signature}`,'CHAIN_LOG',{signature,slot,err:v.err});}catch(e){audit(`chain-parse:${Date.now()}`,'CHAIN_STREAM_ERROR',{error:String(e)});}}
 private retry(){if(this.closed)return; const delay=Math.min(30000,1000*Math.max(1,2**this.reconnect++)); setTimeout(()=>this.connect(),delay);}
}
