import {VerifiedTransaction,ProtocolObservation,ProtocolKind} from "./v21-types.js";
const KNOWN_PROGRAMS:Record<string,ProtocolKind>={
 "11111111111111111111111111111111":"SYSTEM",
 "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA":"SPL_TOKEN",
 "ATokenGPvbdGVxr1b2hvZbsiqW6dA7fF2rQp7r8x4":"ASSOCIATED_TOKEN"
};
export class TransactionProtocolVerifier{
 verify(tx:VerifiedTransaction):ProtocolObservation[]{
  return tx.programIds.map(programId=>{
   const protocol=KNOWN_PROGRAMS[programId]||"CUSTOM_PROGRAM";
   const verified=protocol!=="CUSTOM_PROGRAM";
   return {signature:tx.signature,slot:tx.slot,protocol,programId,accounts:tx.accountKeys,
    instructionCount:tx.instructions,confidence:verified?1:0.25,verified,observedAt:Date.now()};
  });
 }
}