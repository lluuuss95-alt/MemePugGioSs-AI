export type EventKind="TOKEN_ACTIVITY"|"ACCOUNT_CHANGE"|"PROGRAM_ACTIVITY"|"UNKNOWN";
export interface NormalizedMarketEvent{
 id:string; kind:EventKind; signature?:string; slot:number; observedAt:number;
 mint?:string; programId?:string; accounts:string[]; rawRef:string;
 confidence:number; decodable:boolean;
}
export interface NormalizerStats{
 received:number; accepted:number; duplicates:number; outOfOrder:number; unknown:number;
 lastSlot?:number; queueDepth:number;
}
