import crypto from 'node:crypto';
import { db } from './db.js';
import { V52AutonomousPaperLoop, V52MarketTick, V52Result, V52Position } from './v52-autonomous-paper-loop.js';
import type { V51Decision } from './v51-decision-engine.js';

export type V53SupervisorState='RUNNING'|'DEGRADED'|'HALTED';
export interface V53Config {
  heartbeatMs:number;
  maxTickAgeMs:number;
  emergencyRisk:number;
  maxConsecutiveErrors:number;
  maxPositions:number;
  eventCooldownMs:number;
}
export interface V53Tick extends V52MarketTick { risk?:number; source?:string; }
export interface V53Result extends V52Result { supervisorState:V53SupervisorState; monitoredAt:number; stale:boolean; emergency?:boolean; }
export interface V53Health { state:V53SupervisorState; lastTickAt:number|null; lastRunAt:number|null; ticks:number; exits:number; errors:number; consecutiveErrors:number; monitoredPositions:number; liveExecutionEnabled:false; }

export const defaultV53Config:V53Config=Object.freeze({heartbeatMs:1000,maxTickAgeMs:5000,emergencyRisk:75,maxConsecutiveErrors:3,maxPositions:10,eventCooldownMs:1000});

export class V53TradeSupervisor {
  private stateValue:V53SupervisorState='RUNNING';
  private lastTickAt:number|null=null;
  private lastRunAt:number|null=null;
  private ticks=0;
  private exits=0;
  private errors=0;
  private consecutiveErrors=0;
  private lastEvents=new Map<string,number>();
  private latestDecisions=new Map<string,V51Decision>();
  private latestTicks=new Map<string,V53Tick>();

  constructor(private readonly loop=new V52AutonomousPaperLoop(), private readonly cfg:V53Config=defaultV53Config){
    this.ensureSchema();
    this.restoreHealth();
  }

  private ensureSchema(){
    db.exec(`CREATE TABLE IF NOT EXISTS v53_supervisor_events(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT,action TEXT NOT NULL,reason TEXT NOT NULL,state TEXT NOT NULL,latency_ms INTEGER NOT NULL,details_json TEXT NOT NULL)`);
    db.exec(`CREATE TABLE IF NOT EXISTS v53_supervisor_health(id INTEGER PRIMARY KEY CHECK(id=1),state TEXT NOT NULL,last_tick_at INTEGER,last_run_at INTEGER,ticks INTEGER NOT NULL,exits INTEGER NOT NULL,errors INTEGER NOT NULL,consecutive_errors INTEGER NOT NULL)`);
  }

  private restoreHealth(){
    const r=db.prepare(`SELECT * FROM v53_supervisor_health WHERE id=1`).get() as any;
    if(r){ this.stateValue=r.state as V53SupervisorState; this.lastTickAt=r.last_tick_at??null; this.lastRunAt=r.last_run_at??null; this.ticks=Number(r.ticks||0); this.exits=Number(r.exits||0); this.errors=Number(r.errors||0); this.consecutiveErrors=Number(r.consecutive_errors||0); }
  }

  registerDecision(d:V51Decision){
    if(!d || !d.mint) return;
    this.latestDecisions.set(d.mint,d);
  }

  registerDecisions(ds:V51Decision[]){ for(const d of ds)this.registerDecision(d); }

  health():V53Health{
    return {state:this.stateValue,lastTickAt:this.lastTickAt,lastRunAt:this.lastRunAt,ticks:this.ticks,exits:this.exits,errors:this.errors,consecutiveErrors:this.consecutiveErrors,monitoredPositions:this.loop.state().openPositions.length,liveExecutionEnabled:false};
  }

  state(){ return {supervisor:this.health(),portfolio:this.loop.state()}; }

  tick(tick:V53Tick, now=tick.timestamp):V53Result{
    this.lastRunAt=now;
    try{
      this.validateTick(tick,now);
      this.latestTicks.set(tick.mint,tick);
      this.lastTickAt=tick.timestamp;
      this.ticks++;
      const current=this.loop.state().openPositions.find((p:V52Position)=>p.mint===tick.mint);
      if(!current && this.loop.state().openPositions.length>=this.cfg.maxPositions){
        const r=this.syntheticResult('BLOCKED',tick,'MAX_MONITORED_POSITIONS',now);
        this.record(tick,now,r.action,r.reason,now-tick.timestamp,{blocked:true});
        this.persistHealth();
        return r;
      }
      const d=this.continuationDecision(tick,now);
      const emergency=(tick.risk??0)>=this.cfg.emergencyRisk;
      const signalInvalidated=Boolean(tick.signalInvalidated)||emergency;
      const managedTick={...tick,signalInvalidated,risk:tick.risk};
      const result=this.loop.evaluate(d,managedTick,now);
      const stale=now-tick.timestamp>this.cfg.maxTickAgeMs;
      if(result.action==='EXIT_PAPER') this.exits++;
      this.consecutiveErrors=0;
      if(this.stateValue!=='HALTED') this.stateValue=stale?'DEGRADED':'RUNNING';
      this.record(tick,now,result.action,result.reason,now-tick.timestamp,{emergency,stale,source:tick.source??'unknown'});
      this.persistHealth();
      return {...result,supervisorState:this.stateValue,monitoredAt:now,stale,emergency};
    }catch(err){
      this.errors++; this.consecutiveErrors++;
      if(this.consecutiveErrors>=this.cfg.maxConsecutiveErrors)this.stateValue='HALTED'; else this.stateValue='DEGRADED';
      this.persistHealth();
      const msg=err instanceof Error?err.message:'SUPERVISOR_ERROR';
      const fallback=this.syntheticResult('BLOCKED',tick,msg,now);
      this.record(tick,now,'ERROR',msg,now-tick.timestamp,{error:true});
      return {...fallback,supervisorState:this.stateValue,monitoredAt:now,stale:true,emergency:false};
    }
  }

  heartbeat(now=Date.now()):V53Result[]{
    this.lastRunAt=now;
    const positions=this.loop.state().openPositions;
    const out:V53Result[]=[];
    for(const p of positions){
      const t=this.latestTicks.get(p.mint);
      if(!t) continue;
      out.push(this.tick({...t,timestamp:t.timestamp},now));
    }
    if(this.stateValue==='RUNNING' && out.length===0 && positions.length>0 && this.lastTickAt!==null && now-this.lastTickAt>this.cfg.maxTickAgeMs){
      this.stateValue='DEGRADED';
      this.persistHealth();
    }
    return out;
  }

  resetHalt(){ this.stateValue='RUNNING'; this.consecutiveErrors=0; this.persistHealth(); }

  recentEvents(limit=100){return db.prepare(`SELECT * FROM v53_supervisor_events ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}

  private continuationDecision(t:V53Tick,now:number):V51Decision{
    const prior=this.latestDecisions.get(t.mint);
    if(prior) return {...prior,id:prior.id,ts:now,action:'ENTER_PAPER',liveExecutionEnabled:false};
    return {id:crypto.randomUUID(),ts:now,mint:t.mint,signature:'SUPERVISOR',action:'ENTER_PAPER',state:'DECIDED',score:100,confidence:100,risk:t.risk??0,theoreticalAllocationPct:0,reasons:['POSITION_CONTINUATION_SUPERVISION'],blockers:[],invalidationConditions:['MARKET_DATA_INVALID','LIQUIDITY_LOST','RISK_LIMIT_BREACHED'],liveExecutionEnabled:false};
  }

  private validateTick(t:V53Tick,now:number){
    if(!t.mint)throw new Error('MISSING_MINT');
    if(!Number.isFinite(t.price)||t.price<=0)throw new Error('INVALID_PRICE');
    if(!Number.isFinite(t.liquidity)||t.liquidity<0)throw new Error('INVALID_LIQUIDITY');
    if(!Number.isFinite(t.timestamp)||t.timestamp<=0)throw new Error('INVALID_TIMESTAMP');
    if(now<t.timestamp)throw new Error('FUTURE_TICK');
  }

  private syntheticResult(action:'BLOCKED',t:V53Tick,reason:string,now:number):V53Result{
    const s=this.loop.state(); return {action,mint:t.mint,realizedPnl:0,unrealizedPnl:s.unrealizedPnl,cash:s.cash,equity:s.equity,reason,liveExecutionEnabled:false,supervisorState:this.stateValue,monitoredAt:now,stale:true};
  }

  private record(t:V53Tick,now:number,action:string,reason:string,latency:number,details:Record<string,unknown>){
    const key=`${t.mint}:${action}:${reason}`; const last=this.lastEvents.get(key)??0;
    if(now-last<this.cfg.eventCooldownMs)return;
    this.lastEvents.set(key,now);
    db.prepare(`INSERT INTO v53_supervisor_events(id,ts,mint,action,reason,state,latency_ms,details_json) VALUES(?,?,?,?,?,?,?,?)`).run(crypto.randomUUID(),now,t.mint,action,reason,this.stateValue,Math.max(0,Math.round(latency)),JSON.stringify({liveExecutionEnabled:false,...details}));
  }

  private persistHealth(){db.prepare(`INSERT OR REPLACE INTO v53_supervisor_health(id,state,last_tick_at,last_run_at,ticks,exits,errors,consecutive_errors) VALUES(1,?,?,?,?,?,?,?)`).run(this.stateValue,this.lastTickAt,this.lastRunAt,this.ticks,this.exits,this.errors,this.consecutiveErrors);}
}

export const V53_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV53Safe(){if(!V53_SAFETY.shadowOnly||V53_SAFETY.signingEnabled||V53_SAFETY.privateKeyAccess||V53_SAFETY.broadcastEnabled||V53_SAFETY.liveExecutionAllowed)throw new Error('V53_SAFETY_INVARIANT_FAILED');}
