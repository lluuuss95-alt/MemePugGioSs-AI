export type ProtocolKind="UNKNOWN"|"SPL_TOKEN"|"SYSTEM"|"ASSOCIATED_TOKEN"|"CUSTOM_PROGRAM";
export interface TransactionFetchConfig{rpcUrl:string;commitment:"confirmed"|"finalized";maxSupportedTransactionVersion:number;encoding:"json"|"jsonParsed";}
export interface VerifiedTransaction{
 signature:string;slot:number;blockTime:number|null;err:any;fee:number|null;
 accountKeys:string[];programIds:string[];instructions:number;innerInstructions:number;
 raw:any;
}
export interface ProtocolObservation{
 signature:string;slot:number;protocol:ProtocolKind;programId?:string;
 accounts:string[];instructionCount:number;confidence:number;verified:boolean;
 observedAt:number;
}
