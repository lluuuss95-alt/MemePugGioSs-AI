import { V28Signal } from "./v28-types.js";
import { V29RankingConfig, V29RankedSignal, V29RankingResult } from "./v29-types.js";

const DEFAULTS: V29RankingConfig = {
  maxResults: 20,
  minTopScore: 60,
  minConfidence: 55,
  maxRiskScore: 65,
  minLiquidityScore: 25,
  freshnessHalfLifeMs: 5 * 60_000,
  diversityPenalty: 4,
};

const clamp = (v:number) => Math.max(0, Math.min(100, v));
const round = (v:number) => Math.round(v * 100) / 100;

function freshnessDecay(signal: V28Signal, now:number, halfLife:number): number {
  const age = Math.max(0, now - signal.generatedAt);
  return Math.pow(0.5, age / Math.max(1, halfLife));
}

function candidateComposite(signal: V28Signal, now:number, cfg:V29RankingConfig): number {
  const f = signal.features;
  const decay = freshnessDecay(signal, now, cfg.freshnessHalfLifeMs);
  const base = signal.score * 0.55 + signal.confidence * 0.18 + f.liquidityScore * 0.10 +
    f.smartMoneyScore * 0.08 + f.graduationProgress * 0.04 + (100 - signal.riskScore) * 0.05;
  return round(clamp(base * (0.75 + 0.25 * decay)));
}

export class V29SignalRankingEngine {
  constructor(private readonly cfg:V29RankingConfig = DEFAULTS) {}

  rank(signals: V28Signal[], now = Date.now()): V29RankingResult {
    const ranked = signals
      .filter(s => !!s.mint)
      .map((s): V29RankedSignal => {
        const compositeScore = candidateComposite(s, now, this.cfg);
        let band:V29RankedSignal["band"] = "EXCLUDED";
        if (s.state === "BLOCKED" || s.blockers.length) band = "BLOCKED";
        else if (compositeScore >= this.cfg.minTopScore && s.confidence >= this.cfg.minConfidence &&
                 s.riskScore <= this.cfg.maxRiskScore && s.features.liquidityScore >= this.cfg.minLiquidityScore &&
                 (s.state === "CONFIRMED" || s.state === "EARLY_ENTRY")) band = "TOP_SIGNAL";
        else if (s.state === "WATCH") band = "WATCHLIST";
        return { rank:0, mint:s.mint, state:s.state, band, compositeScore, signalScore:s.score,
          confidence:s.confidence, riskScore:s.riskScore, freshness:s.freshness,
          liquidityScore:s.features.liquidityScore, smartMoneyScore:s.features.smartMoneyScore,
          reasons:s.reasons, blockers:s.blockers, generatedAt:s.generatedAt };
      })
      .sort((a,b) => b.compositeScore - a.compositeScore || b.confidence - a.confidence || a.riskScore - b.riskScore || a.mint.localeCompare(b.mint));

    const selected:string[] = [];
    for (const item of ranked) {
      if (item.band !== "TOP_SIGNAL") continue;
      const collision = selected.some(m => m.slice(0,8) === item.mint.slice(0,8));
      if (collision) item.compositeScore = round(clamp(item.compositeScore - this.cfg.diversityPenalty));
      selected.push(item.mint);
    }
    ranked.sort((a,b) => b.compositeScore - a.compositeScore || b.confidence - a.confidence || a.mint.localeCompare(b.mint));
    ranked.forEach((r,i) => r.rank = i + 1);

    const topSignals = ranked.filter(r => r.band === "TOP_SIGNAL").slice(0, this.cfg.maxResults);
    const watchlist = ranked.filter(r => r.band === "WATCHLIST").slice(0, this.cfg.maxResults);
    const blocked = ranked.filter(r => r.band === "BLOCKED").slice(0, this.cfg.maxResults);
    const excluded = ranked.filter(r => r.band === "EXCLUDED").slice(0, this.cfg.maxResults);
    return { ranked, topSignals, watchlist, blocked, excluded, generatedAt: now };
  }
}
