export const V26_SAFETY = Object.freeze({mode:"SHADOW",liveTrading:false,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,autoPromotion:false});
export function assertV26Shadow(){if(V26_SAFETY.liveTrading||V26_SAFETY.signingEnabled||V26_SAFETY.privateKeyAccess||V26_SAFETY.broadcastEnabled||V26_SAFETY.autoPromotion)throw new Error("V26_SAFETY_VIOLATION")}
