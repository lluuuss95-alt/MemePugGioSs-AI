import { db } from './db.js';
import { V35ReputationConfig, V35TraderReputation, V35Window, V35WindowMetrics } from './v35-types.js';

const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));
const now=()=>Date.now();

export const defaultV35Config:V35ReputationConfig={
  minTrades7d:8,
  minTrades30d:20,
  minTradesAll:30,
  minClosedTrades:8,
  minSampleConfidence:60,
  minReputationScore:62,
  maxRiskScore:48,
  maxTokenConcentrationPct:85,
  minConsistencyScore:55
};

type TradeRow={mint:string,side:string,source:string,quote_amount:number,base_amount:number,executed_at:number};

function metrics(rows:TradeRow[], window:V35Window, minTrades:number):V35WindowMetrics {
  const buys=new Map<string,{qty:number,cost:number,openedAt:number}>();
  let closed=0,wins=0,losses=0,pnl=0,gp=0,gl=0,totalHold=0;
  const tokenVolume=new Map<string,number>();
  for(const r of rows){
    const q=Math.abs(Number(r.base_amount)||0), quote=Math.abs(Number(r.quote_amount)||0);
    tokenVolume.set(r.mint,(tokenVolume.get(r.mint)||0)+quote);
    if(r.side==='BUY'){
      const x=buys.get(r.mint)||{qty:0,cost:0,openedAt:r.executed_at};
      x.qty+=q; x.cost+=quote; x.openedAt=Math.min(x.openedAt,r.executed_at); buys.set(r.mint,x);
    } else if(r.side==='SELL') {
      const x=buys.get(r.mint); if(!x||x.qty<=0||q<=0) continue;
      const sold=Math.min(x.qty,q), avg=x.cost/x.qty;
      const realized=(quote*(sold/q))-avg*sold;
      pnl+=realized; closed++; totalHold+=Math.max(0,r.executed_at-x.openedAt);
      if(realized>=0){wins++;gp+=realized}else{losses++;gl+=-realized}
      x.qty-=sold; x.cost-=avg*sold; if(x.qty<=1e-12) buys.delete(r.mint);
    }
  }
  // Closed-trade equity path reconstructed from chronological sells.
  let eq=0,peak=0,maxDd=0;
  const lots=new Map<string,{qty:number,cost:number}>();
  for(const r of rows){
    const q=Math.abs(Number(r.base_amount)||0), quote=Math.abs(Number(r.quote_amount)||0);
    if(r.side==='BUY'){const x=lots.get(r.mint)||{qty:0,cost:0};x.qty+=q;x.cost+=quote;lots.set(r.mint,x);continue;}
    const x=lots.get(r.mint); if(!x||x.qty<=0||q<=0) continue;
    const sold=Math.min(x.qty,q), avg=x.cost/x.qty; eq+=(quote*(sold/q))-avg*sold; peak=Math.max(peak,eq); if(peak>0) maxDd=Math.max(maxDd,(peak-eq)/peak*100);
    x.qty-=sold;x.cost-=avg*sold;if(x.qty<=1e-12)lots.delete(r.mint);
  }
  const totalVol=[...tokenVolume.values()].reduce((a,b)=>a+b,0);
  const topVol=[...tokenVolume.values()].sort((a,b)=>b-a)[0]||0;
  const concentration=totalVol?topVol/totalVol*100:0;
  const total=rows.length;
  const pump=rows.filter(r=>r.source==='VERIFIED_PUMP').length;
  const ps=rows.filter(r=>r.source==='VERIFIED_PUMPSWAP').length;
  const pf=gl>0?gp/gl:(gp>0?3:0);
  const winRate=closed?wins/closed*100:0;
  const sample=clamp(total/Math.max(minTrades,1)*100);
  const consistency=clamp(winRate*0.65+clamp(pf/3*100)*0.35);
  const risk=clamp(maxDd*0.85+Math.max(0,concentration-55)*0.35+Math.max(0,50-consistency)*0.25);
  return {window,trades:total,closedTrades:closed,wins,losses,realizedPnlQuote:pnl,grossProfitQuote:gp,grossLossQuote:gl,winRate,profitFactor:pf,maxDrawdownPct:maxDd,avgHoldMs:closed?totalHold/closed:0,uniqueTokens:new Set(rows.map(r=>r.mint)).size,tokenConcentrationPct:concentration,pumpSharePct:total?pump/total*100:0,pumpSwapSharePct:total?ps/total*100:0,sampleConfidence:sample};
}

export class V35ReputationEngine {
  constructor(private cfg:V35ReputationConfig=defaultV35Config){this.ensureSchema()}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v35_reputation(wallet TEXT PRIMARY KEY,state TEXT NOT NULL,reputation_score REAL NOT NULL,consistency_score REAL NOT NULL,risk_score REAL NOT NULL,sample_quality_score REAL NOT NULL,specialization_score REAL NOT NULL,windows_json TEXT NOT NULL,flags_json TEXT NOT NULL,reasons_json TEXT NOT NULL,updated_at INTEGER NOT NULL); CREATE INDEX IF NOT EXISTS idx_v35_score ON v35_reputation(reputation_score DESC);`)}
  evaluate(wallet:string):V35TraderReputation{
    const all=db.prepare(`SELECT mint,side,source,quote_amount,base_amount,executed_at FROM v34_trades WHERE wallet=? ORDER BY executed_at ASC`).all(wallet) as TradeRow[];
    const cutoff=(ms:number)=>now()-ms;
    const windows:V35WindowMetrics[]=[
      metrics(all.filter(r=>r.executed_at>=cutoff(7*86400000)),'7D',this.cfg.minTrades7d),
      metrics(all.filter(r=>r.executed_at>=cutoff(30*86400000)),'30D',this.cfg.minTrades30d),
      metrics(all.filter(r=>r.executed_at>=cutoff(90*86400000)),'90D',this.cfg.minTrades30d),
      metrics(all,'ALL',this.cfg.minTradesAll)
    ];
    const base=windows[1].trades?windows[1]:windows[3];
    const sampleQuality=clamp((base.sampleConfidence*0.55)+(clamp(base.closedTrades/Math.max(this.cfg.minClosedTrades,1)*100)*0.45));
    const consistency=clamp(windows.reduce((s,w)=>s+(w.closedTrades?clamp(w.winRate*0.65+clamp(w.profitFactor/3*100)*0.35):0),0)/windows.filter(w=>w.closedTrades>0).length||0);
    const risk=clamp(windows.reduce((s,w)=>s+w.maxDrawdownPct*0.7+Math.max(0,w.tokenConcentrationPct-55)*0.3,0)/windows.length);
    const pumpSpec=clamp(Math.max(base.pumpSharePct,base.pumpSwapSharePct));
    const specialization=clamp(pumpSpec*0.8 + (base.uniqueTokens>=5?20:base.uniqueTokens*4));
    const reputation=clamp(consistency*0.4 + (100-risk)*0.25 + sampleQuality*0.2 + specialization*0.15);
    const flags:string[]=[]; const reasons:string[]=[];
    if(base.trades<this.cfg.minTrades30d && all.length<this.cfg.minTradesAll) flags.push('LOW_SAMPLE');
    if(base.tokenConcentrationPct>this.cfg.maxTokenConcentrationPct) flags.push('HIGH_TOKEN_CONCENTRATION');
    if(base.maxDrawdownPct>20) flags.push('HIGH_DRAWDOWN');
    if(base.avgHoldMs<30000 && base.trades>100) flags.push('VERY_HIGH_TRADE_FREQUENCY');
    if(base.pumpSharePct+base.pumpSwapSharePct<20) flags.push('LOW_PUMP_SPECIALIZATION');
    if(sampleQuality<this.cfg.minSampleConfidence) reasons.push('INSUFFICIENT_SAMPLE_CONFIDENCE');
    if(consistency<this.cfg.minConsistencyScore) reasons.push('LOW_CROSS_WINDOW_CONSISTENCY');
    if(risk>this.cfg.maxRiskScore) reasons.push('HIGH_RISK_SCORE');
    if(reputation<this.cfg.minReputationScore) reasons.push('LOW_REPUTATION_SCORE');
    let state:V35TraderReputation['state']='QUALIFIED';
    if(all.length<this.cfg.minTradesAll && base.trades<this.cfg.minTrades30d) state='INSUFFICIENT_DATA';
    else if(flags.includes('HIGH_DRAWDOWN') || risk>this.cfg.maxRiskScore*1.35) state='BLOCKED';
    else if(reasons.length || reputation<this.cfg.minReputationScore) state='WATCH';
    const out={wallet,state,reputationScore:reputation,consistencyScore:consistency,riskScore:risk,sampleQualityScore:sampleQuality,specializationScore:specialization,windows,flags,reasons,updatedAt:now()};
    db.prepare(`INSERT INTO v35_reputation(wallet,state,reputation_score,consistency_score,risk_score,sample_quality_score,specialization_score,windows_json,flags_json,reasons_json,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(wallet) DO UPDATE SET state=excluded.state,reputation_score=excluded.reputation_score,consistency_score=excluded.consistency_score,risk_score=excluded.risk_score,sample_quality_score=excluded.sample_quality_score,specialization_score=excluded.specialization_score,windows_json=excluded.windows_json,flags_json=excluded.flags_json,reasons_json=excluded.reasons_json,updated_at=excluded.updated_at`).run(wallet,state,reputation,consistency,risk,sampleQuality,specialization,JSON.stringify(windows),JSON.stringify(flags),JSON.stringify(reasons),out.updatedAt);
    return out;
  }
  evaluateAll(){const wallets=db.prepare(`SELECT wallet FROM v34_traders`).all() as {wallet:string}[];return wallets.map(x=>this.evaluate(x.wallet));}
  get(wallet:string){const row=db.prepare(`SELECT * FROM v35_reputation WHERE wallet=?`).get(wallet) as any; if(!row) return this.evaluate(wallet); return {...row,reputationScore:row.reputation_score,consistencyScore:row.consistency_score,riskScore:row.risk_score,sampleQualityScore:row.sample_quality_score,specializationScore:row.specialization_score,windows:JSON.parse(row.windows_json),flags:JSON.parse(row.flags_json),reasons:JSON.parse(row.reasons_json),updatedAt:row.updated_at} as V35TraderReputation;}
  top(limit=20){return this.evaluateAll().sort((a,b)=>b.reputationScore-a.reputationScore||b.sampleQualityScore-a.sampleQualityScore||a.wallet.localeCompare(b.wallet)).slice(0,Math.min(100,Math.max(1,limit)));}
}
