import {V25Health, V25LiveState} from "./v25-types.js";

export interface V25HomeFeed {
  mode: "PAPER" | "SHADOW";
  market: {mint:string; venue:string; priceQuotePerBaseUnit:string; marketCapQuote?:string; liquidityQuote?:string; stale:boolean; coherent:boolean}[];
  newTokens: {mint:string; venue:string; progressBps?:string; complete:boolean}[];
  system: {rpc:"READY"|"DEGRADED"|"OFFLINE"; websocket:V25Health["websocket"]; subscriptions:number; staleAccounts:number};
}

export function toHomeFeed(states: V25LiveState[], health: V25Health, rpcReady = true): V25HomeFeed {
  return {
    mode:"PAPER",
    market:states.map(s => ({mint:s.mint,venue:s.venue,priceQuotePerBaseUnit:`${s.priceQuotePerBaseUnit.numerator}/${s.priceQuotePerBaseUnit.denominator}`,marketCapQuote:s.marketCapQuote?.toString(),liquidityQuote:s.liquidityQuote?.toString(),stale:s.stale,coherent:s.coherent})),
    newTokens:states.map(s => ({mint:s.mint,venue:s.venue,progressBps:s.graduationProgressBps?.toString(),complete:s.complete})),
    system:{rpc:rpcReady ? "READY" : "OFFLINE",websocket:health.websocket,subscriptions:health.subscriptions,staleAccounts:health.staleAccounts},
  };
}
