export interface V39AnalyticsSummary {
  startingCapital:number;
  currentEquity:number;
  realizedPnl:number;
  unrealizedPnl:number;
  netPnl:number;
  returnPct:number;
  drawdownPct:number;
  trades:number;
  wins:number;
  losses:number;
  winRate:number;
  fees:number;
  slippageCost:number;
  activeTraders:number;
  updatedAt:number;
}
export interface V39EquityPoint { ts:number; equity:number; pnl:number; returnPct:number; }
export interface V39TraderAnalytics {
  wallet:string; startingCapital:number; currentEquity:number; netPnl:number; returnPct:number;
  originalRealizedPnl:number; copyRealizedPnl:number; copyUnrealizedPnl:number;
  trades:number; wins:number; losses:number; winRate:number; drawdownPct:number;
  fees:number; slippageCost:number; avgLatencyMs:number; copiedSignals:number; blockedSignals:number;
}
export interface V39AnalyticsReport { summary:V39AnalyticsSummary; equityCurve:V39EquityPoint[]; traders:V39TraderAnalytics[]; generatedAt:number; }
