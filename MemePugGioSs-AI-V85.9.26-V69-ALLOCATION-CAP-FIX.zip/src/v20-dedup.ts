export class EventDeduplicator{
 private seen=new Set<string>();
 constructor(private maxEntries=100000){}
 accept(id:string){if(this.seen.has(id))return false;this.seen.add(id);if(this.seen.size>this.maxEntries){const oldest=this.seen.values().next().value; if(oldest!==undefined)this.seen.delete(oldest);}return true}
 size(){return this.seen.size}
}
