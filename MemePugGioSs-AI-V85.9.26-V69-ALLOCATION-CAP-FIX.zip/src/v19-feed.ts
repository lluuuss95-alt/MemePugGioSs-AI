import {FeedConfig,FeedHealth,FeedStatus,SolanaLogEvent} from "./v19-types.js";
type Listener=(e:SolanaLogEvent)=>void;
export class SolanaRealtimeFeed{
 private ws:any=null;private status:FeedStatus="DISCONNECTED";private timer:any;private attempt=0;private stopped=false;private listeners:Listener[]=[];
 private health:FeedHealth={status:"DISCONNECTED",reconnects:0,droppedEvents:0,queueDepth:0};
 constructor(private cfg:FeedConfig,private WS:any=(globalThis as any).WebSocket){}
 onEvent(l:Listener){this.listeners.push(l);return()=>this.listeners=this.listeners.filter(x=>x!==l)}
 getHealth(){return {...this.health,status:this.status}}
 connect(){if(this.stopped||!this.WS)return;this.status="CONNECTING";this.health.status="CONNECTING";
  try{this.ws=new this.WS(this.cfg.wsUrl);this.ws.onopen=()=>this.open();this.ws.onmessage=(e:any)=>this.message(String(e.data));this.ws.onerror=()=>this.fail("websocket error");this.ws.onclose=()=>this.close()}catch(e:any){this.fail(e?.message||"connection failed")}}
 stop(){this.stopped=true;this.status="STOPPED";this.health.status="STOPPED";if(this.timer)clearTimeout(this.timer);try{this.ws?.close()}catch{}}
 private open(){this.status="CONNECTED";this.health.status="CONNECTED";this.health.connectedAt=Date.now();this.attempt=0;const params=this.cfg.mentions?[{mentions:[this.cfg.mentions]},{commitment:this.cfg.commitment}]:["all",{commitment:this.cfg.commitment}];this.ws.send(JSON.stringify({jsonrpc:"2.0",id:1,method:"logsSubscribe",params}))}
 private message(raw:string){let m:any;try{m=JSON.parse(raw)}catch{return}if(m.method!=="logsNotification")return;const v=m.params?.result?.value,s=m.params?.result?.context?.slot;if(!v||typeof s!=="number")return;const e={signature:String(v.signature),slot:s,err:v.err??null,logs:Array.isArray(v.logs)?v.logs:[],receivedAt:Date.now()};this.health.lastEventAt=e.receivedAt;for(const l of this.listeners)l(e)}
 private fail(x:string){this.health.lastError=x;this.status="DEGRADED";this.health.status="DEGRADED"}
 private close(){if(this.stopped)return;this.status="DEGRADED";this.health.status="DEGRADED";this.health.reconnects++;const d=Math.min(this.cfg.reconnectMaxMs,this.cfg.reconnectBaseMs*Math.pow(2,this.attempt++));this.timer=setTimeout(()=>this.connect(),d)}
}