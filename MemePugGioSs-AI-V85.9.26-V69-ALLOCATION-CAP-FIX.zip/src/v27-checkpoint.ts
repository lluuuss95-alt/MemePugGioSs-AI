import {V27Checkpoint, V27CheckpointStore} from "./v27-types.js";

export class InMemoryV27CheckpointStore implements V27CheckpointStore {
  private value: V27Checkpoint = {updatedAt: 0};
  load(){ return {...this.value}; }
  save(checkpoint: V27Checkpoint){ this.value = {...checkpoint}; }
}

export interface V27SqlLike { exec(sql:string):void; prepare(sql:string):{run(...args:any[]):any; get(...args:any[]):any}; }

export class V27SqliteCheckpointStore implements V27CheckpointStore {
  private readonly getStmt;
  private readonly saveStmt;
  constructor(private readonly db: V27SqlLike){
    db.exec(`CREATE TABLE IF NOT EXISTS v27_checkpoints (id INTEGER PRIMARY KEY CHECK(id=1), last_signature TEXT, last_slot INTEGER, updated_at INTEGER NOT NULL);`);
    this.getStmt = db.prepare(`SELECT last_signature,last_slot,updated_at FROM v27_checkpoints WHERE id=1`);
    this.saveStmt = db.prepare(`INSERT INTO v27_checkpoints(id,last_signature,last_slot,updated_at) VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET last_signature=excluded.last_signature,last_slot=excluded.last_slot,updated_at=excluded.updated_at`);
  }
  load(){
    const row:any = this.getStmt.get();
    return row ? {lastSignature:row.last_signature??undefined,lastSlot:row.last_slot==null?undefined:Number(row.last_slot),updatedAt:Number(row.updated_at)} : {updatedAt:0};
  }
  save(c:V27Checkpoint){ this.saveStmt.run(c.lastSignature??null,c.lastSlot??null,c.updatedAt); }
}
