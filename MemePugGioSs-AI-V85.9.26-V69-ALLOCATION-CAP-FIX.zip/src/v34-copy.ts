import { V34CopyCandidate, V34DiscoveryConfig, V34TradeObservation } from './v34-types.js';
import { V34TraderDiscovery } from './v34-discovery.js';

export function toCopyCandidate(t:V34TradeObservation, discovery:V34TraderDiscovery, cfg:V34DiscoveryConfig):V34CopyCandidate {
  const ranked=discovery.ranking().find(x=>x.wallet===t.wallet);
  const latency=Math.max(0,t.observedAt-t.executedAt);
  const reasons:string[]=[];
  if(!ranked) reasons.push('TRADER_NOT_PROFILED');
  if(ranked && ranked.reasons.length) reasons.push(...ranked.reasons);
  if(t.confidence<cfg.minTradeConfidence) reasons.push('LOW_TRADE_CONFIDENCE');
  if(latency>cfg.maxLatencyMs) reasons.push('HIGH_LATENCY');
  const eligible=Boolean(ranked && ranked.reasons.length===0 && t.verified && t.confidence>=cfg.minTradeConfidence && latency<=cfg.maxLatencyMs);
  return {wallet:t.wallet,signature:t.signature,mint:t.mint,side:t.side,source:t.source,detectedAt:t.observedAt,latencyMs:latency,confidence:t.confidence,eligible,blockedReason:eligible?undefined:reasons.join('|')||'BLOCKED'};
}
