import crypto from 'node:crypto';
import {V26TokenDiscovery} from './v26-types.js';
import {V48Candidate} from './v48-ultra-discovery.js';

export type V49Band='DEEP_ANALYSIS'|'WATCH'|'REJECTED';
export interface V49Config {deepThreshold:number;watchThreshold:number;maxLatencyMs:number;}
export interface V49Score {
  id:string; mint:string; signature:string; score:number; confidence:number; band:V49Band;
  metadataScore:number; creatorSignal:number; launchQuality:number; freshnessScore:number;
  reasons:string[]; blockers:string[]; generatedAt:number; latencyMs:number; needsDeepAnalysis:boolean;
  liveExecutionEnabled:false;
}
export const defaultV49Config:V49Config={deepThreshold:70,watchThreshold:45,maxLatencyMs:2500};
const clamp=(n:number)=>Math.max(0,Math.min(100,n));
const round=(n:number)=>Math.round(n*100)/100;

/**
 * V49 is an instant first-pass score. It intentionally does NOT infer profitability,
 * rug probability, or future price direction from token names. Economic features are
 * supplied later by the deep on-chain/market intelligence pipeline.
 */
export class V49InstantScoringEngine {
  constructor(private readonly cfg:V49Config=defaultV49Config){}
  score(candidate:V48Candidate,now=Date.now()):V49Score{
    const t=candidate.token;
    const reasons:string[]=[]; const blockers:string[]=[];
    const name=!!t.name?.trim(), symbol=!!t.symbol?.trim(), uri=!!t.uri?.trim(), creator=!!t.creator?.trim();
    const metadataScore=clamp((name?30:0)+(symbol?20:0)+(uri?20:0)+(t.quoteMint?10:0)+(t.bondingCurve?20:0));
    const creatorSignal=creator?70:0;
    const launchQuality=clamp((candidate.priority==='P0'?70:45)+(t.mayhemMode?0:10)+(t.holderReward?5:0));
    const age=Math.max(0,now-t.detectedAt);
    const freshnessScore=clamp(100-(age/1000)*8);
    const latencyPenalty=Math.max(0,candidate.verificationLatencyMs-this.cfg.maxLatencyMs)/50;
    const score=round(clamp(metadataScore*.35+creatorSignal*.15+launchQuality*.20+freshnessScore*.20+(candidate.action==='DEEP_ANALYSIS'?10:0)-latencyPenalty));
    const confidence=round(clamp(metadataScore*.4+freshnessScore*.3+(creator?20:0)+(candidate.priority==='P0'?10:0)));
    if(!t.bondingCurve||!t.mint) blockers.push('ONCHAIN_IDENTIFIERS_MISSING');
    if(!creator) reasons.push('CREATOR_NOT_PRESENT_IN_CREATE_DATA');
    if(!uri) reasons.push('METADATA_URI_MISSING');
    if(candidate.verificationLatencyMs>this.cfg.maxLatencyMs) reasons.push('VERIFICATION_LATENCY_HIGH');
    if(t.mayhemMode) reasons.push('MAYHEM_MODE_FLAG_PRESENT');
    if(t.holderReward) reasons.push('HOLDER_REWARD_FLAG_PRESENT');
    if(candidate.priority==='P0') reasons.push('VERIFIED_CREATE_WITH_COMPLETE_METADATA');
    else reasons.push('VERIFIED_CREATE_REQUIRES_WATCH');
    let band:V49Band='WATCH';
    if(blockers.length) band='REJECTED';
    else if(score>=this.cfg.deepThreshold && confidence>=55) band='DEEP_ANALYSIS';
    else if(score<this.cfg.watchThreshold) band='REJECTED';
    return {id:crypto.randomUUID(),mint:t.mint,signature:candidate.signature,score,confidence,band,metadataScore:round(metadataScore),creatorSignal,launchQuality:round(launchQuality),freshnessScore:round(freshnessScore),reasons,blockers,generatedAt:now,latencyMs:candidate.verificationLatencyMs,needsDeepAnalysis:band==='DEEP_ANALYSIS',liveExecutionEnabled:false};
  }
}
export const V49_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV49Safe(){if(!V49_SAFETY.shadowOnly||V49_SAFETY.signingEnabled||V49_SAFETY.privateKeyAccess||V49_SAFETY.broadcastEnabled||V49_SAFETY.liveExecutionAllowed)throw new Error('V49_SAFETY_INVARIANT_FAILED');}
