const ALPHABET="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
export function base58(bytes:Uint8Array){
 let n=0n;for(const b of bytes)n=(n<<8n)+BigInt(b);
 let out="";while(n>0n){const r=Number(n%58n);out=ALPHABET[r]+out;n/=58n}
 for(const b of bytes){if(b!==0)break;out="1"+out}return out||"1";
}