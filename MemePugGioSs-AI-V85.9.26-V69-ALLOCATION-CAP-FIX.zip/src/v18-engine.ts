
import crypto from "node:crypto";
import { StrategyParams } from "./v15-types.js";
import { MarketTick, ShadowPosition, ShadowSignal, ShadowTrade, ShadowSession } from "./v18-types.js";

export interface ShadowConfig {
  maxRisk:number; maxDataAgeMs:number; feePct:number; slippagePct:number;
  stopLossPct:number; takeProfitPct:number;
}
export class ShadowEngine {
  readonly session:ShadowSession;
  readonly signals:ShadowSignal[]=[];
  readonly trades:ShadowTrade[]=[];
  readonly positions=new Map<string,ShadowPosition>();
  private equity=0; private peak=0; private latencySum=0; private slippageSum=0;

  constructor(private strategy:StrategyParams, private cfg:ShadowConfig, now=Date.now()){
    this.session={sessionId:crypto.createHash("sha256").update(JSON.stringify({strategy,cfg,now})).digest("hex").slice(0,24),
      startedAt:now,ticks:0,signals:0,blocked:0,trades:0,totalNetPnl:0,maxDrawdown:0,
      avgLatencyMs:0,avgSlippagePct:0,status:"RUNNING"};
  }
  onTick(t:MarketTick, receivedAt=Date.now()):ShadowSignal{
    this.session.ticks++;
    const age=Math.max(0,receivedAt-t.ts);
    const latency=Math.max(0,receivedAt-t.ts);
    this.latencySum+=latency;
    let action:"WATCH"|"ENTER"|"EXIT"|"HOLD"|"BLOCKED"="WATCH", reason="NO_SIGNAL";
    const existing=this.positions.get(t.mint);
    if(age>this.cfg.maxDataAgeMs || t.risk>this.cfg.maxRisk){
      action="BLOCKED"; reason=age>this.cfg.maxDataAgeMs?"STALE_DATA":"RISK_LIMIT"; this.session.blocked++;
    } else if(existing){
      const ret=(t.price-existing.entryPrice)/existing.entryPrice*100;
      if(ret<=-this.cfg.stopLossPct){action="EXIT";reason="STOP_LOSS";}
      else if(ret>=this.cfg.takeProfitPct){action="EXIT";reason="TAKE_PROFIT";}
      else action="HOLD";
    } else if(t.buySellRatio>=this.strategy.buySellRatio&&t.smartMoneyShare>=this.strategy.smartMoneyShare&&
      t.liquidityDelta>=this.strategy.liquidityDeltaMin&&t.holderDelta>=this.strategy.holderDeltaMin){
      action="ENTER";reason="STRATEGY_MATCH";
    }
    const sig={id:crypto.createHash("sha256").update(`${t.mint}:${t.ts}:${action}:${reason}`).digest("hex").slice(0,24),
      mint:t.mint,ts:receivedAt,action,reason,referencePrice:t.price,strategy:this.strategy,latencyMs:latency,dataAgeMs:age};
    this.signals.push(sig);this.session.signals++;
    if(action==="ENTER")this.enter(t);
    if(action==="EXIT")this.exit(t);
    this.session.avgLatencyMs=this.latencySum/this.session.ticks;
    return sig;
  }
  private enter(t:MarketTick){this.positions.set(t.mint,{mint:t.mint,entryPrice:t.price,quantity:1,entryTs:t.ts,lastPrice:t.price,realizedPnl:0,unrealizedPnl:0});}
  private exit(t:MarketTick){
    const p=this.positions.get(t.mint);if(!p)return;
    const gross=t.price-p.entryPrice;
    const slip=Math.abs(t.price)*this.cfg.slippagePct/100;
    const fees=(Math.abs(t.price)+Math.abs(p.entryPrice))*this.cfg.feePct/100;
    const net=gross-slip-fees;
    this.trades.push({mint:t.mint,entryTs:p.entryTs,exitTs:t.ts,entryPrice:p.entryPrice,exitPrice:t.price,quantity:p.quantity,
      grossPnl:gross,simulatedSlippage:slip,simulatedFees:fees,netPnl:net,latencyMs:Math.max(0,Date.now()-t.ts)});
    this.session.trades++;this.session.totalNetPnl+=net;this.equity+=net;this.peak=Math.max(this.peak,this.equity);
    this.session.maxDrawdown=Math.max(this.session.maxDrawdown,this.peak-this.equity);
    this.slippageSum+=this.cfg.slippagePct; this.positions.delete(t.mint);
  }
  stop(now=Date.now()){this.session.endedAt=now;this.session.status="STOPPED";this.session.avgSlippagePct=this.session.trades?this.slippageSum/this.session.trades:0;}
}
