import crypto from 'node:crypto';
import { db } from './db.js';
import { V50DeepTokenIntelligence, type V50Input, type V50Result } from './v50-deep-intelligence.js';
import { V51FinalDecisionEngine, type V51Decision, type V51Input } from './v51-decision-engine.js';
import type { V48Candidate } from './v48-ultra-discovery.js';
import type { V49Score } from './v49-instant-scoring.js';
import type { V56State } from './v56-token-state-fusion.js';
import type { V57Change } from './v57-state-change-detector.js';
import type { V58Job } from './v58-ai-reevaluation.js';

export type V59Escalation='NONE'|'WATCH'|'HIGH'|'CRITICAL';
export type V59Outcome='ENTER_PAPER'|'EXIT_PAPER'|'WAIT'|'BLOCK'|'INSUFFICIENT_DATA';

export interface V59Context {
  candidate: V48Candidate;
  instant: V49Score;
  deepInput?: V50Input;
  existingPosition?: boolean;
  side?: 'BUY'|'SELL';
  currentPrice?: number;
  entryPrice?: number;
}

export interface V59Result {
  id:string; jobId:string; mint:string; ts:number; trigger:V57Change['type'];
  triggerSeverity:V57Change['severity']; stateVersion:number;
  outcome:V59Outcome; escalation:V59Escalation;
  previousOutcome?:V59Outcome;
  score:number; confidence:number; risk:number;
  theoreticalAllocationPct:number;
  deep:V50Result; decision:V51Decision;
  reasons:string[]; blockers:string[];
  liveExecutionEnabled:false;
}

export interface V59Config { criticalRiskThreshold:number; criticalScoreDelta:number; criticalRiskDelta:number; persistHistory:number; }
export const defaultV59Config:V59Config=Object.freeze({criticalRiskThreshold:45,criticalScoreDelta:12,criticalRiskDelta:12,persistHistory:10000});

const outcome=(d:V51Decision):V59Outcome=>d.action==='ENTER_PAPER'?'ENTER_PAPER':d.action==='EXIT_PAPER'?'EXIT_PAPER':d.action==='WAIT'?'WAIT':d.state==='INSUFFICIENT_DATA'?'INSUFFICIENT_DATA':'BLOCK';

/**
 * V59 is the deterministic decision bridge after V58. It re-runs V50 deep
 * intelligence and V51 final decision from the latest verified context. It
 * never signs, broadcasts, or enables live execution.
 */
export class V59DecisionReevaluationEngine {
  private readonly cfg:V59Config;
  private readonly deepEngine:V50DeepTokenIntelligence;
  private readonly decisionEngine:V51FinalDecisionEngine;
  private readonly lastOutcome=new Map<string,V59Outcome>();
  private readonly results:V59Result[]=[];

  constructor(cfg:Partial<V59Config>={},deepEngine=new V50DeepTokenIntelligence(),decisionEngine=new V51FinalDecisionEngine()){
    this.cfg={...defaultV59Config,...cfg}; this.deepEngine=deepEngine; this.decisionEngine=decisionEngine; this.ensureSchema();
  }

  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v59_decision_reevaluations(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,job_id TEXT NOT NULL,mint TEXT NOT NULL,trigger TEXT NOT NULL,severity TEXT NOT NULL,state_version INTEGER NOT NULL,outcome TEXT NOT NULL,escalation TEXT NOT NULL,previous_outcome TEXT,score REAL NOT NULL,confidence REAL NOT NULL,risk REAL NOT NULL,theoretical_allocation_pct REAL NOT NULL,result_json TEXT NOT NULL)`);}

  reevaluate(job:V58Job,change:V57Change,state:V56State,ctx:V59Context,now=Date.now()):V59Result{
    if(job.mint!==state.mint||state.mint!==ctx.candidate.token.mint||change.mint!==state.mint) throw new Error('V59_MINT_CONTEXT_MISMATCH');
    if(!change.actionable) throw new Error('V59_NON_ACTIONABLE_CHANGE');
    if(ctx.instant.mint!==state.mint) throw new Error('V59_INSTANT_STATE_MISMATCH');

    const deep=this.deepEngine.analyze(ctx.candidate,ctx.instant,ctx.deepInput??this.marketInput(state),now);
    const input:V51Input={analysis:deep,side:ctx.side,existingPosition:ctx.existingPosition,currentPrice:ctx.currentPrice,entryPrice:ctx.entryPrice,now};
    const decision=this.decisionEngine.decide(input);
    const out=outcome(decision);
    const prev=this.lastOutcome.get(state.mint);
    const escalation=this.classifyEscalation(change,deep,prev,out);
    const reasons=[...change.actionable?[`REVALUATED_FROM_${change.type}`]:[] ,...decision.reasons];
    const blockers=[...decision.blockers];
    const result:V59Result={id:crypto.randomUUID(),jobId:job.id,mint:state.mint,ts:now,trigger:change.type,triggerSeverity:change.severity,stateVersion:state.version,outcome:out,escalation,previousOutcome:prev,score:deep.score,confidence:deep.confidence,risk:deep.risk,theoreticalAllocationPct:decision.theoreticalAllocationPct,deep,decision,reasons,blockers,liveExecutionEnabled:false};
    this.lastOutcome.set(state.mint,out); this.results.push(result); if(this.results.length>this.cfg.persistHistory)this.results.shift(); this.persist(result);
    return result;
  }

  private marketInput(s:V56State):V50Input{
    return {market:{price:s.price,marketCap:s.marketCap,liquidity:s.liquidity,buyVolume:s.buyVolume,sellVolume:s.sellVolume,flowMomentum:s.flowMomentum,holders:s.holders,holderConcentration:s.holderConcentration,graduationProgress:s.graduationProgress,freshnessMs:s.freshnessMs,sampleSize:s.sourceCount},creator:{reputation:s.creatorScore},smartMoney:{score:s.smartMoneyScore,share:s.smartMoneyShare},regime:s.regime as V50Input['regime']};
  }

  private classifyEscalation(change:V57Change,deep:V50Result,prev:V59Outcome|undefined,current:V59Outcome):V59Escalation{
    if(change.severity==='CRITICAL'||deep.risk>=this.cfg.criticalRiskThreshold)return 'CRITICAL';
    if(change.type==='RISK_ESCALATION'||change.type==='SIGNAL_UPGRADE'||change.type==='SIGNAL_DOWNGRADE'){
      if(typeof change.delta==='number' && Math.abs(change.delta)>=this.cfg.criticalScoreDelta)return 'HIGH';
      if(prev!==current || change.severity==='HIGH')return 'HIGH';
    }
    if(prev!==current)return 'WATCH';
    return change.severity==='WATCH'?'WATCH':'NONE';
  }

  recent(limit=100,mint?:string){return this.results.filter(r=>!mint||r.mint===mint).slice(-Math.min(500,Math.max(1,limit)));}

  private persist(r:V59Result){db.prepare(`INSERT OR REPLACE INTO v59_decision_reevaluations(id,ts,job_id,mint,trigger,severity,state_version,outcome,escalation,previous_outcome,score,confidence,risk,theoretical_allocation_pct,result_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(r.id,r.ts,r.jobId,r.mint,r.trigger,r.triggerSeverity,r.stateVersion,r.outcome,r.escalation,r.previousOutcome??null,r.score,r.confidence,r.risk,r.theoreticalAllocationPct,JSON.stringify(r));}
}

export const V59_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV59Safe(){if(!V59_SAFETY.shadowOnly||V59_SAFETY.signingEnabled||V59_SAFETY.privateKeyAccess||V59_SAFETY.broadcastEnabled||V59_SAFETY.liveExecutionAllowed||V59_SAFETY.autoPromotion)throw new Error('V59_SAFETY_INVARIANT_FAILED');}
