import crypto from 'node:crypto';
import { db } from './db.js';
import { V58AIReevaluationEngine, type V58Job } from './v58-ai-reevaluation.js';
import { V59DecisionReevaluationEngine, type V59Result } from './v59-decision-reevaluation.js';
import type { V56State } from './v56-token-state-fusion.js';
import type { V57Change, V57ChangeType } from './v57-state-change-detector.js';
import type { V73Alert, V73AlertType } from './v73-live-intelligence-alerts.js';
import type { V48Candidate } from './v48-ultra-discovery.js';
import { V49InstantScoringEngine } from './v49-instant-scoring.js';
import type { V49Score } from './v49-instant-scoring.js';
import { assertV58Safe } from './v58-ai-reevaluation.js';
import { assertV59Safe } from './v59-decision-reevaluation.js';

export type V74Status = 'TRIGGERED'|'REEVALUATED'|'SKIPPED'|'BLOCKED';
export interface V74Run { id:string; ts:number; alertId:string; mint:string; status:V74Status; changeType:V57ChangeType|null; jobId:string|null; decisionOutcome:string|null; escalation:string|null; reasons:string[]; liveExecutionEnabled:false; }

const typeMap:Record<V73AlertType,V57ChangeType>={
  NEW_TOKEN:'SIGNAL_UPGRADE', PRICE_ACCELERATION:'MOMENTUM_CHANGE', LIQUIDITY_CHANGE:'LIQUIDITY_CHANGE',
  BUY_PRESSURE_CHANGE:'MOMENTUM_CHANGE', AI_SCORE_CHANGE:'SIGNAL_UPGRADE', RISK_ESCALATION:'RISK_ESCALATION',
  STALE_DATA:'STALE_DATA', FRESH_DATA:'FRESH_DATA'
};
const finite=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));

function row(sql:string, params:any[]=[]):any|undefined { try{return db.prepare(sql).get(...params) as any;}catch{return undefined;} }
function makeState(alert:V73Alert, now:number):V56State|undefined {
  const token=row('SELECT * FROM v26_discovered_tokens WHERE mint=?',[alert.mint]);
  const obs=row('SELECT * FROM observations WHERE mint=? ORDER BY id DESC LIMIT 1',[alert.mint]);
  if(!token && !obs) return undefined;
  const intel=row('SELECT * FROM token_intelligence WHERE mint=?',[alert.mint]);
  const signal=row('SELECT score,confidence,risk_score FROM strategy_signals WHERE mint=? ORDER BY created_at DESC LIMIT 1',[alert.mint]);
  const observedAt=obs?.observed_at?Date.parse(String(obs.observed_at)):NaN;
  const freshnessMs=Number.isFinite(observedAt)?Math.max(0,now-observedAt):undefined;
  const freshness=freshnessMs===undefined?'STALE':freshnessMs<=2000?'FRESH':freshnessMs<=5000?'AGING':'STALE';
  return {mint:alert.mint,signature:token?.signature,slot:finite(token?.slot)?Number(token.slot):undefined,firstSeenAt:finite(token?.detected_at)?Number(token.detected_at):now,lastUpdatedAt:Number.isFinite(observedAt)?observedAt:now,
    name:token?.name,symbol:token?.symbol,creator:token?.creator,bondingCurve:token?.bonding_curve,uri:token?.uri,
    price:finite(obs?.price)?Number(obs.price):undefined,liquidity:finite(obs?.liquidity)?Number(obs.liquidity):undefined,buyVolume:undefined,sellVolume:undefined,flowMomentum:finite(obs?.buy_pressure)?Number(obs.buy_pressure)-50:undefined,
    holders:finite(obs?.holders)?Number(obs.holders):undefined,holderConcentration:finite(intel?.largest_holder_pct)?Number(intel.largest_holder_pct):undefined,
    graduationProgress:undefined,creatorScore:undefined,smartMoneyScore:undefined,smartMoneyShare:undefined,regime:undefined,
    instantScore:finite(signal?.score)?Number(signal.score):undefined,instantConfidence:finite(signal?.confidence)?Number(signal.confidence):undefined,deepScore:undefined,deepConfidence:undefined,risk:finite(signal?.risk_score)?Number(signal.risk_score):undefined,
    freshness:freshness as any,freshnessMs,sourceCount:1,version:Math.max(1,Number(obs?.id??1)),blockers:[],reasons:[`V74_TRIGGER_${alert.type}`],lastSource:'EXTERNAL_INTELLIGENCE' as any};
}

function makeCandidate(state:V56State, now:number):V48Candidate|undefined {
  const token=row('SELECT * FROM v26_discovered_tokens WHERE mint=?',[state.mint]);
  if(!token?.signature || !finite(token.slot)) return undefined;
  return {id:`v74:${state.mint}:${token.signature}`,signature:String(token.signature),slot:Number(token.slot),receivedAt:state.firstSeenAt,verifiedAt:state.firstSeenAt,verificationLatencyMs:0,
    token:{mint:state.mint,bondingCurve:String(token.bonding_curve||''),signature:String(token.signature),slot:Number(token.slot),blockTime:finite(token.block_time)?Number(token.block_time):undefined,createKind:(token.create_kind==='CREATE_V2'?'CREATE_V2':'CREATE'),name:token.name,symbol:token.symbol,uri:token.uri,creator:token.creator,quoteMint:token.quote_mint,mayhemMode:Boolean(token.mayhem_mode),holderReward:Boolean(token.holder_reward),detectedAt:Number(token.detected_at||now)},
    priority:'P1',action:'DEEP_ANALYSIS',reasons:['V74_ALERT_REEVALUATION']};
}

export class V74AIAlertReevaluationBridge {
  private readonly v58:V58AIReevaluationEngine;
  private readonly v59:V59DecisionReevaluationEngine;
  private readonly v49=new V49InstantScoringEngine();
  constructor(v58=new V58AIReevaluationEngine(),v59=new V59DecisionReevaluationEngine()){this.v58=v58;this.v59=v59;this.ensureSchema();assertV58Safe();assertV59Safe();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v74_reevaluation_runs(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,alert_id TEXT NOT NULL,mint TEXT NOT NULL,status TEXT NOT NULL,change_type TEXT,job_id TEXT,decision_outcome TEXT,escalation TEXT,reasons_json TEXT NOT NULL,live_execution_enabled INTEGER NOT NULL DEFAULT 0); CREATE INDEX IF NOT EXISTS idx_v74_runs_ts ON v74_reevaluation_runs(ts);`);}
  trigger(alert:V73Alert,now=Date.now()):V74Run {
    const changeType=typeMap[alert.type];
    if(alert.type==='FRESH_DATA'||!alert.actionable){return this.record({id:crypto.randomUUID(),ts:now,alertId:alert.id,mint:alert.mint,status:'SKIPPED',changeType,jobId:null,decisionOutcome:null,escalation:null,reasons:['ALERT_NOT_ACTIONABLE'],liveExecutionEnabled:false});}
    const state=makeState(alert,now);
    if(!state){return this.record({id:crypto.randomUUID(),ts:now,alertId:alert.id,mint:alert.mint,status:'BLOCKED',changeType,jobId:null,decisionOutcome:null,escalation:null,reasons:['VERIFIED_TOKEN_STATE_UNAVAILABLE'],liveExecutionEnabled:false});}
    const change:V57Change={id:crypto.createHash('sha256').update(`${alert.id}:${state.version}:${changeType}`).digest('hex'),mint:state.mint,ts:now,type:changeType,severity:alert.severity,version:state.version,previousVersion:Math.max(0,state.version-1),message:alert.message,before:alert.before??undefined,after:alert.after??undefined,delta:alert.delta??undefined,actionable:true};
    const job=this.v58.submit(change,state,now);
    if(!job){return this.record({id:crypto.randomUUID(),ts:now,alertId:alert.id,mint:alert.mint,status:'SKIPPED',changeType,jobId:null,decisionOutcome:null,escalation:null,reasons:['V58_DEDUPLICATED_OR_QUEUE_LIMIT'],liveExecutionEnabled:false});}
    const candidate=makeCandidate(state,now);
    if(!candidate){return this.record({id:crypto.randomUUID(),ts:now,alertId:alert.id,mint:alert.mint,status:'TRIGGERED',changeType,jobId:job.id,decisionOutcome:null,escalation:null,reasons:['V58_TRIGGERED','V59_CONTEXT_UNAVAILABLE'],liveExecutionEnabled:false});}
    const instant:V49Score=this.v49.score(candidate,now);
    const result:V59Result=this.v59.reevaluate(job,change,state,{candidate,instant,currentPrice:state.price},now);
    return this.record({id:crypto.randomUUID(),ts:now,alertId:alert.id,mint:alert.mint,status:'REEVALUATED',changeType,jobId:job.id,decisionOutcome:result.outcome,escalation:result.escalation,reasons:[...result.reasons,...result.blockers],liveExecutionEnabled:false});
  }
  triggerMany(alerts:V73Alert[],now=Date.now()){return alerts.map(a=>this.trigger(a,now));}
  recent(limit=100,mint?:string){const n=Math.min(500,Math.max(1,limit));return db.prepare(`SELECT * FROM v74_reevaluation_runs ${mint?'WHERE mint=?':''} ORDER BY ts DESC LIMIT ?`).all(...(mint?[mint,n]:[n]));}
  health(){const r=row(`SELECT COUNT(*) c,SUM(CASE WHEN status='REEVALUATED' THEN 1 ELSE 0 END) re,SUM(CASE WHEN status='BLOCKED' THEN 1 ELSE 0 END) bl FROM v74_reevaluation_runs`);return {state:'RUNNING',runs:Number(r?.c||0),reevaluated:Number(r?.re||0),blocked:Number(r?.bl||0),liveExecutionEnabled:false};}
  private record(r:V74Run){db.prepare(`INSERT INTO v74_reevaluation_runs(id,ts,alert_id,mint,status,change_type,job_id,decision_outcome,escalation,reasons_json,live_execution_enabled) VALUES(?,?,?,?,?,?,?,?,?,?,0)`).run(r.id,r.ts,r.alertId,r.mint,r.status,r.changeType,r.jobId,r.decisionOutcome,r.escalation,JSON.stringify(r.reasons));return r;}
}
export const V74_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV74Safe(){if(!V74_SAFETY.shadowOnly||V74_SAFETY.signingEnabled||V74_SAFETY.privateKeyAccess||V74_SAFETY.broadcastEnabled||V74_SAFETY.liveExecutionAllowed||V74_SAFETY.autoPromotion)throw new Error('V74_SAFETY_INVARIANT_FAILED');}
