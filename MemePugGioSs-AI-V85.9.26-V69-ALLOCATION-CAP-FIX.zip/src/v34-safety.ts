export function assertV34Safety(){
  if(process.env.V34_LIVE_COPY_TRADING==='true') throw new Error('V34_LIVE_COPY_TRADING_DISABLED');
  if(process.env.APP_MODE==='LIVE') throw new Error('V34_LIVE_COPY_REQUIRES_PAPER');
}
