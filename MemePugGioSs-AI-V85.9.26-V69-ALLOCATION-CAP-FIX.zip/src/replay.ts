import { MarketBar } from "./backtest-types.js";

export function chronologicalReplay(input:MarketBar[]):MarketBar[] {
  const bars=[...input].sort((a,b)=>a.ts-b.ts);
  for(let i=1;i<bars.length;i++) if(bars[i].ts<bars[i-1].ts) throw new Error("non-chronological replay");
  return bars;
}
