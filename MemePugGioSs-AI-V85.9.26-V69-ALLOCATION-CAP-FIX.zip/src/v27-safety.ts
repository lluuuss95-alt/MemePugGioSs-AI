export const V27_SAFETY = Object.freeze({
  mode:"PAPER",
  shadowOnly:true,
  signingEnabled:false,
  privateKeyAccess:false,
  broadcastEnabled:false,
  liveExecutionAllowed:false,
  autoPromotion:false,
});
export function assertV27Safe(){
  if(!V27_SAFETY.shadowOnly || V27_SAFETY.signingEnabled || V27_SAFETY.privateKeyAccess || V27_SAFETY.broadcastEnabled || V27_SAFETY.liveExecutionAllowed) throw new Error("V27_SAFETY_INVARIANT_FAILED");
}
