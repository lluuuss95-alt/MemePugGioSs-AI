import crypto from 'node:crypto';
import { db } from './db.js';

export type V73AlertType = 'NEW_TOKEN'|'PRICE_ACCELERATION'|'LIQUIDITY_CHANGE'|'BUY_PRESSURE_CHANGE'|'AI_SCORE_CHANGE'|'RISK_ESCALATION'|'STALE_DATA'|'FRESH_DATA';
export type V73Severity = 'INFO'|'WATCH'|'HIGH'|'CRITICAL';
export interface V73Alert {
  id:string; mint:string; ts:number; type:V73AlertType; severity:V73Severity;
  message:string; actionable:boolean; before:number|null; after:number|null; delta:number|null;
  source:string; dedupeKey:string;
}
export interface V73Config {
  maxAlerts:number; maxPerMint:number; minPriceChangePct:number; minLiquidityChangePct:number;
  minBuyPressureDelta:number; minScoreDelta:number; minRiskDelta:number; staleAfterMs:number;
}
export const defaultV73Config:V73Config=Object.freeze({
  maxAlerts:10000,maxPerMint:100,minPriceChangePct:0.15,minLiquidityChangePct:0.20,
  minBuyPressureDelta:15,minScoreDelta:8,minRiskDelta:8,staleAfterMs:5000
});

function finite(v:unknown):v is number{return typeof v==='number'&&Number.isFinite(v);}
function pct(a:number,b:number){return Math.abs(b-a)/Math.max(Math.abs(a),1);}
function id(mint:string,type:string,ts:number,bucket:number){return crypto.createHash('sha256').update(`${mint}:${type}:${bucket}`).digest('hex');}
function rows(sql:string,params:any[]=[]):any[]{try{return db.prepare(sql).all(...params) as any[]}catch{return [];}}

export class V73LiveIntelligenceAlertEngine {
  private readonly cfg:V73Config;
  private alerts:V73Alert[]=[];
  private seen=new Set<string>();
  private lastPoll=0;
  constructor(cfg:Partial<V73Config>={}){this.cfg={...defaultV73Config,...cfg};this.ensureSchema();this.loadRecent();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v73_intelligence_alerts(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,type TEXT NOT NULL,severity TEXT NOT NULL,message TEXT NOT NULL,actionable INTEGER NOT NULL,before_value REAL,after_value REAL,delta REAL,source TEXT NOT NULL,dedupe_key TEXT NOT NULL); CREATE INDEX IF NOT EXISTS idx_v73_alerts_ts ON v73_intelligence_alerts(ts); CREATE INDEX IF NOT EXISTS idx_v73_alerts_mint_ts ON v73_intelligence_alerts(mint,ts);`);}
  private loadRecent(){for(const r of rows('SELECT * FROM v73_intelligence_alerts ORDER BY ts DESC LIMIT 1000')){this.seen.add(String(r.dedupe_key));this.alerts.unshift(this.map(r));}this.alerts=this.alerts.slice(0,this.cfg.maxAlerts);}
  private map(r:any):V73Alert{return {id:String(r.id),mint:String(r.mint),ts:Number(r.ts),type:r.type,severity:r.severity,message:String(r.message),actionable:Boolean(r.actionable),before:finite(r.before_value)?Number(r.before_value):null,after:finite(r.after_value)?Number(r.after_value):null,delta:finite(r.delta)?Number(r.delta):null,source:String(r.source),dedupeKey:String(r.dedupe_key)};}
  poll(now=Date.now()):V73Alert[]{
    const latest=rows(`SELECT o.* FROM observations o INNER JOIN (SELECT mint,MAX(id) id FROM observations GROUP BY mint) x ON x.id=o.id ORDER BY o.id DESC LIMIT 500`);
    const out:V73Alert[]=[];
    for(const cur of latest){
      const mint=String(cur.mint); const previous=rows(`SELECT price,liquidity,buy_pressure,observed_at FROM observations WHERE mint=? AND id<? ORDER BY id DESC LIMIT 1`,[mint,cur.id])[0];
      const token=rows('SELECT first_seen,last_seen,symbol,name FROM tokens WHERE mint=?',[mint])[0];
      if(!previous){out.push(this.emit(mint,'NEW_TOKEN','INFO',`Nuovo token osservato: ${token?.symbol||mint.slice(0,8)}`,null,finite(cur.price)?Number(cur.price):null,null,'OBSERVATIONS',now));continue;}
      if(finite(previous.price)&&finite(cur.price)&&pct(Number(previous.price),Number(cur.price))>=this.cfg.minPriceChangePct){const d=Number(cur.price)-Number(previous.price);out.push(this.emit(mint,'PRICE_ACCELERATION',Math.abs(d)>=Math.abs(Number(previous.price))*0.5?'HIGH':'WATCH',`Prezzo variato materialmente`,Number(previous.price),Number(cur.price),d,'OBSERVATIONS',now));}
      if(finite(previous.liquidity)&&finite(cur.liquidity)&&pct(Number(previous.liquidity),Number(cur.liquidity))>=this.cfg.minLiquidityChangePct){const d=Number(cur.liquidity)-Number(previous.liquidity);out.push(this.emit(mint,'LIQUIDITY_CHANGE',d<0?'HIGH':'WATCH',`Liquidità ${d<0?'diminuita':'aumentata'} materialmente`,Number(previous.liquidity),Number(cur.liquidity),d,'OBSERVATIONS',now));}
      if(finite(previous.buy_pressure)&&finite(cur.buy_pressure)&&Math.abs(Number(cur.buy_pressure)-Number(previous.buy_pressure))>=this.cfg.minBuyPressureDelta){const d=Number(cur.buy_pressure)-Number(previous.buy_pressure);out.push(this.emit(mint,'BUY_PRESSURE_CHANGE',Math.abs(d)>=30?'HIGH':'WATCH',`Buy pressure cambiata materialmente`,Number(previous.buy_pressure),Number(cur.buy_pressure),d,'OBSERVATIONS',now));}
      const signal=rows('SELECT score,risk_score FROM strategy_signals WHERE mint=? ORDER BY created_at DESC LIMIT 1',[mint])[0];
      const priorSignals=rows('SELECT score,risk_score FROM strategy_signals WHERE mint=? ORDER BY created_at DESC LIMIT 2',[mint]);
      if(signal&&priorSignals.length>1){const ps=priorSignals[1]; if(finite(signal.score)&&finite(ps.score)&&Math.abs(Number(signal.score)-Number(ps.score))>=this.cfg.minScoreDelta){const d=Number(signal.score)-Number(ps.score);out.push(this.emit(mint,'AI_SCORE_CHANGE',d>0?'HIGH':'WATCH',`AI score cambiato materialmente`,Number(ps.score),Number(signal.score),d,'AI_SIGNAL',now));} if(finite(signal.risk_score)&&finite(ps.risk_score)&&Number(signal.risk_score)-Number(ps.risk_score)>=this.cfg.minRiskDelta){const d=Number(signal.risk_score)-Number(ps.risk_score);out.push(this.emit(mint,'RISK_ESCALATION','HIGH',`Risk score aumentato`,Number(ps.risk_score),Number(signal.risk_score),d,'AI_SIGNAL',now));}}
      const observedAt=Date.parse(String(cur.observed_at)); if(Number.isFinite(observedAt)&&now-observedAt>=this.cfg.staleAfterMs){out.push(this.emit(mint,'STALE_DATA','HIGH',`Dati di mercato diventati stale`,null,null,null,'OBSERVATIONS',now));}
    }
    this.lastPoll=now; return out.filter(Boolean);
  }
  recent(limit=100,mint?:string){return this.alerts.filter(a=>!mint||a.mint===mint).slice(0,Math.min(500,Math.max(1,limit)));}
  health(){return {state:'RUNNING',lastPollAt:this.lastPoll,alerts:this.alerts.length,dbBacked:true,liveExecutionEnabled:false};}
  private emit(mint:string,type:V73AlertType,severity:V73Severity,message:string,before:number|null,after:number|null,delta:number|null,source:string,now:number):V73Alert{
    const bucket=Math.floor(now/1000); const dedupeKey=`${mint}:${type}:${bucket}`; const existing=this.seen.has(dedupeKey); if(existing)return {id:'',mint,ts:now,type,severity,message,actionable:false,before,after,delta,source,dedupeKey};
    const alert={id:id(mint,type,now,bucket),mint,ts:now,type,severity,message,actionable:severity!=='INFO',before,after,delta,source,dedupeKey}; this.seen.add(dedupeKey); this.alerts.unshift(alert); this.alerts=this.alerts.slice(0,this.cfg.maxAlerts);
    db.prepare(`INSERT OR IGNORE INTO v73_intelligence_alerts(id,ts,mint,type,severity,message,actionable,before_value,after_value,delta,source,dedupe_key) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(alert.id,alert.ts,alert.mint,alert.type,alert.severity,alert.message,alert.actionable?1:0,alert.before,alert.after,alert.delta,alert.source,alert.dedupeKey); return alert;
  }
}
export const V73_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV73Safe(){if(!V73_SAFETY.shadowOnly||V73_SAFETY.signingEnabled||V73_SAFETY.privateKeyAccess||V73_SAFETY.broadcastEnabled||V73_SAFETY.liveExecutionAllowed||V73_SAFETY.autoPromotion)throw new Error('V73_SAFETY_INVARIANT_FAILED');}
