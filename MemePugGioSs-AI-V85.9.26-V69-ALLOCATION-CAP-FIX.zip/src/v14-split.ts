import { SignalRow, Split } from "./v14-types.js";

export function chronologicalSplit(rows:SignalRow[],trainPct=.6,valPct=.2):Split{
  const xs=[...rows].sort((a,b)=>a.ts-b.ts);
  const a=Math.floor(xs.length*trainPct), b=a+Math.floor(xs.length*valPct);
  return {train:xs.slice(0,a),validation:xs.slice(a,b),test:xs.slice(b)};
}

export function tokenGroupedSplit(rows:SignalRow[],trainPct=.6,valPct=.2):Split{
  const groups=new Map<string,SignalRow[]>();
  for(const r of rows){if(!groups.has(r.mint))groups.set(r.mint,[]);groups.get(r.mint)!.push(r);}
  const mints=[...groups.keys()].sort();
  const a=Math.floor(mints.length*trainPct), b=a+Math.floor(mints.length*valPct);
  const pack=(ms:string[])=>ms.flatMap(m=>groups.get(m)!);
  return {train:pack(mints.slice(0,a)),validation:pack(mints.slice(a,b)),test:pack(mints.slice(b))};
}
