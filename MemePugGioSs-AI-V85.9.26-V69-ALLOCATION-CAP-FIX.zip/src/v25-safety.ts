export const V25_SAFETY = Object.freeze({
  mode: "SHADOW",
  liveTrading: false,
  signingEnabled: false,
  privateKeyAccess: false,
  broadcastEnabled: false,
  autoPromotion: false,
});

export function assertV25Shadow() {
  if (V25_SAFETY.liveTrading || V25_SAFETY.signingEnabled || V25_SAFETY.privateKeyAccess || V25_SAFETY.broadcastEnabled || V25_SAFETY.autoPromotion) {
    throw new Error("V25_SAFETY_VIOLATION");
  }
}
