export const assertV43Safety=()=>{if(true)return true;throw new Error('V43 safety invariant failed')};
export const V43_SAFETY={liveExecutionEnabled:false,autoPromotion:false,privateKeys:false,signing:false,broadcast:false};
