import { NormalizedDexEvent } from "./protocols.js";

export type LifecycleState = "CREATED"|"LIQUIDITY_BOOTSTRAP"|"ACTIVE_TRADING"|"DISTRIBUTION"|"EXIT_RISK"|"UNKNOWN";

export interface LifecycleSnapshot {
  state: LifecycleState;
  buyVolume: number;
  sellVolume: number;
  liquidityDelta: number;
  swaps: number;
  confidence: number;
}

export function classifyLifecycle(events: NormalizedDexEvent[]): LifecycleSnapshot {
  let buy=0, sell=0, liq=0, swaps=0, created=0, remove=0;
  let confidence=0, n=0;
  for (const e of events) {
    confidence += e.confidence; n++;
    if (e.type==="TOKEN_CREATED") created++;
    if (e.type==="SWAP_BUY") { buy += e.quoteAmount ?? 0; swaps++; }
    if (e.type==="SWAP_SELL") { sell += e.quoteAmount ?? 0; swaps++; }
    if (e.type==="LIQUIDITY_ADD") liq += (e.quoteDelta ?? 0);
    if (e.type==="LIQUIDITY_REMOVE") { liq -= (e.quoteDelta ?? 0); remove++; }
  }
  let state: LifecycleState = "UNKNOWN";
  if (remove > 0 && liq < 0) state = "EXIT_RISK";
  else if (created > 0 && swaps === 0) state = "CREATED";
  else if (liq > 0 && swaps < 3) state = "LIQUIDITY_BOOTSTRAP";
  else if (sell > buy * 1.5 && swaps >= 3) state = "DISTRIBUTION";
  else if (swaps >= 3) state = "ACTIVE_TRADING";
  return { state, buyVolume:buy, sellVolume:sell, liquidityDelta:liq, swaps, confidence:n ? confidence/n : 0 };
}
