import {NormalizedMarketEvent} from "./v20-types.js";
export class ShadowEventLedger{
 private events:NormalizedMarketEvent[]=[];
 append(e:NormalizedMarketEvent){this.events.push(e)}
 all(){return [...this.events]}
 since(slot:number){return this.events.filter(e=>e.slot>=slot)}
 size(){return this.events.length}
}
