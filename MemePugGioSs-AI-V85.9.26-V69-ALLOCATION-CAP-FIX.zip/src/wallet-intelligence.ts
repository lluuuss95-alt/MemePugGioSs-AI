export type WalletRole = "DEPLOYER"|"EARLY_BUYER"|"TRADER"|"LIQUIDITY_PROVIDER"|"HOLDER"|"UNKNOWN";

export interface WalletObservation {
  address:string;
  mint:string;
  role:WalletRole;
  slot:number;
  signature:string;
  buyVolume?:number;
  sellVolume?:number;
  balanceDelta?:number;
  relatedWallets?:string[];
}

export interface WalletProfile {
  address:string;
  observations:number;
  tokens:number;
  buyVolume:number;
  sellVolume:number;
  exits:number;
  deployerTokens:number;
  relatedWallets:Set<string>;
}

export function buildWalletProfiles(obs:WalletObservation[]): Map<string,WalletProfile> {
  const map = new Map<string,WalletProfile>();
  for (const o of obs) {
    let p = map.get(o.address);
    if (!p) {
      p={address:o.address,observations:0,tokens:0,buyVolume:0,sellVolume:0,
         exits:0,deployerTokens:0,relatedWallets:new Set()};
      map.set(o.address,p);
    }
    p.observations++;
    p.tokens++;
    p.buyVolume += o.buyVolume ?? 0;
    p.sellVolume += o.sellVolume ?? 0;
    if ((o.sellVolume ?? 0) > 0 && (o.balanceDelta ?? 0) < 0) p.exits++;
    if (o.role==="DEPLOYER") p.deployerTokens++;
    for (const w of o.relatedWallets ?? []) if (w!==o.address) p.relatedWallets.add(w);
  }
  return map;
}

export interface WalletScore {
  address:string;
  risk:number;
  smartMoney:number;
  confidence:number;
  reasons:string[];
}

export function scoreWallet(p:WalletProfile): WalletScore {
  let risk=0, smart=0; const reasons:string[]=[];
  if (p.exits>=3) { risk+=25; reasons.push("repeated observed exits"); }
  if (p.sellVolume > p.buyVolume*1.5 && p.sellVolume>0) { risk+=15; reasons.push("sell volume dominates"); }
  if (p.deployerTokens>=3) { risk+=15; reasons.push("multiple observed deployer-linked tokens"); }
  if (p.tokens>=5 && p.sellVolume>0) smart+=10;
  if (p.tokens>=10 && p.buyVolume>p.sellVolume*1.2) smart+=20;
  const confidence=Math.min(1,p.observations/20);
  return {address:p.address,risk:Math.min(100,risk),smartMoney:Math.min(100,smart)*confidence,confidence,reasons};
}
