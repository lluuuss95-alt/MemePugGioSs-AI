import {V26DiscoveryHealth, V26DiscoveryStore, V26TokenDiscovery} from "./v26-types.js";
import {V27GapRecovery} from "./v27-recovery.js";

export interface V27ResilientState {
  transport: V26DiscoveryHealth["websocket"];
  recovery: "IDLE" | "RUNNING" | "READY" | "DEGRADED";
  recoveredTotal: number;
  lastRecoveryAt?: number;
}

/**
 * Bridge used by the V26 feed callback: when a reconnect completes, run a
 * cursor recovery before trusting the stream as fully synchronized again.
 */
export class V27ResilientDiscovery {
  private state: V27ResilientState = {transport:"DISCONNECTED", recovery:"IDLE", recoveredTotal:0};
  private reconnectPending = false;
  constructor(private readonly recovery: V27GapRecovery, private readonly store: V26DiscoveryStore) {}

  async onHealth(health: V26DiscoveryHealth) {
    const wasDisconnected = this.state.transport === "RECONNECTING" || this.state.transport === "DISCONNECTED";
    this.state.transport = health.websocket;
    if (health.websocket === "RECONNECTING" || health.websocket === "DISCONNECTED") this.reconnectPending = true;
    if (health.websocket === "CONNECTED" && wasDisconnected && this.reconnectPending) {
      this.reconnectPending = false;
      this.state.recovery = "RUNNING";
      try {
        const result = await this.recovery.recover();
        this.state.recoveredTotal += result.recovered;
        this.state.lastRecoveryAt = Date.now();
        this.state.recovery = result.failedTransactions > 0 ? "DEGRADED" : "READY";
      } catch {
        this.state.recovery = "DEGRADED";
      }
    }
  }

  onRecovered(_token: V26TokenDiscovery) {
    // Store insertion is owned by V27GapRecovery; this callback is intentionally side-effect free.
  }

  getState(){ return {...this.state}; }
  tokenCount(){ return this.store.all().length; }
}
