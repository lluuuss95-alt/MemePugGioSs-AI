
import { StrategyParams } from "./v15-types.js";

export type ShadowAction="WATCH"|"ENTER"|"EXIT"|"HOLD"|"BLOCKED";
export interface MarketTick {
  mint:string; ts:number; price:number; liquidity:number;
  buySellRatio:number; smartMoneyShare:number; risk:number;
  liquidityDelta:number; holderDelta:number;
}
export interface ShadowSignal {
  id:string; mint:string; ts:number; action:ShadowAction;
  reason:string; referencePrice:number; strategy:StrategyParams;
  latencyMs:number; dataAgeMs:number;
}
export interface ShadowPosition {
  mint:string; entryPrice:number; quantity:number; entryTs:number;
  lastPrice:number; realizedPnl:number; unrealizedPnl:number;
}
export interface ShadowTrade {
  mint:string; entryTs:number; exitTs:number;
  entryPrice:number; exitPrice:number; quantity:number;
  grossPnl:number; simulatedSlippage:number; simulatedFees:number; netPnl:number;
  latencyMs:number;
}
export interface ShadowSession {
  sessionId:string; startedAt:number; endedAt?:number;
  ticks:number; signals:number; blocked:number; trades:number;
  totalNetPnl:number; maxDrawdown:number;
  avgLatencyMs:number; avgSlippagePct:number;
  status:"RUNNING"|"STOPPED"|"PAUSED";
}
