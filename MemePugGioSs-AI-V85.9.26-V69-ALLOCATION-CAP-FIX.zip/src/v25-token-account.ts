import {V25HttpRpc, JsonRpcHttpClient} from "./v25-rpc.js";
import {V25TokenBalance} from "./v25-types.js";

export interface TokenBalanceRpc {
  getTokenAccountBalance(address: string, commitment?: string): Promise<any>;
}

export class TokenAccountBalanceService {
  constructor(private readonly rpc: TokenBalanceRpc) {}

  async read(address: string, slot = 0, source: V25TokenBalance["source"] = "RPC"): Promise<V25TokenBalance> {
    const result = await this.rpc.getTokenAccountBalance(address, "finalized");
    const value = result?.value;
    if (!value || typeof value.amount !== "string" || typeof value.decimals !== "number") {
      throw new Error("INVALID_TOKEN_ACCOUNT_BALANCE");
    }
    return {
      address,
      mint: typeof value.mint === "string" ? value.mint : "UNKNOWN",
      amount: BigInt(value.amount),
      decimals: value.decimals,
      slot,
      observedAt: Date.now(),
      source,
    };
  }
}

export function tokenBalanceFromNotification(address: string, notification: any): V25TokenBalance | null {
  const value = notification?.params?.result?.value ?? notification?.value;
  const parsed = value?.data?.parsed;
  const tokenAmount = parsed?.info?.tokenAmount;
  if (!tokenAmount || typeof tokenAmount.amount !== "string" || typeof tokenAmount.decimals !== "number") return null;
  return {
    address,
    mint: typeof parsed?.info?.mint === "string" ? parsed.info.mint : "UNKNOWN",
    amount: BigInt(tokenAmount.amount),
    decimals: tokenAmount.decimals,
    slot: Number(notification?.params?.result?.context?.slot ?? notification?.context?.slot ?? 0),
    observedAt: Date.now(),
    source: "SUBSCRIPTION",
  };
}

export function createTokenBalanceService(endpoint: string) {
  return new TokenAccountBalanceService(new JsonRpcHttpClient(endpoint));
}
