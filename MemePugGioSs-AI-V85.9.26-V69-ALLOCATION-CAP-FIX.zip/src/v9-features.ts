export interface TimedPoint {
  ts:number;
  buyVolume:number;
  sellVolume:number;
  liquidity:number;
  smartMoneyVolume:number;
  holders:number;
  risk:number;
}

export interface V9Features {
  buySellRatio:number;
  flowMomentum:number;
  smartMoneyShare:number;
  liquidityDelta:number;
  holderDelta:number;
  risk:number;
  freshnessMs:number;
  sampleSize:number;
}

export function buildV9Features(points:TimedPoint[], now:number):V9Features {
  const sorted=[...points].sort((a,b)=>a.ts-b.ts);
  const n=sorted.length;
  if(!n) return {buySellRatio:0,flowMomentum:0,smartMoneyShare:0,liquidityDelta:0,holderDelta:0,risk:100,freshnessMs:Infinity,sampleSize:0};
  const last=sorted[n-1], prev=sorted[Math.max(0,n-4)];
  const buys=sorted.reduce((s,p)=>s+p.buyVolume,0);
  const sells=sorted.reduce((s,p)=>s+p.sellVolume,0);
  const total=buys+sells;
  const buySellRatio=sells?buys/sells:buys>0?2:0;
  const flowMomentum=(last.buyVolume-last.sellVolume)-(prev.buyVolume-prev.sellVolume);
  const smart=sorted.reduce((s,p)=>s+p.smartMoneyVolume,0);
  const liquidityDelta=last.liquidity-prev.liquidity;
  const holderDelta=last.holders-prev.holders;
  return {buySellRatio,flowMomentum,smartMoneyShare:total?smart/total:0,
    liquidityDelta,holderDelta,risk:last.risk,freshnessMs:Math.max(0,now-last.ts),sampleSize:n};
}
