
import crypto from "node:crypto";
import { DatasetRow } from "./v15-types.js";
import { StressScenario, RobustnessReport } from "./v16-types.js";
import { applyScenario, stressMetrics } from "./v16-stress.js";
import { monteCarlo } from "./v16-montecarlo.js";
import { bootstrapCI } from "./v16-bootstrap.js";

export function robustnessLab(rows:DatasetRow[],scenarios:StressScenario[],mcRuns=1000):RobustnessReport{
  const baseline=stressMetrics("BASELINE",rows);
  const results=scenarios.map((s,i)=>stressMetrics(s.name,applyScenario(rows,s,17+i)));
  const mc=monteCarlo(rows,mcRuns,17);
  const ci=bootstrapCI(rows.map(x=>x.futureReturnPct),2000,17,.95);
  if(rows.length<30)return {runId:hash(rows,scenarios),baseline,scenarios:results,monteCarlo:mc,bootstrapCI:ci,fragilityScore:100,status:"INSUFFICIENT_DATA"};
  const avgStress=results.length?results.reduce((s,x)=>s+x.meanReturn,0)/results.length:baseline.meanReturn;
  const degradation=Math.max(0,baseline.meanReturn-avgStress);
  const fragility=Math.min(100,Math.max(0,degradation*12+(baseline.maxDrawdown>30?25:0)+(mc.probabilityPositive<50?25:0)));
  const status=fragility<25?"ROBUST":fragility<50?"SENSITIVE":"FRAGILE";
  return {runId:hash(rows,scenarios),baseline,scenarios:results,monteCarlo:mc,bootstrapCI:ci,fragilityScore:fragility,status};
}
function hash(rows:DatasetRow[],s:StressScenario[]){return crypto.createHash("sha256").update(JSON.stringify({rows,s})).digest("hex");}
