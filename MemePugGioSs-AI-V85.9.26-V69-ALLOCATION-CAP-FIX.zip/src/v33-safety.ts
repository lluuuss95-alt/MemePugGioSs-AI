export const V33_SAFETY = Object.freeze({
  mode: 'PAPER', liveTrading: false, signingEnabled: false,
  privateKeyAccess: false, broadcastEnabled: false, autoPromotion: false
});

export function assertV33Safety() {
  if (V33_SAFETY.liveTrading || V33_SAFETY.signingEnabled || V33_SAFETY.privateKeyAccess || V33_SAFETY.broadcastEnabled) {
    throw new Error('V33 safety invariant violated');
  }
}
