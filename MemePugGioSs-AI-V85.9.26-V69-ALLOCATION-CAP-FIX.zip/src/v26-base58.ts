const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const INDEX = new Map([...ALPHABET].map((c, i) => [c, i]));

export function decodeBase58(value: string): Uint8Array {
  if (!value) return new Uint8Array();
  let n = 0n;
  for (const c of value) {
    const digit = INDEX.get(c);
    if (digit === undefined) throw new Error("INVALID_BASE58");
    n = n * 58n + BigInt(digit);
  }
  const bytes: number[] = [];
  while (n > 0n) { bytes.push(Number(n & 255n)); n >>= 8n; }
  bytes.reverse();
  let zeros = 0;
  for (const c of value) { if (c === "1") zeros++; else break; }
  return new Uint8Array([...new Array(zeros).fill(0), ...bytes]);
}
