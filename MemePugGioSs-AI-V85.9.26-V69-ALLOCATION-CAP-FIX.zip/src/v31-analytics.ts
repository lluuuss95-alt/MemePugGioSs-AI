import { PaperTrade } from './v31-types.js';
export function performanceByToken(trades: PaperTrade[]) {
  const m: Record<string,{trades:number;pnl:number;wins:number;losses:number}> = {};
  for (const t of trades.filter(x=>x.status==='CLOSED')) { const x=m[t.token] ?? {trades:0,pnl:0,wins:0,losses:0}; x.trades++; x.pnl += t.realizedPnl??0; (t.realizedPnl??0)>0?x.wins++:x.losses++; m[t.token]=x; }
  return Object.entries(m).map(([token,v])=>({token,...v,winRatePct:v.trades?v.wins/v.trades*100:0})).sort((a,b)=>b.pnl-a.pnl);
}
