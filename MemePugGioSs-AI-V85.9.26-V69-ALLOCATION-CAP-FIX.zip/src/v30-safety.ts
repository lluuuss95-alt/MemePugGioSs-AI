export interface V30SafetyConfig { mode:'PAPER'|'SHADOW'; liveTradingAllowed:false; signingEnabled:false; privateKeyAccess:false; broadcastEnabled:false; }
export const V30_SAFETY:V30SafetyConfig = { mode:'PAPER', liveTradingAllowed:false, signingEnabled:false, privateKeyAccess:false, broadcastEnabled:false };
export function assertV30Safety(cfg=V30_SAFETY):void {
  if (cfg.mode !== 'PAPER' || cfg.liveTradingAllowed || cfg.signingEnabled || cfg.privateKeyAccess || cfg.broadcastEnabled) throw new Error('V30 safety invariant violated');
}
