import crypto from 'node:crypto';
import {db} from './db.js';
import {V28Signal} from './v28-types.js';
import {V36CopySignal} from './v36-types.js';
import {V37CopyPaperPortfolio} from './v37-copy-paper.js';
import {V38CopyRiskManager} from './v38-risk.js';
import {V41Config,V41Decision,V41DecisionInput,V41Snapshot} from './v41-types.js';

export const defaultV41Config:V41Config={minScore:65,minConfidence:60,maxRiskScore:45,maxFreshnessMs:30000,minLiquidityQuote:1000,maxDecisionsPerCycle:10,autoPaperExecution:true};

export class V41AutonomousOrchestrator{
  private cycle=0; private lastRunAt:number|null=null; private decisions:V41Decision[]=[];
  constructor(private copyPaper:V37CopyPaperPortfolio,private risk:V38CopyRiskManager,private cfg:V41Config=defaultV41Config){this.ensureSchema()}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v41_decisions(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,state TEXT NOT NULL,action TEXT NOT NULL,source TEXT NOT NULL,mint TEXT NOT NULL,side TEXT,signal_id TEXT,wallet TEXT,score REAL NOT NULL,confidence REAL NOT NULL,risk_score REAL NOT NULL,reasons_json TEXT NOT NULL,risk_checked INTEGER NOT NULL,paper_executed INTEGER NOT NULL)`)}
  private save(d:V41Decision){db.prepare(`INSERT OR REPLACE INTO v41_decisions(id,ts,state,action,source,mint,side,signal_id,wallet,score,confidence,risk_score,reasons_json,risk_checked,paper_executed) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(d.id,d.ts,d.state,d.action,d.source,d.mint,d.side||null,d.signalId||null,d.wallet||null,d.score,d.confidence,d.riskScore,JSON.stringify(d.reasons),d.riskChecked?1:0,d.paperExecuted?1:0);this.decisions.unshift(d);this.decisions=this.decisions.slice(0,500);return d}
  decide(input:V41DecisionInput,now=Date.now()):V41Decision{
    const mint=String(input.mint||''); const score=Number(input.score||0), confidence=Number(input.confidence||0), riskScore=Number(input.riskScore||100), freshness=Number(input.freshnessMs??0), liquidity=Number(input.liquidityQuote??0);
    const reasons:string[]=[];
    if(!mint) reasons.push('MINT_REQUIRED');
    if(input.side!=='BUY'&&input.side!=='SELL') reasons.push('SIDE_REQUIRED');
    if(score<this.cfg.minScore) reasons.push('SCORE_BELOW_THRESHOLD');
    if(confidence<this.cfg.minConfidence) reasons.push('CONFIDENCE_BELOW_THRESHOLD');
    if(riskScore>this.cfg.maxRiskScore) reasons.push('RISK_ABOVE_THRESHOLD');
    if(freshness>this.cfg.maxFreshnessMs) reasons.push('SIGNAL_STALE');
    if(input.source==='COPY_TRADER' && liquidity<this.cfg.minLiquidityQuote) reasons.push('LIQUIDITY_BELOW_THRESHOLD');
    const blocked=reasons.length>0;
    const d:V41Decision={id:crypto.randomUUID(),ts:now,state:blocked?'BLOCKED':'READY',action:blocked?'BLOCK':'OBSERVE',source:input.source||'NONE',mint,side:input.side,signalId:input.signalId,wallet:input.wallet,score,confidence,riskScore,reasons,riskChecked:false,paperExecuted:false,liveExecutionEnabled:false};
    return this.save(d);
  }
  runCycle(signals:V28Signal[],copySignals:V36CopySignal[],now=Date.now()){
    this.cycle++;this.lastRunAt=now;let paperExecutions=0,blocked=0,observed=0;
    const candidates:[V41DecisionInput][]=[];
    for(const s of signals.slice(0,this.cfg.maxDecisionsPerCycle)){ if(s.action!=='PAPER_CANDIDATE'){observed++; continue;} candidates.push([{mint:s.mint,source:'AI_SIGNAL',side:'BUY',score:s.score,confidence:s.confidence,riskScore:s.riskScore,freshnessMs:Math.max(0,now-s.generatedAt),reason:s.reasons.join('; ')} as V41DecisionInput]); }
    for(const s of copySignals.filter(x=>x.state==='ELIGIBLE').slice(0,this.cfg.maxDecisionsPerCycle)) candidates.push([{mint:s.mint,source:'COPY_TRADER',side:s.side,score:s.traderReputation,confidence:s.confidence,riskScore:s.traderRisk,freshnessMs:s.freshnessMs,liquidityQuote:s.liquidityQuote,signalId:s.id,wallet:s.wallet}]);
    for(const [input] of candidates.slice(0,this.cfg.maxDecisionsPerCycle)){
      const d=this.decide(input,now);
      if(d.state==='BLOCKED'){blocked++;continue}
      if(input.source==='COPY_TRADER'&&input.wallet&&input.mint&&input.side){const quote=1;const risk=this.risk.preflight({wallet:input.wallet,mint:input.mint,side:input.side,quoteAmount:quote,signalId:input.signalId||''});d.riskChecked=true;if(risk.decision!=='ALLOW'){d.state='BLOCKED';d.action='BLOCK';d.reasons=[...d.reasons,...risk.reasons];this.save(d);blocked++;continue}if(this.cfg.autoPaperExecution){d.action='COPY_PAPER';d.state='EXECUTED_PAPER';d.paperExecuted=false;/* execution requires a valid market price, so V41 never invents one */d.reasons.push('PAPER_EXECUTION_PENDING_MARKET_PRICE');this.save(d);observed++;continue}}
      d.action=input.side==='SELL'?'EXIT_PAPER':'ENTER_PAPER';d.state='READY';this.save(d);observed++;
    }
    return {cycle:this.cycle,runAt:now,paperExecutions,blocked,observed,decisions:this.recent(20)};
  }
  recent(limit=50){return db.prepare(`SELECT id,ts,state,action,source,mint,side,signal_id signalId,wallet,score,confidence,risk_score riskScore,reasons_json reasons,risk_checked riskChecked,paper_executed paperExecuted FROM v41_decisions ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit))).map((r:any)=>({...r,riskChecked:Boolean(r.riskChecked),paperExecuted:Boolean(r.paperExecuted),reasons:JSON.parse(r.reasons||'[]')})) as V41Decision[]}
  snapshot():V41Snapshot{const rows=this.recent(500);return {mode:'PAPER',state:'READY',lastRunAt:this.lastRunAt,cycle:this.cycle,decisions:rows.length,paperExecutions:rows.filter(x=>x.paperExecuted).length,blocked:rows.filter(x=>x.state==='BLOCKED').length,observed:rows.filter(x=>x.state==='READY').length,liveExecutionEnabled:false,lastDecision:rows[0]||null}}
}
