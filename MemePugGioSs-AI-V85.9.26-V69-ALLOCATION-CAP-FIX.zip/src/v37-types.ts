export type V37PaperTradeState='EXECUTED'|'REJECTED';
export type V37Side='BUY'|'SELL';
export interface V37Config{totalCopyCapital:number;maxTraderAllocationPct:number;feeBps:number;slippageBps:number;maxPositionPct:number;minPaperPrice:number}
export interface V37PaperMarket{price:number;slippageBps?:number;feeBps?:number;markPrice?:number}
export interface V37CopyAccount{wallet:string;allocatedCash:number;cash:number;equity:number;realizedPnl:number;unrealizedPnl:number;fees:number;slippageCost:number;trades:number;wins:number;losses:number;updatedAt:number}
export interface V37CopyPosition{wallet:string;mint:string;quantity:number;avgEntry:number;realizedPnl:number;updatedAt:number}
export interface V37PaperTrade{id:string;signalId:string;wallet:string;mint:string;side:V37Side;marketPrice:number;executionPrice:number;quantity:number;grossQuote:number;fee:number;slippageCost:number;pnl:number;state:V37PaperTradeState;reason?:string;executedAt:number}
export interface V37PortfolioSummary{totalAllocated:number;totalCash:number;totalEquity:number;realizedPnl:number;unrealizedPnl:number;netPnl:number;fees:number;slippageCost:number;trades:number;wins:number;losses:number;winRate:number;drawdownPct:number;byTrader:Array<{wallet:string;allocatedCash:number;equity:number;realizedPnl:number;unrealizedPnl:number;netPnl:number;trades:number;winRate:number}>}
