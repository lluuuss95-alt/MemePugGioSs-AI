/*
 V23 does not blindly decode raw account bytes.
 The layout is versioned behind this interface so an IDL/account decoder can be
 swapped in when the exact deployed account schema is selected.
*/
export interface VerifiedBondingCurveDecoder{
 name:string;
 canDecode(account:any):boolean;
 decode(account:any):import("./v23-types.js").BondingCurveState|null;
}
export interface VerifiedPumpSwapPoolDecoder{
 name:string;
 canDecode(account:any):boolean;
 decode(account:any):import("./v23-types.js").PumpSwapState|null;
}
