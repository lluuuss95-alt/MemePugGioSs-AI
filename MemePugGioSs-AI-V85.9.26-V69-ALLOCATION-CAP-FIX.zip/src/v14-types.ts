export interface SignalRow {
  mint:string; ts:number; signalState:string; score:number; confidence:number;
  futureReturnPct?:number; mfePct?:number; maePct?:number; horizonMs:number;
}

export interface Split {
  train:SignalRow[]; validation:SignalRow[]; test:SignalRow[];
}

export interface SignalReport {
  rows:number; signals:number; confirmed:number; blocked:number;
  meanReturn?:number; medianReturn?:number; winRatePct?:number;
  meanMfe?:number; meanMae?:number; ci95?:[number,number];
  sampleConfidence:number;
}
