import { V28Signal } from "./v28-types.js";

export class V28SignalStore {
  private readonly map = new Map<string,V28Signal>();
  upsert(signal:V28Signal){ this.map.set(signal.mint, signal); }
  get(mint:string){ return this.map.get(mint); }
  all(){ return [...this.map.values()].sort((a,b)=>b.score-a.score || b.generatedAt-a.generatedAt); }
  top(limit=20){ return this.all().slice(0,limit); }
  clear(){ this.map.clear(); }
}
