import {NormalizedMarketEvent} from "./v20-types.js";
export class SlotOrderingBuffer{
 private lastSlot=-1;
 constructor(private maxSkew=32){}
 push(e:NormalizedMarketEvent){
   if(e.slot<this.lastSlot-this.maxSkew)return {accepted:false,outOfOrder:true,event:e};
   if(e.slot>this.lastSlot)this.lastSlot=e.slot;
   return {accepted:true,outOfOrder:false,event:e};
 }
 getLastSlot(){return this.lastSlot}
}
