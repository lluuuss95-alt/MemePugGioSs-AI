import { V29RankingResult } from "./v29-types.js";

export interface V29HomeSignal {
  rank:number; mint:string; band:"TOP_SIGNAL"|"WATCHLIST"|"BLOCKED"|"EXCLUDED";
  state:string; score:number; confidence:number; riskScore:number; freshness:number;
  liquidityScore:number; smartMoneyScore:number; reasons:string[]; blockers:string[];
}

export function toV29HomeFeed(result:V29RankingResult):V29HomeSignal[] {
  return result.ranked.slice(0,20).map(s => ({
    rank:s.rank, mint:s.mint, band:s.band, state:s.state, score:s.compositeScore,
    confidence:s.confidence, riskScore:s.riskScore, freshness:s.freshness,
    liquidityScore:s.liquidityScore, smartMoneyScore:s.smartMoneyScore,
    reasons:s.reasons, blockers:s.blockers
  }));
}
