import crypto from 'node:crypto';
import { db } from './db.js';
import type { V59Result } from './v59-decision-reevaluation.js';
import type { V46Regime } from './v46-types.js';
import { V63CapitalAllocationOptimizer, type V63Candidate, type V63Snapshot } from './v63-capital-allocation-optimizer.js';
import type { V61PositionExposure } from './v61-portfolio-execution-coordinator.js';
import { assertV60Safe } from './v60-autonomous-loop-coordinator.js';
import { assertV61Safe } from './v61-portfolio-execution-coordinator.js';
import { assertV62Safe } from './v62-opportunity-arbitration.js';
import { assertV63Safe } from './v63-capital-allocation-optimizer.js';

export type V75Status='ALLOCATED'|'DEFERRED'|'BLOCKED'|'INSUFFICIENT_CONTEXT';
export interface V75Run {
  id:string; ts:number; mint:string; sourceDecisionId:string; status:V75Status;
  regime:V46Regime; requestedPct:number; optimizedQuote:number;
  arbitrationState:string; reasons:string[]; allocationSnapshotTs:number|null;
  liveExecutionEnabled:false;
}

const finite=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
function inferRegime(mult:number):V46Regime {
  if(mult>=0.99) return 'FAVORABLE';
  if(mult>=0.74) return 'NEUTRAL';
  if(mult>0) return 'HIGH_VOLATILITY';
  return 'UNKNOWN';
}

/**
 * V75 is the bridge from a V59 reevaluation into the already-built portfolio
 * arbitration/allocation stack. It never bypasses V61/V62/V63 limits and never
 * signs, broadcasts, or executes a live transaction. Paper execution remains
 * downstream of V64/V65/V69 and must be invoked separately.
 */
export class V75ReevaluationCapitalLoop {
  private readonly optimizer:V63CapitalAllocationOptimizer;
  constructor(optimizer=new V63CapitalAllocationOptimizer()) {
    this.optimizer=optimizer;
    this.ensureSchema();
    assertV60Safe(); assertV61Safe(); assertV62Safe(); assertV63Safe();
  }
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v75_capital_loop_runs(
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, mint TEXT NOT NULL, source_decision_id TEXT NOT NULL,
    status TEXT NOT NULL, regime TEXT NOT NULL, requested_pct REAL NOT NULL, optimized_quote REAL NOT NULL,
    arbitration_state TEXT NOT NULL, reasons_json TEXT NOT NULL, allocation_snapshot_ts INTEGER,
    live_execution_enabled INTEGER NOT NULL DEFAULT 0
  ); CREATE INDEX IF NOT EXISTS idx_v75_loop_ts ON v75_capital_loop_runs(ts);`);}

  process(result:V59Result, now=Date.now()):V75Run {
    const reasons:string[]=[];
    if(result.liveExecutionEnabled!==false) throw new Error('V75_LIVE_EXECUTION_FLAG_INVALID');
    if(result.outcome!=='ENTER_PAPER') return this.record({id:crypto.randomUUID(),ts:now,mint:result.mint,sourceDecisionId:result.id,status:'BLOCKED',regime:'UNKNOWN',requestedPct:0,optimizedQuote:0,arbitrationState:'HALTED',reasons:['V59_OUTCOME_NOT_ENTER_PAPER'],allocationSnapshotTs:null,liveExecutionEnabled:false});
    const obs=this.latestObservation(result.mint);
    const liquidity=Number(obs?.liquidity);
    if(!finite(liquidity) || liquidity<0) return this.record({id:crypto.randomUUID(),ts:now,mint:result.mint,sourceDecisionId:result.id,status:'INSUFFICIENT_CONTEXT',regime:inferRegime(result.deep.regimeMultiplier),requestedPct:result.theoreticalAllocationPct,optimizedQuote:0,arbitrationState:'HALTED',reasons:['VERIFIED_LIQUIDITY_CONTEXT_UNAVAILABLE'],allocationSnapshotTs:null,liveExecutionEnabled:false});
    const regime=inferRegime(result.deep.regimeMultiplier);
    const candidate:V63Candidate={
      id:`v75:${result.id}`, mint:result.mint, source:'AI_SIGNAL', score:result.score,
      confidence:result.confidence, riskScore:result.risk, liquidityQuote:liquidity,
      requestedPct:result.theoreticalAllocationPct, regime,
      priority:result.score*0.65+result.confidence*0.25-result.risk*0.10,
      correlationGroup:result.mint,
      existingExposureQuote:0,
      freshnessScore:finite(result.deep.liquidityScore)?Math.max(0,Math.min(100,100-result.risk)):undefined,
      liquidityScore:result.deep.liquidityScore, smartMoneyScore:result.deep.smartMoneyScore,
      strategyQuality:result.deep.creatorScore,
    };
    const positions=this.paperExposures();
    const snapshot:V63Snapshot=this.optimizer.optimize([candidate],positions,regime,now);
    const row=snapshot.allocations.find(a=>a.candidateId===candidate.id);
    const status:V75Status=row?.decision==='ALLOCATE'&&row.optimizedQuote>0?'ALLOCATED':row?.decision==='BLOCK'?'BLOCKED':'DEFERRED';
    reasons.push(...(row?.reasons??[]));
    if(status==='ALLOCATED') reasons.push('V63_ALLOCATION_APPROVED');
    else if(status==='DEFERRED') reasons.push('V63_ALLOCATION_DEFERRED');
    return this.record({id:crypto.randomUUID(),ts:now,mint:result.mint,sourceDecisionId:result.id,status,regime,requestedPct:result.theoreticalAllocationPct,optimizedQuote:row?.optimizedQuote??0,arbitrationState:snapshot.arbitration.state,reasons:[...new Set(reasons)],allocationSnapshotTs:snapshot.evaluatedAt,liveExecutionEnabled:false});
  }

  processMany(results:V59Result[],now=Date.now()){return results.map(r=>this.process(r,now));}
  processPending(limit=25,now=Date.now()){
    const n=Math.min(100,Math.max(1,limit));
    const rows=db.prepare(`SELECT result_json FROM v59_decision_reevaluations WHERE outcome='ENTER_PAPER' AND id NOT IN (SELECT source_decision_id FROM v75_capital_loop_runs) ORDER BY ts DESC LIMIT ?`).all(n) as any[];
    const results:V59Result[]=[];
    for(const r of rows){try{const parsed=JSON.parse(String(r.result_json)); if(parsed?.id) results.push(parsed as V59Result);}catch{/* malformed historical row is ignored */}}
    return this.processMany(results,now);
  }
  recent(limit=100,mint?:string){const n=Math.min(500,Math.max(1,limit)); return db.prepare(`SELECT * FROM v75_capital_loop_runs ${mint?'WHERE mint=?':''} ORDER BY ts DESC LIMIT ?`).all(...(mint?[mint,n]:[n]));}
  health(){const r=db.prepare(`SELECT COUNT(*) c,SUM(CASE WHEN status='ALLOCATED' THEN 1 ELSE 0 END) a,SUM(CASE WHEN status='BLOCKED' THEN 1 ELSE 0 END) b FROM v75_capital_loop_runs`).get() as any;return {state:'RUNNING',runs:Number(r?.c||0),allocated:Number(r?.a||0),blocked:Number(r?.b||0),liveExecutionEnabled:false};}

  private latestObservation(mint:string){try{return db.prepare('SELECT * FROM observations WHERE mint=? ORDER BY id DESC LIMIT 1').get(mint) as any;}catch{return undefined;}}
  private paperExposures():V61PositionExposure[]{
    try { return (db.prepare("SELECT mint,entry_notional FROM v52_paper_positions WHERE status='OPEN'").all() as any[]).map(p=>({mint:String(p.mint),notional:Number(p.entry_notional)||0,source:'AI_SIGNAL' as const})); }
    catch { return []; }
  }
  private record(r:V75Run){db.prepare(`INSERT INTO v75_capital_loop_runs(id,ts,mint,source_decision_id,status,regime,requested_pct,optimized_quote,arbitration_state,reasons_json,allocation_snapshot_ts,live_execution_enabled) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)`).run(r.id,r.ts,r.mint,r.sourceDecisionId,r.status,r.regime,r.requestedPct,r.optimizedQuote,r.arbitrationState,JSON.stringify(r.reasons),r.allocationSnapshotTs);return r;}
}

export const V75_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV75Safe(){if(!V75_SAFETY.shadowOnly||V75_SAFETY.signingEnabled||V75_SAFETY.privateKeyAccess||V75_SAFETY.broadcastEnabled||V75_SAFETY.liveExecutionAllowed||V75_SAFETY.autoPromotion)throw new Error('V75_SAFETY_INVARIANT_FAILED');}
