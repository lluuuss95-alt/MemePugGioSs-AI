export class RateLimiter {
  private nextAllowed=0;
  constructor(private readonly minDelayMs:number){}
  async wait(){
    const now=Date.now();
    const delay=Math.max(0,this.nextAllowed-now);
    if(delay) await new Promise(r=>setTimeout(r,delay));
    this.nextAllowed=Date.now()+this.minDelayMs;
  }
}
