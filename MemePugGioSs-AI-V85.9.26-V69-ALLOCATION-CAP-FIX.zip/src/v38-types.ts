export type V38RiskState='NORMAL'|'WARNING'|'HALTED';
export type V38Decision='ALLOW'|'BLOCK';
export interface V38Config{
  maxTotalExposurePct:number;
  maxTokenExposurePct:number;
  maxTraderExposurePct:number;
  maxDailyLossPct:number;
  maxDrawdownPct:number;
  warningDrawdownPct:number;
  maxConcurrentTraders:number;
  maxSharedTokenTraders:number;
  circuitBreakerLossPct:number;
  minAccountEquity:number;
}
export interface V38RiskSnapshot{
  state:V38RiskState;
  totalAllocated:number;
  totalEquity:number;
  totalExposure:number;
  totalExposurePct:number;
  dailyPnl:number;
  dailyLossPct:number;
  drawdownPct:number;
  activeTraders:number;
  activePositions:number;
  maxTokenExposurePct:number;
  maxTraderExposurePct:number;
  evaluatedAt:number;
}
export interface V38CopyRiskInput{
  wallet:string;
  mint:string;
  side:'BUY'|'SELL';
  quoteAmount:number;
  signalId?:string;
  now?:number;
}
export interface V38RiskDecision{
  decision:V38Decision;
  state:V38RiskState;
  reasons:string[];
  snapshot:V38RiskSnapshot;
  requestedQuote:number;
  tokenExposureBefore:number;
  tokenExposureAfter:number;
  traderExposureBefore:number;
  traderExposureAfter:number;
  concentrationPct:number;
  checkedAt:number;
}
