
import { DatasetRow } from "./v15-types.js";
import { MonteCarloSummary } from "./v16-types.js";

function rng(seed:number){let s=seed>>>0;return()=>{s=(1664525*s+1013904223)>>>0;return s/4294967296;};}
export function monteCarlo(rows:DatasetRow[],runs=1000,seed=17):MonteCarloSummary{
  const values:number[]=[]; const drawdowns:number[]=[];
  for(let i=0;i<runs;i++){
    const r=rng(seed+i*7919); let eq=1,peak=1,dd=0,total=0;
    for(let j=0;j<rows.length;j++){
      const x=rows[Math.floor(r()*rows.length)].futureReturnPct;
      eq*=1+x/100; total+=(x); peak=Math.max(peak,eq); dd=Math.max(dd,(peak-eq)/peak*100);
    }
    values.push(total); drawdowns.push(dd);
  }
  values.sort((a,b)=>a-b); drawdowns.sort((a,b)=>a-b);
  const q=(a:number[],p:number)=>a[Math.floor((a.length-1)*p)];
  return {runs,seed,meanReturn:values.reduce((a,b)=>a+b,0)/values.length,
    p05:q(values,.05),p50:q(values,.5),p95:q(values,.95),
    probabilityPositive:values.filter(x=>x>0).length/values.length*100,
    worstDrawdownP95:q(drawdowns,.95)};
}
