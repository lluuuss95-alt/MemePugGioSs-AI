import {V26DiscoveryStore, V26TokenDiscovery} from "./v26-types.js";
export interface V26SqlLike { exec(sql:string):void; prepare(sql:string):{run(...args:any[]):any;get(...args:any[]):any;all(...args:any[]):any[]}; }
export class V26SqliteDiscoveryStore implements V26DiscoveryStore {
  private readonly upsertStmt; private readonly getStmt; private readonly allStmt;
  constructor(private readonly db:V26SqlLike){
    db.exec(`CREATE TABLE IF NOT EXISTS v26_discovered_tokens (mint TEXT PRIMARY KEY,bonding_curve TEXT NOT NULL,signature TEXT NOT NULL,slot INTEGER NOT NULL,block_time INTEGER,create_kind TEXT NOT NULL,name TEXT,symbol TEXT,uri TEXT,creator TEXT,quote_mint TEXT,mayhem_mode INTEGER,holder_reward INTEGER,detected_at INTEGER NOT NULL);`);
    this.upsertStmt=db.prepare(`INSERT INTO v26_discovered_tokens (mint,bonding_curve,signature,slot,block_time,create_kind,name,symbol,uri,creator,quote_mint,mayhem_mode,holder_reward,detected_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(mint) DO UPDATE SET bonding_curve=excluded.bonding_curve,signature=excluded.signature,slot=excluded.slot,block_time=excluded.block_time,create_kind=excluded.create_kind,name=excluded.name,symbol=excluded.symbol,uri=excluded.uri,creator=excluded.creator,quote_mint=excluded.quote_mint,mayhem_mode=excluded.mayhem_mode,holder_reward=excluded.holder_reward,detected_at=excluded.detected_at`);
    this.getStmt=db.prepare(`SELECT * FROM v26_discovered_tokens WHERE mint=?`); this.allStmt=db.prepare(`SELECT * FROM v26_discovered_tokens ORDER BY detected_at DESC LIMIT 1000`);
  }
  has(mint:string){return !!this.getStmt.get(mint)}
  upsert(t:V26TokenDiscovery){this.upsertStmt.run(t.mint,t.bondingCurve,t.signature,t.slot,t.blockTime??null,t.createKind,t.name??null,t.symbol??null,t.uri??null,t.creator??null,t.quoteMint??null,t.mayhemMode?1:0,t.holderReward?1:0,t.detectedAt)}
  all(){return this.allStmt.all().map((r:any)=>({mint:r.mint,bondingCurve:r.bonding_curve,signature:r.signature,slot:Number(r.slot),blockTime:r.block_time==null?undefined:Number(r.block_time),createKind:r.create_kind,name:r.name??undefined,symbol:r.symbol??undefined,uri:r.uri??undefined,creator:r.creator??undefined,quoteMint:r.quote_mint??undefined,mayhemMode:!!r.mayhem_mode,holderReward:!!r.holder_reward,detectedAt:Number(r.detected_at)} as V26TokenDiscovery))}
}
