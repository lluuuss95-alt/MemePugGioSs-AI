import {parsePumpCreateTransaction} from "./v26-pump-create-parser.js";
import {PUMP_PROGRAM_ID} from "./v26-types.js";
import {V26DiscoveryStore} from "./v26-types.js";
import {V27CheckpointStore,V27RecoveryCallbacks,V27RecoveryHealth,V27RecoveryResult,V27SignatureInfo,V27SignatureRpc} from "./v27-types.js";

export class V27GapRecovery {
  private healthState:V27RecoveryHealth={status:"IDLE",runs:0,pages:0,signaturesScanned:0,transactionsFetched:0,recovered:0,alreadyKnown:0,failedTransactions:0};
  private running=false;
  constructor(
    private readonly rpc:V27SignatureRpc,
    private readonly store:V26DiscoveryStore,
    private readonly checkpoint:V27CheckpointStore,
    private readonly callbacks:V27RecoveryCallbacks={},
    private readonly options:{pageSize?:number;maxPages?:number;commitment?:"processed"|"confirmed"|"finalized"}={}
  ){}

  health(){return {...this.healthState};}

  async recover():Promise<V27RecoveryResult>{
    if(this.running) throw new Error("RECOVERY_ALREADY_RUNNING");
    this.running=true;
    const pageSize=Math.min(1000,Math.max(1,this.options.pageSize??100));
    const maxPages=Math.max(1,this.options.maxPages??100);
    const commitment=this.options.commitment??"confirmed";
    const cp=this.checkpoint.load();
    let before:string|undefined;
    let pages=0,scanned=0,recovered=0,alreadyKnown=0,failedTransactions=0;
    let reachedCheckpoint=false;
    let newestSignature:string|undefined;
    let newestSlot:number|undefined;
    this.setHealth({status:"RUNNING",runs:this.healthState.runs+1,lastRunAt:Date.now(),lastError:undefined});
    try{
      outer: while(pages<maxPages){
        const page=await this.rpc.getSignaturesForAddress(PUMP_PROGRAM_ID,{limit:pageSize,before,commitment});
        pages++; this.setHealth({pages,signaturesScanned:scanned});
        if(page.length===0) break;
        for(const info of page){
          scanned++; this.healthState.signaturesScanned=scanned;
          if(!newestSignature){newestSignature=info.signature;newestSlot=info.slot;}
          if(cp.lastSignature && info.signature===cp.lastSignature){reachedCheckpoint=true;break outer;}
          if(info.err!=null){continue;}
          if(this.store.all().some(t=>t.signature===info.signature)){alreadyKnown++;continue;}
          try{
            const tx=await this.rpc.getTransaction(info.signature,commitment);
            this.setHealth({transactionsFetched:this.healthState.transactionsFetched+1});
            if(!tx) continue;
            const token=parsePumpCreateTransaction(info.signature,tx,Date.now());
            if(!token) continue;
            if(this.store.has(token.mint)){alreadyKnown++;continue;}
            this.store.upsert(token); recovered++;
            await this.callbacks.onRecovered?.(token);
            this.setHealth({recovered:this.healthState.recovered+1,lastRecoveredAt:Date.now()});
          }catch(error){
            failedTransactions++;
            this.setHealth({failedTransactions:this.healthState.failedTransactions+1,lastError:error instanceof Error?error.message:String(error)});
          }
        }
        before=page[page.length-1]?.signature;
        if(page.length<pageSize) break;
      }
      if(newestSignature) this.checkpoint.save({lastSignature:newestSignature,lastSlot:newestSlot,updatedAt:Date.now()});
      this.setHealth({status:failedTransactions>0?"DEGRADED":"READY"});
      return {scanned,recovered,alreadyKnown,failedTransactions,pages,reachedCheckpoint,newestSignature,newestSlot};
    }catch(error){
      this.setHealth({status:"ERROR",lastError:error instanceof Error?error.message:String(error)});
      throw error;
    }finally{this.running=false;}
  }

  private setHealth(p:Partial<V27RecoveryHealth>){this.healthState={...this.healthState,...p,signaturesScanned:this.healthState.signaturesScanned};this.healthState.signaturesScanned=Math.max(this.healthState.signaturesScanned,0);this.callbacks.onHealth?.(this.health());}
}
