import {PumpAccountService} from "./v24-account-service.js";
import {DecodedPool} from "./v24-pump-decoder.js";
import {V25AccountKind, V25Health, V25LiveState, V25Snapshot, V25TokenBalance} from "./v25-types.js";
import {V25HttpRpc} from "./v25-rpc.js";
import {TokenAccountBalanceService} from "./v25-token-account.js";
import {buildBondingCurveLiveState, buildPumpSwapLiveState} from "./v25-reconcile.js";
import {V25AccountSubscriber} from "./v25-account-subscribe.js";

export interface V25TrackedToken { mint: string; bondingCurve?: string; pumpPool?: string; }

export class V25LiveStateEngine {
  private readonly tokenBalanceService: TokenAccountBalanceService;
  private readonly accountService: PumpAccountService;
  private readonly subscriber: V25AccountSubscriber;
  private readonly pools = new Map<string, DecodedPool>();
  private readonly bondingMints = new Map<string, string>();
  private readonly balances = new Map<string, V25TokenBalance>();
  private readonly states = new Map<string, V25LiveState>();
  private readonly supplies = new Map<string, {amount: bigint; decimals: number; slot: number}>();
  private healthState: V25Health = {websocket:"DISCONNECTED",subscriptions:0,staleAccounts:0,errors:0,reconnects:0};

  constructor(private readonly rpc: V25HttpRpc, websocketEndpoint: string, private readonly commitment = "finalized") {
    this.tokenBalanceService = new TokenAccountBalanceService(rpc);
    this.accountService = new PumpAccountService(rpc);
    this.subscriber = new V25AccountSubscriber(websocketEndpoint, {
      onSnapshot: snapshot => this.onSnapshot(snapshot),
      onHealth: health => { this.healthState = {...this.healthState, ...health}; },
    }, {commitment: commitment as any});
  }

  track(token: V25TrackedToken) {
    if (token.bondingCurve) {
      this.bondingMints.set(token.bondingCurve, token.mint);
      this.subscriber.subscribe({address:token.bondingCurve, kind:"BONDING_CURVE"});
    }
    if (token.pumpPool) this.subscriber.subscribe({address:token.pumpPool, kind:"PUMPSWAP_POOL"});
  }

  start() { this.subscriber.start(); }
  stop() { this.subscriber.stop(); }

  get(mint: string) { return this.states.get(mint); }
  all() { return [...this.states.values()]; }
  health() { return {...this.healthState, staleAccounts:this.countStale()}; }


  async hydrateBondingCurve(address: string, mint: string) {
    const state = await this.accountService.bondingCurve(address, mint, 0);
    if (!state) throw new Error("BONDING_CURVE_NOT_FOUND");
    this.bondingMints.set(address, mint);
    this.states.set(mint, buildBondingCurveLiveState(state));
    this.subscriber.subscribe({address, kind:"BONDING_CURVE"});
    return this.states.get(mint);
  }

  async hydratePumpPool(poolAddress: string) {
    const pool = await this.accountService.pool(poolAddress, 0);
    if (!pool) throw new Error("PUMP_POOL_NOT_FOUND");
    const [baseVault, quoteVault, supply] = await Promise.all([
      this.tokenBalanceService.read(pool.poolBaseTokenAccount, pool.slot),
      this.tokenBalanceService.read(pool.poolQuoteTokenAccount, pool.slot),
      this.rpc.getTokenSupply(pool.baseMint, this.commitment),
    ]);
    const amount = BigInt(supply?.value?.amount ?? 0);
    const decimals = Number(supply?.value?.decimals ?? 0);
    const supplySlot = Number(supply?.context?.slot ?? pool.slot);
    this.pools.set(poolAddress, pool);
    this.balances.set(pool.poolBaseTokenAccount, baseVault);
    this.balances.set(pool.poolQuoteTokenAccount, quoteVault);
    this.supplies.set(pool.baseMint, {amount, decimals, slot:supplySlot});
    this.recomputePool(poolAddress);
    return this.states.get(pool.baseMint);
  }

  private async onSnapshot(snapshot: V25Snapshot) {
    if (snapshot.kind === "BONDING_CURVE") {
      const mint = this.findMintForBonding(snapshot.address);
      if (!mint) return;
      const state = new (await import("./v24-pump-decoder.js")).PumpAccountDecoder().decodeBondingCurve(snapshot.data, mint, snapshot.slot);
      this.states.set(mint, buildBondingCurveLiveState(state));
      return;
    }
    if (snapshot.kind === "PUMPSWAP_POOL") {
      const pool = new (await import("./v24-pump-decoder.js")).PumpAccountDecoder().decodePool(snapshot.data, snapshot.slot);
      this.pools.set(snapshot.address, pool);
      await this.refreshPoolDependencies(pool);
      return;
    }
    if (snapshot.kind === "POOL_BASE_VAULT" || snapshot.kind === "POOL_QUOTE_VAULT") {
      const balance = snapshot.data && typeof snapshot.data === "object" && "amount" in snapshot.data
        ? snapshot.data as V25TokenBalance
        : null;
      if (balance) {
        this.balances.set(snapshot.address, balance);
        const poolAddress = this.findPoolByVault(snapshot.address);
        if (poolAddress) this.recomputePool(poolAddress);
      }
    }
  }

  private async refreshPoolDependencies(pool: DecodedPool) {
    const [base, quote, supply] = await Promise.all([
      this.tokenBalanceService.read(pool.poolBaseTokenAccount, pool.slot),
      this.tokenBalanceService.read(pool.poolQuoteTokenAccount, pool.slot),
      this.rpc.getTokenSupply(pool.baseMint, this.commitment),
    ]);
    this.balances.set(pool.poolBaseTokenAccount, base);
    this.balances.set(pool.poolQuoteTokenAccount, quote);
    this.supplies.set(pool.baseMint, {amount:BigInt(supply?.value?.amount ?? 0), decimals:Number(supply?.value?.decimals ?? 0), slot:Number(supply?.context?.slot ?? pool.slot)});
    this.subscriber.subscribeMany([
      {address:pool.poolBaseTokenAccount, kind:"POOL_BASE_VAULT"},
      {address:pool.poolQuoteTokenAccount, kind:"POOL_QUOTE_VAULT"},
    ]);
    this.recomputePoolByDecoded(pool);
  }

  private recomputePool(poolAddress: string) {
    const pool = this.pools.get(poolAddress);
    if (pool) this.recomputePoolByDecoded(pool);
  }

  private recomputePoolByDecoded(pool: DecodedPool) {
    const base = this.balances.get(pool.poolBaseTokenAccount);
    const quote = this.balances.get(pool.poolQuoteTokenAccount);
    const supply = this.supplies.get(pool.baseMint);
    if (!base || !quote || !supply) return;
    this.states.set(pool.baseMint, buildPumpSwapLiveState({pool,baseVault:base,quoteVault:quote,totalSupply:supply.amount,supplyDecimals:supply.decimals}));
  }

  private findMintForBonding(address: string) {
    return this.bondingMints.get(address);
  }

  private findPoolByVault(vault: string) {
    for (const [address, pool] of this.pools.entries()) if (pool.poolBaseTokenAccount === vault || pool.poolQuoteTokenAccount === vault) return address;
    return undefined;
  }

  private countStale() { return [...this.states.values()].filter(s => s.stale || !s.coherent).length; }
}
