import { V35AssistantSnapshot } from './v35-types.js';
import { V35ReputationEngine } from './v35-reputation.js';
import { db } from './db.js';

export class V35Assistant {
  constructor(private reputation:V35ReputationEngine){}
  snapshot():V35AssistantSnapshot{
    const followed=Number((db.prepare(`SELECT COUNT(*) c FROM v34_followed WHERE enabled=1`).get() as any)?.c||0);
    const qualified=this.reputation.top(100).filter(x=>x.state==='QUALIFIED').length;
    return {mode:'PAPER',state:'READY',lastAnalysisAt:Date.now(),followedTraders:followed,qualifiedTraders:qualified,paperActionsToday:0,liveExecutionEnabled:false};
  }
}
