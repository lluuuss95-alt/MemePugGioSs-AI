export function isRetryableError(err:any):boolean {
  const code=Number(err?.status ?? err?.code ?? 0);
  if(code===429 || code===408 || code>=500) return true;
  const msg=String(err?.message ?? err ?? "").toLowerCase();
  return /timeout|temporar|rate.?limit|econnreset|503|502/.test(msg);
}
export async function withRetry<T>(fn:()=>Promise<T>,maxRetries:number,baseMs:number,onRetry?:()=>void):Promise<T>{
  let attempt=0;
  while(true){
    try{return await fn();}
    catch(err){
      if(attempt>=maxRetries || !isRetryableError(err)) throw err;
      attempt++; onRetry?.();
      const delay=baseMs*Math.pow(2,attempt-1)+Math.floor(Math.random()*Math.max(1,baseMs));
      await new Promise(r=>setTimeout(r,delay));
    }
  }
}
