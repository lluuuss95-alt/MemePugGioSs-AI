export const V22_SAFETY=Object.freeze({mode:"SHADOW",liveTrading:false,signing:false,privateKeys:false,broadcast:false,autoPromotion:false});
export function assertV22Safety(){if(V22_SAFETY.mode!=="SHADOW"||V22_SAFETY.liveTrading||V22_SAFETY.signing||V22_SAFETY.privateKeys||V22_SAFETY.broadcast||V22_SAFETY.autoPromotion)throw new Error("V22 safety invariant failed");return true}
