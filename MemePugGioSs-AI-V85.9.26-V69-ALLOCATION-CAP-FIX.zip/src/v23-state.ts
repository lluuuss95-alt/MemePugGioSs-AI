import {BondingCurveState,MarketState,PumpSwapState} from "./v23-types.js";
import {bondingMarketCap,spotPrice,pumpSwapEffectiveQuote,progressBps,pumpSwapMarketCap} from "./v23-math.js";
export function bondingMarketState(s:BondingCurveState):MarketState{
 const p=spotPrice(s);
 return {mint:s.mint,venue:"BONDING_CURVE",priceQuotePerToken:p.numerator,priceScale:p.denominator,
  marketCapQuote:bondingMarketCap(s),graduationProgressBps:progressBps(s),complete:s.complete,confidence:1};
}
export function pumpSwapMarketState(s:PumpSwapState,totalSupply:bigint):MarketState{
 const effective=pumpSwapEffectiveQuote(s);
 return {mint:s.mint,venue:"PUMPSWAP",priceQuotePerToken:effective,priceScale:s.baseReserve,
  marketCapQuote:pumpSwapMarketCap(s,totalSupply),complete:true,confidence:1};
}
