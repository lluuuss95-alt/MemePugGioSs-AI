import { V34DiscoveryConfig, V34TraderProfile, V34TraderScore } from './v34-types.js';

const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));

export function scoreTrader(p: V34TraderProfile, cfg: V34DiscoveryConfig): V34TraderScore {
  const winRate=p.closedTrades>0 ? p.wins/p.closedTrades : 0;
  const profitFactor=p.grossLossQuote>0 ? p.grossProfitQuote/p.grossLossQuote : (p.grossProfitQuote>0?3:0);
  const pfScore=clamp(profitFactor/3*100);
  const consistency=clamp((winRate*60)+(pfScore*0.4));
  const risk=clamp((p.maxDrawdownPct*0.8)+(Math.max(0,50-p.consistencyScore)*0.4));
  const sampleConfidence=clamp((p.trades/Math.max(cfg.minTrades,1))*100);
  const quality=clamp(consistency*0.45 + (100-risk)*0.25 + sampleConfidence*0.20 + p.consistencyScore*0.10);
  const reasons:string[]=[];
  if(p.trades<cfg.minTrades) reasons.push('INSUFFICIENT_SAMPLE');
  if(sampleConfidence<cfg.minSampleConfidence) reasons.push('LOW_SAMPLE_CONFIDENCE');
  if(consistency<cfg.minConsistency) reasons.push('LOW_CONSISTENCY');
  if(risk>cfg.maxRisk) reasons.push('HIGH_RISK');
  if(!p.closedTrades) reasons.push('NO_CLOSED_TRADES');
  return {wallet:p.wallet,consistency,risk,sampleConfidence,quality,rank:0,reasons};
}

export function rankTraders(profiles:V34TraderProfile[], cfg:V34DiscoveryConfig): V34TraderScore[] {
  return profiles.map(p=>scoreTrader(p,cfg)).sort((a,b)=>b.quality-a.quality || a.wallet.localeCompare(b.wallet)).map((s,i)=>({...s,rank:i+1}));
}
