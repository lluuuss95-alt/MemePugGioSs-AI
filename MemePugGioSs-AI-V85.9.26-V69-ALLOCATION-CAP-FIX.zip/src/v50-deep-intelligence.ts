import crypto from 'node:crypto';
import { V26TokenDiscovery } from './v26-types.js';
import { V48Candidate } from './v48-ultra-discovery.js';
import { V49Score } from './v49-instant-scoring.js';

export type V50State='ANALYZED'|'INSUFFICIENT_DATA'|'BLOCKED';
export interface V50MarketSnapshot { price?:number; marketCap?:number; liquidity?:number; buyVolume?:number; sellVolume?:number; flowMomentum?:number; holders?:number; holderConcentration?:number; graduationProgress?:number; freshnessMs?:number; sampleSize?:number; }
export interface V50CreatorSnapshot { reputation?:number; priorTokens?:number; priorOutcomes?:number; risk?:number; knownBadPattern?:boolean; }
export interface V50SmartMoneySnapshot { score?:number; share?:number; netFlow?:number; wallets?:number; }
export interface V50Input { market?:V50MarketSnapshot; creator?:V50CreatorSnapshot; smartMoney?:V50SmartMoneySnapshot; regime?:'FAVORABLE'|'NEUTRAL'|'HIGH_VOLATILITY'|'STRESSED'|'NO_TRADE'|'UNKNOWN'; }
export interface V50Result { id:string; mint:string; signature:string; state:V50State; score:number; confidence:number; risk:number; opportunity:number; liquidityScore:number; flowScore:number; holderScore:number; creatorScore:number; smartMoneyScore:number; regimeMultiplier:number; reasons:string[]; blockers:string[]; analyzedAt:number; liveExecutionEnabled:false; }

const clamp=(n:number)=>Math.max(0,Math.min(100,n)); const round=(n:number)=>Math.round(n*100)/100;
const finite=(n:unknown):n is number=>typeof n==='number'&&Number.isFinite(n);

export const defaultV50Policy=Object.freeze({minLiquidity:1000,minConfidence:55,maxRisk:65,minSample:2});

/**
 * V50 performs deep analysis only from explicitly supplied, verified observations.
 * Missing data lowers confidence; it is never fabricated or inferred from names.
 */
export class V50DeepTokenIntelligence {
  constructor(private readonly policy=defaultV50Policy){}
  analyze(candidate:V48Candidate, instant:V49Score, input:V50Input={}, now=Date.now()):V50Result {
    const m=input.market??{}, c=input.creator??{}, s=input.smartMoney??{};
    const reasons:string[]=[]; const blockers:string[]=[];
    const liquidityScore=finite(m.liquidity)?clamp((m.liquidity/10000)*100):0;
    const flowScore=finite(m.flowMomentum)?clamp(50+m.flowMomentum):finite(m.buyVolume)&&finite(m.sellVolume)?clamp((m.buyVolume/(m.buyVolume+m.sellVolume||1))*100):0;
    const holderScore=finite(m.holderConcentration)?clamp(100-m.holderConcentration):finite(m.holders)?clamp(Math.log10(Math.max(1,m.holders))*25):0;
    const creatorScore=finite(c.reputation)?clamp(c.reputation):c.knownBadPattern?0:finite(c.priorTokens)?clamp(35+Math.min(40,c.priorTokens)):0;
    const smartMoneyScore=finite(s.score)?clamp(s.score):finite(s.share)?clamp(s.share*100):0;
    const riskParts:number[]=[];
    if(finite(c.risk)) riskParts.push(clamp(c.risk));
    if(finite(m.holderConcentration)) riskParts.push(clamp(m.holderConcentration));
    if(finite(m.freshnessMs)) riskParts.push(clamp(m.freshnessMs/100));
    const risk=riskParts.length?round(riskParts.reduce((a,b)=>a+b,0)/riskParts.length):round(clamp(100-instant.confidence));
    const regimeMultiplier=input.regime==='FAVORABLE'?1:input.regime==='NEUTRAL'?.75:input.regime==='HIGH_VOLATILITY'?.5:0;
    const opportunity=round(clamp(instant.score*.2+liquidityScore*.2+flowScore*.2+holderScore*.1+creatorScore*.1+smartMoneyScore*.2)*regimeMultiplier);
    const confidenceParts=[instant.confidence];
    if(finite(m.liquidity)) confidenceParts.push(80); if(finite(m.flowMomentum)||finite(m.buyVolume)) confidenceParts.push(75); if(finite(c.reputation)||finite(c.priorTokens)) confidenceParts.push(70); if(finite(s.score)||finite(s.share)) confidenceParts.push(70); if(finite(m.holders)||finite(m.holderConcentration)) confidenceParts.push(65);
    const confidence=round(clamp(confidenceParts.reduce((a,b)=>a+b,0)/confidenceParts.length));
    if(!finite(m.liquidity)) blockers.push('LIQUIDITY_DATA_MISSING'); else if(m.liquidity<this.policy.minLiquidity) blockers.push('LIQUIDITY_BELOW_MINIMUM');
    if(finite(m.sampleSize)&&m.sampleSize<this.policy.minSample) blockers.push('MARKET_SAMPLE_TOO_SMALL');
    if(input.regime==='NO_TRADE'||input.regime==='STRESSED') blockers.push('MARKET_REGIME_BLOCK');
    if(c.knownBadPattern) blockers.push('CREATOR_RISK_PATTERN');
    if(risk>this.policy.maxRisk) blockers.push('RISK_ABOVE_LIMIT');
    if(!finite(m.freshnessMs)) reasons.push('MARKET_FRESHNESS_NOT_AVAILABLE'); else if(m.freshnessMs>5000) reasons.push('MARKET_DATA_STALE');
    if(finite(m.graduationProgress)) reasons.push(`GRADUATION_PROGRESS_${round(m.graduationProgress)}`);
    if(finite(s.score)&&s.score>=60) reasons.push('SMART_MONEY_SIGNAL_PRESENT');
    if(finite(m.flowMomentum)&&m.flowMomentum>0) reasons.push('POSITIVE_FLOW_MOMENTUM');
    if(input.regime) reasons.push(`REGIME_${input.regime}`);
    let state:V50State='ANALYZED';
    if(blockers.length) state='BLOCKED'; else if(confidence<this.policy.minConfidence) state='INSUFFICIENT_DATA';
    return {id:crypto.randomUUID(),mint:candidate.token.mint,signature:candidate.signature,state,score:opportunity,confidence,risk,opportunity,liquidityScore:round(liquidityScore),flowScore:round(flowScore),holderScore:round(holderScore),creatorScore:round(creatorScore),smartMoneyScore:round(smartMoneyScore),regimeMultiplier,reasons,blockers,analyzedAt:now,liveExecutionEnabled:false};
  }
}

export interface V50PipelineCallbacks { onResult?(result:V50Result):void|Promise<void>; }
export class V50DeepPipeline {
  constructor(private readonly engine=new V50DeepTokenIntelligence(),private readonly callbacks:V50PipelineCallbacks={}){}
  async analyze(candidate:V48Candidate,instant:V49Score,input:V50Input={},now=Date.now()){ const result=this.engine.analyze(candidate,instant,input,now); await this.callbacks.onResult?.(result); return result; }
}
export const V50_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV50Safe(){if(!V50_SAFETY.shadowOnly||V50_SAFETY.signingEnabled||V50_SAFETY.privateKeyAccess||V50_SAFETY.broadcastEnabled||V50_SAFETY.liveExecutionAllowed) throw new Error('V50_SAFETY_INVARIANT_FAILED');}
