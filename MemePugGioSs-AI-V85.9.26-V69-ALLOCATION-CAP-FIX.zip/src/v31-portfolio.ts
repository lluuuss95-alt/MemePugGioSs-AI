import { PerformanceMetrics, PortfolioSnapshot, PortfolioState, PaperTrade } from './v31-types.js';

export function markPortfolio(state: PortfolioState, prices: Record<string, number>, now = Date.now()): PortfolioSnapshot {
  let unrealizedPnl = 0, exposure = 0;
  for (const t of state.trades.filter(x => x.status === 'OPEN')) {
    const p = prices[t.token] ?? t.entryPrice;
    exposure += p * t.quantity;
    unrealizedPnl += (p - t.entryPrice) * t.quantity - t.fees - t.slippage;
  }
  const realizedPnl = state.trades.filter(x => x.status === 'CLOSED').reduce((s,t) => s + (t.realizedPnl ?? 0), 0);
  const equity = state.cash + exposure + realizedPnl;
  state.peakEquity = Math.max(state.peakEquity, equity);
  const drawdown = state.peakEquity > 0 ? (state.peakEquity - equity) / state.peakEquity : 0;
  const snap = { timestamp: now, cash: state.cash, equity, unrealizedPnl, realizedPnl, exposure, drawdown, peakEquity: state.peakEquity, openPositions: state.trades.filter(x=>x.status==='OPEN').length };
  state.snapshots.push(snap); return snap;
}

export function closeTrade(state: PortfolioState, tradeId: string, exitPrice: number, reason: PaperTrade['closeReason'], now=Date.now()): PaperTrade {
  const t = state.trades.find(x => x.id === tradeId && x.status === 'OPEN'); if (!t) throw new Error('OPEN_TRADE_NOT_FOUND');
  t.exitPrice = exitPrice; t.closedAt = now; t.status = 'CLOSED'; t.closeReason = reason;
  t.realizedPnl = (exitPrice - t.entryPrice) * t.quantity - t.fees - t.slippage;
  return t;
}

export function performance(state: PortfolioState, startingCapital: number): PerformanceMetrics {
  const closed = state.trades.filter(x=>x.status==='CLOSED');
  const wins = closed.filter(t=>(t.realizedPnl ?? 0)>0), losses = closed.filter(t=>(t.realizedPnl ?? 0)<0);
  const realizedPnl = closed.reduce((s,t)=>s+(t.realizedPnl??0),0);
  const last = state.snapshots[state.snapshots.length-1];
  const grossWin = wins.reduce((s,t)=>s+(t.realizedPnl??0),0), grossLoss = Math.abs(losses.reduce((s,t)=>s+(t.realizedPnl??0),0));
  const maxDD = state.snapshots.reduce((m,s)=>Math.max(m,s.drawdown),0);
  const avgWin = wins.length ? grossWin/wins.length : 0, avgLoss = losses.length ? grossLoss/losses.length : 0;
  return { startingCapital, currentEquity: last?.equity ?? startingCapital, totalReturnPct: ((last?.equity ?? startingCapital)-startingCapital)/startingCapital*100,
    realizedPnl, unrealizedPnl: last?.unrealizedPnl ?? 0, maxDrawdownPct: maxDD*100, winRatePct: closed.length ? wins.length/closed.length*100 : 0,
    profitFactor: grossLoss ? grossWin/grossLoss : grossWin>0 ? Infinity : 0, averageWin: avgWin, averageLoss: avgLoss,
    expectancy: closed.length ? realizedPnl/closed.length : 0, trades: closed.length, wins: wins.length, losses: losses.length };
}
