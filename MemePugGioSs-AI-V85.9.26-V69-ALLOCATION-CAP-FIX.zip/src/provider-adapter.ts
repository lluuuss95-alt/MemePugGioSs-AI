import { HistoricalEvent } from "./historical-types.js";

export interface HistoricalProviderAdapter {
  readonly id:string;
  readonly version:string;
  fetchRange(input:{mint:string;from:number;to:number}):Promise<any[]>;
  normalize(raw:any,index:number):HistoricalEvent|undefined;
}
