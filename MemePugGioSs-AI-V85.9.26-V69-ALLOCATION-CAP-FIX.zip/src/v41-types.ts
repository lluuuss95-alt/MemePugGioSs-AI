export type V41DecisionAction='OBSERVE'|'ENTER_PAPER'|'EXIT_PAPER'|'COPY_PAPER'|'BLOCK';
export type V41DecisionState='READY'|'EXECUTED_PAPER'|'BLOCKED'|'NO_OPPORTUNITY';
export type V41Source='AI_SIGNAL'|'COPY_TRADER'|'NONE';
export interface V41DecisionInput{mint?:string;source?:V41Source;side?:'BUY'|'SELL';score?:number;confidence?:number;riskScore?:number;freshnessMs?:number;liquidityQuote?:number;reason?:string;signalId?:string;wallet?:string;}
export interface V41Decision{ id:string; ts:number; state:V41DecisionState; action:V41DecisionAction; source:V41Source; mint:string; side?:'BUY'|'SELL'; signalId?:string; wallet?:string; score:number; confidence:number; riskScore:number; reasons:string[]; riskChecked:boolean; paperExecuted:boolean; liveExecutionEnabled:false; }
export interface V41Config{minScore:number;minConfidence:number;maxRiskScore:number;maxFreshnessMs:number;minLiquidityQuote:number;maxDecisionsPerCycle:number;autoPaperExecution:boolean;}
export interface V41Snapshot{mode:'PAPER'|'SHADOW';state:'ANALYZING'|'READY'|'PAUSED';lastRunAt:number|null;cycle:number;decisions:number;paperExecutions:number;blocked:number;observed:number;liveExecutionEnabled:false;lastDecision:V41Decision|null;}
