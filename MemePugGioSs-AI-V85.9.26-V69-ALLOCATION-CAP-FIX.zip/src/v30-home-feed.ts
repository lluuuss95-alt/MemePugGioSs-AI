import { V30PaperState } from './v30-types.js';
export interface V30HomeExecutionFeed { paperCash:number; paperEquity:number; realizedPnl:number; unrealizedPnl:number; openPositions:number; lastDecision:string|null; }
export function toV30HomeExecutionFeed(state:V30PaperState):V30HomeExecutionFeed { const last=state.decisions[state.decisions.length-1]; return {paperCash:state.cash,paperEquity:state.equity,realizedPnl:state.realizedPnl,unrealizedPnl:state.unrealizedPnl,openPositions:state.positions.filter(p=>p.status==='OPEN').length,lastDecision:last?.decision ?? null}; }
