import "node:process";
export const config={
 port:Number(process.env.PORT??8787),
 mode:(process.env.APP_MODE??"PAPER") as "PAPER"|"SHADOW"|"LIVE",
 db:process.env.DATABASE_PATH??"./data/memepuggi-oss-ai-v5.db.js",
 jwtSecret:process.env.JWT_SECRET??"CHANGE_ME",
 adminUser:process.env.ADMIN_USER??"admin",
 adminPassword:process.env.ADMIN_PASSWORD??"CHANGE_ME",
 rpc:process.env.SOLANA_RPC_URL??"",
 rpcWs:process.env.SOLANA_RPC_WS_URL??"",
 solanaMentionProgram:process.env.SOLANA_MENTION_PROGRAM??"",
 feed:process.env.MARKET_FEED_URL??"",
 startingCash:Number(process.env.PAPER_STARTING_CASH??10000),
 pollMs:Number(process.env.MARKET_POLL_MS??5000),
 maxQueue:Number(process.env.MAX_INGEST_QUEUE??500),
 staleMs:Number(process.env.STALE_MARKET_MS??15000),
 feeBps:Number(process.env.PAPER_FEE_BPS??10),
 slippageBps:Number(process.env.PAPER_SLIPPAGE_BPS??30),
 rpcTimeoutMs:Number(process.env.SOLANA_RPC_TIMEOUT_MS??5000),
 minOpportunityScore:Number(process.env.MIN_OPPORTUNITY_SCORE??65),
 maxRiskScore:Number(process.env.MAX_TOKEN_RISK_SCORE??45),
 maxTopHolderPct:Number(process.env.MAX_TOP_HOLDER_PCT??25),
 intelCacheMs:Number(process.env.INTEL_CACHE_MS??30000),
 intelBatchSize:Number(process.env.INTEL_BATCH_SIZE??10)
};
if(config.mode==="LIVE") throw new Error("LIVE_MODE_DISABLED_V5");
