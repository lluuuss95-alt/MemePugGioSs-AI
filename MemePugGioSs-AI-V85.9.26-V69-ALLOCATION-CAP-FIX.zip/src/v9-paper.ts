export interface PaperPosition {
  entry:number;
  quantity:number;
  stopLoss:number;
  takeProfit:number;
}

export interface PaperOutcome {
  exit:number;
  pnl:number;
  returnPct:number;
  reason:"TAKE_PROFIT"|"STOP_LOSS"|"SIGNAL_INVALIDATED"|"END_OF_WINDOW";
}

export function simulateExit(p:PaperPosition, prices:number[], invalidatedAt?:number):PaperOutcome {
  for(const price of prices){
    if(price>=p.takeProfit) return {exit:price,pnl:(price-p.entry)*p.quantity,returnPct:(price/p.entry-1)*100,reason:"TAKE_PROFIT"};
    if(price<=p.stopLoss) return {exit:price,pnl:(price-p.entry)*p.quantity,returnPct:(price/p.entry-1)*100,reason:"STOP_LOSS"};
  }
  const exit=prices.at(-1) ?? p.entry;
  const reason=invalidatedAt!==undefined?"SIGNAL_INVALIDATED":"END_OF_WINDOW";
  return {exit,pnl:(exit-p.entry)*p.quantity,returnPct:(exit/p.entry-1)*100,reason};
}
