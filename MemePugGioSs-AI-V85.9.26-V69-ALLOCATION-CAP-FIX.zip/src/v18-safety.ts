
export const V18_SAFETY = Object.freeze({
  mode:"SHADOW",
  signingEnabled:false,
  broadcastEnabled:false,
  privateKeyAccess:false,
  liveExecutionAllowed:false
});
export function assertShadowOnly(){if(V18_SAFETY.mode!=="SHADOW"||V18_SAFETY.signingEnabled||V18_SAFETY.broadcastEnabled)throw new Error("V18 shadow safety invariant violated");}
