import crypto from 'node:crypto';
import { db } from './db.js';
import { V70SystemHealthRecovery, type V70ComponentStatus, type V70Result } from './v70-system-health-recovery.js';
import { V79PaperPortfolioReconciliation, type V79Report } from './v79-paper-portfolio-reconciliation.js';

export type V80State='READY'|'RECOVERING'|'BLOCKED'|'DEGRADED';
export type V80Action='NONE'|'RUN_RECOVERY'|'BLOCK_PAPER'|'ALLOW_PAPER'|'FLAG_MANUAL_REVIEW';
export interface V80Input { now?:number; components?:V70ComponentStatus[]; queueDepth?:number; maxQueueDepth?:number; errorRatePct?:number; consecutiveRecoveryFailures?:number; forceRecovery?:boolean; }
export interface V80Result { id:string; ts:number; state:V80State; action:V80Action; paperExecutionAllowed:boolean; health:V70Result; recovery?:V79Report; reasons:string[]; liveExecutionEnabled:false; }

export const V80_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV80Safe(){if(!V80_SAFETY.shadowOnly||V80_SAFETY.signingEnabled||V80_SAFETY.privateKeyAccess||V80_SAFETY.broadcastEnabled||V80_SAFETY.liveExecutionAllowed||V80_SAFETY.autoPromotion)throw new Error('V80_SAFETY_INVARIANT_FAILED');}

const allHealthy=(now:number):V70ComponentStatus[]=>[
  'SOLANA_FEED','PUMPFUN_DISCOVERY','AI_PIPELINE','DATABASE','SCHEDULER','PAPER_EXECUTION','WEBSOCKET'
].map(component=>({component:component as any,state:'HEALTHY',lastHeartbeat:now,latencyMs:0}));

export class V80AutonomousPaperRecoverySupervisor {
  private readonly healthEngine:V70SystemHealthRecovery;
  private readonly reconciliation:V79PaperPortfolioReconciliation;
  private last?:V80Result;
  constructor(healthEngine?:V70SystemHealthRecovery,reconciliation?:V79PaperPortfolioReconciliation){
    this.healthEngine=healthEngine??new V70SystemHealthRecovery();
    this.reconciliation=reconciliation??new V79PaperPortfolioReconciliation();
    this.ensureSchema(); assertV80Safe();
  }
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v80_recovery_supervisor_runs(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,state TEXT NOT NULL,action TEXT NOT NULL,paper_execution_allowed INTEGER NOT NULL,health_state TEXT NOT NULL,recovery_state TEXT,reasons_json TEXT NOT NULL,result_json TEXT NOT NULL)`);db.exec(`CREATE INDEX IF NOT EXISTS idx_v80_runs_ts ON v80_recovery_supervisor_runs(ts)`);}

  tick(input:V80Input={}):V80Result{
    const now=input.now??Date.now();
    const components=input.components?.length?input.components:allHealthy(now);
    const health=this.healthEngine.evaluate({now,components,queueDepth:input.queueDepth,maxQueueDepth:input.maxQueueDepth,errorRatePct:input.errorRatePct,consecutiveRecoveryFailures:input.consecutiveRecoveryFailures});
    const reasons=[...health.reasons];
    let state:V80State='READY',action:V80Action='ALLOW_PAPER',allowed=false,recovery:V79Report|undefined;
    const shouldRecover=Boolean(input.forceRecovery)||health.state==='DEGRADED'||health.state==='RECOVERING'||health.state==='HALTED';
    if(shouldRecover){
      state='RECOVERING'; action='RUN_RECOVERY'; allowed=false;
      recovery=this.reconciliation.recover(now);
      if(recovery.state==='HEALTHY'||recovery.state==='RECOVERED'){
        const post=this.healthEngine.evaluate({now,components:allHealthy(now),queueDepth:0,maxQueueDepth:input.maxQueueDepth,errorRatePct:0,consecutiveRecoveryFailures:0});
        if(post.state==='RUNNING'){state='READY';action='ALLOW_PAPER';allowed=true;}
        else {state='DEGRADED';action='BLOCK_PAPER';reasons.push('POST_RECOVERY_HEALTH_NOT_RUNNING');}
      } else {state=recovery.state==='FAILED'?'BLOCKED':'DEGRADED';action=recovery.state==='FAILED'?'BLOCK_PAPER':'FLAG_MANUAL_REVIEW';reasons.push(`RECOVERY_${recovery.state}`);}
    } else if(health.state==='RUNNING'){state='READY';action='ALLOW_PAPER';allowed=true;}
    else {state='BLOCKED';action='BLOCK_PAPER';reasons.push('HEALTH_NOT_SAFE_TO_RUN_PAPER');}
    const result:V80Result={id:crypto.randomUUID(),ts:now,state,action,paperExecutionAllowed:allowed,health,recovery,reasons:[...new Set(reasons)],liveExecutionEnabled:false};
    this.last=result;db.prepare(`INSERT INTO v80_recovery_supervisor_runs VALUES(?,?,?,?,?,?,?,?,?)`).run(result.id,now,result.state,result.action,allowed?1:0,health.state,recovery?.state??null,JSON.stringify(result.reasons),JSON.stringify(result));
    return result;
  }
  current():V80Result|null{return this.last??null;}
  recent(limit=50){return db.prepare(`SELECT * FROM v80_recovery_supervisor_runs ORDER BY ts DESC LIMIT ?`).all(Math.min(200,Math.max(1,limit)));}
  status(){const r=this.current() as any;return {state:r?.state??'UNKNOWN',action:r?.action??'NONE',paperExecutionAllowed:Boolean(r?.paperExecutionAllowed),healthState:r?.health?.state??r?.health_state??'UNKNOWN',recoveryState:r?.recovery?.state??r?.recovery_state??null,lastTs:Number(r?.ts||0),liveExecutionEnabled:false};}
}
