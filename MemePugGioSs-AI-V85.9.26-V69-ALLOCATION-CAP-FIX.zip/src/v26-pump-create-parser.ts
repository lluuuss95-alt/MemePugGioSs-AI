import {decodeBase58} from "./v26-base58.js";
import {PUMP_PROGRAM_ID, V26CreateKind, V26TokenDiscovery} from "./v26-types.js";

// Verified against the current Pump public IDL. create is legacy SPL-token flow;
// create_v2 is the current Token-2022-compatible creation flow.
const CREATE = Uint8Array.from([24,30,200,40,5,28,7,119]);
const CREATE_V2 = Uint8Array.from([214,144,76,236,95,139,49,180]);

function equal(a: Uint8Array, b: Uint8Array) { return a.length >= b.length && b.every((v, i) => a[i] === v); }

function readU32LE(b: Uint8Array, o: number) {
  if (o + 4 > b.length) throw new Error("TRUNCATED_U32");
  return (b[o] | (b[o+1] << 8) | (b[o+2] << 16) | (b[o+3] << 24)) >>> 0;
}
function readString(b: Uint8Array, o: number): {value:string; next:number} {
  const len = readU32LE(b, o); o += 4;
  if (o + len > b.length) throw new Error("TRUNCATED_STRING");
  return {value:new TextDecoder().decode(b.slice(o, o + len)), next:o + len};
}
function readPubkeyBase58(b: Uint8Array, o: number): {value:string; next:number} {
  if (o + 32 > b.length) throw new Error("TRUNCATED_PUBKEY");
  return {value:encodeBase58(b.slice(o, o + 32)), next:o + 32};
}
function encodeBase58(bytes: Uint8Array) {
  let n = 0n; for (const x of bytes) n = (n << 8n) + BigInt(x);
  let out = ""; while (n > 0n) { const r = Number(n % 58n); out = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"[r] + out; n /= 58n; }
  for (const x of bytes) { if (x !== 0) break; out = "1" + out; }
  return out || "1";
}

function allAccountKeys(tx: any): string[] {
  const staticKeys = (tx?.transaction?.message?.accountKeys ?? []).map((k:any) => typeof k === "string" ? k : k?.pubkey).filter(Boolean);
  const loaded = tx?.meta?.loadedAddresses;
  return [...staticKeys, ...(loaded?.writable ?? []), ...(loaded?.readonly ?? [])];
}
function compiledInstructions(tx: any): any[] {
  return tx?.transaction?.message?.instructions ?? [];
}

export interface ParsedCreateCandidate {
  mint: string;
  bondingCurve: string;
  kind: V26CreateKind;
  name?: string;
  symbol?: string;
  uri?: string;
  creator?: string;
  quoteMint?: string;
  mayhemMode?: boolean;
  holderReward?: boolean;
}

function parseArgs(kind: V26CreateKind, data: Uint8Array) {
  let o = 8;
  try {
    const name = readString(data, o); o = name.next;
    const symbol = readString(data, o); o = symbol.next;
    const uri = readString(data, o); o = uri.next;
    const creator = readPubkeyBase58(data, o); o = creator.next;
    if (kind === "CREATE") return {name:name.value, symbol:symbol.value, uri:uri.value, creator:creator.value};
    const mayhemMode = data[o] === 1; o += 1;
    // Pump's OptionBool/OptionU64 are defined structs with one bool/u64 field.
    // They are EOF-tolerant in create_v2: an omitted trailing field means false/0.
    if (o < data.length) o += 1; // deprecated is_cashback_enabled
    if (o + 8 <= data.length) o += 8; // creator_fee_bps
    let holderReward = false;
    if (o < data.length) holderReward = data[o] === 1;
    return {name:name.value, symbol:symbol.value, uri:uri.value, creator:creator.value, mayhemMode, holderReward};
  } catch {
    return {};
  }
}

export function parsePumpCreateTransaction(signature: string, tx: any, now = Date.now()): V26TokenDiscovery | null {
  if (!tx || tx.meta?.err) return null;
  const keys = allAccountKeys(tx);
  for (const ix of compiledInstructions(tx)) {
    const programId = typeof ix?.programId === "string" ? ix.programId : keys[Number(ix?.programIdIndex)];
    if (programId !== PUMP_PROGRAM_ID || typeof ix?.data !== "string" || !Array.isArray(ix?.accounts)) continue;
    let data: Uint8Array;
    try { data = decodeBase58(ix.data); } catch { continue; }
    const kind: V26CreateKind | undefined = equal(data, CREATE) ? "CREATE" : equal(data, CREATE_V2) ? "CREATE_V2" : undefined;
    if (!kind) continue;
    const mint = keys[Number(ix.accounts[0])];
    const bondingCurve = keys[Number(ix.accounts[2])];
    if (!mint || !bondingCurve) return null;
    const args = parseArgs(kind, data);
    const quoteMint = kind === "CREATE_V2" && ix.accounts.length > 16 ? keys[Number(ix.accounts[16])] : undefined;
    const slot = Number(tx.slot ?? tx.meta?.slot ?? 0);
    return {mint, bondingCurve, signature, slot, blockTime: typeof tx.blockTime === "number" ? tx.blockTime : undefined, createKind:kind, quoteMint, ...args, detectedAt:now};
  }
  return null;
}

export function parseLogCandidate(signature: string, logMessage: any): boolean {
  return typeof logMessage === "string" && logMessage.includes("Program " + PUMP_PROGRAM_ID + " invoke");
}
