export type FeedStatus="DISCONNECTED"|"CONNECTING"|"CONNECTED"|"DEGRADED"|"STOPPED";
export interface FeedConfig{wsUrl:string;commitment:"processed"|"confirmed"|"finalized";mentions?:string;reconnectBaseMs:number;reconnectMaxMs:number;maxQueue:number;}
export interface SolanaLogEvent{signature:string;slot:number;err:any;logs:string[];receivedAt:number;}
export interface FeedHealth{status:FeedStatus;connectedAt?:number;lastEventAt?:number;reconnects:number;droppedEvents:number;queueDepth:number;lastError?:string;latencyMs?:number;}
