import crypto from 'node:crypto';
import {PUMP_PROGRAM_ID, V26TokenDiscovery, V26TransactionRpc} from './v26-types.js';
import {parseLogCandidate, parsePumpCreateTransaction} from './v26-pump-create-parser.js';

export type V48Priority = 'P0'|'P1'|'P2'|'REJECTED';
export type V48Action = 'DEEP_ANALYSIS'|'WATCH'|'REJECT';

export interface V48Candidate {
  id:string;
  signature:string;
  slot:number;
  receivedAt:number;
  /** Backward-compatible alias retained for older V56/V60 fixtures. */
  detectedAt?:number;
  verifiedAt:number;
  verificationLatencyMs:number;
  token:V26TokenDiscovery;
  priority:V48Priority;
  action:V48Action;
  reasons:string[];
}

export interface V48Health {
  state:'STOPPED'|'RUNNING'|'DEGRADED';
  eventsSeen:number;
  queued:number;
  inFlight:number;
  verified:number;
  discovered:number;
  duplicates:number;
  rejected:number;
  failed:number;
  maxQueueDepth:number;
  avgVerificationLatencyMs:number;
  p95VerificationLatencyMs:number;
  lastEventAt?:number;
  lastDiscoveredAt?:number;
  lastError?:string;
}

export interface V48Config {
  concurrency:number;
  maxQueue:number;
  maxSeen:number;
  maxVerificationLatencyMs:number;
  minNameLength:number;
  minSymbolLength:number;
  processCreateV2:boolean;
}

export const defaultV48Config:V48Config={
  concurrency:8,
  maxQueue:2000,
  maxSeen:50000,
  maxVerificationLatencyMs:2500,
  minNameLength:2,
  minSymbolLength:1,
  processCreateV2:true,
};

export interface V48Callbacks {
  onCandidate?(candidate:V48Candidate):void|Promise<void>;
  onHealth?(health:V48Health):void;
  onError?(error:Error):void;
}

interface QueueItem { signature:string; slot:number; logs:string[]; receivedAt:number; }

/**
 * Low-latency Pump.fun discovery layer. It does not guess that a log is a token
 * creation: every queued event is verified with getTransaction and the official
 * V26 create/create_v2 parser before entering the downstream AI pipeline.
 */
export class V48UltraLowLatencyDiscovery {
  private readonly cfg:V48Config;
  private readonly queue:QueueItem[]=[];
  private readonly seenSignatures=new Set<string>();
  private readonly seenMints=new Set<string>();
  private readonly latencies:number[]=[];
  private inFlight=0;
  private running=false;
  private draining=false;
  private healthState:V48Health={state:'STOPPED',eventsSeen:0,queued:0,inFlight:0,verified:0,discovered:0,duplicates:0,rejected:0,failed:0,maxQueueDepth:0,avgVerificationLatencyMs:0,p95VerificationLatencyMs:0};

  constructor(private readonly rpc:V26TransactionRpc, private readonly callbacks:V48Callbacks={}, cfg:Partial<V48Config>={}) {
    this.cfg={...defaultV48Config,...cfg,concurrency:Math.max(1,Math.min(32,Math.floor(cfg.concurrency??defaultV48Config.concurrency))),maxQueue:Math.max(1,Math.floor(cfg.maxQueue??defaultV48Config.maxQueue))};
  }

  start(){this.running=true;this.setHealth({state:'RUNNING'});void this.drain();}
  stop(){this.running=false;this.queue.length=0;this.setHealth({state:'STOPPED',queued:0});}
  health(){return {...this.healthState};}

  /** Feed directly from logsSubscribe. Returns false when the event is not a Pump.fun log candidate. */
  ingestLog(signature:string,slot:number,logs:string[],receivedAt=Date.now()):boolean {
    this.healthState.eventsSeen++;
    this.setHealth({eventsSeen:this.healthState.eventsSeen,lastEventAt:receivedAt});
    if(!signature || !logs.some(x=>parseLogCandidate(signature,x))) return false;
    if(this.seenSignatures.has(signature)){this.healthState.duplicates++;this.setHealth({duplicates:this.healthState.duplicates});return true;}
    this.remember(this.seenSignatures,signature,this.cfg.maxSeen);
    if(this.queue.length>=this.cfg.maxQueue){
      // Keep newest events: the queue is an ingress buffer, not a second ledger.
      this.queue.shift();
      this.healthState.rejected++;
    }
    this.queue.push({signature,slot,logs,receivedAt});
    this.setHealth({queued:this.queue.length,maxQueueDepth:Math.max(this.healthState.maxQueueDepth,this.queue.length)});
    void this.drain();
    return true;
  }

  private async drain(){
    if(this.draining)return;
    this.draining=true;
    try{
      while(this.running && this.inFlight<this.cfg.concurrency && this.queue.length){
        const item=this.queue.shift()!;
        this.inFlight++;
        this.setHealth({queued:this.queue.length,inFlight:this.inFlight});
        void this.process(item).finally(()=>{this.inFlight--;this.setHealth({inFlight:this.inFlight});void this.drain();});
      }
    } finally { this.draining=false; }
  }

  private async process(item:QueueItem){
    try{
      const tx=await this.rpc.getTransaction(item.signature,'confirmed');
      const verifiedAt=Date.now();
      const token=parsePumpCreateTransaction(item.signature,tx,verifiedAt);
      this.healthState.verified++;
      const latency=Math.max(0,verifiedAt-item.receivedAt);
      this.recordLatency(latency);
      this.setHealth({verified:this.healthState.verified});
      if(!token){return;}
      if(!this.cfg.processCreateV2 && token.createKind==='CREATE_V2'){this.healthState.rejected++;this.setHealth({rejected:this.healthState.rejected});return;}
      if(this.seenMints.has(token.mint)){this.healthState.duplicates++;this.setHealth({duplicates:this.healthState.duplicates});return;}
      this.remember(this.seenMints,token.mint,this.cfg.maxSeen);
      const triage=this.triage(token,latency);
      if(triage.action==='REJECT'){this.healthState.rejected++;this.setHealth({rejected:this.healthState.rejected});}
      else {this.healthState.discovered++;this.setHealth({discovered:this.healthState.discovered,lastDiscoveredAt:verifiedAt});}
      const candidate:V48Candidate={id:crypto.randomUUID(),signature:item.signature,slot:item.slot||Number(tx?.slot??0),receivedAt:item.receivedAt,verifiedAt,verificationLatencyMs:latency,token,priority:triage.priority,action:triage.action,reasons:triage.reasons};
      await this.callbacks.onCandidate?.(candidate);
    } catch(error){
      this.healthState.failed++;
      this.setHealth({state:'DEGRADED',failed:this.healthState.failed,lastError:error instanceof Error?error.message:String(error)});
      this.callbacks.onError?.(error instanceof Error?error:new Error(String(error)));
    }
  }

  private triage(token:V26TokenDiscovery,latency:number):Pick<V48Candidate,'priority'|'action'|'reasons'>{
    const reasons:string[]=[];
    if(!token.mint) reasons.push('MINT_MISSING');
    if(!token.bondingCurve) reasons.push('BONDING_CURVE_MISSING');
    if(!token.creator) reasons.push('CREATOR_MISSING');
    if((token.name?.trim().length??0)<this.cfg.minNameLength) reasons.push('NAME_INCOMPLETE');
    if((token.symbol?.trim().length??0)<this.cfg.minSymbolLength) reasons.push('SYMBOL_INCOMPLETE');
    if(latency>this.cfg.maxVerificationLatencyMs) reasons.push('VERIFICATION_SLOW');
    if(reasons.includes('MINT_MISSING')||reasons.includes('BONDING_CURVE_MISSING')) return {priority:'REJECTED',action:'REJECT',reasons};
    // Fast triage is deliberately conservative: metadata quality changes priority,
    // not the economic/rug verdict. Deep on-chain analysis remains downstream.
    const complete=!reasons.includes('NAME_INCOMPLETE')&&!reasons.includes('SYMBOL_INCOMPLETE')&&!reasons.includes('CREATOR_MISSING');
    if(complete && latency<=this.cfg.maxVerificationLatencyMs) return {priority:'P0',action:'DEEP_ANALYSIS',reasons:['VERIFIED_PUMP_CREATE',...reasons]};
    return {priority:'P1',action:'WATCH',reasons:['VERIFIED_PUMP_CREATE',...reasons]};
  }

  private recordLatency(ms:number){this.latencies.push(ms);if(this.latencies.length>1000)this.latencies.shift();const sorted=[...this.latencies].sort((a,b)=>a-b);const avg=this.latencies.reduce((a,b)=>a+b,0)/this.latencies.length;const p95=sorted[Math.min(sorted.length-1,Math.floor(sorted.length*0.95))]??0;this.setHealth({avgVerificationLatencyMs:Math.round(avg*100)/100,p95VerificationLatencyMs:p95});}
  private remember(set:Set<string>,value:string,max:number){set.add(value);if(set.size>max){const first=set.values().next().value as string|undefined;if(first)set.delete(first);}}
  private setHealth(p:Partial<V48Health>){this.healthState={...this.healthState,...p};this.callbacks.onHealth?.(this.health());}
}

export const V48_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV48Safe(){if(!V48_SAFETY.shadowOnly||V48_SAFETY.signingEnabled||V48_SAFETY.privateKeyAccess||V48_SAFETY.broadcastEnabled||V48_SAFETY.liveExecutionAllowed) throw new Error('V48_SAFETY_INVARIANT_FAILED');}

export {PUMP_PROGRAM_ID};
