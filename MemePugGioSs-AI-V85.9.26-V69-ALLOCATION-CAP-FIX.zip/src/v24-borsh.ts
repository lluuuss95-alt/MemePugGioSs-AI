export class Cursor{
 private o=0;constructor(private b:Uint8Array){}
 get offset(){return this.o}
 need(n:number){if(this.o+n>this.b.length)throw new Error("ACCOUNT_DATA_TRUNCATED")}
 u8(){this.need(1);return this.b[this.o++]}
 bool(){const x=this.u8();if(x!==0&&x!==1)throw new Error("INVALID_BOOL");return x===1}
 u16(){this.need(2);const x=this.b[this.o]|(this.b[this.o+1]<<8);this.o+=2;return x}
 u64(){this.need(8);let x=0n;for(let i=0;i<8;i++)x|=BigInt(this.b[this.o+i])<<(8n*BigInt(i));this.o+=8;return x}
 i128(){this.need(16);let x=0n;for(let i=0;i<16;i++)x|=BigInt(this.b[this.o+i])<<(8n*BigInt(i));this.o+=16;const sign=1n<<127n;return (x&sign)?x-(1n<<128n):x}
 bytes(n:number){this.need(n);const x=this.b.slice(this.o,this.o+n);this.o+=n;return x}
 pubkey(){return this.bytes(32)}
 remaining(){return this.b.length-this.o}
}