import crypto from 'node:crypto';
import { db } from './db.js';

export type V66Side='BUY'|'SELL';
export type V66Quality='GOOD'|'WARNING'|'POOR'|'BLOCKED';

export interface V66ExecutionObservation {
  mint:string;
  side:V66Side;
  observedAt:number;
  decisionAt?:number;
  marketPrice:number;
  simulatedPrice:number;
  paperPrice?:number;
  liquidity?:number;
  simulatedSlippageBps?:number;
  simulatedPriceImpactBps?:number;
  simulatedFeeBps?:number;
  paperFeeBps?:number;
}

export interface V66Config {
  maxSimulationDeviationBps:number;
  maxPaperDeviationBps:number;
  maxLatencyMs:number;
  warningDeviationBps:number;
  warningLatencyMs:number;
  minLiquidity:number;
}

export interface V66Result {
  id:string;
  ts:number;
  mint:string;
  side:V66Side;
  quality:V66Quality;
  marketPrice:number;
  simulatedPrice:number;
  paperPrice:number|null;
  simulationDeviationBps:number;
  paperDeviationBps:number|null;
  simulationLatencyMs:number|null;
  paperLatencyMs:number|null;
  liquidity:number|null;
  simulatedSlippageBps:number;
  simulatedPriceImpactBps:number;
  blockers:string[];
  warnings:string[];
  liveExecutionEnabled:false;
}

export const defaultV66Config:V66Config=Object.freeze({
  maxSimulationDeviationBps:300,
  maxPaperDeviationBps:500,
  maxLatencyMs:5000,
  warningDeviationBps:150,
  warningLatencyMs:1500,
  minLiquidity:1000,
});

const finite=(n:unknown)=>Number.isFinite(Number(n))?Number(n):NaN;
const absBps=(a:number,b:number)=>Number.isFinite(a)&&Number.isFinite(b)&&a>0&&b>0?Math.abs(b/a-1)*10000:Infinity;

export class V66ExecutionQualityMonitor {
  constructor(private readonly cfg:V66Config=defaultV66Config){this.ensureSchema();}

  private ensureSchema(){
    db.exec(`CREATE TABLE IF NOT EXISTS v66_execution_quality(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, mint TEXT NOT NULL, side TEXT NOT NULL,
      quality TEXT NOT NULL, market_price REAL NOT NULL, simulated_price REAL NOT NULL,
      paper_price REAL, simulation_deviation_bps REAL NOT NULL, paper_deviation_bps REAL,
      simulation_latency_ms REAL, paper_latency_ms REAL, liquidity REAL,
      simulated_slippage_bps REAL NOT NULL, simulated_price_impact_bps REAL NOT NULL,
      blockers_json TEXT NOT NULL, warnings_json TEXT NOT NULL, details_json TEXT NOT NULL
    )`);
  }

  observe(o:V66ExecutionObservation):V66Result{
    const ts=o.observedAt;
    const market=finite(o.marketPrice), sim=finite(o.simulatedPrice);
    const paper=o.paperPrice===undefined?NaN:finite(o.paperPrice);
    const liquidity=o.liquidity===undefined?NaN:finite(o.liquidity);
    const simDev=absBps(market,sim);
    const paperDev=Number.isFinite(paper)?absBps(market,paper):null;
    const simLatency=o.decisionAt===undefined?null:Math.max(0,ts-o.decisionAt);
    const paperLatency=o.decisionAt===undefined?null:Math.max(0,ts-o.decisionAt);
    const blockers:string[]=[]; const warnings:string[]=[];

    if(!Number.isFinite(market)||market<=0) blockers.push('MARKET_PRICE_INVALID');
    if(!Number.isFinite(sim)||sim<=0) blockers.push('SIMULATED_PRICE_INVALID');
    if(Number.isFinite(paper)&&paper<=0) blockers.push('PAPER_PRICE_INVALID');
    if(Number.isFinite(liquidity)&&liquidity<this.cfg.minLiquidity) warnings.push('LIQUIDITY_NEAR_OR_BELOW_MINIMUM');
    if(simDev>this.cfg.maxSimulationDeviationBps) blockers.push('SIMULATION_DEVIATION_TOO_HIGH');
    if(paperDev!==null&&paperDev>this.cfg.maxPaperDeviationBps) blockers.push('PAPER_DEVIATION_TOO_HIGH');
    if(simLatency!==null&&simLatency>this.cfg.maxLatencyMs) blockers.push('SIMULATION_LATENCY_TOO_HIGH');
    if(paperLatency!==null&&paperLatency>this.cfg.maxLatencyMs) blockers.push('PAPER_LATENCY_TOO_HIGH');
    if(simDev>this.cfg.warningDeviationBps) warnings.push('SIMULATION_DEVIATION_WARNING');
    if(paperDev!==null&&paperDev>this.cfg.warningDeviationBps) warnings.push('PAPER_DEVIATION_WARNING');
    if(simLatency!==null&&simLatency>this.cfg.warningLatencyMs) warnings.push('LATENCY_WARNING');

    let quality:V66Quality='GOOD';
    if(blockers.length) quality='BLOCKED';
    else if(warnings.length) quality='WARNING';
    else if(paperDev===null || paperDev<=this.cfg.maxPaperDeviationBps) quality='GOOD';
    else quality='WARNING';

    const result:V66Result={
      id:crypto.randomUUID(),ts,mint:o.mint,side:o.side,quality,
      marketPrice:Number.isFinite(market)?market:0,simulatedPrice:Number.isFinite(sim)?sim:0,
      paperPrice:Number.isFinite(paper)?paper:null,simulationDeviationBps:Number.isFinite(simDev)?simDev:Infinity,
      paperDeviationBps:paperDev,simulationLatencyMs:simLatency,paperLatencyMs:paperLatency,
      liquidity:Number.isFinite(liquidity)?liquidity:null,simulatedSlippageBps:finite(o.simulatedSlippageBps)||0,
      simulatedPriceImpactBps:finite(o.simulatedPriceImpactBps)||0,blockers,warnings,liveExecutionEnabled:false,
    };
    db.prepare(`INSERT INTO v66_execution_quality VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      result.id,ts,result.mint,result.side,result.quality,result.marketPrice,result.simulatedPrice,result.paperPrice,
      result.simulationDeviationBps,result.paperDeviationBps,result.simulationLatencyMs,result.paperLatencyMs,result.liquidity,
      result.simulatedSlippageBps,result.simulatedPriceImpactBps,JSON.stringify(blockers),JSON.stringify(warnings),
      JSON.stringify({observation:o,liveExecutionEnabled:false})
    );
    return result;
  }

  summary(mint?:string){
    const rows=(mint?db.prepare(`SELECT * FROM v66_execution_quality WHERE mint=? ORDER BY ts DESC`).all(mint):db.prepare(`SELECT * FROM v66_execution_quality ORDER BY ts DESC`).all()) as any[];
    const valid=rows.filter(r=>Number.isFinite(r.simulation_deviation_bps));
    const avg=(key:string)=>valid.length?valid.reduce((s,r)=>s+Number(r[key]||0),0)/valid.length:0;
    return {samples:rows.length,good:rows.filter(r=>r.quality==='GOOD').length,warning:rows.filter(r=>r.quality==='WARNING').length,blocked:rows.filter(r=>r.quality==='BLOCKED').length,avgSimulationDeviationBps:avg('simulation_deviation_bps'),avgPaperDeviationBps:avg('paper_deviation_bps'),avgLatencyMs:avg('paper_latency_ms'),liveExecutionEnabled:false};
  }

  recent(limit=100){return db.prepare(`SELECT * FROM v66_execution_quality ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}
}

export const V66_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV66Safe(){if(!V66_SAFETY.shadowOnly||V66_SAFETY.signingEnabled||V66_SAFETY.privateKeyAccess||V66_SAFETY.broadcastEnabled||V66_SAFETY.liveExecutionAllowed||V66_SAFETY.autoPromotion)throw new Error('V66_SAFETY_INVARIANT_FAILED');}
