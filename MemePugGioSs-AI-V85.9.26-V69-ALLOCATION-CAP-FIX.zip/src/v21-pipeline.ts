import {SolanaTransactionRpc} from "./v21-rpc.js";import {TransactionProtocolVerifier} from "./v21-verifier.js";import {ProtocolObservation} from "./v21-types.js";
export class VerifiedTransactionPipeline{
 constructor(private rpc:SolanaTransactionRpc,private verifier=new TransactionProtocolVerifier()){}
 async inspect(signature:string):Promise<ProtocolObservation[]>{
  const tx=await this.rpc.getTransaction(signature);if(!tx)return [];
  if(tx.err!==null)return [];
  return this.verifier.verify(tx);
 }
}