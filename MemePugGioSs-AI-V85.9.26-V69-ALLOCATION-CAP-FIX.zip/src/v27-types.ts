export interface V27SignatureInfo {
  signature: string;
  slot: number;
  err: unknown | null;
  blockTime?: number | null;
  confirmationStatus?: string;
}

export interface V27SignatureRpc {
  getSignaturesForAddress(address: string, options: {limit?: number; before?: string; until?: string; commitment?: string}): Promise<V27SignatureInfo[]>;
  getTransaction(signature: string, commitment?: string): Promise<any>;
}

export interface V27Checkpoint {
  lastSignature?: string;
  lastSlot?: number;
  updatedAt: number;
}

export interface V27CheckpointStore {
  load(): V27Checkpoint;
  save(checkpoint: V27Checkpoint): void;
}

export interface V27RecoveryHealth {
  status: "IDLE" | "RUNNING" | "READY" | "DEGRADED" | "ERROR";
  runs: number;
  pages: number;
  signaturesScanned: number;
  transactionsFetched: number;
  recovered: number;
  alreadyKnown: number;
  failedTransactions: number;
  lastRunAt?: number;
  lastRecoveredAt?: number;
  lastError?: string;
}

export interface V27RecoveryResult {
  scanned: number;
  recovered: number;
  alreadyKnown: number;
  failedTransactions: number;
  pages: number;
  reachedCheckpoint: boolean;
  newestSignature?: string;
  newestSlot?: number;
}

export interface V27RecoveryCallbacks {
  onRecovered?(token: any): void | Promise<void>;
  onHealth?(health: V27RecoveryHealth): void;
}
