export type V43Outcome='WIN'|'LOSS'|'FLAT'|'INVALIDATED'|'TIMEOUT'|'BLOCKED'|'UNKNOWN';
export type V43Feature='score'|'confidence'|'riskScore'|'liquidity'|'freshness'|'source'|'copyReputation';
export interface V43Feedback{decisionId:string;outcome:V43Outcome;realizedPnl?:number;returnPct?:number;durationMs?:number;exitReason?:string;ts?:number;}
export interface V43FeatureStats{feature:V43Feature;samples:number;wins:number;losses:number;winRate:number;avgReturnPct:number;confidence:number;adjustment:number;}
export interface V43Policy{version:number;sampleCount:number;minSamplesForAdaptation:number;scoreWeight:number;confidenceWeight:number;riskPenaltyWeight:number;liquidityWeight:number;freshnessWeight:number;copyReputationWeight:number;adaptedAt:number|null;autoPromotion:false;}
export interface V43Snapshot{state:'LEARNING'|'READY'|'INSUFFICIENT_DATA'|'PAUSED';samples:number;wins:number;losses:number;winRate:number;avgReturnPct:number;policy:V43Policy;lastFeedbackAt:number|null;liveExecutionEnabled:false;}
