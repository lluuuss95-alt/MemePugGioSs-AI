import { V81PaperEngineGate, assertV81Safe, type V81GateResult } from './v81-paper-engine-gate.js';
import { V82PaperTransactionJournal, assertV82Safe } from './v82-paper-transaction-journal.js';
import { V77PaperExecutionCommitLayer, assertV77Safe, type V77Input, type V77Result } from './v77-paper-execution-commit-layer.js';
import { V78PaperPositionLifecycle, assertV78Safe, type V78Input, type V78Result } from './v78-paper-position-lifecycle.js';

export type V83Status='CONFIRMED'|'BLOCKED'|'FAILED'|'MANUAL_REVIEW';
export interface V83Result { operation:'ENTER'|'EXIT'; correlationKey:string; status:V83Status; gate:V81GateResult; journalId:string; execution?:V77Result|V78Result; reason:string; liveExecutionEnabled:false; }
export const V83_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV83Safe(){assertV81Safe();assertV82Safe();assertV77Safe();assertV78Safe();if(!V83_SAFETY.shadowOnly||V83_SAFETY.signingEnabled||V83_SAFETY.privateKeyAccess||V83_SAFETY.broadcastEnabled||V83_SAFETY.liveExecutionAllowed||V83_SAFETY.autoPromotion)throw new Error('V83_SAFETY_INVARIANT_FAILED');}

export class V83PaperExecutionCoordinator {
  constructor(private readonly gate=new V81PaperEngineGate(),private readonly journal=new V82PaperTransactionJournal(),private readonly entry=new V77PaperExecutionCommitLayer(),private readonly exitLifecycle=new V78PaperPositionLifecycle()){assertV83Safe();}
  enter(input:V77Input):V83Result{
    const key=input.idempotencyKey??`V77:${input.bridge.id}`; const prep=this.journal.prepare('ENTER',key,input); const gate=this.gate.evaluate({operation:'ENTER',now:input.now??Date.now(),refresh:true});
    if(!gate.allowed){const f=this.journal.fail('ENTER',key,input,`GATE_BLOCK:${gate.reason}`);return {operation:'ENTER',correlationKey:key,status:'BLOCKED',gate,journalId:f.id,reason:f.error!,liveExecutionEnabled:false};}
    try{const execution=this.entry.commit(input); if(execution.status==='COMMITTED'||execution.status==='ALREADY_COMMITTED'){const c=this.journal.commit('ENTER',key,input,execution,input.now??Date.now());const f=this.journal.confirm('ENTER',key,input,execution,input.now??Date.now());return {operation:'ENTER',correlationKey:key,status:'CONFIRMED',gate,journalId:f.id,execution,reason:execution.reason,liveExecutionEnabled:false};} const f=this.journal.fail('ENTER',key,input,execution.reason,input.now??Date.now());return {operation:'ENTER',correlationKey:key,status:'FAILED',gate,journalId:f.id,execution,reason:execution.reason,liveExecutionEnabled:false};}catch(e){const f=this.journal.fail('ENTER',key,input,String(e),input.now??Date.now());return {operation:'ENTER',correlationKey:key,status:'FAILED',gate,journalId:f.id,reason:String(e),liveExecutionEnabled:false};}
  }
  exit(input:V78Input):V83Result{
    const key=input.idempotencyKey??`V78:${input.tick.mint}:${input.tick.timestamp}`; this.journal.prepare('EXIT',key,input); const gate=this.gate.evaluate({operation:'EXIT',now:input.now??Date.now(),refresh:true});
    if(!gate.allowed){const f=this.journal.fail('EXIT',key,input,`GATE_BLOCK:${gate.reason}`);return {operation:'EXIT',correlationKey:key,status:'BLOCKED',gate,journalId:f.id,reason:f.error!,liveExecutionEnabled:false};}
    try{const execution=this.exitLifecycle.monitor(input); if(execution.status==='EXIT_COMMITTED'||execution.status==='ALREADY_COMMITTED'||execution.status==='NO_ACTIVE_POSITION'){const f=this.journal.confirm('EXIT',key,input,execution,input.now??Date.now());return {operation:'EXIT',correlationKey:key,status:'CONFIRMED',gate,journalId:f.id,execution,reason:execution.reason,liveExecutionEnabled:false};} const f=this.journal.fail('EXIT',key,input,execution.reason,input.now??Date.now());return {operation:'EXIT',correlationKey:key,status:'FAILED',gate,journalId:f.id,execution,reason:execution.reason,liveExecutionEnabled:false};}catch(e){const f=this.journal.fail('EXIT',key,input,String(e),input.now??Date.now());return {operation:'EXIT',correlationKey:key,status:'FAILED',gate,journalId:f.id,reason:String(e),liveExecutionEnabled:false};}
  }
  recover(){return this.journal.recoverPending();}
  health(){return {journal:this.journal.health(),gate:this.gate.status(),entry:this.entry.health(),exit:this.exitLifecycle.health(),liveExecutionEnabled:false};}
  recent(limit=100){return this.journal.recent(limit);}
}
export const v83Coordinator=new V83PaperExecutionCoordinator();
