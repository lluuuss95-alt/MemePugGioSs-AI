export function assertV35Safety(){
  if(process.env.LIVE_TRADING==='true') throw new Error('V35_BLOCKS_LIVE_TRADING');
  if(process.env.SIGNING_ENABLED==='true') throw new Error('V35_BLOCKS_SIGNING');
  if(process.env.BROADCAST_ENABLED==='true') throw new Error('V35_BLOCKS_BROADCAST');
}
