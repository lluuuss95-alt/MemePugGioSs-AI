import crypto from 'node:crypto';
import { db } from './db.js';
import { V61PortfolioExecutionCoordinator, type V61Candidate, type V61PositionExposure, type V61Snapshot } from './v61-portfolio-execution-coordinator.js';
import type { V46Regime } from './v46-types.js';

export type V62Strategy='AI_SIGNAL'|'PUMP_EARLY'|'SMART_MONEY'|'COPY_TRADER';
export type V62Decision='SELECT'|'REDUCE'|'BLOCK'|'DEFER';
export type V62State='NORMAL'|'WARNING'|'HALTED';

export interface V62Candidate extends V61Candidate {
  strategy?: V62Strategy;
  correlationGroup?: string;
  priority?: number;
  conflictKey?: string;
}

export interface V62Config {
  maxConcurrentOpportunities: number;
  maxPerStrategy: number;
  maxStrategyExposurePct: number;
  maxCorrelationGroupPct: number;
  maxSameMintCandidates: number;
  arbitrationReservePct: number;
  minLiquidityQuote: number;
  minScore: number;
  minConfidence: number;
}

export interface V62DecisionRow {
  id: string;
  candidateId: string;
  mint: string;
  strategy: V62Strategy;
  decision: V62Decision;
  priority: number;
  requestedQuote: number;
  approvedQuote: number;
  reasons: string[];
}

export interface V62Snapshot {
  evaluatedAt: number;
  state: V62State;
  candidateCount: number;
  selectedCount: number;
  blockedCount: number;
  deferredCount: number;
  conflictCount: number;
  selectedQuote: number;
  portfolio: V61Snapshot;
  decisions: V62DecisionRow[];
  liveExecutionEnabled: false;
}

export const defaultV62Config: V62Config = Object.freeze({
  maxConcurrentOpportunities: 8,
  maxPerStrategy: 4,
  maxStrategyExposurePct: 15,
  maxCorrelationGroupPct: 12,
  maxSameMintCandidates: 1,
  arbitrationReservePct: 20,
  minLiquidityQuote: 1000,
  minScore: 55,
  minConfidence: 50,
});

const finite=(n:unknown,d=0)=>Number.isFinite(Number(n))?Number(n):d;
const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));

/**
 * V62 is the opportunity arbitration layer. It resolves competition between
 * AI, Pump.fun early-entry, Smart Money and Copy Trading candidates before
 * V61 applies the final portfolio gate. It never signs, broadcasts or trades.
 */
export class V62OpportunityArbitrator {
  constructor(
    private readonly cfg: V62Config = defaultV62Config,
    private readonly portfolio = new V61PortfolioExecutionCoordinator(),
  ){ this.ensureSchema(); }

  private ensureSchema(){
    db.exec(`CREATE TABLE IF NOT EXISTS v62_opportunity_decisions(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, candidate_id TEXT NOT NULL,
      mint TEXT NOT NULL, strategy TEXT NOT NULL, decision TEXT NOT NULL,
      priority REAL NOT NULL, requested_quote REAL NOT NULL, approved_quote REAL NOT NULL,
      reasons_json TEXT NOT NULL
    )`);
    db.exec(`CREATE TABLE IF NOT EXISTS v62_arbitration_snapshots(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, state TEXT NOT NULL,
      candidate_count INTEGER NOT NULL, selected_count INTEGER NOT NULL,
      blocked_count INTEGER NOT NULL, deferred_count INTEGER NOT NULL,
      conflict_count INTEGER NOT NULL, selected_quote REAL NOT NULL,
      details_json TEXT NOT NULL
    )`);
  }

  private strategy(c: V62Candidate): V62Strategy {
    return c.strategy || (c.source === 'COPY_TRADER' ? 'COPY_TRADER' : 'AI_SIGNAL');
  }

  private priority(c: V62Candidate): number {
    return finite(c.priority, finite(c.score)*0.65 + finite(c.confidence)*0.25 - finite(c.riskScore)*0.10);
  }

  arbitrate(
    candidates: V62Candidate[],
    positions: V61PositionExposure[] = [],
    regime: V46Regime = 'UNKNOWN',
    now = Date.now(),
  ): V62Snapshot {
    const capital = 10000;
    const maxStrategyExposure = capital * clamp(this.cfg.maxStrategyExposurePct,0,100)/100;
    const maxGroupExposure = capital * clamp(this.cfg.maxCorrelationGroupPct,0,100)/100;
    const reserve = capital * clamp(this.cfg.arbitrationReservePct,0,100)/100;

    const ordered=[...candidates].sort((a,b)=>this.priority(b)-this.priority(a)||a.mint.localeCompare(b.mint)||a.id.localeCompare(b.id));
    const seenMint=new Set<string>();
    const strategyCount=new Map<V62Strategy,number>();
    const strategyQuote=new Map<V62Strategy,number>();
    const groupQuote=new Map<string,number>();
    const decisions:V62DecisionRow[]=[];
    const winners:V62Candidate[]=[];
    let conflictCount=0;
    let selectedQuote=0;

    for(const c of ordered){
      const strategy=this.strategy(c);
      const p=this.priority(c);
      const requested=Math.max(0,finite(c.requestedPct,5))*capital/100;
      const reasons:string[]=[];
      const group=c.correlationGroup||c.mint;

      if(regime==='NO_TRADE'||regime==='STRESSED'||regime==='UNKNOWN') reasons.push('REGIME_BLOCKS_ARBITRATION');
      if(finite(c.liquidityQuote)<this.cfg.minLiquidityQuote) reasons.push('LIQUIDITY_BELOW_ARBITRATION_MIN');
      if(finite(c.score)<this.cfg.minScore) reasons.push('SCORE_BELOW_ARBITRATION_MIN');
      if(finite(c.confidence)<this.cfg.minConfidence) reasons.push('CONFIDENCE_BELOW_ARBITRATION_MIN');
      if(seenMint.has(c.mint)) { reasons.push('SAME_MINT_CONFLICT'); conflictCount++; }
      if((strategyCount.get(strategy)||0)>=this.cfg.maxPerStrategy) reasons.push('STRATEGY_OPPORTUNITY_CAP');
      if((strategyQuote.get(strategy)||0)+requested>maxStrategyExposure) reasons.push('STRATEGY_EXPOSURE_CAP');
      if((groupQuote.get(group)||0)+requested>maxGroupExposure) reasons.push('CORRELATION_GROUP_EXPOSURE_CAP');
      if(winners.length>=this.cfg.maxConcurrentOpportunities) reasons.push('GLOBAL_OPPORTUNITY_CAP');
      if(selectedQuote+requested>Math.max(0,capital-reserve)) reasons.push('ARBITRATION_CAPITAL_RESERVE');

      let decision:V62Decision='SELECT';
      let approved=reasons.length?0:requested;
      if(reasons.includes('SAME_MINT_CONFLICT')) decision='BLOCK';
      else if(reasons.length) decision='DEFER';
      if(decision==='SELECT' && approved<=0) decision='DEFER';

      if(decision==='SELECT'){
        winners.push(c); seenMint.add(c.mint); selectedQuote+=approved;
        strategyCount.set(strategy,(strategyCount.get(strategy)||0)+1);
        strategyQuote.set(strategy,(strategyQuote.get(strategy)||0)+approved);
        groupQuote.set(group,(groupQuote.get(group)||0)+approved);
      }

      const row:V62DecisionRow={id:crypto.randomUUID(),candidateId:c.id,mint:c.mint,strategy,decision,priority:p,requestedQuote:requested,approvedQuote:approved,reasons};
      decisions.push(row);
      db.prepare(`INSERT INTO v62_opportunity_decisions VALUES(?,?,?,?,?,?,?,?,?,?)`).run(row.id,now,row.candidateId,row.mint,row.strategy,row.decision,row.priority,row.requestedQuote,row.approvedQuote,JSON.stringify(row.reasons));
    }

    // V61 remains the final portfolio gate. We deliberately pass only arbitrated winners.
    const portfolio= this.portfolio.coordinate(winners,positions,regime,now);
    for(const p of portfolio.allocations){
      const d=decisions.find(x=>x.candidateId===p.candidateId);
      if(d && p.decision==='BLOCK'){
        d.decision='BLOCK'; d.approvedQuote=0; d.reasons.push(...p.reasons.map(r=>`V61:${r}`));
      } else if(d && p.decision==='REDUCE_PAPER'){
        d.decision='REDUCE'; d.approvedQuote=p.approvedQuote;
        d.reasons.push('V61_PORTFOLIO_REDUCED');
      }
    }

    const blockedCount=decisions.filter(d=>d.decision==='BLOCK').length;
    const deferredCount=decisions.filter(d=>d.decision==='DEFER').length;
    const state:V62State=portfolio.state==='HALTED'?'HALTED':(portfolio.state==='WARNING'?'WARNING':'NORMAL');
    const snapshot:V62Snapshot={
      evaluatedAt:now,state,candidateCount:candidates.length,selectedCount:winners.length,
      blockedCount,deferredCount,conflictCount,selectedQuote,portfolio,decisions,liveExecutionEnabled:false,
    };
    db.prepare(`INSERT INTO v62_arbitration_snapshots VALUES(?,?,?,?,?,?,?,?,?,?)`).run(
      crypto.randomUUID(),now,state,candidates.length,winners.length,blockedCount,deferredCount,conflictCount,selectedQuote,JSON.stringify(snapshot)
    );
    return snapshot;
  }

  recent(limit=100){
    return db.prepare(`SELECT * FROM v62_arbitration_snapshots ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));
  }
}

export const V62_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV62Safe(){
  if(!V62_SAFETY.shadowOnly||V62_SAFETY.signingEnabled||V62_SAFETY.privateKeyAccess||V62_SAFETY.broadcastEnabled||V62_SAFETY.liveExecutionAllowed||V62_SAFETY.autoPromotion) throw new Error('V62_SAFETY_INVARIANT_FAILED');
}
