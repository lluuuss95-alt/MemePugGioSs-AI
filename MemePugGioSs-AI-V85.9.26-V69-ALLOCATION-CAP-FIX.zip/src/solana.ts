import { config } from './config.js';
let id=0;
export async function rpc(method:string,params:any[]=[]){
  if(!config.rpc) throw new Error('SOLANA_RPC_NOT_CONFIGURED');
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),config.rpcTimeoutMs);
  try{
    const r=await fetch(config.rpc,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:++id,method,params}),signal:controller.signal});
    if(!r.ok) throw new Error(`RPC_HTTP_${r.status}`); const j:any=await r.json(); if(j.error) throw new Error(`RPC_${j.error.code}:${j.error.message}`); return j.result;
  } finally { clearTimeout(timer); }
}
export const solana={
 health:()=>rpc('getHealth'), slot:()=>rpc('getSlot',[{commitment:'confirmed'}]), balance:(owner:string)=>rpc('getBalance',[owner,{commitment:'confirmed'}]),
 tokenAccounts:(owner:string)=>rpc('getTokenAccountsByOwner',[owner,{programId:'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'},{encoding:'jsonParsed',commitment:'confirmed'}]),
 signatures:(address:string,limit=20)=>rpc('getSignaturesForAddress',[address,{limit,commitment:'confirmed'}]),
 tokenSupply:(mint:string)=>rpc('getTokenSupply',[mint,{commitment:'confirmed'}]),
 largestAccounts:(mint:string)=>rpc('getTokenLargestAccounts',[mint,{commitment:'confirmed'}]),
 mintAccount:(mint:string)=>rpc('getAccountInfo',[mint,{encoding:'jsonParsed',commitment:'confirmed'}]),
 tx:(signature:string)=>rpc('getTransaction',[signature,{encoding:'jsonParsed',commitment:'confirmed',maxSupportedTransactionVersion:0}])
};
