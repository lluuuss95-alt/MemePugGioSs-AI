import crypto from 'node:crypto';
import { db } from './db.js';

export type V82Phase='PREPARE'|'COMMIT'|'CONFIRM'|'FAIL'|'RECOVER';
export type V82Status='PENDING'|'COMMITTED'|'CONFIRMED'|'FAILED'|'MANUAL_REVIEW';
export interface V82Entry { id:string; ts:number; operation:'ENTER'|'EXIT'|'ORDER'|'RECONCILE'; correlationKey:string; phase:V82Phase; status:V82Status; payload:any; result?:any; error?:string; fingerprint:string; }

export const V82_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV82Safe(){ if(!V82_SAFETY.shadowOnly||V82_SAFETY.signingEnabled||V82_SAFETY.privateKeyAccess||V82_SAFETY.broadcastEnabled||V82_SAFETY.liveExecutionAllowed||V82_SAFETY.autoPromotion) throw new Error('V82_SAFETY_INVARIANT_FAILED'); }

const fp=(value:unknown)=>crypto.createHash('sha256').update(JSON.stringify(value,(k,v)=>typeof v==='number'&&Number.isNaN(v)?'NaN':v)).digest('hex');

export class V82PaperTransactionJournal {
  constructor(){this.ensureSchema();assertV82Safe();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v82_paper_transaction_journal(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,operation TEXT NOT NULL,correlation_key TEXT NOT NULL,phase TEXT NOT NULL,status TEXT NOT NULL,payload_json TEXT NOT NULL,result_json TEXT,error TEXT,fingerprint TEXT NOT NULL); CREATE INDEX IF NOT EXISTS idx_v82_journal_corr ON v82_paper_transaction_journal(correlation_key,ts); CREATE INDEX IF NOT EXISTS idx_v82_journal_ts ON v82_paper_transaction_journal(ts);`);}
  append(operation:V82Entry['operation'],correlationKey:string,phase:V82Phase,status:V82Status,payload:any,result?:any,error?:string,now=Date.now()):V82Entry{
    const entry:V82Entry={id:crypto.randomUUID(),ts:now,operation,correlationKey,phase,status,payload,result,error,fingerprint:fp({operation,correlationKey,phase,status,payload,result,error})};
    db.prepare(`INSERT INTO v82_paper_transaction_journal(id,ts,operation,correlation_key,phase,status,payload_json,result_json,error,fingerprint) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(entry.id,entry.ts,entry.operation,entry.correlationKey,entry.phase,entry.status,JSON.stringify(entry.payload??null),entry.result===undefined?null:JSON.stringify(entry.result),entry.error??null,entry.fingerprint);
    return entry;
  }
  prepare(operation:V82Entry['operation'],correlationKey:string,payload:any,now=Date.now()){return this.append(operation,correlationKey,'PREPARE','PENDING',payload,undefined,undefined,now);}
  commit(operation:V82Entry['operation'],correlationKey:string,payload:any,result:any,now=Date.now()){return this.append(operation,correlationKey,'COMMIT','COMMITTED',payload,result,undefined,now);}
  confirm(operation:V82Entry['operation'],correlationKey:string,payload:any,result:any,now=Date.now()){return this.append(operation,correlationKey,'CONFIRM','CONFIRMED',payload,result,undefined,now);}
  fail(operation:V82Entry['operation'],correlationKey:string,payload:any,error:string,now=Date.now()){return this.append(operation,correlationKey,'FAIL','FAILED',payload,undefined,error,now);}
  latest(correlationKey:string){const r:any=db.prepare(`SELECT * FROM v82_paper_transaction_journal WHERE correlation_key=? ORDER BY ts DESC,rowid DESC LIMIT 1`).get(correlationKey);return r?this.map(r):null;}
  pending(limit=100){const rows:any[]=db.prepare(`SELECT j.* FROM v82_paper_transaction_journal j WHERE j.phase='PREPARE' AND j.status='PENDING' AND NOT EXISTS(SELECT 1 FROM v82_paper_transaction_journal x WHERE x.correlation_key=j.correlation_key AND x.phase IN ('CONFIRM','FAIL') AND x.ts>=j.ts) ORDER BY j.ts ASC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));return rows.map(r=>this.map(r));}
  recoverPending(now=Date.now()){const pending=this.pending(500);const recovered:V82Entry[]=[];for(const p of pending) recovered.push(this.append(p.operation,p.correlationKey,'RECOVER','MANUAL_REVIEW',p.payload,undefined,'PENDING_TRANSACTION_REQUIRES_DETERMINISTIC_REVIEW',now));return recovered;}
  recent(limit=100){return (db.prepare(`SELECT * FROM v82_paper_transaction_journal ORDER BY ts DESC,rowid DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit))) as any[]).map(r=>this.map(r));}
  health(){const pending=this.pending(500);const latest=this.recent(1)[0]??null;return {state:pending.length?'PENDING_REVIEW':'HEALTHY',pending:pending.length,last:latest,liveExecutionEnabled:false};}
  private map(r:any):V82Entry{return {id:r.id,ts:Number(r.ts),operation:r.operation,correlationKey:r.correlation_key,phase:r.phase,status:r.status,payload:r.payload_json?JSON.parse(r.payload_json):null,result:r.result_json?JSON.parse(r.result_json):undefined,error:r.error??undefined,fingerprint:r.fingerprint};}
}
