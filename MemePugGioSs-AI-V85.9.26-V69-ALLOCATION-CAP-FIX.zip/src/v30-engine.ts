import { V29RankedSignal } from './v29-types.js';
import { V30DecisionRecord, V30EvaluationResult, V30ExecutionConfig, V30MarketTick, V30PaperState, V30Position } from './v30-types.js';

export const V30_DEFAULTS: V30ExecutionConfig = {
  initialCash: 10000,
  maxPortfolioExposurePct: 35,
  maxPositionPct: 8,
  minCompositeScore: 60,
  minConfidence: 55,
  maxRiskScore: 65,
  entrySlippageBps: 30,
  exitSlippageBps: 40,
  feeBps: 25,
  stopLossPct: 8,
  takeProfitPct: 16,
  maxHoldingMs: 60 * 60_000,
  staleAfterMs: 30_000,
};

const clamp = (n:number, lo=0, hi=1) => Math.max(lo, Math.min(hi, n));
const round = (n:number) => Math.round(n * 1e8) / 1e8;

export function createV30State(cfg: V30ExecutionConfig = V30_DEFAULTS): V30PaperState {
  return { cash: cfg.initialCash, equity: cfg.initialCash, realizedPnl: 0, unrealizedPnl: 0, positions: [], decisions: [], generatedAt: Date.now() };
}

export class V30PaperExecutionEngine {
  constructor(private readonly cfg: V30ExecutionConfig = V30_DEFAULTS, private state: V30PaperState = createV30State(cfg)) {}

  getState(): V30PaperState { return structuredClone(this.state); }

  evaluate(signal: V29RankedSignal, tick: V30MarketTick, now=tick.timestamp): V30EvaluationResult {
    const existing = this.state.positions.find(p => p.mint === signal.mint && p.status === 'OPEN');
    let decision: V30DecisionRecord;
    if (tick.mint !== signal.mint || !Number.isFinite(tick.price) || tick.price <= 0) {
      decision = this.record(signal, 'NO_ACTION', 'INVALID_MARKET_TICK', now);
    } else if (now - signal.generatedAt > this.cfg.staleAfterMs) {
      decision = this.record(signal, 'BLOCKED', 'STALE_SIGNAL', now);
    } else if (signal.band === 'BLOCKED' || signal.blockers.length) {
      decision = this.record(signal, 'BLOCKED', 'RISK_BLOCKER', now);
    } else if (existing) {
      decision = this.manageOpen(existing, signal, tick, now);
    } else if (signal.band === 'TOP_SIGNAL' && signal.compositeScore >= this.cfg.minCompositeScore && signal.confidence >= this.cfg.minConfidence && signal.riskScore <= this.cfg.maxRiskScore) {
      decision = this.enter(signal, tick, now);
    } else {
      decision = this.record(signal, 'HOLD', 'SIGNAL_BELOW_ENTRY_GATE', now);
    }
    this.markToMarket(now);
    return { decision, state: this.getState() };
  }

  private enter(signal: V29RankedSignal, tick: V30MarketTick, now:number): V30DecisionRecord {
    const openExposure = this.state.positions.filter(p=>p.status==='OPEN').reduce((s,p)=>s+p.entryNotional,0);
    const maxExposure = this.cfg.initialCash * this.cfg.maxPortfolioExposurePct / 100;
    const availableExposure = Math.max(0, maxExposure - openExposure);
    const confidenceFactor = clamp(signal.confidence / 100);
    const riskFactor = clamp(1 - signal.riskScore / 100);
    const scoreFactor = clamp((signal.compositeScore - this.cfg.minCompositeScore) / Math.max(1, 100-this.cfg.minCompositeScore));
    const requested = this.cfg.initialCash * this.cfg.maxPositionPct / 100 * (0.35 + 0.65 * confidenceFactor * riskFactor * (0.5 + 0.5*scoreFactor));
    const notional = Math.min(requested, availableExposure, this.state.cash);
    if (notional <= 0) return this.record(signal, 'BLOCKED', 'EXPOSURE_LIMIT', now);
    const fillPrice = tick.price * (1 + this.cfg.entrySlippageBps / 10000);
    const fee = notional * this.cfg.feeBps / 10000;
    const spend = notional + fee;
    if (spend > this.state.cash) return this.record(signal, 'BLOCKED', 'INSUFFICIENT_CASH', now);
    const qty = notional / fillPrice;
    const p:V30Position = { id:`v30-${signal.mint}-${now}`, mint:signal.mint, status:'OPEN', quantity:qty, entryPrice:fillPrice, currentPrice:fillPrice, entryNotional:notional, exitNotional:0, unrealizedPnl:-fee, realizedPnl:0, openedAt:now, stopPrice:fillPrice*(1-this.cfg.stopLossPct/100), takeProfitPrice:fillPrice*(1+this.cfg.takeProfitPct/100) };
    this.state.cash = round(this.state.cash - spend); this.state.positions.push(p);
    return this.record(signal, 'ENTER_PAPER', `PAPER_ENTRY_NOTIONAL_${round(notional)}`, now);
  }

  private manageOpen(p:V30Position, signal:V29RankedSignal, tick:V30MarketTick, now:number):V30DecisionRecord {
    p.currentPrice = tick.price;
    const age = now - p.openedAt;
    if (tick.price <= p.stopPrice) return this.close(p, signal, tick, now, 'STOP_LOSS');
    if (tick.price >= p.takeProfitPrice) return this.close(p, signal, tick, now, 'TAKE_PROFIT');
    if (age >= this.cfg.maxHoldingMs || signal.state === 'INVALIDATED' || signal.riskScore > this.cfg.maxRiskScore) return this.close(p, signal, tick, now, 'SIGNAL_EXIT');
    return this.record(signal, 'HOLD', 'POSITION_OPEN', now);
  }

  private close(p:V30Position, signal:V29RankedSignal, tick:V30MarketTick, now:number, reason:string):V30DecisionRecord {
    const fillPrice = tick.price * (1 - this.cfg.exitSlippageBps / 10000);
    const gross = p.quantity * fillPrice;
    const fee = gross * this.cfg.feeBps / 10000;
    const proceeds = gross - fee;
    p.status='CLOSED'; p.closedAt=now; p.exitNotional=gross; p.realizedPnl=round(proceeds - p.entryNotional - (p.entryNotional*this.cfg.feeBps/10000)); p.unrealizedPnl=0; p.currentPrice=fillPrice; p.exitReason=reason;
    this.state.cash=round(this.state.cash+proceeds); this.state.realizedPnl=round(this.state.realizedPnl+p.realizedPnl);
    return this.record(signal, 'EXIT_PAPER', reason, now);
  }

  private markToMarket(now:number) {
    this.state.unrealizedPnl=round(this.state.positions.filter(p=>p.status==='OPEN').reduce((s,p)=>s+(p.currentPrice-p.entryPrice)*p.quantity,0));
    const openValue=this.state.positions.filter(p=>p.status==='OPEN').reduce((s,p)=>s+p.currentPrice*p.quantity,0);
    this.state.equity=round(this.state.cash+openValue); this.state.generatedAt=now;
  }

  private record(signal:V29RankedSignal, decision:V30DecisionRecord['decision'], reason:string, timestamp:number):V30DecisionRecord {
    const r={mint:signal.mint,decision,reason,score:signal.compositeScore,confidence:signal.confidence,riskScore:signal.riskScore,timestamp};
    this.state.decisions.push(r); if(this.state.decisions.length>500) this.state.decisions.shift(); return r;
  }
}
