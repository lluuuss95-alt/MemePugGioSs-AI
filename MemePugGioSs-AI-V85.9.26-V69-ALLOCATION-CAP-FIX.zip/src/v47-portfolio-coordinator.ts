import crypto from 'node:crypto';
import {db} from './db.js';
import {V46OpportunityAllocator} from './v46-allocator.js';
import {V46Candidate,V46Regime} from './v46-types.js';

export type V47Candidate = V46Candidate & { correlationGroup?: string; existingExposureQuote?: number };
export type V47Config = { maxPortfolioPct:number; maxCorrelationGroupPct:number; maxSourcePct:number; minLiquidityQuote:number; reservePct:number };
export type V47Allocation = { id:string; candidateId:string; mint:string; source:string; state:'ALLOCATED'|'REDUCED'|'BLOCKED'; allocationQuote:number; allocationPct:number; portfolioPct:number; reasons:string[]; correlationGroup?:string };
export type V47Snapshot = { evaluatedAt:number; capital:number; reserveQuote:number; requestedCount:number; allocatedQuote:number; allocatedPct:number; allocations:V47Allocation[]; liveExecutionEnabled:false };

export const defaultV47Config:V47Config={maxPortfolioPct:35,maxCorrelationGroupPct:12,maxSourcePct:20,minLiquidityQuote:1000,reservePct:20};
const clamp=(x:number,a:number,b:number)=>Math.max(a,Math.min(b,x));

export class V47PortfolioCoordinator {
  constructor(private allocator=new V46OpportunityAllocator(), private cfg=defaultV47Config){this.ensureSchema()}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v47_portfolio_allocations(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,candidate_id TEXT NOT NULL,mint TEXT NOT NULL,source TEXT NOT NULL,state TEXT NOT NULL,allocation_quote REAL NOT NULL,allocation_pct REAL NOT NULL,portfolio_pct REAL NOT NULL,reasons_json TEXT NOT NULL,correlation_group TEXT)`)}
  coordinate(candidates:V47Candidate[], regime:V46Regime='UNKNOWN', now=Date.now()):V47Snapshot {
    const base=this.allocator.allocate(candidates,regime,now);
    const maxPortfolio=base.capital*clamp(this.cfg.maxPortfolioPct,0,100)/100;
    const maxGroup=base.capital*clamp(this.cfg.maxCorrelationGroupPct,0,100)/100;
    const maxSource=base.capital*clamp(this.cfg.maxSourcePct,0,100)/100;
    const groupUsed=new Map<string,number>(), sourceUsed=new Map<string,number>();
    let total=0; const allocations:V47Allocation[]=[];
    for(const a of base.allocations){
      const c=candidates.find(x=>x.id===a.candidateId);
      const reasons=[...a.reasons];
      if(!c){reasons.push('CANDIDATE_NOT_FOUND')}
      if(c && c.liquidityQuote<this.cfg.minLiquidityQuote) reasons.push('PORTFOLIO_LIQUIDITY_GATE');
      const group=c?.correlationGroup||c?.mint;
      const groupAfter=(groupUsed.get(group||'')||0)+a.allocationQuote;
      const sourceAfter=(sourceUsed.get(a.source)||0)+a.allocationQuote;
      if(a.state!=='BLOCKED' && groupAfter>maxGroup) reasons.push('CORRELATION_GROUP_LIMIT');
      if(a.state!=='BLOCKED' && sourceAfter>maxSource) reasons.push('SOURCE_CONCENTRATION_LIMIT');
      const remaining=Math.max(0,maxPortfolio-total);
      let amount=Math.min(a.allocationQuote,remaining);
      if(reasons.length) amount=0;
      const state:V47Allocation['state']=reasons.length?'BLOCKED':amount<a.allocationQuote?'REDUCED':'ALLOCATED';
      if(state!=='BLOCKED'){total+=amount;groupUsed.set(group||'',(groupUsed.get(group||'')||0)+amount);sourceUsed.set(a.source,(sourceUsed.get(a.source)||0)+amount)}
      const row={id:crypto.randomUUID(),candidateId:a.candidateId,mint:a.mint,source:a.source,state,allocationQuote:amount,allocationPct:base.capital?amount/base.capital*100:0,portfolioPct:base.capital?total/base.capital*100:0,reasons,correlationGroup:group};
      allocations.push(row);
      db.prepare(`INSERT INTO v47_portfolio_allocations(id,ts,candidate_id,mint,source,state,allocation_quote,allocation_pct,portfolio_pct,reasons_json,correlation_group) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(row.id,now,row.candidateId,row.mint,row.source,row.state,row.allocationQuote,row.allocationPct,row.portfolioPct,JSON.stringify(row.reasons),row.correlationGroup||null);
    }
    return {evaluatedAt:now,capital:base.capital,reserveQuote:base.reserveQuote,requestedCount:candidates.length,allocatedQuote:total,allocatedPct:base.capital?total/base.capital*100:0,allocations,liveExecutionEnabled:false};
  }
}
