
import { DatasetRow } from "./v15-types.js";
import { MarketRegime, RegimeSnapshot, RegimePerformance } from "./v17-types.js";

function mean(x:number[]){return x.length?x.reduce((a,b)=>a+b,0)/x.length:0;}
function classify(vol:number,liq:number,mom:number):MarketRegime{
  if(liq<0.5)return "LOW_LIQUIDITY";
  if(vol>0.08)return "HIGH_VOL";
  if(vol<0.025)return "LOW_VOL";
  if(mom>0.04)return "HIGH_MOMENTUM";
  return "NORMAL";
}
export function detectRegime(rows:DatasetRow[]):RegimeSnapshot{
  const ret=rows.map(x=>x.futureReturnPct/100);
  const vol=Math.sqrt(mean(ret.map(x=>(x-mean(ret))**2)));
  const liq=mean(rows.map(x=>Math.max(0,Math.min(1,(x.liquidityDelta+10)/20))));
  const mom=mean(rows.map(x=>x.buySellRatio-1));
  return {regime:classify(vol,liq,mom),volatility:vol,liquidity:liq,momentum:mom,samples:rows.length};
}
export function regimePerformance(rows:DatasetRow[]):RegimePerformance[]{
  const buckets=new Map<MarketRegime,DatasetRow[]>();
  for(const r of rows){const key=detectRegime([r]).regime;(buckets.get(key)||buckets.set(key,[]).get(key)!).push(r);}
  return [...buckets.entries()].map(([regime,xs])=>{
    let eq=1,peak=1,dd=0;
    for(const x of xs){eq*=1+x.futureReturnPct/100;peak=Math.max(peak,eq);dd=Math.max(dd,(peak-eq)/peak*100);}
    return {regime,samples:xs.length,meanReturn:mean(xs.map(x=>x.futureReturnPct)),
      winRate:xs.filter(x=>x.futureReturnPct>0).length/xs.length*100,maxDrawdown:dd,totalReturn:(eq-1)*100};
  });
}
