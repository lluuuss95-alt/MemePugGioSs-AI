
import { DatasetRow } from "./v15-types.js";
import { StressScenario, StressMetrics } from "./v16-types.js";

export function applyScenario(rows:DatasetRow[], s:StressScenario, seed=17):DatasetRow[]{
  let state=seed>>>0;
  const rnd=()=>{state=(1664525*state+1013904223)>>>0;return state/4294967296;};
  return rows.filter(()=>rnd()>=s.missingDataRate).map(r=>{
    const delay=s.entryDelayBars+s.exitDelayBars+s.executionDelayBars;
    const executionCost=(s.feeMultiplier-1)*0.1+(s.slippageMultiplier-1)*0.2;
    const liquidityPenalty=(1-s.liquidityMultiplier)*0.5;
    return {...r,futureReturnPct:r.futureReturnPct-executionCost-liquidityPenalty-delay*0.05};
  });
}

export function stressMetrics(scenario:string,rows:DatasetRow[]):StressMetrics{
  const xs=rows.map(r=>r.futureReturnPct);
  if(!xs.length)return {scenario,samples:0,meanReturn:0,medianReturn:0,winRate:0,maxDrawdown:0,worstTrade:0,profitFactor:0,totalReturn:0};
  const sorted=[...xs].sort((a,b)=>a-b);
  let equity=1,peak=1,maxDD=0;
  let gains=0,losses=0;
  for(const x of xs){equity*=1+x/100;peak=Math.max(peak,equity);maxDD=Math.max(maxDD,(peak-equity)/peak*100);if(x>0)gains+=x;else losses+=-x;}
  return {scenario,samples:xs.length,meanReturn:xs.reduce((a,b)=>a+b,0)/xs.length,
    medianReturn:sorted[Math.floor(sorted.length/2)],winRate:xs.filter(x=>x>0).length/xs.length*100,
    maxDrawdown:maxDD,worstTrade:sorted[0],profitFactor:losses?gains/losses:Infinity,totalReturn:(equity-1)*100};
}
