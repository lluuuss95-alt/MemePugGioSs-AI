export function maxDrawdown(curve:number[]):number {
  let peak=-Infinity, max=0;
  for(const x of curve){ peak=Math.max(peak,x); if(peak>0) max=Math.max(max,(peak-x)/peak); }
  return max*100;
}
function returns(curve:number[]):number[] {
  const r:number[]=[];
  for(let i=1;i<curve.length;i++) if(curve[i-1]!==0) r.push(curve[i]/curve[i-1]-1);
  return r;
}
function mean(xs:number[]){return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:0;}
function std(xs:number[]){if(xs.length<2)return 0;const m=mean(xs);return Math.sqrt(mean(xs.map(x=>(x-m)**2)));}
export function sharpe(curve:number[]):number {const r=returns(curve),s=std(r);return s?mean(r)/s*Math.sqrt(252):0;}
export function sortino(curve:number[]):number {const r=returns(curve),down=r.filter(x=>x<0),s=std(down);return s?mean(r)/s*Math.sqrt(252):0;}
export function tradeStats(pnls:number[]){
  const wins=pnls.filter(x=>x>0),losses=pnls.filter(x=>x<0);
  const grossWin=wins.reduce((a,b)=>a+b,0), grossLoss=Math.abs(losses.reduce((a,b)=>a+b,0));
  return {winRatePct:pnls.length?wins.length/pnls.length*100:0,
    expectancy:mean(pnls),profitFactor:grossLoss?grossWin/grossLoss:wins.length?Infinity:0};
}
