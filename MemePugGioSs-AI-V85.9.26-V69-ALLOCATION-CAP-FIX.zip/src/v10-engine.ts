import { MarketBar, BacktestConfig, Strategy } from "./backtest-types.js";
import { runBacktest } from "./backtester.js";

export function evaluateStrategy(strategy:Strategy,bars:MarketBar[],cfg:BacktestConfig){
  return runBacktest(strategy,bars,cfg);
}
export function compareStrategies(strategies:Strategy[],bars:MarketBar[],cfg:BacktestConfig){
  return strategies.map(s=>runBacktest(s,bars,cfg));
}
