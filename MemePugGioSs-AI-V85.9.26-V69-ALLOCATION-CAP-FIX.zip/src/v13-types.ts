export interface TokenEvent {
  id:string; mint:string; ts:number; price?:number;
  buyVolume?:number; sellVolume?:number; liquidity?:number;
  holders?:number; smartMoneyVolume?:number; risk?:number;
}

export interface WindowSnapshot {
  mint:string; startTs:number; endTs:number; durationMs:number;
  open?:number; high?:number; low?:number; close?:number;
  buyVolume:number; sellVolume:number; netFlow:number;
  liquidityStart?:number; liquidityEnd?:number; liquidityDelta?:number;
  holdersStart?:number; holdersEnd?:number; holderDelta?:number;
  smartMoneyStart:number; smartMoneyEnd:number; smartMoneyDelta:number;
  eventCount:number;
}

export interface ForwardLabel {
  mint:string; startTs:number; horizonMs:number;
  futureReturnPct?:number; mfePct?:number; maePct?:number;
  futureEvents:number;
}

export interface DatasetQuality {
  rows:number; tokens:number; duplicateEvents:number;
  missingPriceWindows:number; missingFutureLabels:number;
}
