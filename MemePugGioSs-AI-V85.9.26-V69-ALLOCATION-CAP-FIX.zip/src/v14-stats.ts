export function mean(xs:number[]){return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:undefined;}
export function median(xs:number[]){
  if(!xs.length)return undefined;
  const s=[...xs].sort((a,b)=>a-b),m=Math.floor(s.length/2);
  return s.length%2?s[m]:(s[m-1]+s[m])/2;
}
export function bootstrapCI(xs:number[],iterations=500,seed=17):[number,number]|undefined{
  if(xs.length<5)return undefined;
  let state=seed>>>0; const rand=()=>{state=(1664525*state+1013904223)>>>0;return state/4294967296};
  const means:number[]=[];
  for(let k=0;k<iterations;k++){let s=0;for(let i=0;i<xs.length;i++)s+=xs[Math.floor(rand()*xs.length)];means.push(s/xs.length);}
  means.sort((a,b)=>a-b);
  return [means[Math.floor(iterations*.025)],means[Math.floor(iterations*.975)]];
}
