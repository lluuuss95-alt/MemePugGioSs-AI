import crypto from 'node:crypto';
import { db } from './db.js';
import { V35ReputationEngine } from './v35-reputation.js';
import { V34TradeObservation } from './v34-types.js';
import { V36CopyConfig, V36CopySignal, V36MarketContext } from './v36-types.js';

export const defaultV36Config:V36CopyConfig={
  minReputationScore:62,
  maxRiskScore:48,
  minSampleConfidence:60,
  maxLatencyMs:5000,
  minTradeConfidence:0.85,
  minLiquidityQuote:5000,
  minVolume5mQuote:10000,
  maxFreshnessMs:15000,
  maxTokenExposurePct:5,
  cooldownMs:30000
};

const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));
const n=(v:unknown,d=0)=>Number.isFinite(Number(v))?Number(v):d;

export class V36CopySignalEngine {
  constructor(private reputation:V35ReputationEngine, private cfg:V36CopyConfig=defaultV36Config){this.ensureSchema()}

  private ensureSchema(){db.exec(`
    CREATE TABLE IF NOT EXISTS v36_copy_signals(
      id TEXT PRIMARY KEY,wallet TEXT NOT NULL,signature TEXT NOT NULL,mint TEXT NOT NULL,side TEXT NOT NULL,
      source TEXT NOT NULL,state TEXT NOT NULL,detected_at INTEGER NOT NULL,executed_at INTEGER NOT NULL,
      latency_ms INTEGER NOT NULL,confidence REAL NOT NULL,trader_reputation REAL NOT NULL,trader_risk REAL NOT NULL,
      sample_confidence REAL NOT NULL,liquidity_quote REAL NOT NULL,volume5m_quote REAL NOT NULL,
      market_risk_score REAL NOT NULL,freshness_ms INTEGER NOT NULL,copy_size_pct REAL NOT NULL,
      reasons_json TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_v36_signals_time ON v36_copy_signals(detected_at DESC);
    CREATE INDEX IF NOT EXISTS idx_v36_signals_wallet ON v36_copy_signals(wallet,detected_at DESC);
  `)}

  evaluate(t:V34TradeObservation, market:V36MarketContext={}):V36CopySignal {
    const id=crypto.createHash('sha256').update(`${t.wallet}|${t.signature}|${t.mint}|${t.side}`).digest('hex');
    const rep=this.reputation.get(t.wallet);
    const followed=Boolean((db.prepare(`SELECT 1 FROM v34_followed WHERE wallet=? AND enabled=1 AND copy_paper=1`).get(t.wallet) as any));
    const latency=Math.max(0,t.observedAt-t.executedAt);
    const freshness=n(market.freshnessMs,Date.now()-t.observedAt);
    const liquidity=n(market.liquidityQuote),volume=n(market.volume5mQuote),marketRisk=clamp(n(market.riskScore,50));
    const reasons:string[]=[];
    if(!followed) reasons.push('TRADER_NOT_FOLLOWED');
    if(!rep) reasons.push('NO_REPUTATION');
    if(rep && rep.state!=='QUALIFIED') reasons.push(`TRADER_${rep.state}`);
    if(rep && rep.reputationScore<this.cfg.minReputationScore) reasons.push('LOW_REPUTATION');
    if(rep && rep.riskScore>this.cfg.maxRiskScore) reasons.push('TRADER_RISK_TOO_HIGH');
    if(rep && rep.sampleQualityScore<this.cfg.minSampleConfidence) reasons.push('LOW_SAMPLE_CONFIDENCE');
    if(!t.verified) reasons.push('UNVERIFIED_TRADE');
    if(t.confidence<this.cfg.minTradeConfidence) reasons.push('LOW_TRADE_CONFIDENCE');
    if(latency>this.cfg.maxLatencyMs) reasons.push('HIGH_LATENCY');
    if(liquidity<this.cfg.minLiquidityQuote) reasons.push('LOW_LIQUIDITY');
    if(volume<this.cfg.minVolume5mQuote) reasons.push('LOW_VOLUME');
    if(freshness>this.cfg.maxFreshnessMs) reasons.push('STALE_MARKET');
    if(market.tradable===false) reasons.push('MARKET_NOT_TRADABLE');
    const recent=db.prepare(`SELECT detected_at FROM v36_copy_signals WHERE wallet=? AND mint=? ORDER BY detected_at DESC LIMIT 1`).get(t.wallet,t.mint) as any;
    if(recent && Date.now()-Number(recent.detected_at)<this.cfg.cooldownMs) reasons.push('COPY_COOLDOWN');
    const eligible=reasons.length===0;
    const confidence=clamp((t.confidence*55)+((rep?.reputationScore||0)*0.30)+((100-marketRisk)*0.15));
    const copySizePct=eligible?Math.min(this.cfg.maxTokenExposurePct,Math.max(0.5,confidence/100*this.cfg.maxTokenExposurePct)):0;
    const signal:V36CopySignal={id,wallet:t.wallet,signature:t.signature,mint:t.mint,side:t.side as 'BUY'|'SELL',source:t.source,state:eligible?'ELIGIBLE':'BLOCKED',detectedAt:t.observedAt,executedAt:t.executedAt,latencyMs:latency,confidence,traderReputation:rep?.reputationScore||0,traderRisk:rep?.riskScore||100,sampleConfidence:rep?.sampleQualityScore||0,liquidityQuote:liquidity,volume5mQuote:volume,marketRiskScore:marketRisk,freshnessMs:freshness,copySizePct,reasons};
    db.prepare(`INSERT OR REPLACE INTO v36_copy_signals(id,wallet,signature,mint,side,source,state,detected_at,executed_at,latency_ms,confidence,trader_reputation,trader_risk,sample_confidence,liquidity_quote,volume5m_quote,market_risk_score,freshness_ms,copy_size_pct,reasons_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(signal.id,signal.wallet,signal.signature,signal.mint,signal.side,signal.source,signal.state,signal.detectedAt,signal.executedAt,signal.latencyMs,signal.confidence,signal.traderReputation,signal.traderRisk,signal.sampleConfidence,signal.liquidityQuote,signal.volume5mQuote,signal.marketRiskScore,signal.freshnessMs,signal.copySizePct,JSON.stringify(signal.reasons));
    return signal;
  }

  recent(limit=50):V36CopySignal[]{
    const rows=db.prepare(`SELECT id,wallet,signature,mint,side,source,state,detected_at as detectedAt,executed_at as executedAt,latency_ms as latencyMs,confidence,trader_reputation as traderReputation,trader_risk as traderRisk,sample_confidence as sampleConfidence,liquidity_quote as liquidityQuote,volume5m_quote as volume5mQuote,market_risk_score as marketRiskScore,freshness_ms as freshnessMs,copy_size_pct as copySizePct,reasons_json FROM v36_copy_signals ORDER BY detected_at DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit))) as any[];
    return rows.map(r=>({...r,reasons:JSON.parse(r.reasons_json||'[]')}));
  }

  eligible(limit=20){return this.recent(200).filter(x=>x.state==='ELIGIBLE').slice(0,limit)}
}
