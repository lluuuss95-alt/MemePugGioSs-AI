import { BacktestConfig, BacktestResult, MarketBar, Strategy, Trade } from "./backtest-types.js";
import { chronologicalReplay } from "./replay.js";
import { maxDrawdown, sharpe, sortino, tradeStats } from "./metrics.js";

export function runBacktest(strategy:Strategy, input:MarketBar[], cfg:BacktestConfig):BacktestResult {
  const bars=chronologicalReplay(input);
  let cash=cfg.initialCash, position=0, avgEntry=0;
  const curve:number[]=[cash], trades:Trade[]=[], pnls:number[]=[];
  for(let i=0;i<bars.length;i++){
    const bar=bars[i];
    const history=bars.slice(0,i+1); // never exposes future
    const equity=cash+position*bar.price;
    const action=strategy.decide({index:i,bars:history,cash,position,equity});
    const maxQty=(equity*cfg.maxPositionFraction)/bar.price;
    const qty=Math.max(0,Math.min(maxQty,Math.abs(action.fraction)*equity/bar.price));
    const slip=cfg.slippageBps/10000;
    if(action.side==="BUY" && qty>0){
      const px=bar.price*(1+slip), fee=px*qty*cfg.feeBps/10000;
      const cost=px*qty+fee;
      if(cost<=cash){
        avgEntry=position+qty>0?(avgEntry*position+px*qty)/(position+qty):px;
        position+=qty; cash-=cost;
        trades.push({ts:bar.ts,side:"BUY",price:px,quantity:qty,fee,reason:action.reason});
      }
    } else if(action.side==="SELL" && position>0){
      const sellQty=Math.min(position,qty||position), px=bar.price*(1-slip), fee=px*sellQty*cfg.feeBps/10000;
      const proceeds=px*sellQty-fee, pnl=(px-avgEntry)*sellQty-fee;
      position-=sellQty; cash+=proceeds;
      pnls.push(pnl); trades.push({ts:bar.ts,side:"SELL",price:px,quantity:sellQty,fee,reason:action.reason,pnl});
      if(position===0) avgEntry=0;
    }
    curve.push(cash+position*bar.price);
  }
  const finalEquity=curve.at(-1) ?? cfg.initialCash, stats=tradeStats(pnls);
  return {strategyId:strategy.id,initialCash:cfg.initialCash,finalEquity,
    totalReturnPct:(finalEquity/cfg.initialCash-1)*100,maxDrawdownPct:maxDrawdown(curve),
    ...stats,sharpe:sharpe(curve),sortino:sortino(curve),trades,equityCurve:curve};
}
