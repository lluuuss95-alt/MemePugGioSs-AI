import { FlowSnapshot } from "./flow.js";
import { LifecycleSnapshot } from "./lifecycle.js";

export interface V7Risk {
  riskScore:number;
  opportunityDelta:number;
  reasons:string[];
  blocked:boolean;
}

export function scoreV7(flow:FlowSnapshot, life:LifecycleSnapshot): V7Risk {
  let risk=0, opp=0; const reasons:string[]=[];
  if (life.state==="EXIT_RISK") { risk+=45; reasons.push("liquidity removal / exit-risk lifecycle"); }
  if (life.state==="DISTRIBUTION") { risk+=25; reasons.push("sell pressure suggests distribution"); }
  if (flow.sellVolume > flow.buyVolume * 1.5 && flow.sells >= 3) { risk+=15; reasons.push("sell flow dominates"); }
  if (flow.liquidityDelta < 0) { risk+=20; reasons.push("negative liquidity delta"); }
  if (flow.uniqueTraders >= 5 && flow.buyRatio >= 0.65) opp += 10;
  if (life.state==="ACTIVE_TRADING" && flow.buyRatio >= 0.60) opp += 8;
  if (life.confidence < 0.5) { risk+=10; reasons.push("low protocol/lifecycle confidence"); }
  risk=Math.min(100,risk); opp=Math.max(-100,Math.min(100,opp));
  return { riskScore:risk, opportunityDelta:opp, reasons, blocked:risk>=60 || life.state==="EXIT_RISK" };
}
