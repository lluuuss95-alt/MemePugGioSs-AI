export const V31_SAFETY = Object.freeze({ mode:'PAPER', liveTrading:false, signingEnabled:false, privateKeyAccess:false, broadcastEnabled:false, autoPromotion:false });
export function assertV31Safe(){ if(V31_SAFETY.liveTrading||V31_SAFETY.signingEnabled||V31_SAFETY.privateKeyAccess||V31_SAFETY.broadcastEnabled) throw new Error('V31_SAFETY_VIOLATION'); }
