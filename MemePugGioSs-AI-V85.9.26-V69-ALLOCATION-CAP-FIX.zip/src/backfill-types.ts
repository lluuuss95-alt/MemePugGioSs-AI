export interface SignatureRecord {
  signature:string;
  slot:number;
  blockTime?:number|null;
  err?:unknown|null;
}

export interface BackfillCheckpoint {
  address:string;
  before?:string;
  until?:string;
  fetchedSignatures:number;
  fetchedTransactions:number;
  lastSignature?:string;
  lastSlot?:number;
  updatedAt:number;
  fingerprint:string;
}

export interface BackfillConfig {
  pageLimit:number;
  maxPages:number;
  concurrency:number;
  minDelayMs:number;
  maxRetries:number;
  backoffBaseMs:number;
}

export interface BackfillStats {
  pages:number;
  signatures:number;
  transactions:number;
  missingTransactions:number;
  retries:number;
  startedAt:number;
  finishedAt:number;
}
