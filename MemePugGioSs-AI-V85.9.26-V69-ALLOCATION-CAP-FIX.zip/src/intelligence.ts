import { solana } from './solana.js';
import { config } from './config.js';

export type TokenIntel = {
  mint:string;
  supply?:number;
  decimals?:number;
  largestHolderPct?:number;
  top10HolderPct?:number;
  mintAuthorityPresent?:boolean;
  freezeAuthorityPresent?:boolean;
  rpcCheckedAt:string;
  riskScore:number;
  flags:string[];
};

export async function inspectToken(mint:string):Promise<TokenIntel>{
  const flags:string[]=[]; let supply=0, decimals=0, largestHolderPct:number|undefined;
  let mintAuthorityPresent:boolean|undefined; let freezeAuthorityPresent:boolean|undefined;
  try {
    const s:any=await solana.tokenSupply(mint); supply=Number(s?.value?.uiAmount??0); decimals=Number(s?.value?.decimals??0);
  } catch { flags.push('SUPPLY_UNAVAILABLE'); }
  try {
    const m:any=await solana.mintAccount(mint);
    const info=m?.value?.data?.parsed?.info;
    mintAuthorityPresent=Boolean(info?.mintAuthority); freezeAuthorityPresent=Boolean(info?.freezeAuthority);
    if(mintAuthorityPresent) flags.push('MINT_AUTHORITY_PRESENT');
    if(freezeAuthorityPresent) flags.push('FREEZE_AUTHORITY_PRESENT');
  } catch { flags.push('MINT_METADATA_UNAVAILABLE'); }
  try {
    const l:any=await solana.largestAccounts(mint);
    const rows=l?.value??[]; if(supply>0 && rows.length){ const top=Number(rows[0]?.uiAmount??0); largestHolderPct=Math.min(100,top/supply*100); }
  } catch { flags.push('HOLDER_DISTRIBUTION_UNAVAILABLE'); }
  let risk=0;
  if(mintAuthorityPresent) risk+=25;
  if(freezeAuthorityPresent) risk+=25;
  if(largestHolderPct!=null){ if(largestHolderPct>=25) risk+=35; else if(largestHolderPct>=15) risk+=20; else if(largestHolderPct>=8) risk+=10; }
  if(flags.some(x=>x.endsWith('UNAVAILABLE'))) risk+=10;
  return {mint,supply,decimals,largestHolderPct,mintAuthorityPresent,freezeAuthorityPresent,rpcCheckedAt:new Date().toISOString(),riskScore:Math.min(100,risk),flags};
}
