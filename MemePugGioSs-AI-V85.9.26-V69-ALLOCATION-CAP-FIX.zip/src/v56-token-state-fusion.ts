import crypto from 'node:crypto';
import { db } from './db.js';
import type { V48Candidate } from './v48-ultra-discovery.js';
import type { V49Score } from './v49-instant-scoring.js';
import type { V50Result } from './v50-deep-intelligence.js';
import type { V53Tick } from './v53-trade-supervisor.js';

export type V56Freshness='FRESH'|'AGING'|'STALE'|'UNKNOWN';
export type V56Source='DISCOVERY'|'INSTANT_SCORE'|'DEEP_INTELLIGENCE'|'MARKET_TICK'|'EXTERNAL_INTELLIGENCE';
export interface V56State {
  mint:string; signature?:string; slot?:number; firstSeenAt:number; lastUpdatedAt:number;
  name?:string; symbol?:string; creator?:string; bondingCurve?:string; uri?:string;
  price?:number; marketCap?:number; liquidity?:number; buyVolume?:number; sellVolume?:number; flowMomentum?:number;
  holders?:number; holderConcentration?:number; graduationProgress?:number;
  creatorScore?:number; smartMoneyScore?:number; smartMoneyShare?:number; regime?:string;
  instantScore?:number; instantConfidence?:number; deepScore?:number; deepConfidence?:number; risk?:number;
  freshness:V56Freshness; freshnessMs?:number; sourceCount:number; version:number;
  blockers:string[]; reasons:string[]; lastSource?:V56Source;
}
export interface V56Config { staleAfterMs:number; agingAfterMs:number; maxStates:number; maxReasons:number; maxBlockers:number; }
export const defaultV56Config:V56Config=Object.freeze({staleAfterMs:5000,agingAfterMs:2000,maxStates:100000,maxReasons:20,maxBlockers:20});
export interface V56Health { state:'STOPPED'|'RUNNING'|'DEGRADED'|'HALTED'; states:number; updates:number; created:number; rejected:number; stale:number; lastUpdateAt:number|null; }

const finite=(n:unknown):n is number=>typeof n==='number'&&Number.isFinite(n);
const clean=(xs:string[],max:number)=>Array.from(new Set(xs.filter(Boolean))).slice(-max);

/**
 * V56 maintains one deterministic, realtime state per mint. It only merges
 * explicitly observed fields; absent values are never fabricated or inferred.
 */
export class V56TokenStateFusion {
  private readonly cfg:V56Config;
  private readonly states=new Map<string,V56State>();
  private health:V56Health={state:'STOPPED',states:0,updates:0,created:0,rejected:0,stale:0,lastUpdateAt:null};
  constructor(cfg:Partial<V56Config>={}){this.cfg={...defaultV56Config,...cfg};this.ensureSchema();}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v56_token_states(mint TEXT PRIMARY KEY,state_json TEXT NOT NULL,updated_at INTEGER NOT NULL,version INTEGER NOT NULL)`);db.exec(`CREATE TABLE IF NOT EXISTS v56_state_events(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,source TEXT NOT NULL,version INTEGER NOT NULL,details_json TEXT NOT NULL)`);}
  start(){this.health={...this.health,state:'RUNNING'};}
  stop(){this.health={...this.health,state:'STOPPED'};}
  halt(){this.health={...this.health,state:'HALTED'};}
  healthSnapshot(now=Date.now()){this.refreshFreshness(now);return {...this.health,states:this.states.size};}

  applyDiscovery(c:V48Candidate,now=Date.now()){return this.update(c.token.mint,{signature:c.signature,slot:c.slot,firstSeenAt:c.receivedAt??c.detectedAt??now,name:c.token.name,symbol:c.token.symbol,creator:c.token.creator,bondingCurve:c.token.bondingCurve,uri:c.token.uri},'DISCOVERY',now);}
  applyInstant(i:V49Score,now=Date.now()){return this.update(i.mint,{signature:i.signature,instantScore:i.score,instantConfidence:i.confidence,reasons:i.reasons,blockers:i.blockers},'INSTANT_SCORE',now);}
  applyDeep(r:V50Result,now=Date.now()){return this.update(r.mint,{signature:r.signature,deepScore:r.score,deepConfidence:r.confidence,risk:r.risk,creatorScore:r.creatorScore,smartMoneyScore:r.smartMoneyScore,regime:r.regimeMultiplier===1?'FAVORABLE':r.regimeMultiplier===.75?'NEUTRAL':r.regimeMultiplier===.5?'HIGH_VOLATILITY':undefined,reasons:r.reasons,blockers:r.blockers},'DEEP_INTELLIGENCE',now);}
  applyMarketTick(t:V53Tick,now=Date.now()){return this.update(t.mint,{price:t.price,marketCap:(t as any).marketCap,liquidity:(t as any).liquidity,buyVolume:(t as any).buyVolume,sellVolume:(t as any).sellVolume,flowMomentum:(t as any).flowMomentum,risk:t.risk},'MARKET_TICK',now);}
  applyExternal(mint:string,fields:Partial<V56State>,now=Date.now()){return this.update(mint,fields,'EXTERNAL_INTELLIGENCE',now);}

  get(mint:string,now=Date.now()){const s=this.states.get(mint);if(!s)return undefined;this.refreshOne(s,now);return {...s};}
  list(limit=100,now=Date.now()){this.refreshFreshness(now);return [...this.states.values()].sort((a,b)=>b.lastUpdatedAt-a.lastUpdatedAt).slice(0,Math.min(500,Math.max(1,limit))).map(s=>({...s}));}

  private update(mint:string,patch:Partial<V56State>,source:V56Source,now:number){
    if(!mint){this.health.rejected++;return undefined;}
    let s=this.states.get(mint);
    if(!s){
      if(this.states.size>=this.cfg.maxStates){this.evictOldest();}
      s={mint,firstSeenAt:patch.firstSeenAt??now,lastUpdatedAt:now,freshness:'FRESH',sourceCount:0,version:0,blockers:[],reasons:[]};
      this.states.set(mint,s);this.health.created++;
    }
    const beforeVersion=s.version;
    const arrayPatch=patch as any;
    Object.entries(patch).forEach(([k,v])=>{if(v!==undefined&&k!=='mint'&&k!=='version'&&k!=='firstSeenAt'&&k!=='lastUpdatedAt'&&k!=='freshness'&&k!=='sourceCount'&&k!=='blockers'&&k!=='reasons') (s as any)[k]=v;});
    if(Array.isArray(arrayPatch.reasons))s.reasons=clean([...s.reasons,...arrayPatch.reasons],this.cfg.maxReasons);
    if(Array.isArray(arrayPatch.blockers))s.blockers=clean([...s.blockers,...arrayPatch.blockers],this.cfg.maxBlockers);
    s.lastUpdatedAt=now;s.sourceCount++;s.version++;s.lastSource=source;s.freshness='FRESH';s.freshnessMs=0;
    this.health.updates++;this.health.lastUpdateAt=now;this.health.states=this.states.size;
    this.persist(s,source,now);
    return {...s,previousVersion:beforeVersion};
  }
  private refreshOne(s:V56State,now:number){const age=Math.max(0,now-s.lastUpdatedAt);s.freshnessMs=age;s.freshness=age<=this.cfg.agingAfterMs?'FRESH':age<=this.cfg.staleAfterMs?'AGING':'STALE';}
  private refreshFreshness(now:number){let stale=0;for(const s of this.states.values()){this.refreshOne(s,now);if(s.freshness==='STALE')stale++;}this.health.stale=stale;this.health.states=this.states.size;}
  private evictOldest(){let oldest:string|undefined;let ts=Infinity;for(const [mint,s] of this.states){if(s.lastUpdatedAt<ts){ts=s.lastUpdatedAt;oldest=mint;}}if(oldest)this.states.delete(oldest);}
  private persist(s:V56State,source:V56Source,now:number){const stateJson=JSON.stringify(s);db.prepare(`INSERT OR REPLACE INTO v56_token_states(mint,state_json,updated_at,version) VALUES(?,?,?,?)`).run(s.mint,stateJson,now,s.version);db.prepare(`INSERT OR REPLACE INTO v56_state_events(id,ts,mint,source,version,details_json) VALUES(?,?,?,?,?,?)`).run(crypto.createHash('sha256').update(`${s.mint}:${source}:${s.version}:${now}`).digest('hex'),now,s.mint,source,s.version,JSON.stringify({shadowOnly:true,liveExecutionEnabled:false}));}
}

export const V56_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV56Safe(){if(!V56_SAFETY.shadowOnly||V56_SAFETY.signingEnabled||V56_SAFETY.privateKeyAccess||V56_SAFETY.broadcastEnabled||V56_SAFETY.liveExecutionAllowed||V56_SAFETY.autoPromotion)throw new Error('V56_SAFETY_INVARIANT_FAILED');}
