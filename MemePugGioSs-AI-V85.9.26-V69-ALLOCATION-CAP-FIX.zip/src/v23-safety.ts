export const V23_SAFETY=Object.freeze({mode:"SHADOW",liveTrading:false,signing:false,privateKeys:false,broadcast:false,autoPromotion:false});
export function assertV23Safety(){if(V23_SAFETY.mode!=="SHADOW"||V23_SAFETY.liveTrading||V23_SAFETY.signing||V23_SAFETY.privateKeys||V23_SAFETY.broadcast||V23_SAFETY.autoPromotion)throw new Error("V23 safety invariant failed");return true}
