export type V25AccountKind = "BONDING_CURVE" | "PUMPSWAP_POOL" | "POOL_BASE_VAULT" | "POOL_QUOTE_VAULT";
export type V25Venue = "BONDING_CURVE" | "PUMPSWAP";

export interface V25TokenBalance {
  address: string;
  mint: string;
  amount: bigint;
  decimals: number;
  slot: number;
  observedAt: number;
  source: "RPC" | "SUBSCRIPTION";
}

export interface V25LiveState {
  mint: string;
  venue: V25Venue;
  slot: number;
  observedAt: number;
  stale: boolean;
  coherent: boolean;
  slotSpread: number;
  priceQuotePerBaseUnit: { numerator: bigint; denominator: bigint };
  marketCapQuote?: bigint;
  liquidityQuote?: bigint;
  graduationProgressBps?: bigint;
  complete: boolean;
  baseReserve: bigint;
  quoteReserve: bigint;
  virtualQuoteReserves: bigint;
  effectiveQuoteReserves: bigint;
  supply?: bigint;
  supplyDecimals?: number;
  confidence: number;
}

export interface V25Health {
  websocket: "DISCONNECTED" | "CONNECTING" | "CONNECTED" | "RECONNECTING";
  subscriptions: number;
  lastNotificationAt?: number;
  lastStateAt?: number;
  staleAccounts: number;
  errors: number;
  reconnects: number;
}

export interface V25Snapshot {
  key: string;
  kind: V25AccountKind;
  address: string;
  slot: number;
  observedAt: number;
  data: unknown;
}
