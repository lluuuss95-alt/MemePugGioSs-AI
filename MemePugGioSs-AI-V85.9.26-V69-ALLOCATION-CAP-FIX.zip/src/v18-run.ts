
import { ShadowEngine } from "./v18-engine.js";
import { StrategyParams } from "./v15-types.js";
import { MarketTick } from "./v18-types.js";
import { assertShadowOnly } from "./v18-safety.js";

export function runShadow(strategy:StrategyParams,ticks:MarketTick[],cfg:any){
  assertShadowOnly();
  const e=new ShadowEngine(strategy,cfg, ticks[0]?.ts||Date.now());
  for(const t of ticks)e.onTick(t,t.ts+10);
  e.stop(ticks.at(-1)?.ts||Date.now());
  return {session:e.session,signals:e.signals,trades:e.trades};
}
