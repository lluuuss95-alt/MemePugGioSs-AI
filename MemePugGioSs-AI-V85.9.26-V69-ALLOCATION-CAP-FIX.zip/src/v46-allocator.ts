import crypto from 'node:crypto';
import {db} from './db.js';
import {V46Allocation,V46Candidate,V46Config,V46Regime,V46Snapshot} from './v46-types.js';

export const defaultV46Config:V46Config={capital:10000,reservePct:20,maxTotalExposurePct:35,maxPositionPct:5,maxTokenPct:10,maxTraderPct:12,maxPositions:10,minAllocation:25,highVolatilityMultiplier:0.5,neutralMultiplier:0.75,favorableMultiplier:1};
const clamp=(x:number,a:number,b:number)=>Math.max(a,Math.min(b,x));
const num=(v:unknown,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const multiplier=(r:V46Regime,c:V46Config)=>r==='FAVORABLE'?c.favorableMultiplier:r==='NEUTRAL'?c.neutralMultiplier:r==='HIGH_VOLATILITY'?c.highVolatilityMultiplier:0;

export class V46OpportunityAllocator{
  constructor(private cfg:V46Config=defaultV46Config){this.ensureSchema()}
  private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v46_allocations(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,candidate_id TEXT NOT NULL,mint TEXT NOT NULL,source TEXT NOT NULL,wallet TEXT,regime TEXT NOT NULL,state TEXT NOT NULL,allocation_quote REAL NOT NULL,allocation_pct REAL NOT NULL,priority_score REAL NOT NULL,reasons_json TEXT NOT NULL)`)}
  allocate(candidates:V46Candidate[],regime:V46Regime='UNKNOWN',now=Date.now()):V46Snapshot{
    const reserve=this.cfg.capital*clamp(this.cfg.reservePct,0,100)/100;
    let available=Math.max(0,this.cfg.capital-reserve);
    const maxTotal=this.cfg.capital*clamp(this.cfg.maxTotalExposurePct,0,100)/100;
    const maxPosition=this.cfg.capital*clamp(this.cfg.maxPositionPct,0,100)/100;
    const maxToken=this.cfg.capital*clamp(this.cfg.maxTokenPct,0,100)/100;
    const maxTrader=this.cfg.capital*clamp(this.cfg.maxTraderPct,0,100)/100;
    const effectiveRegime=regime||'UNKNOWN';
    const mult=multiplier(effectiveRegime,this.cfg);
    const tokenUsed=new Map<string,number>(), traderUsed=new Map<string,number>();
    let total=0; const out:V46Allocation[]=[];
    const sorted=[...candidates].sort((a,b)=>this.priority(b,effectiveRegime)-this.priority(a,effectiveRegime));
    for(const c of sorted){
      const reasons:string[]=[]; const priority=this.priority(c,effectiveRegime);
      if(!c.id||!c.mint){reasons.push('CANDIDATE_ID_OR_MINT_REQUIRED')}
      if(effectiveRegime==='NO_TRADE'||effectiveRegime==='STRESSED'||effectiveRegime==='UNKNOWN')reasons.push('REGIME_BLOCKS_ALLOCATION');
      if(c.riskScore>45)reasons.push('RISK_ABOVE_ALLOCATION_THRESHOLD');
      if(c.liquidityQuote<=0)reasons.push('LIQUIDITY_REQUIRED');
      if(out.filter(x=>x.state!=='BLOCKED').length>=this.cfg.maxPositions)reasons.push('MAX_POSITIONS_REACHED');
      const desiredPct=clamp(num(c.requestedPct,this.cfg.maxPositionPct),0,this.cfg.maxPositionPct)*mult;
      const desired=Math.min(maxPosition,this.cfg.capital*desiredPct/100);
      const tokenAfter=(tokenUsed.get(c.mint)||0)+desired;
      const traderAfter=c.wallet?(traderUsed.get(c.wallet)||0)+desired:desired;
      if(tokenAfter>maxToken)reasons.push('TOKEN_CONCENTRATION_LIMIT');
      if(c.wallet&&traderAfter>maxTrader)reasons.push('TRADER_CONCENTRATION_LIMIT');
      const remainingTotal=Math.min(available,maxTotal-total);
      const amount=Math.min(desired,Math.max(0,remainingTotal));
      if(amount<this.cfg.minAllocation)reasons.push('ALLOCATION_BELOW_MINIMUM');
      const state:V46Allocation['state']=reasons.length?'BLOCKED':amount<desired?'REDUCED':'ALLOCATED';
      const allocation=state==='BLOCKED'?0:amount;
      if(state!=='BLOCKED'){total+=allocation;available-=allocation;tokenUsed.set(c.mint,(tokenUsed.get(c.mint)||0)+allocation);if(c.wallet)traderUsed.set(c.wallet,(traderUsed.get(c.wallet)||0)+allocation)}
      const row:V46Allocation={candidateId:c.id,mint:c.mint,source:c.source,wallet:c.wallet,state,allocationQuote:allocation,allocationPct:this.cfg.capital?allocation/this.cfg.capital*100:0,priorityScore:priority,reasons,regime:effectiveRegime};
      out.push(row);db.prepare(`INSERT INTO v46_allocations(id,ts,candidate_id,mint,source,wallet,regime,state,allocation_quote,allocation_pct,priority_score,reasons_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(crypto.randomUUID(),now,row.candidateId,row.mint,row.source,row.wallet||null,row.regime,row.state,row.allocationQuote,row.allocationPct,row.priorityScore,JSON.stringify(row.reasons));
    }
    return {capital:this.cfg.capital,reserveQuote:reserve,allocatedQuote:total,allocatedPct:this.cfg.capital?total/this.cfg.capital*100:0,remainingQuote:this.cfg.capital-reserve-total,candidateCount:candidates.length,allocatedCount:out.filter(x=>x.state!=='BLOCKED').length,blockedCount:out.filter(x=>x.state==='BLOCKED').length,regime:effectiveRegime,evaluatedAt:now,allocations:out,liveExecutionEnabled:false};
  }
  private priority(c:V46Candidate,r:V46Regime){const risk=clamp(num(c.riskScore,100),0,100);const liq=clamp(num(c.liquidityQuote)/10000,0,1)*10;const base=clamp(num(c.score),0,100)*0.5+clamp(num(c.confidence),0,100)*0.3+(100-risk)*0.2;return base+liq+(r==='FAVORABLE'?5:r==='NEUTRAL'?0:r==='HIGH_VOLATILITY'?-5:-20)}
  recent(limit=100){return db.prepare(`SELECT candidate_id candidateId,mint,source,wallet,regime,state,allocation_quote allocationQuote,allocation_pct allocationPct,priority_score priorityScore,reasons_json reasons,ts FROM v46_allocations ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit))).map((r:any)=>({...r,reasons:JSON.parse(r.reasons||'[]')}))}
}
