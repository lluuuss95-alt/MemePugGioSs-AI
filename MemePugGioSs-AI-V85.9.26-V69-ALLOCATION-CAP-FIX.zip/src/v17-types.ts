
import { StrategyParams, DatasetRow } from "./v15-types.js";

export type MarketRegime = "LOW_VOL"|"NORMAL"|"HIGH_VOL"|"LOW_LIQUIDITY"|"HIGH_MOMENTUM"|"MIXED";

export interface RegimeSnapshot {
  regime:MarketRegime;
  volatility:number;
  liquidity:number;
  momentum:number;
  samples:number;
}

export interface WalkForwardWindow {
  id:number;
  trainStart:number; trainEnd:number;
  validationStart:number; validationEnd:number;
  testStart:number; testEnd:number;
  trainSamples:number; validationSamples:number; testSamples:number;
}

export interface RegimePerformance {
  regime:MarketRegime;
  samples:number;
  meanReturn:number;
  winRate:number;
  maxDrawdown:number;
  totalReturn:number;
}

export interface WalkForwardResult {
  window:WalkForwardWindow;
  /** Compatibility mirror for legacy lab consumers. */
  testSamples?:number;
  selectedParams?:StrategyParams;
  validationMean:number;
  testMean:number;
  testWinRate:number;
  degradation:number;
  regime?:MarketRegime;
}

export interface V17Report {
  runId:string;
  windows:WalkForwardResult[];
  regimePerformance:RegimePerformance[];
  regimeCoverage:number;
  consistencyScore:number;
  status:"CONSISTENT"|"REGIME_SENSITIVE"|"UNSTABLE"|"INSUFFICIENT_DATA";
}
