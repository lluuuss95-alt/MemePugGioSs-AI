import { WalletObservation } from "./wallet-intelligence.js";

export interface WalletCluster {
  id:string;
  wallets:string[];
  sharedEdges:number;
  confidence:number;
  risk:number;
  reasons:string[];
}

export function buildClusters(obs:WalletObservation[]): WalletCluster[] {
  const graph=new Map<string,Set<string>>();
  for(const o of obs){
    if(!graph.has(o.address)) graph.set(o.address,new Set());
    for(const w of o.relatedWallets??[]){
      if(w===o.address) continue;
      graph.get(o.address)!.add(w);
      if(!graph.has(w)) graph.set(w,new Set());
      graph.get(w)!.add(o.address);
    }
  }
  const seen=new Set<string>(); const out:WalletCluster[]=[];
  let i=0;
  for(const start of graph.keys()){
    if(seen.has(start)) continue;
    const stack=[start], nodes:string[]=[]; seen.add(start);
    while(stack.length){
      const n=stack.pop()!; nodes.push(n);
      for(const w of graph.get(n)??[]) if(!seen.has(w)){seen.add(w);stack.push(w);}
    }
    if(nodes.length<2) continue;
    let edges=0;
    for(const n of nodes) for(const w of graph.get(n)??[]) if(nodes.includes(w)) edges++;
    edges=Math.floor(edges/2);
    const confidence=Math.min(1,edges/Math.max(1,nodes.length));
    const risk=Math.min(100,Math.round(confidence*50));
    out.push({id:`cluster-${++i}`,wallets:nodes,sharedEdges:edges,confidence,risk,
      reasons:confidence>=0.7?["dense observable wallet relationships"]:["limited relationship evidence"]});
  }
  return out;
}
