import { HistoricalEvent } from "./historical-types.js";

export class ReplayCursor {
  private i=0;
  constructor(private readonly events:HistoricalEvent[]){}
  peek(){return this.events[this.i];}
  next(){return this.events[this.i++];}
  hasNext(){return this.i<this.events.length;}
  index(){return this.i;}
  reset(){this.i=0;}
}

export function windowUntil(events:HistoricalEvent[],ts:number):HistoricalEvent[]{
  return events.filter(e=>e.ts<=ts);
}
