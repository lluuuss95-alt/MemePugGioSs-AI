import {SolanaLogEvent} from "./v19-types.js";import {MarketTick} from "./v18-types.js";
export interface VerifiedProtocolAdapter{name:string;canDecode(e:SolanaLogEvent):boolean;decode(e:SolanaLogEvent):MarketTick|null}
export class ProtocolAdapterRouter{constructor(private adapters:VerifiedProtocolAdapter[]){}parse(e:SolanaLogEvent){for(const a of this.adapters)if(a.canDecode(e))return a.decode(e);return null}}
