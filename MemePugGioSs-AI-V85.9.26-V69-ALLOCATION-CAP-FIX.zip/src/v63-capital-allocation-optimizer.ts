import crypto from 'node:crypto';
import { db } from './db.js';
import { V62OpportunityArbitrator, type V62Candidate, type V62Snapshot } from './v62-opportunity-arbitration.js';
import type { V61PositionExposure } from './v61-portfolio-execution-coordinator.js';
import type { V46Regime } from './v46-types.js';

export type V63Decision='ALLOCATE'|'REDUCE'|'BLOCK'|'DEFER';
export type V63State='NORMAL'|'WARNING'|'HALTED';

export interface V63Candidate extends V62Candidate {
  freshnessScore?: number;
  liquidityScore?: number;
  smartMoneyScore?: number;
  strategyQuality?: number;
  requestedPct?: number;
}

export interface V63Config {
  minAllocation: number;
  maxPositionPct: number;
  maxTotalAllocationPct: number;
  scoreWeight: number;
  confidenceWeight: number;
  riskWeight: number;
  liquidityWeight: number;
  freshnessWeight: number;
  smartMoneyWeight: number;
  strategyQualityWeight: number;
  favorableMultiplier: number;
  neutralMultiplier: number;
  highVolatilityMultiplier: number;
}

export interface V63AllocationRow {
  id: string;
  candidateId: string;
  mint: string;
  strategy: string;
  decision: V63Decision;
  weight: number;
  requestedQuote: number;
  approvedCeiling: number;
  optimizedQuote: number;
  reasons: string[];
}

export interface V63Snapshot {
  evaluatedAt: number;
  state: V63State;
  capital: number;
  totalOptimizedQuote: number;
  candidateCount: number;
  allocatedCount: number;
  blockedCount: number;
  deferredCount: number;
  arbitration: V62Snapshot;
  allocations: V63AllocationRow[];
  liveExecutionEnabled: false;
}

export const defaultV63Config: V63Config=Object.freeze({
  minAllocation:25,
  maxPositionPct:5,
  maxTotalAllocationPct:35,
  scoreWeight:0.30,
  confidenceWeight:0.20,
  riskWeight:0.15,
  liquidityWeight:0.10,
  freshnessWeight:0.10,
  smartMoneyWeight:0.10,
  strategyQualityWeight:0.05,
  favorableMultiplier:1,
  neutralMultiplier:0.75,
  highVolatilityMultiplier:0.5,
});

const finite=(n:unknown,d=0)=>Number.isFinite(Number(n))?Number(n):d;
const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
const normalize=(n:number)=>clamp(n,0,100)/100;

function regimeMultiplier(regime:V46Regime,cfg:V63Config){
  if(regime==='FAVORABLE') return cfg.favorableMultiplier;
  if(regime==='NEUTRAL') return cfg.neutralMultiplier;
  if(regime==='HIGH_VOLATILITY') return cfg.highVolatilityMultiplier;
  return 0;
}

/**
 * V63 redistributes the capital that has already passed V62/V61 ceilings.
 * It never creates additional exposure beyond the upstream portfolio gate.
 * Scores are deterministic and bounded; no profitability prediction is used.
 */
export class V63CapitalAllocationOptimizer {
  constructor(
    private readonly cfg:V63Config=defaultV63Config,
    private readonly arbitrator=new V62OpportunityArbitrator(),
  ){this.ensureSchema();}

  private ensureSchema(){
    db.exec(`CREATE TABLE IF NOT EXISTS v63_capital_allocations(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, candidate_id TEXT NOT NULL,
      mint TEXT NOT NULL, strategy TEXT NOT NULL, decision TEXT NOT NULL,
      weight REAL NOT NULL, requested_quote REAL NOT NULL, approved_ceiling REAL NOT NULL,
      optimized_quote REAL NOT NULL, reasons_json TEXT NOT NULL
    )`);
    db.exec(`CREATE TABLE IF NOT EXISTS v63_allocation_snapshots(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, state TEXT NOT NULL,
      capital REAL NOT NULL, total_optimized_quote REAL NOT NULL,
      candidate_count INTEGER NOT NULL, allocated_count INTEGER NOT NULL,
      blocked_count INTEGER NOT NULL, deferred_count INTEGER NOT NULL,
      details_json TEXT NOT NULL
    )`);
  }

  private weight(c:V63Candidate){
    const score=normalize(c.score);
    const confidence=normalize(c.confidence);
    const risk=1-normalize(c.riskScore);
    const liquidity=normalize(c.liquidityScore ?? clamp(finite(c.liquidityQuote)/100,0,100));
    const freshness=normalize(c.freshnessScore ?? 100);
    const smart=normalize(c.smartMoneyScore ?? 50);
    const quality=normalize(c.strategyQuality ?? 50);
    return Math.max(0.0001,
      score*this.cfg.scoreWeight+
      confidence*this.cfg.confidenceWeight+
      risk*this.cfg.riskWeight+
      liquidity*this.cfg.liquidityWeight+
      freshness*this.cfg.freshnessWeight+
      smart*this.cfg.smartMoneyWeight+
      quality*this.cfg.strategyQualityWeight
    );
  }

  optimize(candidates:V63Candidate[], positions:V61PositionExposure[]=[], regime:V46Regime='UNKNOWN', now=Date.now()):V63Snapshot{
    const arbitration=this.arbitrator.arbitrate(candidates,positions,regime,now);
    const mult=regimeMultiplier(regime,this.cfg);
    const byId=new Map(candidates.map(c=>[c.id,c]));
    const rows:V63AllocationRow[]=[];

    // Only allocations already approved by V62/V61 can be redistributed.
    const eligible=arbitration.decisions.filter(d=>d.decision==='SELECT' && d.approvedQuote>0)
      .map(d=>({d,c:byId.get(d.candidateId)})).filter(x=>!!x.c) as {d:typeof arbitration.decisions[number],c:V63Candidate}[];
    const totalCeiling=eligible.reduce((s,x)=>s+x.d.approvedQuote,0);
    const maxTotal=Math.min(totalCeiling,10000*clamp(this.cfg.maxTotalAllocationPct,0,100)/100);
    const weights=eligible.map(x=>this.weight(x.c));
    const weightSum=weights.reduce((a,b)=>a+b,0)||1;

    for(let i=0;i<eligible.length;i++){
      const {d,c}=eligible[i];
      const w=weights[i]/weightSum;
      const positionCap=10000*clamp(this.cfg.maxPositionPct,0,100)/100;
      const optimized=Math.min(d.approvedQuote,positionCap,maxTotal*w*mult);
      const reasons:string[]=[];
      if(mult<=0) reasons.push('REGIME_BLOCKS_ALLOCATION');
      if(optimized<this.cfg.minAllocation) reasons.push('OPTIMIZED_ALLOCATION_BELOW_MINIMUM');
      let decision:V63Decision=optimized>=this.cfg.minAllocation?'ALLOCATE':'DEFER';
      if(mult<=0) decision='BLOCK';
      rows.push({id:crypto.randomUUID(),candidateId:c.id,mint:c.mint,strategy:d.strategy,decision,weight:w,requestedQuote:d.requestedQuote,approvedCeiling:d.approvedQuote,optimizedQuote:decision==='ALLOCATE'?optimized:0,reasons});
    }

    // If caps leave unused capacity, make a second deterministic pass among eligible rows
    // with remaining ceiling, without exceeding any upstream limit.
    let used=rows.reduce((s,r)=>s+r.optimizedQuote,0);
    if(mult>0 && used<maxTotal && rows.length){
      for(let pass=0;pass<3 && used<maxTotal;pass++){
        let changed=false;
        for(const r of rows){
          if(r.decision!=='ALLOCATE') continue;
          const room=Math.max(0,r.approvedCeiling-r.optimizedQuote);
          const add=Math.min(room,maxTotal-used);
          if(add>0){r.optimizedQuote+=add; used+=add; changed=true;}
          if(used>=maxTotal) break;
        }
        if(!changed) break;
      }
    }

    const blockedCount=rows.filter(r=>r.decision==='BLOCK').length;
    const deferredCount=rows.filter(r=>r.decision==='DEFER').length;
    const state:V63State=arbitration.state==='HALTED'?'HALTED':arbitration.state==='WARNING'?'WARNING':'NORMAL';
    const snapshot:V63Snapshot={evaluatedAt:now,state,capital:10000,totalOptimizedQuote:rows.reduce((s,r)=>s+r.optimizedQuote,0),candidateCount:candidates.length,allocatedCount:rows.filter(r=>r.optimizedQuote>0).length,blockedCount,deferredCount,arbitration,allocations:rows,liveExecutionEnabled:false};
    for(const r of rows) db.prepare(`INSERT INTO v63_capital_allocations VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(r.id,now,r.candidateId,r.mint,r.strategy,r.decision,r.weight,r.requestedQuote,r.approvedCeiling,r.optimizedQuote,JSON.stringify(r.reasons));
    db.prepare(`INSERT INTO v63_allocation_snapshots VALUES(?,?,?,?,?,?,?,?,?,?)`).run(crypto.randomUUID(),now,state,snapshot.capital,snapshot.totalOptimizedQuote,snapshot.candidateCount,snapshot.allocatedCount,blockedCount,deferredCount,JSON.stringify(snapshot));
    return snapshot;
  }

  recent(limit=100){return db.prepare(`SELECT * FROM v63_allocation_snapshots ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}
}

export const V63_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV63Safe(){if(!V63_SAFETY.shadowOnly||V63_SAFETY.signingEnabled||V63_SAFETY.privateKeyAccess||V63_SAFETY.broadcastEnabled||V63_SAFETY.liveExecutionAllowed||V63_SAFETY.autoPromotion)throw new Error('V63_SAFETY_INVARIANT_FAILED');}
