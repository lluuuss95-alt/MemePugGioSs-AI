import crypto from 'node:crypto';
import { db } from './db.js';
import type { V51Decision } from './v51-decision-engine.js';
import type { V63AllocationRow } from './v63-capital-allocation-optimizer.js';

export type V64Decision='ALLOW_PAPER'|'BLOCK';
export type V64State='READY'|'WARNING'|'HALTED';

export interface V64MarketState {
  mint:string;
  price:number;
  liquidity:number;
  updatedAt:number;
  verified?:boolean;
  stale?:boolean;
  risk?:number;
  regime?:string;
  slippageBps?:number;
}

export interface V64PortfolioState {
  exposureQuote:number;
  capital:number;
  reservePct:number;
  maxExposurePct:number;
  openPositions:number;
  maxPositions:number;
  existingMint?:boolean;
  allocatedQuote:number;
}

export interface V64Input {
  decision:V51Decision;
  allocation?:V63AllocationRow;
  market:V64MarketState;
  portfolio:V64PortfolioState;
  now?:number;
}

export interface V64Config {
  minLiquidity:number;
  maxDecisionAgeMs:number;
  maxStateAgeMs:number;
  maxRisk:number;
  maxSlippageBps:number;
  maxExposurePct:number;
  reservePct:number;
  maxPositions:number;
  requireVerifiedData:boolean;
  requireAllocation:boolean;
}

export interface V64Result {
  id:string;
  ts:number;
  mint:string;
  decision:V64Decision;
  state:V64State;
  checks:Record<string,boolean>;
  blockers:string[];
  warnings:string[];
  approvedQuote:number;
  liveExecutionEnabled:false;
}

export const defaultV64Config:V64Config=Object.freeze({
  minLiquidity:1000,
  maxDecisionAgeMs:5000,
  maxStateAgeMs:5000,
  maxRisk:45,
  maxSlippageBps:150,
  maxExposurePct:35,
  reservePct:20,
  maxPositions:10,
  requireVerifiedData:true,
  requireAllocation:true,
});

const finite=(n:unknown,d=0)=>Number.isFinite(Number(n))?Number(n):d;

export class V64AutonomousExecutionGuard {
  constructor(private readonly cfg:V64Config=defaultV64Config){this.ensureSchema();}
  private ensureSchema(){
    db.exec(`CREATE TABLE IF NOT EXISTS v64_pretrade_checks(
      id TEXT PRIMARY KEY, ts INTEGER NOT NULL, mint TEXT NOT NULL, decision TEXT NOT NULL,
      state TEXT NOT NULL, approved_quote REAL NOT NULL, checks_json TEXT NOT NULL,
      blockers_json TEXT NOT NULL, warnings_json TEXT NOT NULL, details_json TEXT NOT NULL
    )`);
  }

  validate(input:V64Input):V64Result{
    const now=input.now??Date.now(); const d=input.decision; const m=input.market; const p=input.portfolio;
    const checks:Record<string,boolean>={}; const blockers:string[]=[]; const warnings:string[]=[];
    checks.decision_is_entry=d.action==='ENTER_PAPER';
    if(!checks.decision_is_entry) blockers.push('DECISION_NOT_ENTER_PAPER');
    checks.mint_matches=m.mint===d.mint;
    if(!checks.mint_matches) blockers.push('MINT_MISMATCH');
    checks.decision_fresh=now-d.ts<=this.cfg.maxDecisionAgeMs;
    if(!checks.decision_fresh) blockers.push('DECISION_STALE');
    checks.market_fresh=now-m.updatedAt<=this.cfg.maxStateAgeMs && !m.stale;
    if(!checks.market_fresh) blockers.push('MARKET_STATE_STALE');
    checks.price_valid=Number.isFinite(m.price)&&m.price>0;
    if(!checks.price_valid) blockers.push('PRICE_INVALID');
    checks.liquidity_valid=Number.isFinite(m.liquidity)&&m.liquidity>=this.cfg.minLiquidity;
    if(!checks.liquidity_valid) blockers.push('LIQUIDITY_BELOW_MINIMUM');
    checks.data_verified=!this.cfg.requireVerifiedData || m.verified===true;
    if(!checks.data_verified) blockers.push('DATA_NOT_VERIFIED');
    checks.risk_valid=finite(d.risk,999)<=this.cfg.maxRisk && (m.risk===undefined || finite(m.risk,999)<=this.cfg.maxRisk);
    if(!checks.risk_valid) blockers.push('RISK_LIMIT_BREACHED');
    checks.regime_valid=!['NO_TRADE','STRESSED','UNKNOWN'].includes(String(m.regime??'UNKNOWN'));
    if(!checks.regime_valid) blockers.push('REGIME_BLOCKED');
    const slip=finite(m.slippageBps,0); checks.slippage_valid=slip<=this.cfg.maxSlippageBps;
    if(!checks.slippage_valid) blockers.push('SLIPPAGE_LIMIT_BREACHED');
    checks.position_limit=p.openPositions<this.cfg.maxPositions;
    if(!checks.position_limit) blockers.push('MAX_POSITIONS_REACHED');
    checks.no_existing_position=!p.existingMint;
    if(!checks.no_existing_position) blockers.push('TOKEN_ALREADY_OPEN');
    const maxExposure=p.capital*this.cfg.maxExposurePct/100;
    const reserve=p.capital*this.cfg.reservePct/100;
    const after=p.exposureQuote+Math.max(0,p.allocatedQuote);
    checks.exposure_limit=after<=maxExposure;
    if(!checks.exposure_limit) blockers.push('PORTFOLIO_EXPOSURE_LIMIT');
    checks.reserve_protected=p.capital-after>=reserve;
    if(!checks.reserve_protected) blockers.push('RESERVE_PROTECTION');
    const allocation=p.allocatedQuote;
    checks.allocation_valid=!this.cfg.requireAllocation || (Number.isFinite(allocation)&&allocation>0);
    if(!checks.allocation_valid) blockers.push('NO_VALID_CAPITAL_ALLOCATION');
    if(d.blockers.length) warnings.push(...d.blockers.map(x=>`DECISION_BLOCKER:${x}`));
    if(d.risk>=this.cfg.maxRisk*0.8) warnings.push('RISK_NEAR_LIMIT');
    if(m.liquidity<this.cfg.minLiquidity*1.5) warnings.push('LIQUIDITY_NEAR_MINIMUM');

    const allowed=blockers.length===0;
    const result:V64Result={id:crypto.randomUUID(),ts:now,mint:d.mint,decision:allowed?'ALLOW_PAPER':'BLOCK',state:allowed?(warnings.length?'WARNING':'READY'):'HALTED',checks,blockers,warnings,approvedQuote:allowed?allocation:0,liveExecutionEnabled:false};
    db.prepare(`INSERT INTO v64_pretrade_checks VALUES(?,?,?,?,?,?,?,?,?,?)`).run(result.id,now,result.mint,result.decision,result.state,result.approvedQuote,JSON.stringify(checks),JSON.stringify(blockers),JSON.stringify(warnings),JSON.stringify({decisionId:d.id,market:m,portfolio:p,liveExecutionEnabled:false}));
    return result;
  }
  recent(limit=100){return db.prepare(`SELECT * FROM v64_pretrade_checks ORDER BY ts DESC LIMIT ?`).all(Math.min(500,Math.max(1,limit)));}
}

export const V64_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV64Safe(){if(!V64_SAFETY.shadowOnly||V64_SAFETY.signingEnabled||V64_SAFETY.privateKeyAccess||V64_SAFETY.broadcastEnabled||V64_SAFETY.liveExecutionAllowed||V64_SAFETY.autoPromotion)throw new Error('V64_SAFETY_INVARIANT_FAILED');}
