export function assertV38Safety(){
  if(process.env.LIVE_TRADING==='true') throw new Error('V38_BLOCKS_LIVE_TRADING');
  if(process.env.SIGNING_ENABLED==='true') throw new Error('V38_BLOCKS_SIGNING');
  if(process.env.BROADCAST_ENABLED==='true') throw new Error('V38_BLOCKS_BROADCAST');
  if(process.env.AUTO_PROMOTION==='true') throw new Error('V38_BLOCKS_AUTO_PROMOTION');
}
