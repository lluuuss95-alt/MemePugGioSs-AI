import {DexEvent,Venue} from "./v22-types.js";
export type PumpLifecycle="CREATED"|"BONDING_CURVE"|"GRADUATED_TO_PUMPSWAP"|"PUMPSWAP_TRADING"|"UNKNOWN";
export interface LifecycleState{mint:string;state:PumpLifecycle;firstSeen:number;lastSlot:number;graduationSlot?:number;confidence:number}
export class PumpLifecycleTracker{
 private map=new Map<string,LifecycleState>();
 apply(e:DexEvent):LifecycleState|null{
  if(!e.mint)return null;
  const cur=this.map.get(e.mint);
  let state:PumpLifecycle=cur?.state||"UNKNOWN";
  if(e.type==="TOKEN_CREATE")state="CREATED";
  if(e.venue==="PUMP_BONDING_CURVE"&&(e.type==="SWAP"||e.type==="LIQUIDITY_CHANGE"))state="BONDING_CURVE";
  if(e.type==="GRADUATION"){state="GRADUATED_TO_PUMPSWAP"}
  if(e.venue==="PUMPSWAP"&&e.type==="SWAP")state="PUMPSWAP_TRADING";
  const next={mint:e.mint,state,firstSeen:cur?.firstSeen||e.observedAt,lastSlot:e.slot,graduationSlot:cur?.graduationSlot,confidence:e.confidence};
  if(e.type==="GRADUATION")next.graduationSlot=e.slot;
  this.map.set(e.mint,next);return next;
 }
 get(mint:string){return this.map.get(mint)}
}
