import crypto from "node:crypto";
import {NormalizedMarketEvent,NormalizerStats,EventKind} from "./v20-types.js";
import {EventDeduplicator} from "./v20-dedup.js";
import {SlotOrderingBuffer} from "./v20-ordering.js";

export interface RawFeedEvent{
 source:"logs"|"account"|"program";
 slot:number; observedAt:number; signature?:string; programId?:string;
 accounts?:string[]; logs?:string[]; data?:unknown; rawRef:string;
}
export interface Decoder{
 name:string;
 canDecode(e:RawFeedEvent):boolean;
 decode(e:RawFeedEvent):Partial<NormalizedMarketEvent>;
}
export class MarketEventNormalizer{
 private dedup=new EventDeduplicator();
 private ordering=new SlotOrderingBuffer();
 private stats:NormalizerStats={received:0,accepted:0,duplicates:0,outOfOrder:0,unknown:0,queueDepth:0};
 constructor(private decoders:Decoder[]){}
 normalize(raw:RawFeedEvent):NormalizedMarketEvent|null{
   this.stats.received++;
   const id=raw.signature?`${raw.source}:${raw.signature}`:crypto.createHash("sha256").update(JSON.stringify(raw)).digest("hex");
   if(!this.dedup.accept(id)){this.stats.duplicates++;return null;}
   let patch:Partial<NormalizedMarketEvent>={kind:"UNKNOWN",confidence:0,decodable:false};
   for(const d of this.decoders)if(d.canDecode(raw)){patch={...patch,...d.decode(raw),decodable:true};break;}
   if(!patch.decodable)this.stats.unknown++;
   const e:NormalizedMarketEvent={
     id,kind:(patch.kind||"UNKNOWN") as EventKind,signature:raw.signature,slot:raw.slot,
     observedAt:raw.observedAt,mint:patch.mint,programId:patch.programId||raw.programId,
     accounts:patch.accounts||raw.accounts||[],rawRef:raw.rawRef,
     confidence:Math.max(0,Math.min(1,patch.confidence??0)),decodable:!!patch.decodable
   };
   const ordered=this.ordering.push(e);
   if(!ordered.accepted){this.stats.outOfOrder++;return null;}
   this.stats.accepted++;this.stats.lastSlot=this.ordering.getLastSlot();return e;
 }
 getStats(){return {...this.stats,queueDepth:0}}
}
