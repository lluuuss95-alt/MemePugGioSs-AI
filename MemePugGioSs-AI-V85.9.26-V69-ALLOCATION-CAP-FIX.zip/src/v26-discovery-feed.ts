import WebSocket from "ws";
import {PUMP_PROGRAM_ID, V26DiscoveryHealth, V26TokenDiscovery, V26TransactionRpc, V26DiscoveryStore} from "./v26-types.js";
import {parseLogCandidate, parsePumpCreateTransaction} from "./v26-pump-create-parser.js";
import {V25LiveStateEngine, V25TrackedToken} from "./v25-state-engine.js";

export interface V26DiscoveryCallbacks { onToken?(token:V26TokenDiscovery):void|Promise<void>; onHealth?(health:V26DiscoveryHealth):void; onError?(error:Error):void; }

export class V26PumpDiscovery {
  private ws:WebSocket|null=null;
  private subscription?:number;
  private requestId=1;
  private stopped=true;
  private reconnects=0;
  private timer:ReturnType<typeof setTimeout>|undefined;
  private healthState:V26DiscoveryHealth={websocket:"DISCONNECTED",eventsSeen:0,transactionsFetched:0,candidates:0,discovered:0,duplicates:0,failedFetches:0,parserErrors:0};
  private readonly seenSignatures=new Set<string>();

  constructor(private readonly wsEndpoint:string, private readonly rpc:V26TransactionRpc, private readonly store:V26DiscoveryStore, private readonly callbacks:V26DiscoveryCallbacks={}, private readonly stateEngine?:V25LiveStateEngine, private readonly options:{commitment?:"processed"|"confirmed"|"finalized"; maxSeen?:number; reconnectBaseMs?:number; reconnectMaxMs?:number}={}){}

  start(){ if(!this.stopped)return; this.stopped=false; this.connect(); }
  stop(){ this.stopped=true; if(this.timer)clearTimeout(this.timer); this.timer=undefined; this.subscription=undefined; this.ws?.close(); this.ws=null; this.setHealth({websocket:"DISCONNECTED"}); }
  health(){return {...this.healthState};}
  tokens(){return this.store.all();}

  private setHealth(p:Partial<V26DiscoveryHealth>){this.healthState={...this.healthState,...p};this.callbacks.onHealth?.(this.health());}
  private connect(){
    if(this.stopped)return;
    this.setHealth({websocket:this.reconnects?"RECONNECTING":"CONNECTING"});
    const ws=new WebSocket(this.wsEndpoint);this.ws=ws;
    ws.on("open",()=>{this.setHealth({websocket:"CONNECTED"});const id=this.requestId++;ws.send(JSON.stringify({jsonrpc:"2.0",id,method:"logsSubscribe",params:[{mentions:[PUMP_PROGRAM_ID]},{commitment:this.options.commitment??"confirmed"}]}));});
    ws.on("message",d=>void this.onMessage(d.toString()));
    ws.on("error",e=>{this.callbacks.onError?.(e instanceof Error?e:new Error(String(e)));});
    ws.on("close",()=>{if(this.stopped)return;this.subscription=undefined;this.scheduleReconnect();});
  }
  private scheduleReconnect(){if(this.timer||this.stopped)return;this.reconnects++;const base=this.options.reconnectBaseMs??500,max=this.options.reconnectMaxMs??15000;const delay=Math.min(max,base*2**Math.min(6,this.reconnects-1));this.setHealth({websocket:"RECONNECTING"});this.timer=setTimeout(()=>{this.timer=undefined;this.connect()},delay)}

  private async onMessage(raw:string){
    let m:any;try{m=JSON.parse(raw)}catch{return}
    if(typeof m.id==="number"&&m.result!==undefined){if(typeof m.result==="number")this.subscription=m.result;return;}
    if(m.method!=="logsNotification")return;
    const value=m.params?.result?.value;const signature=value?.signature;const slot=Number(m.params?.result?.context?.slot??0);
    this.healthState.eventsSeen++;this.setHealth({eventsSeen:this.healthState.eventsSeen,lastSignature:signature,lastSlot:slot,lastEventAt:Date.now()});
    if(!signature||!parseLogCandidate(signature, (value?.logs??[]).find((x:any)=>parseLogCandidate(signature,x))))return;
    if(this.seenSignatures.has(signature)){this.healthState.duplicates++;this.setHealth({duplicates:this.healthState.duplicates});return;}
    this.remember(signature);
    try{
      const tx=await this.rpc.getTransaction(signature,this.options.commitment??"confirmed");this.healthState.transactionsFetched++;this.setHealth({transactionsFetched:this.healthState.transactionsFetched});
      const token=parsePumpCreateTransaction(signature,tx,Date.now());if(!token){return;}
      this.healthState.candidates++;this.setHealth({candidates:this.healthState.candidates});
      if(this.store.has(token.mint)){this.healthState.duplicates++;this.setHealth({duplicates:this.healthState.duplicates});return;}
      this.store.upsert(token);this.healthState.discovered++;this.setHealth({discovered:this.healthState.discovered});
      if(this.stateEngine){const tracked:V25TrackedToken={mint:token.mint,bondingCurve:token.bondingCurve};this.stateEngine.track(tracked);void this.stateEngine.hydrateBondingCurve(token.bondingCurve,token.mint).catch(()=>undefined);}
      await this.callbacks.onToken?.(token);
    }catch(error){this.healthState.failedFetches++;this.setHealth({failedFetches:this.healthState.failedFetches});this.callbacks.onError?.(error instanceof Error?error:new Error(String(error)));}
  }
  private remember(signature:string){this.seenSignatures.add(signature);const max=this.options.maxSeen??10000;if(this.seenSignatures.size>max){const first=this.seenSignatures.values().next().value as string|undefined;if(first)this.seenSignatures.delete(first)}}
}
