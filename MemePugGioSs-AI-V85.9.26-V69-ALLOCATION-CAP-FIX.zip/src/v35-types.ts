export type V35Window = '7D'|'30D'|'90D'|'ALL';
export type V35ReputationState = 'QUALIFIED'|'WATCH'|'BLOCKED'|'INSUFFICIENT_DATA';

export interface V35WindowMetrics {
  window: V35Window;
  trades: number;
  closedTrades: number;
  wins: number;
  losses: number;
  realizedPnlQuote: number;
  grossProfitQuote: number;
  grossLossQuote: number;
  winRate: number;
  profitFactor: number;
  maxDrawdownPct: number;
  avgHoldMs: number;
  uniqueTokens: number;
  tokenConcentrationPct: number;
  pumpSharePct: number;
  pumpSwapSharePct: number;
  sampleConfidence: number;
}

export interface V35TraderReputation {
  wallet: string;
  state: V35ReputationState;
  reputationScore: number;
  consistencyScore: number;
  riskScore: number;
  sampleQualityScore: number;
  specializationScore: number;
  windows: V35WindowMetrics[];
  flags: string[];
  reasons: string[];
  updatedAt: number;
}

export interface V35ReputationConfig {
  minTrades7d: number;
  minTrades30d: number;
  minTradesAll: number;
  minClosedTrades: number;
  minSampleConfidence: number;
  minReputationScore: number;
  maxRiskScore: number;
  maxTokenConcentrationPct: number;
  minConsistencyScore: number;
}

export interface V35AssistantSnapshot {
  mode: 'PAPER'|'SHADOW';
  state: 'ANALYZING'|'READY'|'PAUSED';
  lastAnalysisAt: number;
  followedTraders: number;
  qualifiedTraders: number;
  paperActionsToday: number;
  liveExecutionEnabled: false;
}
