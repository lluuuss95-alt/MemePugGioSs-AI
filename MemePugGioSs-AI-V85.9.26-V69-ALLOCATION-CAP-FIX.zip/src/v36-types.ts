export type V36CopyState = 'PROPOSED'|'ELIGIBLE'|'BLOCKED'|'EXPIRED'|'EXECUTED_PAPER';
export type V36CopySide = 'BUY'|'SELL';

export interface V36MarketContext {
  liquidityQuote?: number;
  volume5mQuote?: number;
  price?: number;
  riskScore?: number;
  freshnessMs?: number;
  tradable?: boolean;
}

export interface V36CopyConfig {
  minReputationScore: number;
  maxRiskScore: number;
  minSampleConfidence: number;
  maxLatencyMs: number;
  minTradeConfidence: number;
  minLiquidityQuote: number;
  minVolume5mQuote: number;
  maxFreshnessMs: number;
  maxTokenExposurePct: number;
  cooldownMs: number;
}

export interface V36CopySignal {
  id: string;
  wallet: string;
  signature: string;
  mint: string;
  side: V36CopySide;
  source: string;
  state: V36CopyState;
  detectedAt: number;
  executedAt: number;
  latencyMs: number;
  confidence: number;
  traderReputation: number;
  traderRisk: number;
  sampleConfidence: number;
  liquidityQuote: number;
  volume5mQuote: number;
  marketRiskScore: number;
  freshnessMs: number;
  copySizePct: number;
  reasons: string[];
}
