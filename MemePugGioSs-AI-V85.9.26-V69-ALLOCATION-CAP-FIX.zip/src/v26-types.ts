export const PUMP_PROGRAM_ID = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P";
export type V26CreateKind = "CREATE" | "CREATE_V2";

export interface V26TokenDiscovery {
  mint: string;
  bondingCurve: string;
  signature: string;
  slot: number;
  blockTime?: number;
  createKind: V26CreateKind;
  name?: string;
  symbol?: string;
  uri?: string;
  creator?: string;
  quoteMint?: string;
  mayhemMode?: boolean;
  holderReward?: boolean;
  detectedAt: number;
}

export interface V26DiscoveryHealth {
  websocket: "DISCONNECTED" | "CONNECTING" | "CONNECTED" | "RECONNECTING";
  subscription?: number;
  eventsSeen: number;
  transactionsFetched: number;
  candidates: number;
  discovered: number;
  duplicates: number;
  failedFetches: number;
  parserErrors: number;
  lastSignature?: string;
  lastSlot?: number;
  lastEventAt?: number;
}

export interface V26TransactionRpc {
  getTransaction(signature: string, commitment?: string): Promise<any>;
}

export interface V26DiscoveryStore {
  has(mint: string): boolean;
  upsert(token: V26TokenDiscovery): void;
  all(): V26TokenDiscovery[];
}
