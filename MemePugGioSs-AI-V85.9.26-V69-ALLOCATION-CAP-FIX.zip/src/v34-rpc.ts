export interface V34SignatureInfo { signature:string; slot:number; err:any; blockTime:number|null; confirmationStatus:string|null }
export class V34WalletHistoryRpc {
  constructor(private rpcUrl:string, private commitment:'confirmed'|'finalized'='finalized'){}
  private async call(method:string,params:any[]){const r=await fetch(this.rpcUrl,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:Date.now(),method,params})});if(!r.ok)throw new Error(`RPC_HTTP_${r.status}`);const j:any=await r.json();if(j.error)throw new Error(`RPC_${j.error.code||'ERROR'}:${j.error.message||''}`);return j.result}
  async signatures(address:string,limit=100,before?:string,until?:string):Promise<V34SignatureInfo[]>{return this.call('getSignaturesForAddress',[address,{commitment:this.commitment,limit:Math.min(1000,Math.max(1,limit)),...(before?{before}:{}),...(until?{until}:{})}])}
  async transaction(signature:string){return this.call('getTransaction',[signature,{commitment:this.commitment,maxSupportedTransactionVersion:0,encoding:'jsonParsed'}])}
}
