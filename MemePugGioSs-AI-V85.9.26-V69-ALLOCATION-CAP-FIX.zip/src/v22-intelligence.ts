import {DexEvent} from "./v22-types.js";
import {FlowAggregator} from "./v22-flow.js";
import {PumpLifecycleTracker} from "./v22-pump-lifecycle.js";
export interface MarketIntelligence{mint:string;venue:string;lifecycle:string;netFlow:number;buySellRatio:number;uniqueTraders:number;confidence:number;tradable:boolean;reason:string}
export class V22MarketIntelligence{
 constructor(private flow=new FlowAggregator(),private lifecycle=new PumpLifecycleTracker()){}
 apply(e:DexEvent):MarketIntelligence|null{
  if(!e.mint)return null;const life=this.lifecycle.apply(e);const flow=this.flow.apply(e);
  if(!life)return null;
  const ratio=flow&&flow.sells>0?flow.buys/flow.sells:flow?.buys?Infinity:0;
  const tradable=Boolean(e.verified&&e.venue!=="UNKNOWN"&&life.confidence>=0.8);
  return {mint:e.mint,venue:e.venue,lifecycle:life.state,netFlow:flow?.netQuote||0,buySellRatio:ratio,uniqueTraders:flow?.uniqueTraders||0,confidence:e.confidence,tradable,reason:tradable?"verified protocol event":"insufficient protocol verification"};
 }
}
