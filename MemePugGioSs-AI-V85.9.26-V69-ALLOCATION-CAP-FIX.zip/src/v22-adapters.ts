import {DexEvent,ProtocolAdapter,Venue} from "./v22-types.js";
/*
 V22 intentionally keeps protocol-specific decoding behind adapters.
 A decoder is allowed to emit a BUY/SELL/POOL event only when its instruction
 layout and program addresses are verified against the protocol source.
*/
export class AdapterRegistry{
 private adapters:ProtocolAdapter[]=[];
 register(a:ProtocolAdapter){this.adapters.push(a)}
 decode(tx:any):DexEvent[]{for(const a of this.adapters)if(a.canDecode(tx))return a.decode(tx);return []}
 list(){return this.adapters.map(a=>({name:a.name,venue:a.venue}))}
}
export class UnknownProtocolAdapter implements ProtocolAdapter{
 name="unknown";venue:Venue="UNKNOWN";
 canDecode(){return true}
 decode(tx:any):DexEvent[]{return [{id:`unknown:${tx.signature}`,signature:tx.signature,slot:tx.slot,venue:"UNKNOWN",type:"UNKNOWN",side:"UNKNOWN",confidence:0,verified:false,observedAt:Date.now()}]}
}
