import crypto from 'node:crypto';
import { db } from './db.js';
import { V83PaperExecutionCoordinator, assertV83Safe } from './v83-paper-execution-coordinator.js';
import { V80AutonomousPaperRecoverySupervisor } from './v80-autonomous-paper-recovery-supervisor.js';
import { V79PaperPortfolioReconciliation } from './v79-paper-portfolio-reconciliation.js';

export interface V84Readiness { state:'READY'|'BLOCKED'|'DEGRADED'; mode:'PAPER'; liveExecutionEnabled:false; safety:{signingEnabled:false;privateKeyAccess:false;broadcastEnabled:false;autoPromotion:false;liveExecutionEnabled:false}; checks:Record<string,{ok:boolean;detail:string}>; generatedAt:number; }
export const V84_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV84Safe(){assertV83Safe();if(!V84_SAFETY.shadowOnly||V84_SAFETY.signingEnabled||V84_SAFETY.privateKeyAccess||V84_SAFETY.broadcastEnabled||V84_SAFETY.liveExecutionAllowed||V84_SAFETY.autoPromotion)throw new Error('V84_SAFETY_INVARIANT_FAILED');}

export class V84FinalControlPlane {
  private readonly supervisor=new V80AutonomousPaperRecoverySupervisor();
  private readonly reconciliation=new V79PaperPortfolioReconciliation();
  constructor(private readonly coordinator=new V83PaperExecutionCoordinator()){db.exec(`CREATE TABLE IF NOT EXISTS v84_readiness_checks(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,state TEXT NOT NULL,result_json TEXT NOT NULL)`);assertV84Safe();}
  readiness(now=Date.now()):V84Readiness{
    const checks:Record<string,{ok:boolean;detail:string}>={};
    checks.safety={ok:true,detail:'PAPER/SHADOW; signing, keys, broadcast, live and auto-promotion disabled'};
    const gate=this.coordinator.health().gate as any; checks.paperGate={ok:gate.allowed===true&&gate.supervisorState==='READY',detail:`gate=${gate.state} supervisor=${gate.supervisorState}`};
    const journal=this.coordinator.health().journal as any; checks.transactionJournal={ok:journal.state==='HEALTHY',detail:`journal=${journal.state} pending=${journal.pending}`};
    const reconciliation=this.reconciliation.inspect(); checks.reconciliation={ok:reconciliation.state==='HEALTHY'||reconciliation.state==='RECOVERED',detail:`reconciliation=${reconciliation.state}`};
    const supervisor=this.supervisor.status(); checks.recoverySupervisor={ok:supervisor.state==='READY'&&supervisor.paperExecutionAllowed===true,detail:`supervisor=${supervisor.state} allowed=${supervisor.paperExecutionAllowed}`};
    const state=Object.values(checks).every(x=>x.ok)?'READY':Object.values(checks).some(x=>x.ok)?'DEGRADED':'BLOCKED';
    const result:V84Readiness={state,mode:'PAPER',liveExecutionEnabled:false,safety:{signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,autoPromotion:false,liveExecutionEnabled:false},checks,generatedAt:now};
    db.prepare(`INSERT INTO v84_readiness_checks VALUES(?,?,?,?)`).run(crypto.randomUUID(),now,state,JSON.stringify(result)); return result;
  }
  snapshot(){return {version:'V84',readiness:this.readiness(),coordinator:this.coordinator.health(),reconciliation:this.reconciliation.inspect(),supervisor:this.supervisor.status(),liveExecutionEnabled:false};}
}
export const v84ControlPlane=new V84FinalControlPlane();
