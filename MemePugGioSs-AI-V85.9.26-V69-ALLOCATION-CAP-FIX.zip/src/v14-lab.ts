import { SignalReport, SignalRow } from "./v14-types.js";
import { mean,median,bootstrapCI } from "./v14-stats.js";

export function evaluateSignals(rows:SignalRow[],minSamples=30):SignalReport{
  const returns=rows.map(r=>r.futureReturnPct).filter((x):x is number=>Number.isFinite(x));
  const mfe=rows.map(r=>r.mfePct).filter((x):x is number=>Number.isFinite(x));
  const mae=rows.map(r=>r.maePct).filter((x):x is number=>Number.isFinite(x));
  const confirmed=rows.filter(r=>r.signalState==="CONFIRMED").length;
  const blocked=rows.filter(r=>r.signalState==="BLOCKED").length;
  return {rows:rows.length,signals:rows.length,confirmed,blocked,
    meanReturn:mean(returns),medianReturn:median(returns),
    winRatePct:returns.length?returns.filter(x=>x>0).length/returns.length*100:undefined,
    meanMfe:mean(mfe),meanMae:mean(mae),ci95:bootstrapCI(returns),
    sampleConfidence:Math.min(1,returns.length/minSamples)};
}
