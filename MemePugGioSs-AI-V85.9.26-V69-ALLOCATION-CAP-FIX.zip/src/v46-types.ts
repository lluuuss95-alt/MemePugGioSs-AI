export type V46Regime='FAVORABLE'|'NEUTRAL'|'HIGH_VOLATILITY'|'STRESSED'|'NO_TRADE'|'UNKNOWN';
export type V46AllocationState='ALLOCATED'|'REDUCED'|'BLOCKED';
export interface V46Config{capital:number;reservePct:number;maxTotalExposurePct:number;maxPositionPct:number;maxTokenPct:number;maxTraderPct:number;maxPositions:number;minAllocation:number;highVolatilityMultiplier:number;neutralMultiplier:number;favorableMultiplier:number;}
export interface V46Candidate{ id:string; mint:string; source:'AI_SIGNAL'|'COPY_TRADER'; score:number; confidence:number; riskScore:number; liquidityQuote:number; wallet?:string; requestedPct?:number; regime?:V46Regime; }
export interface V46Allocation{candidateId:string;mint:string;source:string;wallet?:string;state:V46AllocationState;allocationQuote:number;allocationPct:number;priorityScore:number;reasons:string[];regime:V46Regime;}
export interface V46Snapshot{capital:number;reserveQuote:number;allocatedQuote:number;allocatedPct:number;remainingQuote:number;candidateCount:number;allocatedCount:number;blockedCount:number;regime:V46Regime;evaluatedAt:number;allocations:V46Allocation[];liveExecutionEnabled:false;}
