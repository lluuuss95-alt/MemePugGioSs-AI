export interface StrategyParams {
  buySellRatio:number;
  smartMoneyShare:number;
  riskMax:number;
  liquidityDeltaMin:number;
  holderDeltaMin:number;
}

export interface DatasetRow {
  mint:string; ts:number;
  buySellRatio:number; smartMoneyShare:number; risk:number;
  liquidityDelta:number; holderDelta:number;
  futureReturnPct:number;
}

export interface CandidateResult {
  params:StrategyParams;
  trainSamples:number;
  validationSamples:number;
  trainMean:number;
  validationMean:number;
  validationWinRate:number;
  gap:number;
  complexity:number;
  confidence:number;
  adjustedScore:number;
  eligible:boolean;
  testMean?:number;
}
