import {DexEvent,TradeSide} from "./v22-types.js";
export interface FlowState{mint:string;buys:number;sells:number;buyQuote:number;sellQuote:number;netQuote:number;uniqueTraders:number;lastSlot:number}
export class FlowAggregator{
 private states=new Map<string,FlowState>();private traders=new Map<string,Set<string>>();
 apply(e:DexEvent):FlowState|null{
  if(!e.mint||e.type!=="SWAP")return null;
  let s=this.states.get(e.mint)||{mint:e.mint,buys:0,sells:0,buyQuote:0,sellQuote:0,netQuote:0,uniqueTraders:0,lastSlot:e.slot};
  const q=e.quoteAmount||0;
  if(e.side==="BUY"){s.buys++;s.buyQuote+=q;s.netQuote+=q}
  if(e.side==="SELL"){s.sells++;s.sellQuote+=q;s.netQuote-=q}
  if(e.trader){let set=this.traders.get(e.mint);if(!set){set=new Set();this.traders.set(e.mint,set)}set.add(e.trader);s.uniqueTraders=set.size}
  s.lastSlot=e.slot;this.states.set(e.mint,s);return s;
 }
 get(mint:string){return this.states.get(mint)}
}
