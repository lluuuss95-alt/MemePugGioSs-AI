import crypto from "node:crypto";
import { DatasetRow, StrategyParams, CandidateResult } from "./v15-types.js";
import { generateGrid } from "./v15-grid.js";
import { evaluateSplit } from "./v15-evaluator.js";

export interface OptimizationResult {
  runId:string;
  candidates:CandidateResult[];
  shortlist:CandidateResult[];
  bestTest?:CandidateResult;
}

export function optimize(space:Record<keyof StrategyParams,number[]>,train:DatasetRow[],validation:DatasetRow[],test:DatasetRow[],maxCandidates=200):OptimizationResult{
  const params=generateGrid(space,maxCandidates);
  const candidates=params.map(p=>evaluateSplit(p,train,validation)).sort((a,b)=>b.adjustedScore-a.adjustedScore);
  const shortlist=candidates.filter(x=>x.eligible).slice(0,Math.min(10,candidates.length));
  const tested=shortlist.map(c=>({...c,testMean:evaluateTest(c.params,test)}));
  const runId=crypto.createHash("sha256").update(JSON.stringify({space,params})).digest("hex");
  return {runId,candidates,shortlist:tested,bestTest:tested[0]};
}
function evaluateTest(p:StrategyParams,rows:DatasetRow[]){
  const xs=rows.filter(r=>r.buySellRatio>=p.buySellRatio&&r.smartMoneyShare>=p.smartMoneyShare&&r.risk<=p.riskMax&&r.liquidityDelta>=p.liquidityDeltaMin&&r.holderDelta>=p.holderDeltaMin);
  return xs.length?xs.reduce((s,x)=>s+x.futureReturnPct,0)/xs.length:0;
}
