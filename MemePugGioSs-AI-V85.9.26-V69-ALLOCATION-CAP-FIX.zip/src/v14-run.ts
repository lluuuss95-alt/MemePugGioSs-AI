import crypto from "node:crypto";
import { SignalRow } from "./v14-types.js";
import { evaluateSignals } from "./v14-lab.js";
import { chronologicalSplit,tokenGroupedSplit } from "./v14-split.js";

export function runSignalLab(rows:SignalRow[]){
  const chronological=chronologicalSplit(rows);
  const grouped=tokenGroupedSplit(rows);
  const manifest=crypto.createHash("sha256").update(JSON.stringify(rows)).digest("hex");
  return {manifest,overall:evaluateSignals(rows),chronological:{
    train:evaluateSignals(chronological.train),validation:evaluateSignals(chronological.validation),test:evaluateSignals(chronological.test)
  },grouped:{
    train:evaluateSignals(grouped.train),validation:evaluateSignals(grouped.validation),test:evaluateSignals(grouped.test)
  }};
}
