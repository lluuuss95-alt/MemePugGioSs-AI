import { TokenEvent, WindowSnapshot, ForwardLabel } from "./v13-types.js";
import { HORIZONS, dedupeEvents, buildSnapshot, buildForwardLabel, fingerprint, quality } from "./window-factory.js";

export function buildTokenDataset(raw:TokenEvent[], stepMs=60_000){
  const events=dedupeEvents(raw);
  const byMint=new Map<string,TokenEvent[]>();
  for(const e of events){if(!byMint.has(e.mint))byMint.set(e.mint,[]);byMint.get(e.mint)!.push(e);}
  const snapshots:WindowSnapshot[]=[]; const labels:ForwardLabel[]=[];
  for(const [mint,xs] of byMint){
    const first=xs[0]?.ts??0,last=xs.at(-1)?.ts??0;
    for(let t=first;t<=last;t+=stepMs){
      const base=xs.filter(e=>e.ts<=t).at(-1);
      if(!base) continue;
      for(const h of Object.values(HORIZONS)){
        const start=t-h;
        snapshots.push(buildSnapshot(xs,start,t));
        labels.push(buildForwardLabel(xs,t,h));
      }
    }
  }
  return {events,snapshots,labels,fingerprint:fingerprint(snapshots,labels),quality:quality(raw,snapshots,labels)};
}
