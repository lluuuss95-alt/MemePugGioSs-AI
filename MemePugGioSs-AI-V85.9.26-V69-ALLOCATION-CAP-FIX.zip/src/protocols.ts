export type ProtocolKind = "PUMP_LIKE" | "AMM" | "ORDERBOOK" | "UNKNOWN";

export type NormalizedDexEvent =
  | { type:"TOKEN_CREATED"; mint:string; signature:string; slot:number; confidence:number; evidence:string[] }
  | { type:"LIQUIDITY_ADD"|"LIQUIDITY_REMOVE"; mint:string; signature:string; slot:number; confidence:number; evidence:string[]; baseDelta?:number; quoteDelta?:number }
  | { type:"SWAP_BUY"|"SWAP_SELL"; mint:string; signature:string; slot:number; confidence:number; evidence:string[]; baseAmount?:number; quoteAmount?:number; trader?:string }
  | { type:"TRANSFER"|"AUTHORITY_CHANGE"|"LARGE_HOLDER_MOVE"|"UNKNOWN_PROTOCOL_EVENT"; mint:string; signature:string; slot:number; confidence:number; evidence:string[] };

export interface ProtocolAdapter {
  readonly kind: ProtocolKind;
  matches(tx:any): boolean;
  decode(tx:any, mint:string): NormalizedDexEvent[];
}

export class GenericUnknownAdapter implements ProtocolAdapter {
  readonly kind = "UNKNOWN" as const;
  matches(_tx:any) { return true; }
  decode(tx:any, mint:string): NormalizedDexEvent[] {
    return [{
      type:"UNKNOWN_PROTOCOL_EVENT",
      mint,
      signature:String(tx?.transaction?.signatures?.[0] ?? ""),
      slot:Number(tx?.slot ?? 0),
      confidence:0,
      evidence:["No trusted protocol decoder matched"]
    }];
  }
}

export class AdapterRegistry {
  constructor(private readonly adapters: ProtocolAdapter[], private readonly fallback = new GenericUnknownAdapter()) {}
  decode(tx:any, mint:string): NormalizedDexEvent[] {
    const adapter = this.adapters.find(a => a.matches(tx)) ?? this.fallback;
    return adapter.decode(tx, mint);
  }
}
