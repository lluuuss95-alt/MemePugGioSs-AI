import { Strategy } from "./backtest-types.js";

export const momentumStrategy:Strategy={
  id:"momentum-v1",
  decide(ctx){
    if(ctx.bars.length<4) return {side:"HOLD",fraction:0,reason:"warmup"};
    const a=ctx.bars.at(-4)!.price,b=ctx.bars.at(-1)!.price;
    const change=b/a-1;
    if(change>0.03 && ctx.position===0) return {side:"BUY",fraction:0.5,reason:"3-bar momentum"};
    if(change<0 && ctx.position>0) return {side:"SELL",fraction:1,reason:"momentum reversal"};
    return {side:"HOLD",fraction:0,reason:"no edge"};
  }
};
