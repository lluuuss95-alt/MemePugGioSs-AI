export type Venue="PUMP_BONDING_CURVE"|"PUMPSWAP"|"UNKNOWN";
export type TradeSide="BUY"|"SELL"|"UNKNOWN";
export type MarketEventType="TOKEN_CREATE"|"SWAP"|"LIQUIDITY_CHANGE"|"GRADUATION"|"UNKNOWN";
export interface DexEvent{
 id:string;signature:string;slot:number;venue:Venue;type:MarketEventType;side:TradeSide;
 mint?:string;trader?:string;pool?:string;quoteAmount?:number;baseAmount?:number;
 price?:number;liquidityQuote?:number;confidence:number;verified:boolean;observedAt:number;
}
export interface ProtocolAdapter{
 name:string;venue:Venue;canDecode(tx:any):boolean;decode(tx:any):DexEvent[];
}
