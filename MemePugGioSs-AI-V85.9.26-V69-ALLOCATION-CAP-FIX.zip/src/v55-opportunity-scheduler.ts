import crypto from 'node:crypto';
import { db } from './db.js';
import type { V48Candidate } from './v48-ultra-discovery.js';
import type { V49Score } from './v49-instant-scoring.js';

export type V55Band='DEEP_ANALYSIS'|'WATCH'|'REJECTED';
export type V55Priority='CRITICAL'|'HIGH'|'NORMAL'|'LOW';
export type V55State='RUNNING'|'DEGRADED'|'STOPPED'|'HALTED';
export interface V55Job { id:string; mint:string; band:V55Band; priority:V55Priority; enqueuedAt:number; expiresAt:number; candidate:V48Candidate; instant:V49Score; attempts:number; }
export interface V55Config { maxQueue:number; maxInFlight:number; maxPerMintQueued:number; maxJobsPerMintPerWindow:number; fairnessWindowMs:number; maxWaitMs:number; jobTtlMs:number; windowMs:number; }
export interface V55Health { state:V55State; queued:number; inFlight:number; submitted:number; dispatched:number; completed:number; rejected:number; expired:number; deduplicated:number; failed:number; starvedPrevented:number; activeMints:number; lastDispatchAt:number|null; }
export interface V55Callbacks { onDeepAnalysis?(job:V55Job):void|Promise<void>; onWatch?(job:V55Job):void|Promise<void>; onRejected?(job:V55Job):void|Promise<void>; onError?(error:Error,job:V55Job):void|Promise<void>; }

export const defaultV55Config:V55Config=Object.freeze({maxQueue:10000,maxInFlight:4,maxPerMintQueued:3,maxJobsPerMintPerWindow:6,fairnessWindowMs:1500,maxWaitMs:5000,jobTtlMs:15000,windowMs:1000});
const rank=(p:V55Priority)=>p==='CRITICAL'?4:p==='HIGH'?3:p==='NORMAL'?2:1;

/** V55 schedules verified opportunities; it does not create signals or execute trades. */
export class V55OpportunityScheduler {
 private readonly cfg:V55Config; private readonly queue:V55Job[]=[]; private readonly ids=new Set<string>(); private readonly mintDispatches=new Map<string,number[]>();
 private running=false; private draining=false; private inFlight=0; private h:V55Health={state:'STOPPED',queued:0,inFlight:0,submitted:0,dispatched:0,completed:0,rejected:0,expired:0,deduplicated:0,failed:0,starvedPrevented:0,activeMints:0,lastDispatchAt:null};
 constructor(private readonly callbacks:V55Callbacks={},cfg:Partial<V55Config>={}){this.cfg={...defaultV55Config,...cfg}; this.ensureSchema();}
 private ensureSchema(){db.exec(`CREATE TABLE IF NOT EXISTS v55_scheduler_events(id TEXT PRIMARY KEY,ts INTEGER NOT NULL,mint TEXT NOT NULL,band TEXT NOT NULL,priority TEXT NOT NULL,status TEXT NOT NULL,wait_ms INTEGER NOT NULL,attempts INTEGER NOT NULL,details_json TEXT NOT NULL)`);}
 start(){this.running=true;this.h={...this.h,state:'RUNNING'};void this.drain();}
 stop(){this.running=false;this.queue.length=0;this.h={...this.h,state:'STOPPED',queued:0};}
 halt(){this.running=false;this.h={...this.h,state:'HALTED'};}
 health(){return {...this.h};}
 enqueue(candidate:V48Candidate,instant:V49Score,now=Date.now()):V55Job|null{
  this.h.submitted++;
  const band:V55Band=instant.band;
  const priority:V55Priority=band==='DEEP_ANALYSIS'?(instant.score>=85?'CRITICAL':'HIGH'):band==='WATCH'?'NORMAL':'LOW';
  const id=crypto.createHash('sha256').update(`${candidate.signature}:${candidate.token.mint}:${instant.generatedAt}:${band}`).digest('hex');
  if(this.ids.has(id)){this.h.deduplicated++;return null;}
  if(band==='REJECTED'){const job=this.make(id,candidate,instant,priority,now);this.h.rejected++;this.persist(job,'REJECTED',0);void this.callbacks.onRejected?.(job);return job;}
  const queuedForMint=this.queue.filter(j=>j.mint===candidate.token.mint).length;
  if(queuedForMint>=this.cfg.maxPerMintQueued || this.queue.length>=this.cfg.maxQueue){this.h.rejected++;this.persist(this.make(id,candidate,instant,priority,now),'QUEUE_LIMIT',0);return null;}
  const job=this.make(id,candidate,instant,priority,now);this.ids.add(id);this.queue.push(job);this.h.queued=this.queue.length;this.h.activeMints=new Set(this.queue.map(j=>j.mint)).size;this.persist(job,'QUEUED',0);if(this.running)void this.drain();return job;
 }
 private make(id:string,c:V48Candidate,i:V49Score,priority:V55Priority,now:number):V55Job{return {id,mint:c.token.mint,band:i.band,priority,enqueuedAt:now,expiresAt:now+this.cfg.jobTtlMs,candidate:c,instant:i,attempts:0};}
 private async drain(){if(this.draining)return;this.draining=true;try{while(this.running&&this.inFlight<this.cfg.maxInFlight&&this.queue.length){this.expire();if(!this.queue.length)break;const job=this.pick();if(!job)break;this.inFlight++;this.h.inFlight=this.inFlight;this.h.dispatched++;this.h.lastDispatchAt=Date.now();job.attempts++;this.persist(job,'DISPATCHED',Date.now()-job.enqueuedAt);void this.run(job);}}finally{this.draining=false;}}
 private async run(job:V55Job){try{if(job.band==='DEEP_ANALYSIS')await this.callbacks.onDeepAnalysis?.(job);else await this.callbacks.onWatch?.(job);this.h.completed++;this.persist(job,'COMPLETED',Date.now()-job.enqueuedAt);}catch(e){this.h.failed++;this.h.state='DEGRADED';this.persist(job,'FAILED',Date.now()-job.enqueuedAt);await this.callbacks.onError?.(e instanceof Error?e:new Error(String(e)),job);}finally{this.inFlight--;this.h.inFlight=this.inFlight;this.h.queued=this.queue.length;this.h.activeMints=new Set(this.queue.map(j=>j.mint)).size;if(this.running)void this.drain();}}
 private pick(){let best=-1;let bestScore=-Infinity;const now=Date.now();for(let i=0;i<this.queue.length;i++){const j=this.queue[i];const age=now-j.enqueuedAt;const waited=Math.min(2,age/this.cfg.fairnessWindowMs);const starvation=age>=this.cfg.maxWaitMs?3:0;const recent=this.mintDispatches.get(j.mint)??[];const windowStart=now-this.cfg.windowMs;const used=recent.filter(t=>t>=windowStart).length;if(used>=this.cfg.maxJobsPerMintPerWindow)continue;const score=rank(j.priority)*10+waited+starvation;if(starvation>0)this.h.starvedPrevented++;if(score>bestScore){bestScore=score;best=i;}}
  if(best<0)return undefined;const j=this.queue.splice(best,1)[0];const a=this.mintDispatches.get(j.mint)??[];a.push(now);this.mintDispatches.set(j.mint,a.slice(-this.cfg.maxJobsPerMintPerWindow));this.h.queued=this.queue.length;return j;}
 private expire(){const now=Date.now();for(let i=this.queue.length-1;i>=0;i--){if(this.queue[i].expiresAt<=now){const j=this.queue.splice(i,1)[0];this.h.expired++;this.persist(j,'EXPIRED',now-j.enqueuedAt);}}this.h.queued=this.queue.length;}
 private persist(j:V55Job,status:string,wait:number){db.prepare(`INSERT OR REPLACE INTO v55_scheduler_events(id,ts,mint,band,priority,status,wait_ms,attempts,details_json) VALUES(?,?,?,?,?,?,?,?,?)`).run(j.id,j.enqueuedAt,j.mint,j.band,j.priority,status,Math.max(0,Math.round(wait)),j.attempts,JSON.stringify({liveExecutionEnabled:false,shadowOnly:true}));}
}
export const V55_SAFETY=Object.freeze({mode:'PAPER',shadowOnly:true,signingEnabled:false,privateKeyAccess:false,broadcastEnabled:false,liveExecutionAllowed:false,autoPromotion:false});
export function assertV55Safe(){if(!V55_SAFETY.shadowOnly||V55_SAFETY.signingEnabled||V55_SAFETY.privateKeyAccess||V55_SAFETY.broadcastEnabled||V55_SAFETY.liveExecutionAllowed)throw new Error('V55_SAFETY_INVARIANT_FAILED');}
