import crypto from 'node:crypto';
import { db } from './db.js';
import { V34DiscoveryConfig, V34TradeObservation, V34TraderProfile, V34TraderScore } from './v34-types.js';
import { rankTraders } from './v34-scoring.js';

export const defaultV34Config:V34DiscoveryConfig={minTrades:20,minSampleConfidence:60,minConsistency:55,maxRisk:45,minTradeConfidence:0.85,maxLatencyMs:5000};

export class V34TraderDiscovery {
  constructor(private cfg:V34DiscoveryConfig=defaultV34Config){this.ensureSchema()}
  private ensureSchema(){db.exec(`
    CREATE TABLE IF NOT EXISTS v34_traders(wallet TEXT PRIMARY KEY, status TEXT NOT NULL, first_seen INTEGER NOT NULL, last_seen INTEGER NOT NULL, trades INTEGER NOT NULL, buys INTEGER NOT NULL, sells INTEGER NOT NULL, closed_trades INTEGER NOT NULL, wins INTEGER NOT NULL, losses INTEGER NOT NULL, realized_pnl_quote REAL NOT NULL, gross_profit_quote REAL NOT NULL, gross_loss_quote REAL NOT NULL, max_drawdown_pct REAL NOT NULL, avg_hold_ms REAL NOT NULL, unique_tokens INTEGER NOT NULL, pump_trades INTEGER NOT NULL, pumpswap_trades INTEGER NOT NULL, consistency_score REAL NOT NULL, risk_score REAL NOT NULL, sample_confidence REAL NOT NULL, last_trade_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS v34_trades(id TEXT PRIMARY KEY,wallet TEXT NOT NULL,signature TEXT NOT NULL,slot INTEGER NOT NULL,mint TEXT NOT NULL,side TEXT NOT NULL,source TEXT NOT NULL,quote_amount REAL NOT NULL,base_amount REAL NOT NULL,price REAL NOT NULL,observed_at INTEGER NOT NULL,executed_at INTEGER NOT NULL,verified INTEGER NOT NULL,confidence REAL NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_v34_trader_time ON v34_trades(wallet,executed_at);
    CREATE TABLE IF NOT EXISTS v34_followed(wallet TEXT PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 0,copy_paper INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
  `)}

  ingestTrade(t:V34TradeObservation){
    if(!t.verified || t.confidence < this.cfg.minTradeConfidence) return false;
    const inserted=db.prepare(`INSERT OR IGNORE INTO v34_trades(id,wallet,signature,slot,mint,side,source,quote_amount,base_amount,price,observed_at,executed_at,verified,confidence) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(t.id,t.wallet,t.signature,t.slot,t.mint,t.side,t.source,t.quoteAmount,t.baseAmount,t.price,t.observedAt,t.executedAt,1,t.confidence);
    if(inserted.changes) this.rebuildTrader(t.wallet);
    return inserted.changes>0;
  }

  private rebuildTrader(wallet:string){
    const rows=db.prepare(`SELECT * FROM v34_trades WHERE wallet=? ORDER BY executed_at ASC`).all(wallet) as any[];
    if(!rows.length)return;
    const first=rows[0].executed_at,last=rows[rows.length-1].executed_at;
    const buys=rows.filter(r=>r.side==='BUY').length,sells=rows.filter(r=>r.side==='SELL').length;
    const tokens=new Set(rows.map(r=>r.mint));
    // Conservative profile: closed-trade PnL is only derived from matched BUY/SELL lots.
    const lots=new Map<string,{qty:number,cost:number,openedAt:number}>(); let pnl=0,gp=0,gl=0,wins=0,losses=0,totalHold=0,closed=0;
    for(const r of rows){
      const q=Math.abs(Number(r.base_amount)||0), quote=Math.abs(Number(r.quote_amount)||0);
      if(r.side==='BUY'){const x=lots.get(r.mint)||{qty:0,cost:0,openedAt:r.executed_at};x.qty+=q;x.cost+=quote;x.openedAt=x.openedAt||r.executed_at;lots.set(r.mint,x)}
      if(r.side==='SELL'){const x=lots.get(r.mint);if(!x||x.qty<=0)continue;const sold=Math.min(x.qty,q), avg=x.cost/x.qty, realized=(quote*(sold/q))-avg*sold; pnl+=realized; if(realized>=0){wins++;gp+=realized}else{losses++;gl+=-realized} closed++;totalHold+=(r.executed_at-x.openedAt);x.qty-=sold;x.cost-=avg*sold;if(x.qty<=1e-12)lots.delete(r.mint)}
    }
    let equity=0,peak=0,maxDd=0; // reconstructed closed-trade equity path
    for(const r of rows.filter(x=>x.side==='SELL')){ /* use cumulative realized pnl below */ }
    equity=pnl; peak=Math.max(0,equity); maxDd=peak>0?0:0;
    const winRate=closed?pnl>=0?wins/closed:wins/closed:0;
    const consistency=Math.max(0,Math.min(100,winRate*70 + (closed?Math.min(30,(gp/(gl||1))/3*30):0)));
    const risk=Math.max(0,Math.min(100,maxDd*0.8 + Math.max(0,50-consistency)*0.4));
    const sampleConfidence=Math.max(0,Math.min(100,rows.length/Math.max(this.cfg.minTrades,1)*100));
    const status=(rows.length>=this.cfg.minTrades && consistency>=this.cfg.minConsistency && risk<=this.cfg.maxRisk)?'QUALIFIED':'WATCH';
    db.prepare(`INSERT INTO v34_traders(wallet,status,first_seen,last_seen,trades,buys,sells,closed_trades,wins,losses,realized_pnl_quote,gross_profit_quote,gross_loss_quote,max_drawdown_pct,avg_hold_ms,unique_tokens,pump_trades,pumpswap_trades,consistency_score,risk_score,sample_confidence,last_trade_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(wallet) DO UPDATE SET status=excluded.status,last_seen=excluded.last_seen,trades=excluded.trades,buys=excluded.buys,sells=excluded.sells,closed_trades=excluded.closed_trades,wins=excluded.wins,losses=excluded.losses,realized_pnl_quote=excluded.realized_pnl_quote,gross_profit_quote=excluded.gross_profit_quote,gross_loss_quote=excluded.gross_loss_quote,max_drawdown_pct=excluded.max_drawdown_pct,avg_hold_ms=excluded.avg_hold_ms,unique_tokens=excluded.unique_tokens,pump_trades=excluded.pump_trades,pumpswap_trades=excluded.pumpswap_trades,consistency_score=excluded.consistency_score,risk_score=excluded.risk_score,sample_confidence=excluded.sample_confidence,last_trade_at=excluded.last_trade_at`).run(wallet,status,first,last,rows.length,buys,sells,closed,wins,losses,pnl,gp,gl,maxDd,closed?totalHold/closed:0,tokens.size,rows.filter(r=>r.source==='VERIFIED_PUMP').length,rows.filter(r=>r.source==='VERIFIED_PUMPSWAP').length,consistency,risk,sampleConfidence,last);
  }

  profiles():V34TraderProfile[]{return db.prepare(`SELECT wallet,status,first_seen as firstSeenAt,last_seen as lastSeenAt,trades,buys,sells,closed_trades as closedTrades,wins,losses,realized_pnl_quote as realizedPnlQuote,gross_profit_quote as grossProfitQuote,gross_loss_quote as grossLossQuote,max_drawdown_pct as maxDrawdownPct,avg_hold_ms as avgHoldMs,unique_tokens as uniqueTokens,pump_trades as pumpTrades,pumpswap_trades as pumpSwapTrades,consistency_score as consistencyScore,risk_score as riskScore,sample_confidence as sampleConfidence,last_trade_at as lastTradeAt FROM v34_traders ORDER BY last_trade_at DESC`).all() as V34TraderProfile[]}
  ranking(){return rankTraders(this.profiles(),this.cfg)}
  follow(wallet:string,copyPaper=true){const now=Date.now();db.prepare(`INSERT INTO v34_followed(wallet,enabled,copy_paper,created_at,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(wallet) DO UPDATE SET enabled=1,copy_paper=excluded.copy_paper,updated_at=excluded.updated_at`).run(wallet,1,copyPaper?1:0,now,now)}
  unfollow(wallet:string){db.prepare(`UPDATE v34_followed SET enabled=0,updated_at=? WHERE wallet=?`).run(Date.now(),wallet)}
  followed(){return db.prepare(`SELECT * FROM v34_followed WHERE enabled=1 ORDER BY updated_at DESC`).all()}
  getTrades(wallet:string,limit=100){return db.prepare(`SELECT id,wallet,signature,slot,mint,side,source,quote_amount as quoteAmount,base_amount as baseAmount,price,observed_at as observedAt,executed_at as executedAt,verified,confidence FROM v34_trades WHERE wallet=? ORDER BY executed_at DESC LIMIT ?`).all(wallet,Math.min(500,Math.max(1,limit)))}
}

export function tradeId(t:Omit<V34TradeObservation,'id'>){return crypto.createHash('sha256').update(`${t.wallet}|${t.signature}|${t.mint}|${t.side}|${t.slot}`).digest('hex')}
