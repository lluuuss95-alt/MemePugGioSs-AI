import { V30PaperState, V30Position, V30DecisionRecord } from './v30-types.js';

export interface V32PortfolioSummary {
  startingCapital: number;
  cash: number;
  equity: number;
  realizedPnl: number;
  unrealizedPnl: number;
  peakEquity: number;
  drawdownPct: number;
  exposure: number;
  openPositions: number;
  totalTrades: number;
  lastUpdated: number;
}

export interface V32LedgerSnapshot extends V32PortfolioSummary { id: number; }
export interface V32PersistedPosition extends V30Position { persistedAt: number; }
export interface V32PersistedDecision extends V30DecisionRecord { id: number; }

export interface V32LedgerState {
  version: 32;
  startingCapital: number;
  state: V30PaperState;
  summary: V32PortfolioSummary;
}
