# V25 Checklist

- [x] accountSubscribe boundary
- [x] reconnect with exponential backoff
- [x] initial getAccountInfo hydration boundary
- [x] Pump BondingCurve live state
- [x] PumpSwap Pool live metadata
- [x] SPL vault balance service
- [x] token supply refresh
- [x] PumpSwap effective quote reserve
- [x] slot coherence gate
- [x] stale state gate
- [x] Home data contract without UI redesign
- [x] Shadow-only safety invariants
- [x] V25 unit tests
- [ ] production RPC soak test
- [ ] long-run persistence / snapshot database
- [ ] verified live Pump/PumpSwap account fixtures
