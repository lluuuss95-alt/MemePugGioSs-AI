# V38 Architecture — Copy Risk Manager

V38 adds a portfolio-level risk gate in front of V37 Copy Paper execution.

Flow:

`V36 Copy Signal -> V38 Risk Preflight -> V37 Paper Portfolio`

Controls:
- total portfolio exposure
- per-token concentration
- per-trader exposure
- daily loss limit
- drawdown warning and hard halt
- concurrent active trader limit
- shared-token trader concentration
- depleted paper-account check
- circuit breaker state: NORMAL / WARNING / HALTED

Every preflight is persisted with its decision and explicit blocking reasons. V38 does not sign, broadcast, or execute live transactions.
