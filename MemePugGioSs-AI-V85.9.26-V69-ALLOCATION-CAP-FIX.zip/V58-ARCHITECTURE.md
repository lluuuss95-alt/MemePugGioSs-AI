# V58 — Event-Driven AI Re-Evaluation Engine

V58 turns V57 material state changes into bounded, prioritized AI re-evaluation jobs.

Flow:
Pump.fun/Solana -> V48 Discovery -> V54 Router -> V49 Instant Score -> V55 Scheduler -> V50 Deep Intelligence -> V56 Unified State -> V57 Change Detector -> V58 Re-evaluation -> V51 Decision -> V46/V47 Allocation -> V52/V53 Paper

## Rules
- Only actionable V57 changes can trigger re-evaluation.
- CRITICAL/HIGH/NORMAL priority queue.
- Bounded queue and bounded concurrency.
- Per-mint cooldown and rate window prevent event storms.
- Duplicate change/version combinations are ignored.
- Expired jobs are audited.
- Every job/result is persisted in SQLite.
- V58 never executes a trade and never signs or broadcasts.
- A real AI/decision callback can be connected later; this V58 core provides the deterministic event-driven orchestration boundary.

## Safety
PAPER/SHADOW only. `signingEnabled=false`, `privateKeyAccess=false`, `broadcastEnabled=false`, `liveExecutionAllowed=false`, `autoPromotion=false`.
