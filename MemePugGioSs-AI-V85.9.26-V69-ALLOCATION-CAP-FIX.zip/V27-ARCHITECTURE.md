# V27 — Discovery Gap Recovery & Android Realtime Layer

V27 closes the main reliability gap of V26: a WebSocket stream can disconnect and miss notifications. The backend now has a cursor-based recovery engine.

## Pipeline

`Pump logsSubscribe -> V26 discovery -> disconnect -> V27 getSignaturesForAddress -> getTransaction -> V26 parser -> discovery store -> V25 state engine -> API/WebSocket -> Android`

Solana exposes `getSignaturesForAddress` with `before`, `until`, and `limit`, allowing cursor pagination. Recovery walks newest-to-oldest pages until the persisted checkpoint is reached. A transaction is then fetched and passed through the existing verified V26 parser.

## Checkpoint

V27 stores the newest processed signature/slot. SQLite support is provided by `V27SqliteCheckpointStore`; an in-memory implementation is used for tests.

## Safety

Recovery only observes and stores public chain data. V27 does not sign, broadcast, access private keys, or enable live execution.

## Android

The Android client gains a realtime WebSocket client for the existing authenticated `/ws` channel. HTTP remains the initial hydration path; WebSocket state becomes the low-latency update path. The UI remains the official Home design and is not redesigned.
