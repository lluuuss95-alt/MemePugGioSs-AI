# MemePugGioSs AI V9 — Smart Money & Early Entry Engine

V9 combines token intelligence, DEX flow and wallet intelligence into a time-aware opportunity engine.

Pipeline:
market/on-chain observations -> feature windows -> smart-money flow -> accumulation/distribution
-> early-entry signal -> simulated entry/exit -> outcome attribution -> score calibration.

Important:
- V9 is a research and paper-trading engine, not a profit guarantee.
- Signals are only valid with sufficient sample size and fresh data.
- No signal can authorize LIVE trading.
- Future leakage is prohibited: features at time T may only use observations <= T.
- All signals include confidence, freshness and reasons.

Signal dimensions:
1. Flow momentum
2. Smart-money participation
3. Liquidity trend
4. Wallet concentration change
5. Buy/sell imbalance
6. Lifecycle state
7. Risk delta
8. Data quality

Signal states:
WATCH -> EARLY_ENTRY_CANDIDATE -> CONFIRMED -> INVALIDATED
with BLOCKED when risk/data gates fail.
