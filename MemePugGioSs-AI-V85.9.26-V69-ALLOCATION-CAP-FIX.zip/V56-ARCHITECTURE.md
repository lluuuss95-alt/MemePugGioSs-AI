# V56 — Real-Time Token State Fusion

V56 maintains a single deterministic state per token mint and merges only explicitly observed fields from Discovery, Instant Scoring, Deep Intelligence, Market Ticks and optional verified intelligence sources.

## Flow

Pump.fun/Solana events -> V48 Discovery -> V54 Router -> V49 Instant Score -> V55 Scheduler -> V50 Deep Intelligence -> V56 Unified State -> V51 Decision / V52 Execution / V53 Supervisor.

V56 can also receive market ticks directly for low-latency state refresh.

## Guarantees

- one state per mint;
- monotonic version per accepted update;
- explicit source attribution;
- no fabricated values for missing fields;
- freshness classification (`FRESH`, `AGING`, `STALE`, `UNKNOWN`);
- bounded in-memory state count;
- persistent snapshot and event audit in SQLite;
- repeated observations merge into the same mint state;
- Paper/Shadow safety invariant remains enforced.

## Important boundary

V56 is a state-fusion layer, not a trading decision engine. It does not predict future prices, create orders, sign transactions, or broadcast transactions.

## Persistence

- `v56_token_states`: latest state per mint
- `v56_state_events`: append-style audit events keyed by deterministic event id

## Freshness

Default thresholds:
- `FRESH`: <= 2s
- `AGING`: >2s and <=5s
- `STALE`: >5s

Thresholds are configurable and should be tuned after observing real feed latency.
