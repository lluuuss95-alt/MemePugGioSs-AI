# V75 — AI Re-Evaluation → Arbitration & Capital Allocation Loop

V75 bridges a V59 decision reevaluation into the existing V60/V61/V62/V63 control stack without bypassing any upstream gate.

## Flow

V59 ENTER_PAPER → V75 context validation → V62 arbitration via V63 → V61 portfolio limits → V63 optimized allocation → Paper readiness for downstream V64/V65/V69.

V75 does not itself sign, broadcast, execute live orders, or promote Paper to live. A V59 outcome other than ENTER_PAPER is blocked before allocation. Verified/latest observation liquidity is required; missing context produces INSUFFICIENT_CONTEXT.

## Allocation safeguards

- V61 open Paper positions are converted to exposure inputs.
- V62 strategy, liquidity, score, confidence, reserve, correlation and opportunity caps remain authoritative.
- V63 position and total allocation caps remain authoritative.
- Regime is derived only from the explicit V59/V50 regime multiplier: 1.0 FAVORABLE, 0.75 NEUTRAL, 0.5 HIGH_VOLATILITY, otherwise UNKNOWN.
- No fabricated liquidity or market state is used.

## Persistence

`v75_capital_loop_runs` records status, regime, requested percentage, optimized quote, arbitration state and reasons.

## Safety

PAPER/SHADOW only. `signingEnabled=false`, `privateKeyAccess=false`, `broadcastEnabled=false`, `liveExecutionAllowed=false`, `autoPromotion=false`.
