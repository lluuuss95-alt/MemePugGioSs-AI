# V12 Checklist

- [x] Solana signature pagination contract
- [x] before/until cursors
- [x] Transaction detail fetch contract
- [x] Checkpoint/resume state
- [x] Rate limiter
- [x] Exponential backoff
- [x] Retry classification
- [x] Bounded transaction concurrency
- [x] Signature deduplication
- [x] Backfill statistics
- [x] Deterministic checkpoint fingerprint
- [x] Provider adapter boundary
- [x] V11 dataset handoff
- [x] Unit tests
- [x] PAPER/research-only
