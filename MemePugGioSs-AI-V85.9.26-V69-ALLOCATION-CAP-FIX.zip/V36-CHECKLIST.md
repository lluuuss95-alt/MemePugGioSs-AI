# V36 Checklist

- [x] V35 reputation input integrated
- [x] Follow + copy-paper gate
- [x] Trade verification/confidence gate
- [x] Latency gate
- [x] Liquidity and volume gates
- [x] Market freshness/risk/tradability gates
- [x] Cooldown gate
- [x] Exposure cap
- [x] Persistent copy-signal ledger
- [x] REST endpoints
- [x] WebSocket eligible-signal feed
- [x] Live signing disabled
- [x] Broadcast disabled
- [x] Auto-promotion disabled
- [x] Unit safety test
