# V20 Checklist

- [x] Multi-source raw event contract
- [x] Deterministic event identity
- [x] Deduplication
- [x] Slot ordering guard
- [x] Verified decoder interface
- [x] UNKNOWN fallback
- [x] Decoder confidence
- [x] Shadow event ledger
- [x] Safety invariants
- [x] Tests
