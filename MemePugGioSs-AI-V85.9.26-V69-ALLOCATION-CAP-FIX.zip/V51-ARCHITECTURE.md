# V51 — AI Final Decision Engine

V51 is the final decision gate between verified deep token intelligence and the paper portfolio pipeline.

Flow:
Pump.fun -> V48 discovery -> V49 instant triage -> V50 deep intelligence -> V51 final decision -> V46 allocator/V47 coordinator -> paper position manager.

Actions: ENTER_PAPER, WATCH, WAIT, EXIT_PAPER, BLOCK. Current implementation emits ENTER_PAPER/WAIT/EXIT_PAPER/BLOCK; WATCH remains reserved for a future neutral-watch routing layer.

Gates are explicit and deterministic: deep-analysis state, score, confidence, risk, freshness, liquidity and market-regime support. Missing or stale observations never become fabricated values.

Theoretical sizing is capped by the configured maximum position percentage and is not an order amount. No live signing, private-key access, broadcast or auto-promotion is permitted.

Every decision contains reasons, blockers and invalidation conditions and is persisted in `v51_decisions` for audit/replay.
