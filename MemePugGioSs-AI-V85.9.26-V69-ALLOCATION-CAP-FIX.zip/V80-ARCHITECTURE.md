# V80 — Autonomous Paper Recovery Supervisor

## Objective
Continuously gate the Paper execution engine on system health and portfolio consistency. V80 connects V70 System Health with V79 Portfolio Reconciliation.

## Flow
`V70 health -> V80 supervisor -> V79 reconciliation/recovery -> post-recovery health -> PAPER allowed/blocked`

## Rules
- Paper execution is allowed only after V70 reports RUNNING and V79 is HEALTHY/RECOVERED.
- DEGRADED/RECOVERING/HALTED health triggers deterministic V79 recovery.
- FAILED reconciliation blocks Paper and flags manual review.
- V80 never invents market values or repairs ambiguous state.
- V80 never deletes ledger rows automatically.
- Safety remains PAPER/SHADOW only.

## Persistence
`v80_recovery_supervisor_runs` stores each decision, health state, recovery state, reasons and serialized result.

## API integration
- `GET /api/v80/recovery-supervisor`
- `POST /api/v80/recovery-supervisor/run`
- `GET /api/v80/mobile/recovery-supervisor`

## Safety
signing=false, privateKeys=false, broadcast=false, live=false, autoPromotion=false.
