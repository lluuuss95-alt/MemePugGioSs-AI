# V33 — Paper Trading Replay & Recovery Engine

V33 makes the Paper portfolio recoverable after process/backend restarts.

Flow:
V32 persistent ledger -> V33 recovery -> consistency checks -> checkpoint -> Android realtime state.

## Guarantees
- Loads portfolio/positions/decisions from the persistent V32 ledger.
- Detects duplicate position IDs and invalid numeric state.
- Hashes canonical portfolio state for checkpoint integrity.
- Creates durable recovery checkpoints.
- Reports HEALTHY/DEGRADED status instead of silently accepting inconsistent state.

V33 is PAPER-only. It does not sign, broadcast, access private keys, or execute live trades.
