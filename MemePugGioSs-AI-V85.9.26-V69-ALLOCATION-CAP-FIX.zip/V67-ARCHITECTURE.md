# V67 — AI Execution Calibration Engine

V67 calibrates Paper execution assumptions from rolling V66 execution-quality observations. It is deliberately bounded and cannot promote itself to live execution.

## Inputs
- V66 simulated slippage and price impact
- V66 Paper latency/deviation
- V66 quality/block rate

## Calibration
- rolling window: 100 observations
- minimum sample gate: 10
- relative adjustment cap: ±20%
- absolute slippage/impact adjustment cap: 100 bps
- latency adjustment cap: ±1000 ms
- insufficient data returns baseline unchanged

The engine uses robust medians rather than reacting to a single observation. Low confidence or high block rates produce DEGRADED state. Calibration is persisted in `v67_execution_calibrations` with reasons and confidence.

## Safety
V67 only produces calibration parameters for PAPER/SHADOW. It never signs, broadcasts, accesses private keys, submits live transactions, or auto-promotes the system.
