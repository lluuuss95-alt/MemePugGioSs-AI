# V76 — Allocation → Risk Calibration → Pre-Trade Guard → Execution Simulation Bridge

V76 closes the deterministic Paper-only bridge between V75 capital allocation and the existing V69 end-to-end pipeline.

Flow:
V75 ALLOCATED → V68 risk calibration → V64 pre-trade guard → V65 execution simulation → V69 end-to-end verification → PAPER_ENTRY_READY/BLOCKED.

Rules:
- V68 can only reduce the allocation/risk envelope; it never increases upstream V75 capital.
- V64 is a hard gate for freshness, liquidity, verification, risk, regime, exposure, reserve, position count and allocation validity.
- V65 is a paper constant-product execution simulation; it never signs, broadcasts or submits transactions.
- V69 remains the final end-to-end verifier and does not execute live trades.
- No private keys, signing, broadcast, live execution or automatic promotion are introduced.
- All bridge runs are persisted in `v76_allocation_bridge_runs`.
- `PAPER_ENTRY_READY` means the pipeline is ready for the existing downstream Paper execution layer; it is not a real transaction.

Endpoint:
- `POST /api/v76/allocation-bridge` — execute the bridge with explicit V59/V75/market/pool/portfolio context.
- `GET /api/v76/allocation-bridge` — recent persisted bridge runs.
- `GET /api/v76/mobile/allocation-bridge` — mobile-safe status/recent runs.
