# MemePugGioSs AI — V48 Ultra-Low-Latency Pump.fun Discovery & Triage

## Objective
Minimize discovery-to-analysis latency for newly created Pump.fun tokens while preserving the verified-transaction boundary.

## Flow
`Pump.fun logsSubscribe -> ingress dedup -> bounded queue -> getTransaction(confirmed) -> verified create/create_v2 parser -> fast triage -> V28/V29/V41/V46/V47 downstream`

## Fast triage
- P0 / DEEP_ANALYSIS: verified create, required identity fields present, verification latency within configured budget.
- P1 / WATCH: verified create but metadata/latency is incomplete or slower.
- REJECTED: missing mint or bonding curve, or explicitly disabled create_v2 handling.

The triage layer does **not** infer profitability, scam status, or future price direction from a token name, symbol, or URI. Economic/risk decisions remain downstream in the existing AI/risk pipeline.

## Throughput controls
- bounded ingress queue
- configurable concurrency (default 8, max 32)
- signature and mint deduplication
- newest-event preservation when the queue is full
- latency metrics: average and p95
- degraded health state on RPC/parser failures

## Safety
V48 remains PAPER/SHADOW. No private keys, signing, transaction broadcast, live execution, or automatic promotion are enabled.

## Integration note
V26/V27 remain the durable discovery/recovery path. V48 is the low-latency front door for live logs. Recovery remains necessary after disconnects so low latency does not trade away completeness.
