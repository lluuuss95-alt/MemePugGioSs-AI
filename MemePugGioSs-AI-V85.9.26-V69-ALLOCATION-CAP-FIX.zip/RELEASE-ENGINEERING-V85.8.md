# MemePugGioSs AI V85.8 — Release Engineering

V85.8 does not add trading functionality. It closes the environmental certification gap by making the previously blocked runtime/build checks executable in a clean networked CI environment.

## Node certification
1. Generate `package-lock.json` in CI from the declared package manifest.
2. Run a clean `npm ci` from that generated lockfile.
3. Run TypeScript build and test typecheck.
4. Run source, safety, Paper E2E, full test suite and runtime Paper validation.
5. Produce and upload final certification artifacts.

## Android certification
1. Install Java 17 and Android SDK 35.
2. Install Gradle 8.9 in CI.
3. Build `android-app` with `assembleDebug`.
4. Upload the generated APK as a CI artifact.

## Local-environment limitation
The current execution environment still cannot reach the npm registry and has no local Gradle installation. Therefore this package does **not** claim runtime or Android certification locally. The CI workflow is the authoritative path for those checks.

## Safety
Paper/Shadow only. No private keys, signing, broadcast, live execution, or auto-promotion are enabled.
