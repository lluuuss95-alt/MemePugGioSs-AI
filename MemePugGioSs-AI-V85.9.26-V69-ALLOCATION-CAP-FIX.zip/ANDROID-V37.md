# Android V37 — Copy Paper Portfolio

The Android operator console consumes the V37 WebSocket `copyPaper` snapshot and the REST endpoints under `/api/v37/copy/*`.

Home widgets planned/connected:
- Copy Trading total allocated capital
- Copy Trading equity and net P&L
- realized/unrealized P&L
- drawdown and win rate
- top copied traders by current paper equity
- recent copied paper trades
- rejected copy signals with reasons

No private keys or transaction signing are stored in the Android client. V37 remains PAPER/SHADOW only.
