# V28 Checklist

- [x] Deterministic real-time signal engine
- [x] Explicit risk gate
- [x] Freshness gate
- [x] Sample-confidence gate
- [x] Liquidity gate
- [x] Explainable reasons/blockers
- [x] Signal states
- [x] Paper-only action output
- [x] Home feed adapter
- [x] Unit tests
- [ ] Validation on real historical/live dataset
- [ ] Trained model evaluation
- [ ] Production performance calibration
