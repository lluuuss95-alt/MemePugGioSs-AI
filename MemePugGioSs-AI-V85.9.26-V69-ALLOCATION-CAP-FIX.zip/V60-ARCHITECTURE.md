# V60 — Autonomous AI Trade Loop Coordinator

V60 is the single per-token orchestration layer for the PAPER/SHADOW trading loop.

## Flow

Pump.fun / Solana -> V48 Discovery -> V49 Instant Score -> V55 Priority -> V50 Deep Intelligence -> V56 State Fusion -> V57 Change Detection -> V58 Re-evaluation Queue -> V59 Decision Re-evaluation -> **V60 Coordinator** -> V52 Paper Execution -> V53 Supervisor -> P&L / Learning.

## Responsibilities

- one lifecycle per mint;
- idempotent handling of duplicate change events;
- context consistency checks across job/change/state/candidate/instant score;
- bridge V59 outcomes to Paper execution;
- continuous position monitoring through V53;
- heartbeat supervision;
- persistent audit trail in `v60_loop_events`;
- explicit lifecycle states: IDLE, ANALYZING, DECIDED, OPEN_PAPER, MONITORING, CLOSED_PAPER, BLOCKED, ERROR.

## Safety

V60 is structurally PAPER/SHADOW only:

- `signingEnabled=false`
- `privateKeyAccess=false`
- `broadcastEnabled=false`
- `liveExecutionAllowed=false`
- `autoPromotion=false`

No live trading path is introduced by V60.

## Design note

V60 does not claim that every Solana token is literally processed in the same millisecond. It is designed around the low-latency event path already provided by V48/V54/V55/V58, with bounded concurrency and deterministic per-token control so bursts cannot bypass risk gates.
