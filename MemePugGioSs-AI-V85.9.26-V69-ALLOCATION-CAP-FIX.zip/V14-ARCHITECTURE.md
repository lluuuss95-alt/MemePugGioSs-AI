# MemePugGioSs AI V14 — Historical Signal Lab

V14 evaluates V9 signals across V13 datasets at scale.

Pipeline:
V13 windows -> point-in-time features -> V9 signal -> simulated entry -> forward labels
-> grouped statistics -> train/validation/test -> out-of-sample report.

Key safeguards:
- token-grouped splits prevent the same token appearing across train and test;
- chronological splits are supported;
- minimum sample thresholds;
- confidence intervals are reported with results;
- no strategy is selected automatically for LIVE;
- multiple-testing awareness is recorded;
- every run has a deterministic manifest.

Metrics:
signal count, confirmation rate, blocked rate, average return, median return,
win rate, MFE, MAE, expectancy, max drawdown proxy, and sample confidence.
