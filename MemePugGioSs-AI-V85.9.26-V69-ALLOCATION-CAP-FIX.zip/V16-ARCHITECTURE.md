# V16 — Robustness & Stress Testing Engine

V16 subjects candidate strategy outcomes to adverse but explicit assumptions.

Stress dimensions:
- higher fees
- higher slippage
- execution delay
- entry/exit delay
- reduced liquidity
- missing observations

Statistical checks:
- deterministic Monte Carlo resampling
- bootstrap confidence interval
- drawdown measurement
- worst trade
- profit factor
- scenario degradation
- fragility score

Interpretation:
ROBUST = limited degradation under configured stress.
SENSITIVE = meaningful degradation.
FRAGILE = substantial degradation.
INSUFFICIENT_DATA = too few observations.

The labels are research diagnostics, not predictions of future performance.
No strategy is automatically promoted or deployed.
