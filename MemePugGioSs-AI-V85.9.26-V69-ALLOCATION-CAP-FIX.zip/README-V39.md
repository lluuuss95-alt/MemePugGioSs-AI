# V39 — Copy Trading Analytics

V39 turns the V35-V38 copy pipeline into a measurable research environment. It does not invent historical equity points: the equity curve begins when V39 snapshots are recorded, while realized copy P&L is read from the persistent V37 ledger.

See `V39-ARCHITECTURE.md`, `V39-CHECKLIST.md`, `V39-RELEASE.md` and `ANDROID-V39.md`.
