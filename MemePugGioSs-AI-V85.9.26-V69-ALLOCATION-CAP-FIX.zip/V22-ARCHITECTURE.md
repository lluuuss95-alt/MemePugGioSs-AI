# V22 — Verified DEX & Pump.fun Intelligence

V22 converts verified transaction observations into market events behind a strict protocol-adapter boundary.

Pipeline:

V21 transaction -> verified adapter -> DEX event -> Pump lifecycle + flow aggregation -> Market Intelligence -> Shadow AI

## Pump lifecycle
CREATED -> BONDING_CURVE -> GRADUATED_TO_PUMPSWAP -> PUMPSWAP_TRADING

The two venues are deliberately separated.

## Event types
- TOKEN_CREATE
- SWAP
- LIQUIDITY_CHANGE
- GRADUATION

## Safety
A token is not marked tradable merely because it appears on-chain. The event must come from a verified adapter with sufficient confidence. Unknown events remain non-tradable.

No live orders, signing, key access or broadcast.
