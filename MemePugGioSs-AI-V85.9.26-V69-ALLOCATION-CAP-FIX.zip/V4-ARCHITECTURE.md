# V4 architecture

```text
Authorized market feed ─┐
                        ├─> bounded ingestion queue ─> validation/dedup ─> SQLite WAL
Solana JSON-RPC ────────┘                                      │
                                                               v
                                                          AI scanner
                                                               │
                                                     risk + freshness gates
                                                               │
                                                        PAPER execution
                                                               │
                                                cash/equity + positions
                                                               │
                                                REST + authenticated WS
                                                               │
                                                          Dashboard
```

The Solana adapter follows the documented JSON-RPC model. Transaction/account inspection is read-only in V4.
