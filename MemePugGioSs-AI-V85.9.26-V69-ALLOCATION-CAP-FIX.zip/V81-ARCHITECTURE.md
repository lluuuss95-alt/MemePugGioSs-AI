# V81 — Autonomous Paper Engine Gate

V81 places a mandatory execution gate in front of every Paper order mutation.

## Flow

V70 System Health → V79 Portfolio Reconciliation → V80 Recovery Supervisor → V81 Paper Engine Gate → V52 Paper Order / V53 Supervisor.

The gate evaluates the latest V80 state before an ENTER/EXIT Paper operation. If the supervisor state is missing or stale, V81 refreshes V80. A Paper mutation is allowed only when V80 returns `READY` and `paperExecutionAllowed=true`.

## Guarantees

- ENTER and EXIT both pass through the same gate.
- A blocked/recovering/degraded supervisor blocks the Paper mutation.
- Stale supervisor state is refreshed before enforcement.
- Every gate decision is persisted in `v81_paper_engine_gate_runs`.
- Gate decisions are non-destructive; they never invent portfolio state.
- Live execution remains impossible through this layer.

## Safety invariant

`mode=PAPER`, `shadowOnly=true`, `signingEnabled=false`, `privateKeyAccess=false`, `broadcastEnabled=false`, `liveExecutionAllowed=false`, `autoPromotion=false`.
