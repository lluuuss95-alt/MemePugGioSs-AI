# MemePugGioSs AI — V26 Architecture

## Live Token Discovery + Pump.fun Auto-Tracking

V26 closes the gap between “know a Pump token address” and “discover new Pump tokens automatically”.

Pipeline:

`Solana logsSubscribe -> Pump Program mention -> signature -> getTransaction -> verified create/create_v2 parser -> token registry -> V25 live account engine`

### Verified discovery

The discovery layer watches the official Pump program `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`. It only promotes a transaction to a token when a compiled instruction belongs to that program and its instruction discriminator matches the documented `create` or `create_v2` instruction. The mint and bonding-curve accounts are taken from the instruction account positions rather than inferred from names or logs.

The current Pump IDL documents `create` with discriminator `[24,30,200,40,5,28,7,119]` and `create_v2` with discriminator `[214,144,76,236,95,139,49,180]`. It also documents the current account ordering and argument layout. The current `create_v2` account layout puts `mint` first and `bonding_curve` third, and its arguments include name, symbol, URI and creator. citeturn2search1turn1view0

### Auto-tracking

Every newly verified token is immediately registered and handed to V25. V25 then hydrates the BondingCurve account and subscribes to subsequent account changes. No trade is executed.

### Deduplication

V26 deduplicates both signatures and mint addresses. Replayed websocket notifications do not create duplicate token records.

### Home screen

V26 adds a data contract only. The official Home design is unchanged. The existing “Nuovi Token da Pump.fun (Live)” panel can consume the V26 discovery feed without a redesign.

### Safety

- PAPER/SHADOW only
- no private keys
- no signing
- no transaction broadcast
- no live execution
- no automatic promotion

### Known limitations

1. Metadata arguments are decoded when the transaction payload is parseable; otherwise the token remains validly discovered with missing metadata.
2. V26 uses `getTransaction` after a log notification, so RPC rate limits can reduce discovery throughput.
3. This is a verified Pump-program discovery boundary, not a guarantee that every token visible on third-party sites is observed by one websocket provider.
4. Non-Pump venues are intentionally not mixed into this discovery path.
