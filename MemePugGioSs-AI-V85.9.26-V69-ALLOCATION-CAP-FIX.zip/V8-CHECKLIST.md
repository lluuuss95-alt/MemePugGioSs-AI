# V8 Checklist

- [x] Wallet profile model
- [x] Token-wallet relationship model
- [x] Deployers / early buyers tracking hooks
- [x] Behavioral feature extraction
- [x] Wallet clustering by observable transaction relationships
- [x] Dev reputation scoring
- [x] Wallet risk scoring
- [x] Smart-money score with sample-size confidence
- [x] Cluster risk scoring
- [x] Explainable score reasons
- [x] Uncertainty/confidence handling
- [x] V8 opportunity/risk gate
- [x] PAPER-only safety boundary
- [x] Unit tests
