# V78 — Paper Position Lifecycle & Real-Time Exit Commit

V78 closes the Paper execution lifecycle after V77 entry commit.

Flow: V77 committed Paper entry -> V53 supervisor market monitoring -> V52 position management -> V78 idempotent exit commit -> persisted exit ledger.

## Exit conditions

V52 remains the source of truth for exit conditions: stop loss, take profit, trailing stop, timeout, signal invalidation, risk gate and liquidity loss. V78 does not replace or loosen those controls.

## Idempotency

Exit commits use an explicit idempotency key, defaulting to `EXIT:<mint>:<tick.timestamp>`. A replay of the same key returns `ALREADY_COMMITTED` and never re-enters or re-closes the position. A short recent-exit reconciliation window prevents a duplicate close after a retry when the Paper position has already disappeared.

## Persistence

Table: `v78_exit_commits`.

It stores position id, mint, commit key, exit reason, realized P&L, supervisor state and safety metadata.

## Safety

PAPER/SHADOW only. No private keys, signing, broadcast, live execution or auto-promotion.

## Reconciliation

`reconcile()` exposes current Paper open positions and recent persisted exit commits so the backend can reconcile lifecycle state after restart/reconnect.
