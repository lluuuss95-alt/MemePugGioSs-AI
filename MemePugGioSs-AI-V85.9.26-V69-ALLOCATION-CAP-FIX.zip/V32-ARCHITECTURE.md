# V32 — Persistent Trading Ledger & Android Live Portfolio

V32 adds a durable SQLite ledger for the V30 Paper portfolio. Portfolio cash/equity, positions, decisions and snapshots survive backend restarts. The API and authenticated WebSocket expose a compact portfolio summary to Android.

Safety remains PAPER-only: no signing, private keys, broadcast or live execution.
