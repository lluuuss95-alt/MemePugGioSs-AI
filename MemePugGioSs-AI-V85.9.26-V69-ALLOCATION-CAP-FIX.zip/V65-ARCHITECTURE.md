# V65 — Paper Execution Transaction Simulator & Slippage Engine

V65 adds a deterministic, paper-only execution simulator between the pre-trade guard and future execution validation.

## Flow

V63 capital allocation → V64 pre-trade guard → **V65 execution simulation** → V52 paper execution.

V65 models a constant-product pool from verified base/quote reserves. It calculates:
- reference price;
- fee-adjusted input;
- output amount;
- effective execution price;
- price impact in basis points;
- external slippage allowance;
- total modeled slippage;
- post-trade reserves.

## Blocking rules

V65 blocks when:
- mint does not match;
- pool reserves are invalid/too small;
- pool fee is outside configured bounds;
- pool state is stale;
- the pool is not verified when verification is required;
- input or slippage parameters are invalid;
- external slippage exceeds the configured bound;
- input consumes the reserve;
- modeled price impact is too high;
- total slippage exceeds the requested maximum.

Warnings are emitted when impact or external slippage approaches configured limits.

## Safety

V65 is strictly PAPER/SHADOW. It does not hold private keys, sign transactions, broadcast transactions, enable live execution, or promote itself to live mode.

The simulator is intentionally isolated from live transaction submission. It is a modeling component for realistic Paper Trading and later validation.
