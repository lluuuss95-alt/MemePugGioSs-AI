import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = new URL('../src/', import.meta.url).pathname;
const files=[];
function walk(dir){ for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const p=path.join(dir,e.name); if(e.isDirectory()) walk(p); else if(e.name.endsWith('.ts')) files.push(p); } }
walk(root);
let unsafe=[];
const patterns=[/liveExecutionAllowed\s*:\s*true/g,/liveExecutionEnabled\s*:\s*true/g,/signingEnabled\s*:\s*true/g,/broadcastEnabled\s*:\s*true/g,/privateKeyAccess\s*:\s*true/g,/autoPromotion\s*:\s*true/g];
for(const f of files){ const s=fs.readFileSync(f,'utf8'); for(const re of patterns){ if(re.test(s)) unsafe.push(f+':'+re); re.lastIndex=0; } }
const sha=crypto.createHash('sha256');
for(const f of files.sort()){ sha.update(path.relative(root,f)+'\0'); sha.update(fs.readFileSync(f)); }
console.log(JSON.stringify({files:files.length,unsafeFlags:unsafe,sourceFingerprint:sha.digest('hex')},null,2));
if(unsafe.length) process.exit(2);
