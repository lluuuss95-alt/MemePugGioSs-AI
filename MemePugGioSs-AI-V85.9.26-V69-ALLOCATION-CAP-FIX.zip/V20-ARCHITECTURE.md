# V20 — Market Event Normalization Layer

V20 sits between Solana realtime feeds and the AI/scanner layer.

Pipeline:

Solana PubSub -> Raw Feed Events -> Deduplication -> Slot Ordering -> Verified Decoders -> Normalized Market Events -> Shadow Ledger -> Scanner

## Event sources
- logs
- account
- program

## Guarantees
- deterministic event identity
- duplicate suppression
- bounded dedup memory
- slot ordering guard
- unknown events remain UNKNOWN
- decoder confidence is explicit
- every normalized event can be persisted in the Shadow ledger

No price, DEX, Pump.fun or trading semantics are guessed from raw logs.
Only a verified decoder can mark an event as decodable.
