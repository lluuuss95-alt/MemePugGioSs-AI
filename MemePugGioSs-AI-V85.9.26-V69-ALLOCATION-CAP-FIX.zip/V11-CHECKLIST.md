# V11 Checklist

- [x] Canonical historical event schema
- [x] CSV ingestion
- [x] JSON ingestion
- [x] Timestamp validation
- [x] Slot validation
- [x] Deterministic deduplication
- [x] Chronological ordering
- [x] Quarantine records
- [x] Dataset fingerprint
- [x] Dataset manifest/version
- [x] Deterministic replay cursor
- [x] Replay anti-future-leakage guard
- [x] Provider adapter boundary
- [x] Dataset summary statistics
- [x] Unit tests
- [x] PAPER/research-only safety
