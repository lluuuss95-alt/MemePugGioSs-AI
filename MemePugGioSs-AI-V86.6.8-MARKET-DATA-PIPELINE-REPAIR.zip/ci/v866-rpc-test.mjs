import assert from 'node:assert/strict';
import { JsonRpcHttpClient } from '../dist/v25-rpc.js';

const successFetch = async (_url, init) => {
  const body = JSON.parse(init.body);
  assert.equal(body.method, 'getAccountInfo');
  return new Response(JSON.stringify({ jsonrpc: '2.0', id: body.id, result: { context: { slot: 123 }, value: { data: ['AQID', 'base64'] } } }), { status: 200, headers: { 'content-type': 'application/json' } });
};
const client = new JsonRpcHttpClient('https://rpc.invalid', successFetch);
const result = await client.getAccountInfo('SomeMint111111111111111111111111111111111');
assert.equal(result.context.slot, 123);


const fallbackClient = new JsonRpcHttpClient('https://primary.invalid', async (url, init) => {
  if (url === 'https://primary.invalid') throw Object.assign(new Error('primary unavailable'), { name: 'TypeError', cause: { code: 'ECONNRESET' } });
  const body = JSON.parse(init.body);
  return new Response(JSON.stringify({ jsonrpc: '2.0', id: body.id, result: { context: { slot: 456 }, value: null } }), { status: 200, headers: { 'content-type': 'application/json' } });
});
const fallbackResult = await fallbackClient.getAccountInfo('SomeMint111111111111111111111111111111111');
assert.equal(fallbackResult.context.slot, 456, 'HTTP RPC should recover through a fallback endpoint');

const throttled = new JsonRpcHttpClient('https://rpc.invalid', async () => new Response('rate limited', { status: 429 }));
await assert.rejects(() => throttled.getAccountInfo('SomeMint111111111111111111111111111111111'), /RPC_HTTP_429/);

const offline = new JsonRpcHttpClient('https://rpc.invalid', async () => { throw Object.assign(new Error('socket reset'), { name: 'TypeError', cause: { code: 'ECONNRESET' } }); });
await assert.rejects(() => offline.getAccountInfo('SomeMint111111111111111111111111111111111'), /RPC_TRANSPORT_TypeError:socket reset cause=ECONNRESET/);
console.log('V86.6 RPC diagnostics tests PASS');
