import assert from 'node:assert/strict';
import { buildBondingCurveLiveState, buildPumpSwapLiveState } from '../dist/v25-reconcile.js';
const now = Date.now();
const curve = buildBondingCurveLiveState({
  mint: 'Mint111111111111111111111111111111111111',
  virtualTokenReserves: 1_000_000_000_000_000n,
  virtualQuoteReserves: 30_000_000_000n,
  realTokenReserves: 800_000_000_000_000n,
  realQuoteReserves: 50_000_000_000n,
  tokenTotalSupply: 1_000_000_000_000_000n,
  complete: false, slot: 100, observedAt: now,
  quoteMint: undefined,
});
assert.equal(curve.realQuoteReserve, 50_000_000_000n);
assert.equal(curve.venue, 'BONDING_CURVE');
const pool = buildPumpSwapLiveState({
  pool: {
    poolBump: 1, index: 0, creator: 'creator', baseMint: 'base', quoteMint: 'So11111111111111111111111111111111111111112',
    lpMint: 'lp', poolBaseTokenAccount: 'base-vault', poolQuoteTokenAccount: 'quote-vault', lpSupply: 1n,
    coinCreator: 'creator', isMayhemMode: false, isCashbackCoin: false, creatorFeeBps: 0n, isHolderReward: false,
    virtualQuoteReserves: 30_000_000_000n, slot: 1, observedAt: now - 60_000,
  },
  baseVault: { address: 'base-vault', mint: 'base', amount: 1_000_000_000_000_000n, decimals: 6, slot: 101, observedAt: now, source: 'RPC' },
  quoteVault: { address: 'quote-vault', mint: 'So11111111111111111111111111111111111111112', amount: 50_000_000_000n, decimals: 9, slot: 102, observedAt: now, source: 'RPC' },
  totalSupply: 1_000_000_000_000_000n, supplyDecimals: 6, now,
});
assert.equal(pool.realQuoteReserve, 50_000_000_000n);
assert.equal(pool.quoteMint, 'So11111111111111111111111111111111111111112');
assert.equal(pool.stale, false, 'static pool metadata must not make live vault prices stale');
assert.equal(pool.coherent, true, 'coherence follows the two live vault slots');
console.log('V86.5 market state tests PASS');
