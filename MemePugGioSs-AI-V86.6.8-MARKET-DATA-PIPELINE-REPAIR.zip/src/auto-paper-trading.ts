import crypto from 'node:crypto';
import { db } from './db.js';
import { config } from './config.js';
import { opportunities } from './scanner.js';
import { paperOrder, account, positions } from './paper.js';

const INTERVAL_MS = 10_000;
const MIN_LIQUIDITY_USD = 10_000;
const MAX_RISK_SCORE = 35;
const MIN_SCORE = 70;
const MAX_OPEN_POSITIONS = 3;
const POSITION_PCT = 2;
const RESERVE_PCT = 30;
const STOP_LOSS_PCT = 8;
const TAKE_PROFIT_PCT = 15;
const MAX_HOLD_MS = 60 * 60_000;

let timer: any;
let busy = false;
let rerunRequested = false;
let lastScanAt: string | null = null;
let lastTickAt: string | null = null;
let lastTickError = '';
let tickCount = 0;
let lastScanStatus = 'IN ATTESA';
let lastCandidateCount = 0;
let lastEligibleCount = 0;
let lastBlockReasons: Record<string, number> = {};

db.exec(`
CREATE TABLE IF NOT EXISTS auto_paper_settings(id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL);
INSERT OR IGNORE INTO auto_paper_settings(id,enabled,updated_at) VALUES(1,0,datetime('now'));
CREATE TABLE IF NOT EXISTS auto_paper_positions(mint TEXT PRIMARY KEY, entry_price REAL NOT NULL, high_price REAL NOT NULL, opened_at TEXT NOT NULL, symbol TEXT, entry_order_id TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS auto_paper_events(id TEXT PRIMARY KEY, ts TEXT NOT NULL, mint TEXT, symbol TEXT, action TEXT NOT NULL, price REAL, quantity REAL, pnl REAL NOT NULL DEFAULT 0, reason TEXT NOT NULL, details_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS auto_paper_snapshots(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, cash REAL NOT NULL, equity REAL NOT NULL, realized_pnl REAL NOT NULL, unrealized_pnl REAL NOT NULL, open_positions INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_auto_paper_snapshots_ts ON auto_paper_snapshots(ts);
CREATE INDEX IF NOT EXISTS idx_auto_paper_events_ts ON auto_paper_events(ts);
`);

function enabled(){ return Number((db.prepare('SELECT enabled FROM auto_paper_settings WHERE id=1').get() as any)?.enabled||0)===1; }
function recordEvent(mint:string|undefined,symbol:string|undefined,action:string,price:number|undefined,quantity:number|undefined,pnl:number,reason:string,details:unknown={}){
  db.prepare('INSERT INTO auto_paper_events(id,ts,mint,symbol,action,price,quantity,pnl,reason,details_json) VALUES(?,?,?,?,?,?,?,?,?,?)').run(crypto.randomUUID(),new Date().toISOString(),mint??null,symbol??null,action,price??null,quantity??null,pnl,reason,JSON.stringify({...((details&&typeof details==='object')?details:{}),mode:'PAPER',liveExecutionEnabled:false}));
}
function snapshot(){
  const a=account(); const ps=positions();
  const realized=Number((db.prepare('SELECT COALESCE(SUM(realized_pnl),0) pnl FROM positions').get() as any)?.pnl||0);
  const unreal=ps.reduce((s:any,p:any)=>s+Number(p.unrealizedPnl||0),0);
  db.prepare('INSERT INTO auto_paper_snapshots(ts,cash,equity,realized_pnl,unrealized_pnl,open_positions) VALUES(?,?,?,?,?,?)').run(new Date().toISOString(),Number(a?.cash||0),Number(a?.equity||0),realized,unreal,ps.filter((p:any)=>Number(p.quantity)>0).length);
}
function marketFor(mint:string){return db.prepare(`SELECT o.price,o.liquidity,o.observed_at,t.symbol,t.name FROM observations o JOIN tokens t ON t.mint=o.mint WHERE o.mint=? AND o.quality='OK' AND o.price>0 AND o.liquidity>0 ORDER BY o.observed_at DESC,o.id DESC LIMIT 1`).get(mint) as any;}
function safeCandidate(o:any): {ok:true;market:any;tokenRisk:any}|{ok:false;reason:string} {
  const r=db.prepare('SELECT risk_score,largest_holder_pct,mint_authority_present,freeze_authority_present FROM token_intelligence WHERE mint=?').get(o.mint) as any;
  const m=marketFor(o.mint); if(!m||!r)return {ok:false,reason:'DATI_MERCATO_O_RISCHIO_MANCANTI'};
  const observed=Date.parse(String(m.observed_at||'')); const age=Date.now()-observed;
  if(!Number.isFinite(Number(m.price))||Number(m.price)<=0)return {ok:false,reason:'PREZZO_NON_VERIFICATO'};
  if(!Number.isFinite(Number(m.liquidity))||Number(m.liquidity)<MIN_LIQUIDITY_USD)return {ok:false,reason:'LIQUIDITA_INSUFFICIENTE'};
  if(!Number.isFinite(age)||age<0||age>Math.min(config.staleMs,90_000))return {ok:false,reason:'DATO_OBSOLETO'};
  if(!Number.isFinite(Number(r.risk_score))||Number(r.risk_score)>MAX_RISK_SCORE)return {ok:false,reason:'RISCHIO_ELEVATO_O_IGNOTO'};
  if(r.mint_authority_present!==0&&r.mint_authority_present!==false)return {ok:false,reason:'AUTORITA_MINT_NON_VERIFICATA_O_PRESENTE'};
  if(r.freeze_authority_present!==0&&r.freeze_authority_present!==false)return {ok:false,reason:'FREEZE_AUTHORITY_NON_VERIFICATA_O_PRESENTE'};
  if(r.largest_holder_pct==null||!Number.isFinite(Number(r.largest_holder_pct))||Number(r.largest_holder_pct)>25)return {ok:false,reason:'CONCENTRAZIONE_HOLDER_NON_ACCETTABILE'};
  if(!o.tradable||Number(o.score)<MIN_SCORE)return {ok:false,reason:'SCORE_INSUFFICIENTE'};
  return {ok:true,market:m,tokenRisk:r};
}
function tick(){
  if(config.mode!=='PAPER')return;
  // If enablement changes while a tick is in flight, guarantee a fresh tick
  // after it completes so status cannot remain falsely DISATTIVATED.
  if(busy){rerunRequested=true;return;}
  busy=true;
  tickCount++; lastTickAt=new Date().toISOString(); lastTickError='';
  try{
    const now=Date.now();
    const tracked=db.prepare('SELECT * FROM auto_paper_positions').all() as any[];
    const currentPositions=positions() as any[];
    for(const trackedPosition of tracked){
      const p=currentPositions.find((x:any)=>x.mint===trackedPosition.mint&&Number(x.quantity)>0);
      if(!p){db.prepare('DELETE FROM auto_paper_positions WHERE mint=?').run(trackedPosition.mint);continue;}
      const m=marketFor(trackedPosition.mint); if(!m)continue;
      const observed=Date.parse(String(m.observed_at||'')); if(!Number.isFinite(observed)||now-observed>Math.min(config.staleMs,90_000)||Number(m.price)<=0)continue;
      const price=Number(m.price),entry=Number(trackedPosition.entry_price),high=Math.max(Number(trackedPosition.high_price),price);
      db.prepare('UPDATE auto_paper_positions SET high_price=? WHERE mint=?').run(high,trackedPosition.mint);
      const age=now-Date.parse(String(trackedPosition.opened_at));
      let reason=''; if(price<=entry*(1-STOP_LOSS_PCT/100))reason='STOP_LOSS_8_PERCENT'; else if(price>=entry*(1+TAKE_PROFIT_PCT/100))reason='TAKE_PROFIT_15_PERCENT'; else if(price<=high*0.93&&high>entry)reason='TRAILING_STOP_7_PERCENT'; else if(age>=MAX_HOLD_MS)reason='MAX_HOLD_60_MINUTES';
      if(reason){const orderId=`auto-paper-${crypto.randomUUID()}`;try{const fill=paperOrder({orderId,mint:trackedPosition.mint,side:'SELL',quantity:Number(p.quantity)});const pnl=(Number(fill.price)-entry)*Number(fill.quantity)-Number(fill.fee||0);recordEvent(trackedPosition.mint,p.symbol,'AUTO_EXIT',Number(fill.price),Number(fill.quantity),pnl,reason,{orderId:fill.orderId});db.prepare('DELETE FROM auto_paper_positions WHERE mint=?').run(trackedPosition.mint);}catch(e){recordEvent(trackedPosition.mint,p.symbol,'EXIT_BLOCKED',price,Number(p.quantity),0,String(e));}}
    }
    const open=positions().filter((p:any)=>Number(p.quantity)>0) as any[];
    if(enabled()){
      const a=account(); const maxNotional=Math.max(0,Math.min(Number(a.equity||0)*POSITION_PCT/100,Number(a.cash||0)-Number(a.equity||0)*RESERVE_PCT/100));
      const candidates=opportunities();
      lastScanAt=new Date().toISOString();
      lastCandidateCount=candidates.length;
      lastEligibleCount=0;
      lastBlockReasons={};
      if(open.length>=MAX_OPEN_POSITIONS) lastScanStatus='LIMITE_POSIZIONI_RAGGIUNTA';
      else if(maxNotional<5) { lastScanStatus='CAPITALE_DISPONIBILE_INSUFFICIENTE'; lastBlockReasons[lastScanStatus]=1; }
      else {
        lastScanStatus='SCANSIONE_COMPLETATA';
        const already=new Set(open.map((p:any)=>p.mint));
        for(const o of candidates){
          if(open.length>=MAX_OPEN_POSITIONS||already.has(o.mint))continue;
          const checked=safeCandidate(o);
          if(!checked.ok){lastBlockReasons[checked.reason]=(lastBlockReasons[checked.reason]||0)+1;continue;}
          lastEligibleCount++;
          const price=Number(checked.market.price),quantity=Math.floor((maxNotional/price)*1e8)/1e8;
          if(!Number.isFinite(quantity)||quantity<=0)continue;
          const orderId=`auto-paper-${crypto.randomUUID()}`;
          try{
            const fill=paperOrder({orderId,mint:o.mint,side:'BUY',quantity});
            db.prepare('INSERT OR REPLACE INTO auto_paper_positions(mint,entry_price,high_price,opened_at,symbol,entry_order_id) VALUES(?,?,?,?,?,?)').run(o.mint,Number(fill.price),Number(fill.price),fill.filledAt,o.symbol||o.name||o.mint.slice(0,8),fill.orderId);
            recordEvent(o.mint,o.symbol||o.name,'AUTO_ENTRY',Number(fill.price),Number(fill.quantity),0,'ALL_PAPER_RISK_GATES_PASSED',{score:o.score,riskScore:o.riskScore,liquidity:checked.market.liquidity,orderId:fill.orderId});
            already.add(o.mint); open.push({mint:o.mint});
          }catch(e){recordEvent(o.mint,o.symbol,'ENTRY_BLOCKED',price,quantity,0,String(e));}
        }
      }
    } else { lastScanStatus='AUTOMAZIONE_DISATTIVATA'; }
    snapshot();
  }catch(e){lastTickError=String(e);lastScanStatus='ERRORE_MOTORE';recordEvent(undefined,undefined,'ENGINE_ERROR',undefined,undefined,0,String(e));}
  finally{
    busy=false;
    if(rerunRequested){
      rerunRequested=false;
      queueMicrotask(tick);
    }
  }
}
export function autoPaperStatus(){
  const setting=db.prepare('SELECT enabled,updated_at updatedAt FROM auto_paper_settings WHERE id=1').get() as any;
  const a=account(); const ps=positions() as any[];
  const events=db.prepare('SELECT * FROM auto_paper_events ORDER BY ts DESC LIMIT 100').all().map((r:any)=>({...r,details:JSON.parse(r.details_json||'{}')}));
  const curve=db.prepare('SELECT ts,cash,equity,realized_pnl realizedPnl,unrealized_pnl unrealizedPnl,open_positions openPositions FROM auto_paper_snapshots ORDER BY id DESC LIMIT 300').all().reverse();
  const totalPnl=Number(a?.equity||0)-config.startingCash;
  return {version:'V86',enabled:Number(setting?.enabled||0)===1,updatedAt:setting?.updatedAt,mode:'PAPER',liveExecutionEnabled:false,startingCapital:config.startingCash,cash:Number(a?.cash||0),equity:Number(a?.equity||0),totalPnl,realizedPnl:Number((db.prepare('SELECT COALESCE(SUM(realized_pnl),0) pnl FROM positions').get() as any)?.pnl||0),unrealizedPnl:ps.reduce((s:number,p:any)=>s+Number(p.unrealizedPnl||0),0),openPositions:ps.filter((p:any)=>Number(p.quantity)>0).length,autoManagedPositions:(db.prepare('SELECT COUNT(*) n FROM auto_paper_positions').get() as any).n,events,curve,diagnostics:{lastTickAt,tickCount,lastTickError,lastScanAt,scanStatus:lastScanStatus,candidateCount:lastCandidateCount,eligibleCount:lastEligibleCount,blockedBy:lastBlockReasons},limits:{intervalMs:INTERVAL_MS,minLiquidityUsd:MIN_LIQUIDITY_USD,maxRiskScore:MAX_RISK_SCORE,minScore:MIN_SCORE,maxOpenPositions:MAX_OPEN_POSITIONS,positionPct:POSITION_PCT,reservePct:RESERVE_PCT,stopLossPct:STOP_LOSS_PCT,takeProfitPct:TAKE_PROFIT_PCT,maxHoldMs:MAX_HOLD_MS}};
}
export function setAutoPaperEnabled(value:boolean){
  if(config.mode!=='PAPER')throw new Error('AUTO_PAPER_REQUIRES_PAPER_MODE');
  db.prepare('UPDATE auto_paper_settings SET enabled=?,updated_at=? WHERE id=1').run(value?1:0,new Date().toISOString());
  if(value)tick();
  return autoPaperStatus();
}
export function startAutoPaperTrading(){if(timer)clearInterval(timer);timer=setInterval(tick,INTERVAL_MS);timer.unref?.();if(enabled())tick();}
