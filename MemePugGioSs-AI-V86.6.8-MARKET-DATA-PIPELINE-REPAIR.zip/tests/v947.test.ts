import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'memepug-v947-'));
process.env.DATABASE_PATH = path.join(tempDir, 'test.sqlite');
process.env.APP_MODE = 'PAPER';

try {
  const { runMarketEnrichment, marketEnrichmentStatus } = await import('../src/market-enrichment.js');
  const result = await runMarketEnrichment();
  assert.equal(result.status, 'WAITING_FOR_TOKENS', 'empty inventory must not be reported as healthy');
  assert.equal(result.inventoryTokens, 0);
  assert.equal(result.eligibleTokens, 0);
  assert.equal(result.intervalMs, 60_000, 'enrichment should use a rate-limited 60-second interval');
  assert.match(result.lastError, /WAITING_FOR_ELIGIBLE_TOKENS/);
  const status = marketEnrichmentStatus();
  assert.equal(status.provider, 'DexScreener');
  assert.equal(status.configured, true);
  console.log('V947 TOKEN PIPELINE REGRESSION PASS');
} finally {
  try {
    const { db } = await import('../src/db.js');
    db.close();
  } catch {}
  fs.rmSync(tempDir, { recursive: true, force: true });
}
