import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
const ui = readFileSync("android-app/app/src/main/java/com/memepuggi/ossai/ui/MemePugApp.kt", "utf8");
assert.match(ui, /statusBarsPadding\(\)/, "dashboard content must avoid the Android status bar");
assert.match(ui, /navigationBarsPadding\(\)/, "bottom navigation must avoid the Android system navigation area");
assert.match(ui, /val compact = maxWidth < 600\.dp[\s\S]*?SOLANA MAINNET/, "header must use a compact mobile layout with badges on a separate row");
assert.match(ui, /Text\("MemePugGioSs AI", color=Text, fontSize=21\.sp/, "mobile title must fit on narrow screens");
console.log("V86.6.38 dashboard layout regression checks PASS");
