import { runBacktest } from './backtester.js';
import type { MarketBar, Strategy, StrategyAction, BacktestConfig, BacktestResult } from './backtest-types.js';

const CONFIG: BacktestConfig = {
  initialCash: 1000,
  feeBps: 100,
  slippageBps: 150,
  maxPositionFraction: 0.10,
};
const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));

class MomentumStrategy implements Strategy {
  id = 'momentum-5';
  decide(ctx: { index:number; bars:MarketBar[]; cash:number; position:number; equity:number }): StrategyAction {
    if (ctx.bars.length < 6) return { side:'HOLD', fraction:0, reason:'WARMUP' };
    const now = ctx.bars.at(-1)!.price, prior = ctx.bars.at(-6)!.price;
    const ret = (now / prior - 1) * 100;
    if (ctx.position > 0 && ret < -0.4) return { side:'SELL', fraction:1, reason:'MOMENTUM_BREAK' };
    if (ctx.position <= 0 && ret > 0.8) return { side:'BUY', fraction:1, reason:'POSITIVE_MOMENTUM' };
    return { side:'HOLD', fraction:0, reason:'NO_MOMENTUM_EDGE' };
  }
}
class MeanReversionStrategy implements Strategy {
  id = 'mean-reversion-10';
  decide(ctx: { index:number; bars:MarketBar[]; cash:number; position:number; equity:number }): StrategyAction {
    if (ctx.bars.length < 10) return { side:'HOLD', fraction:0, reason:'WARMUP' };
    const prices = ctx.bars.slice(-10).map(b=>b.price);
    const mean = prices.reduce((a,b)=>a+b,0)/prices.length;
    const deviation = (prices.at(-1)! / mean - 1) * 100;
    if (ctx.position > 0 && deviation > 0.8) return { side:'SELL', fraction:1, reason:'REVERSION_TARGET' };
    if (ctx.position <= 0 && deviation < -1.5) return { side:'BUY', fraction:1, reason:'OVERSOLD_VS_MEAN' };
    return { side:'HOLD', fraction:0, reason:'NO_REVERSION_EDGE' };
  }
}
class BreakoutStrategy implements Strategy {
  id = 'breakout-12';
  decide(ctx: { index:number; bars:MarketBar[]; cash:number; position:number; equity:number }): StrategyAction {
    if (ctx.bars.length < 13) return { side:'HOLD', fraction:0, reason:'WARMUP' };
    const previous = ctx.bars.slice(-13,-1).map(b=>b.price);
    const high = Math.max(...previous);
    const now = ctx.bars.at(-1)!.price;
    const mean = previous.reduce((a,b)=>a+b,0)/previous.length;
    if (ctx.position > 0 && now < mean * 0.99) return { side:'SELL', fraction:1, reason:'BREAKOUT_FAILURE' };
    if (ctx.position <= 0 && now > high * 1.003) return { side:'BUY', fraction:1, reason:'RANGE_BREAKOUT' };
    return { side:'HOLD', fraction:0, reason:'NO_BREAKOUT' };
  }
}

export interface V86LearningCandidate {
  strategyId:string;
  train:{returnPct:number; maxDrawdownPct:number; trades:number; winRatePct:number};
  outOfSample:{returnPct:number; maxDrawdownPct:number; trades:number; winRatePct:number; profitFactor:number; expectancy:number};
  score:number;
  eligibleForPaperTrial:boolean;
  reasons:string[];
}
export interface V86LearningLabResult {
  status:'EVALUATED'|'INSUFFICIENT_DATA';
  bars:number;
  trainBars:number;
  testBars:number;
  candidates:V86LearningCandidate[];
  recommendation:string|null;
  policy:{mode:'PAPER_ONLY'; minBars:number; minTestTrades:number; maxAllowedDrawdownPct:number; autoPromotion:false; liveExecutionEnabled:false};
  disclaimer:string;
}

function compact(r:BacktestResult) {
  return {returnPct:r.totalReturnPct,maxDrawdownPct:r.maxDrawdownPct,trades:r.trades.filter(t=>t.side==='SELL').length,winRatePct:r.winRatePct,profitFactor:r.profitFactor,expectancy:r.expectancy};
}

/**
 * Small, deterministic strategy tournament. A chronological holdout is used;
 * the winner is only a candidate for a later PAPER trial, never live execution.
 * Historical results do not predict future profitability.
 */
export function evaluateV86LearningLab(input: unknown): V86LearningLabResult {
  const bars = Array.isArray(input) ? input : [];
  const policy = { mode:'PAPER_ONLY' as const, minBars:200, minTestTrades:5, maxAllowedDrawdownPct:20, autoPromotion:false as const, liveExecutionEnabled:false as const };
  if (bars.length < policy.minBars || bars.length > 5000) {
    return { status:'INSUFFICIENT_DATA', bars:bars.length, trainBars:0, testBars:0, candidates:[], recommendation:null, policy,
      disclaimer:'Servono almeno 200 barre cronologiche e al massimo 5000. Risultati storici non garantiscono profitti futuri.' };
  }
  const clean: MarketBar[] = [];
  let lastTs = -Infinity;
  for (const raw of bars) {
    if (!raw || typeof raw !== 'object') throw new Error('INVALID_BAR');
    const ts = Number((raw as any).ts), price = Number((raw as any).price);
    if (!Number.isFinite(ts) || !Number.isFinite(price) || price <= 0 || ts <= lastTs) throw new Error('BARS_MUST_HAVE_POSITIVE_PRICES_AND_STRICTLY_INCREASING_TIMESTAMPS');
    clean.push({ts,price});
    lastTs = ts;
  }
  const split = Math.floor(clean.length * 0.70);
  const train = clean.slice(0,split), test = clean.slice(split);
  const strategies: Strategy[] = [new MomentumStrategy(),new MeanReversionStrategy(),new BreakoutStrategy()];
  const candidates = strategies.map(strategy => {
    const tr = compact(runBacktest(strategy,train,CONFIG));
    const te = compact(runBacktest(strategy,test,CONFIG));
    const reasons:string[] = [];
    if (te.trades < policy.minTestTrades) reasons.push('INSUFFICIENT_OUT_OF_SAMPLE_TRADES');
    if (te.returnPct <= 0) reasons.push('NON_POSITIVE_OUT_OF_SAMPLE_RETURN');
    if (te.maxDrawdownPct > policy.maxAllowedDrawdownPct) reasons.push('DRAWDOWN_LIMIT_EXCEEDED');
    if (!Number.isFinite(te.returnPct) || !Number.isFinite(te.maxDrawdownPct)) reasons.push('NON_FINITE_METRICS');
    const score = clamp(te.returnPct - te.maxDrawdownPct * 0.75 + (Number.isFinite(te.profitFactor) ? Math.min(2,te.profitFactor)*0.25 : 0),-1000,1000);
    return {strategyId:strategy.id,train:{returnPct:tr.returnPct,maxDrawdownPct:tr.maxDrawdownPct,trades:tr.trades,winRatePct:tr.winRatePct},
      outOfSample:{returnPct:te.returnPct,maxDrawdownPct:te.maxDrawdownPct,trades:te.trades,winRatePct:te.winRatePct,profitFactor:te.profitFactor,expectancy:te.expectancy},
      score,eligibleForPaperTrial:reasons.length===0,reasons};
  }).sort((a,b)=>b.score-a.score);
  const best = candidates.find(c=>c.eligibleForPaperTrial);
  return {status:'EVALUATED',bars:clean.length,trainBars:train.length,testBars:test.length,candidates,
    recommendation:best?.strategyId??null,policy,
    disclaimer:'Confronto iniziale su dati storici con commissioni e slippage ipotizzati. Una candidate idonea richiede ulteriore PAPER forward-test; nessuna strategia è promossa automaticamente e il trading reale resta disabilitato.'};
}
