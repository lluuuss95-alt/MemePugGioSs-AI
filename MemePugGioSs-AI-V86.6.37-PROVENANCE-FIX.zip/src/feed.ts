import {config} from "./config.js"; import {enqueue} from "./ingestion.js"; import WebSocket from "ws";
export async function pollFeed(){if(!config.feed)return {received:0,configured:false}; const r=await fetch(config.feed,{headers:{accept:"application/json"}}); if(!r.ok)throw new Error(`FEED_HTTP_${r.status}`); const j:any=await r.json(); const items=Array.isArray(j)?j:(j.events??j.data??j.tokens??[]); let received=0; for(const x of items){if(!x?.mint)continue; enqueue({eventId:String(x.eventId??x.id??`${x.mint}:${x.timestamp??x.observedAt??Date.now()}`),mint:String(x.mint),symbol:x.symbol,name:x.name,source:String(x.source??"market-feed"),eventTime:new Date(x.timestamp??x.observedAt??Date.now()).toISOString(),slot:x.slot,price:Number(x.price??0)||undefined,liquidity:Number(x.liquidity??0)||undefined,volume5m:Number(x.volume5m??0)||undefined,holders:Number(x.holders??0)||undefined,ageSeconds:Number(x.ageSeconds??0)||undefined,buyPressure:Number(x.buyPressure??0)||undefined,raw:x}); received++;} return {received,configured:true};}


/** PumpPortal public discovery stream. It records new-token metadata and forwards
 * creation/migration events to the on-chain market-data runtime; it never places trades. */
let pumpWs: WebSocket | undefined;
let pumpRetry: ReturnType<typeof setTimeout> | undefined;
let pumpStopped = false;
let pumpReconnects = 0;
const pumpHealth = { status: "DISABLED", messages: 0, tokensReceived: 0, lastMessageAt: null as string | null, lastError: "" };
const pumpSeen = new Set<string>();
let pumpEventHandler: ((item: any) => void) | undefined;
export function setPumpPortalEventHandler(handler: (item: any) => void) { pumpEventHandler = handler; }

export function pumpPortalStatus() { return { ...pumpHealth, reconnects: pumpReconnects, configured: true }; }
export function startPumpPortalFeed() {
  if (pumpWs || pumpRetry) return;
  pumpStopped = false;
  connectPumpPortal();
}
export function stopPumpPortalFeed() {
  pumpStopped = true;
  if (pumpRetry) clearTimeout(pumpRetry);
  pumpRetry = undefined;
  pumpWs?.close();
  pumpWs = undefined;
  pumpHealth.status = "DISABLED";
}
function connectPumpPortal() {
  if (pumpStopped) return;
  pumpHealth.status = pumpReconnects ? "RECONNECTING" : "CONNECTING";
  const endpoint = process.env.PUMPPORTAL_WS_URL || "wss://pumpportal.fun/api/data";
  const ws = new WebSocket(endpoint);
  pumpWs = ws;
  ws.on("open", () => {
    pumpReconnects = 0;
    pumpHealth.status = "CONNECTED";
    pumpHealth.lastError = "";
    ws.send(JSON.stringify({ method: "subscribeNewToken" }));
    // Migration events are free and let the market-data runtime switch from the
    // bonding curve account to the PumpSwap pool without opening another socket.
    ws.send(JSON.stringify({ method: "subscribeMigration" }));
  });
  ws.on("message", (raw) => {
    pumpHealth.messages++;
    pumpHealth.lastMessageAt = new Date().toISOString();
    try {
      const item: any = JSON.parse(raw.toString());
      try { void pumpEventHandler?.(item); } catch (error) { pumpHealth.lastError = `MARKET_EVENT_HANDLER_ERROR: ${String(error)}`; }
      const mint = String(item?.mint ?? "");
      if (!mint || mint.length < 20 || (item?.txType && item.txType !== "create") || pumpSeen.has(mint)) return;
      pumpSeen.add(mint);
      if (pumpSeen.size > 20000) pumpSeen.delete(pumpSeen.values().next().value as string);
      const now = new Date().toISOString();
      enqueue({
        eventId: `pumpportal:new-token:${mint}`,
        mint,
        symbol: typeof item.symbol === "string" ? item.symbol : undefined,
        name: typeof item.name === "string" ? item.name : undefined,
        source: "pumpportal-new-token",
        eventTime: now,
        raw: { ...item, feed: "PumpPortal subscribeNewToken", observedAt: now }
      });
      pumpHealth.tokensReceived++;
    } catch (error) {
      pumpHealth.lastError = `MESSAGE_PARSE_ERROR: ${String(error)}`;
    }
  });
  ws.on("error", (error) => { pumpHealth.lastError = String(error); });
  ws.on("close", () => {
    if (pumpWs === ws) pumpWs = undefined;
    if (pumpStopped) return;
    pumpHealth.status = "RECONNECTING";
    pumpReconnects++;
    pumpRetry = setTimeout(() => { pumpRetry = undefined; connectPumpPortal(); }, Math.min(30000, 1000 * 2 ** Math.min(pumpReconnects, 5)));
  });
}
