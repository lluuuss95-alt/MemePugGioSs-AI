import { db } from './db.js'; import { config } from './config.js';
export type Opportunity={mint:string;symbol:string;name:string;price:number;liquidity:number;volume5m:number;holders:number;buyPressure:number;score:number;riskScore:number;tradable:boolean;stale:boolean;flags:string[]};
export function opportunities():Opportunity[]{
 const rows:any[]=db.prepare(`SELECT t.mint,t.symbol,t.name,t.source AS token_source,t.first_seen,o.price,o.liquidity,o.volume5m,o.holders,o.buy_pressure,o.observed_at,o.raw_json,o.age_seconds,i.risk_score,i.flags_json FROM tokens t JOIN observations o ON o.id=(SELECT id FROM observations x WHERE x.mint=t.mint AND x.quality='OK' ORDER BY x.observed_at DESC,x.id DESC LIMIT 1) LEFT JOIN token_intelligence i ON i.mint=t.mint WHERE o.quality='OK' ORDER BY o.observed_at DESC LIMIT 200`).all();
 return rows.map(r=>{const observed=Date.parse(r.observed_at);const stale=!Number.isFinite(observed)||Date.now()-observed>config.staleMs;const score=scoreMarket(r);const riskKnown=r.risk_score!==null&&r.risk_score!==undefined&&Number.isFinite(Number(r.risk_score));const riskScore=riskKnown?Number(r.risk_score):100;let flags:string[]=[];try{flags=JSON.parse(r.flags_json??'[]')}catch{flags=[]}if(!riskKnown)flags.push('RISK_DATA_UNAVAILABLE');if(!Number.isFinite(Number(r.price))||Number(r.price)<=0)flags.push('PRICE_UNVERIFIED');if(!Number.isFinite(Number(r.liquidity))||Number(r.liquidity)<=0)flags.push('LIQUIDITY_UNVERIFIED');if(stale)flags.push('STALE_MARKET_DATA');const tradable=!stale&&riskKnown&&score>=config.minOpportunityScore&&riskScore<=config.maxRiskScore&&Number(r.price)>0&&Number(r.liquidity)>0;return {...r,score,riskScore,flags,stale,tradable};}).sort((a,b)=>Number(b.tradable)-Number(a.tradable)||b.score-a.score);
}
function scoreMarket(r:any){
 let raw:any={};try{raw=JSON.parse(String(r.raw_json??'{}'))}catch{}
 const onChainCurve=raw?.provider==='SolanaRPC-PumpCurve'&&raw?.venue==='BONDING_CURVE';
 if(onChainCurve){
  const liquidity=Number(r.liquidity??0),risk=Number(r.risk_score);
  const observed=Date.parse(String(r.observed_at??'')),freshMs=Date.now()-observed;
  const firstSeen=Date.parse(String(r.first_seen??'')),tokenAgeMs=Date.now()-firstSeen;
  const progress=Number(raw.curveProgressBps);
  const liquidityScore=Math.min(30,Math.log10(Math.max(1,liquidity)+1)*6);
  const riskScore=Number.isFinite(risk)?Math.max(0,25*(1-Math.min(100,Math.max(0,risk))/100)):0;
  const progressScore=Number.isFinite(progress)?(progress>=1000&&progress<=8500?20:progress<1000?8:4):0;
  const freshnessScore=Number.isFinite(freshMs)&&freshMs>=0&&freshMs<=15000?15:Number.isFinite(freshMs)&&freshMs>=0&&freshMs<=60000?10:0;
  const ageScore=Number.isFinite(tokenAgeMs)&&tokenAgeMs>=15000&&tokenAgeMs<=10*60_000?10:Number.isFinite(tokenAgeMs)&&tokenAgeMs>=0&&tokenAgeMs<15000?4:0;
  return Math.round((liquidityScore+riskScore+progressScore+freshnessScore+ageScore)*100)/100;
 }
 let s=0;s+=Math.min(30,(r.buy_pressure??0)*30);s+=Math.min(25,Math.log10(Math.max(1,r.volume5m??0)+1)*8);s+=Math.min(25,Math.log10(Math.max(1,r.liquidity??0)+1)*6);s+=Math.min(20,Math.log10(Math.max(1,r.holders??0)+1)*5);return Math.round(s*100)/100;
}
