import { config } from './config.js'; import { db,audit } from './db.js'; import { pollFeed } from './feed.js'; import { drain,ingestQueue } from './ingestion.js'; import { inspectToken } from './intelligence.js'; import { opportunities } from './scanner.js';
let timer:any=null,drainTimer:any=null,running=false,ticks=0,lastError='',lastCycleAt='';
const intelCache=new Map<string,{at:number} & Record<string,any>>();
export async function tick(){
 if(running)return;
 running=true;
 ticks++;
 let feedError='';
 try{
  // Drain first so PumpPortal ingestion events are persisted before the feed poll.
  drain(500);
  try{await pollFeed();}
  catch(e){feedError=String(e);audit(`feed-poll-error:${Date.now()}`,'FEED_POLL_ERROR',{error:feedError});}
  // Persist anything added while pollFeed was running, regardless of its outcome.
  drain(500);
  await enrichTopTokens();
  markToMarket();
  lastError=feedError;
  lastCycleAt=new Date().toISOString();
 }catch(e){
  lastError=String(e);
  audit(`engine-error:${Date.now()}`,'ENGINE_ERROR',{error:lastError});
 }finally{running=false;}
}
async function enrichTopTokens(){if(!config.rpc)return; const batch=Math.max(1,config.intelBatchSize??10); const cutoff=new Date(Date.now()-Math.max(60000,config.intelCacheMs??300000)).toISOString(); const candidates:any[]=db.prepare(`SELECT t.mint FROM tokens t LEFT JOIN token_intelligence i ON i.mint=t.mint WHERE i.mint IS NULL OR i.checked_at < ? ORDER BY CASE WHEN i.mint IS NULL THEN 0 WHEN i.largest_holder_pct IS NULL THEN 1 ELSE 2 END, t.last_seen DESC LIMIT ?`).all(cutoff,batch); for(const x of candidates){const cached=intelCache.get(x.mint); if(cached&&Date.now()-cached.at<Math.max(60000,config.intelCacheMs??300000))continue; try{const i=await inspectToken(x.mint); db.prepare(`INSERT INTO token_intelligence(mint,supply,decimals,largest_holder_pct,top10_holder_pct,mint_authority_present,freeze_authority_present,risk_score,flags_json,checked_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(mint) DO UPDATE SET supply=excluded.supply,decimals=excluded.decimals,largest_holder_pct=excluded.largest_holder_pct,top10_holder_pct=excluded.top10_holder_pct,mint_authority_present=excluded.mint_authority_present,freeze_authority_present=excluded.freeze_authority_present,risk_score=excluded.risk_score,flags_json=excluded.flags_json,checked_at=excluded.checked_at`).run(i.mint,i.supply??null,i.decimals??null,i.largestHolderPct??null,i.top10HolderPct??null,i.mintAuthorityPresent===undefined?null:(i.mintAuthorityPresent?1:0),i.freezeAuthorityPresent===undefined?null:(i.freezeAuthorityPresent?1:0),i.riskScore,JSON.stringify(i.flags),i.rpcCheckedAt); intelCache.set(x.mint,{...i,at:Date.now()});}catch(e){const failedAt=new Date().toISOString();try{db.prepare(`INSERT INTO token_intelligence(mint,risk_score,flags_json,checked_at) VALUES(?,?,?,?) ON CONFLICT(mint) DO UPDATE SET flags_json=excluded.flags_json,checked_at=excluded.checked_at`).run(x.mint,null,JSON.stringify(['TOKEN_INTELLIGENCE_UNAVAILABLE']),failedAt);}catch{} intelCache.set(x.mint,{at:Date.now(),failed:true});audit(`intel-error:${x.mint}`,'INTELLIGENCE_ERROR',{mint:x.mint,error:String(e)});}}}
function markToMarket(){const rows:any[]=db.prepare(`SELECT p.mint,p.quantity,p.avg_entry,o.price FROM positions p LEFT JOIN observations o ON o.id=(SELECT id FROM observations WHERE mint=p.mint AND quality='OK' ORDER BY observed_at DESC LIMIT 1) WHERE p.quantity>0`).all();let equity=Number((db.prepare('SELECT cash FROM account WHERE id=1').get() as any).cash);for(const r of rows)equity+=r.quantity*(r.price??r.avg_entry);db.prepare('UPDATE account SET equity=?,updated_at=? WHERE id=1').run(equity,new Date().toISOString());}
export function startEngine(){if(timer)return;timer=setInterval(tick,config.pollMs);drainTimer=setInterval(()=>{try{drain(250);}catch(e){lastError=String(e);audit(`ingestion-drain-error:${Date.now()}`,'INGESTION_DRAIN_ERROR',{error:lastError});}},250);drainTimer.unref?.();try{drain(500);}catch(e){lastError=String(e);}void tick();}
export function status(){return {version:'V5',running,scheduled:Boolean(timer),ticks,lastError,lastCycleAt,queueDepth:ingestQueue.size,dropped:ingestQueue.dropped};}
