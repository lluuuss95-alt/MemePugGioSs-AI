import { config } from './config.js';

const WSOL = 'So11111111111111111111111111111111111111112';
const TOKEN_PROGRAMS = new Set([
  'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
  'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb',
]);
const TIMEOUT_MS = 6_000;

export interface V86OnChainEvidence {
  mint: string;
  checkedAt: string;
  rpc: string;
  mintAccount: { status: 'PASS'|'FAIL'|'UNKNOWN'; owner?: string; initialized?: boolean; decimals?: number; supplyRaw?: string; mintAuthorityPresent?: boolean|null; freezeAuthorityPresent?: boolean|null; note: string };
  concentration: { status: 'OBSERVED'|'UNKNOWN'; largestHolderPct?: number; top10HolderPct?: number; accountsObserved?: number; note: string };
  lpLockOrBurn: { status: 'UNKNOWN'; note: string };
  decision: 'WATCH';
  liveExecutionEnabled: false;
}

async function rpc(method: string, params: unknown[]): Promise<any> {
  const url = process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 'v86-evidence', method, params }),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  if (!response.ok) throw new Error(`SOLANA_RPC_HTTP_${response.status}`);
  const body: any = await response.json();
  if (body?.error) throw new Error(`SOLANA_RPC_${String(body.error.code ?? 'ERROR')}`);
  return body?.result;
}

function coptionPresent(data: Buffer, offset: number): boolean|null {
  if (data.length < offset + 36) return null;
  const tag = data.readUInt32LE(offset);
  return tag === 0 ? false : tag === 1 ? true : null;
}

/**
 * Read-only standard SPL Mint layout inspection. Holder concentration is calculated
 * only from the largest accounts returned by RPC and is explicitly not a full holder
 * census. LP lock/burn remains UNKNOWN until the actual venue/pool/LP asset is proved.
 */
export async function inspectV86OnChainEvidence(mint: string): Promise<V86OnChainEvidence> {
  const checkedAt = new Date().toISOString();
  const cleanMint = String(mint || '').trim();
  if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(cleanMint)) throw new Error('INVALID_SOLANA_MINT');
  const rpcUrl = process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
  const [accountResult, supplyResult, largestResult] = await Promise.allSettled([
    rpc('getAccountInfo', [cleanMint, { encoding: 'base64', commitment: 'confirmed' }]),
    rpc('getTokenSupply', [cleanMint, { commitment: 'confirmed' }]),
    rpc('getTokenLargestAccounts', [cleanMint, { commitment: 'confirmed' }]),
  ]);

  let mintAccount: V86OnChainEvidence['mintAccount'];
  let supplyRaw: string|undefined;
  let decimals: number|undefined;
  if (accountResult.status === 'fulfilled' && accountResult.value?.value?.data?.[0]) {
    const account = accountResult.value.value;
    const raw = Buffer.from(String(account.value.data[0]), 'base64');
    const owner = String(account.value.owner || '');
    if (!TOKEN_PROGRAMS.has(owner)) {
      mintAccount = { status: 'FAIL', owner, note: 'Il mint non è posseduto da un programma Token SPL riconosciuto.' };
    } else if (raw.length < 82) {
      mintAccount = { status: 'UNKNOWN', owner, note: 'Layout del mint non riconosciuto; possibile Token-2022 o dato incompleto.' };
    } else {
      const mintAuthorityPresent = coptionPresent(raw, 0);
      const freezeAuthorityPresent = coptionPresent(raw, 46);
      const supplyFromLayout = raw.readBigUInt64LE(36).toString();
      decimals = raw.readUInt8(44);
      supplyRaw = supplyFromLayout;
      mintAccount = {
        status: 'PASS', owner, initialized: raw.readUInt8(45) === 1, decimals, supplyRaw,
        mintAuthorityPresent, freezeAuthorityPresent,
        note: 'Mint letto da Solana RPC. Le autorità sono state lette dal layout standard; per Token-2022 serve un parser specifico delle estensioni.',
      };
    }
  } else {
    mintAccount = { status: 'UNKNOWN', note: accountResult.status === 'rejected' ? String(accountResult.reason?.message || accountResult.reason).slice(0, 220) : 'Account mint non trovato o non leggibile.' };
  }

  let concentration: V86OnChainEvidence['concentration'];
  if (supplyResult.status === 'fulfilled' && largestResult.status === 'fulfilled') {
    const supply = supplyResult.value?.value;
    const accounts = Array.isArray(largestResult.value?.value) ? largestResult.value.value : [];
    const total = Number(supply?.amount);
    const largest = accounts.map((x: any) => Number(x?.amount)).filter((n: number) => Number.isFinite(n) && n >= 0).sort((a: number,b: number) => b-a);
    if (Number.isFinite(total) && total > 0 && largest.length) {
      concentration = {
        status: 'OBSERVED',
        largestHolderPct: largest[0] / total * 100,
        top10HolderPct: largest.slice(0,10).reduce((a:number,b:number)=>a+b,0) / total * 100,
        accountsObserved: largest.length,
        note: 'Concentrazione calcolata sugli account più grandi restituiti dall’RPC, non su un censimento completo. Pool, burn address e account programmatici possono influire.',
      };
    } else concentration = { status: 'UNKNOWN', note: 'Supply o lista dei maggiori account non valida/non disponibile.' };
  } else {
    concentration = { status: 'UNKNOWN', note: 'RPC non ha restituito sia la supply sia i maggiori account.' };
  }

  return {
    mint: cleanMint, checkedAt, rpc: (() => { try { return new URL(rpcUrl).origin; } catch { return 'configured RPC endpoint'; } })(),
    mintAccount, concentration,
    lpLockOrBurn: { status: 'UNKNOWN', note: 'Non verificato: serve identificare la venue e la pool esatta e dimostrare on-chain lo stato delle quote LP/lock/burn.' },
    decision: 'WATCH',
    liveExecutionEnabled: false,
  };
}
