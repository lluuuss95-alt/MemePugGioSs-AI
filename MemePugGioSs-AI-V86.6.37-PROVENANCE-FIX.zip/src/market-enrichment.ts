/**
 * Market-provider enrichment has been removed from this release.
 * Token discovery and on-chain safety checks remain available through their
 * independent modules. This compatibility stub intentionally performs no HTTP
 * requests and never imports external market-price providers.
 */
export type MarketEnrichmentStatus = {
  status: 'DISABLED';
  enabled: false;
  providerRequests: 0;
  lastError: '';
};

const disabledStatus: MarketEnrichmentStatus = {
  status: 'DISABLED',
  enabled: false,
  providerRequests: 0,
  lastError: '',
};

export async function runMarketEnrichment(): Promise<MarketEnrichmentStatus> {
  return { ...disabledStatus };
}

export function marketEnrichmentStatus(): MarketEnrichmentStatus {
  return { ...disabledStatus };
}

export function startMarketEnrichment(): void {
  // Intentionally disabled: no timer and no outbound provider requests.
}

export function stopMarketEnrichment(): void {
  // Intentionally disabled: there is no running worker to stop.
}
