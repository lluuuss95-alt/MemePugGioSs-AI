import crypto from "node:crypto"; import jwt from "jsonwebtoken"; import {config} from "./config.js"; import {db} from "./db.js";
function hash(p:string){return crypto.scryptSync(p,config.jwtSecret,32).toString("hex")}
export function ensureAdmin(){
  // Keep the configured admin password synchronized with the persisted account.
  // This updates only the password hash for the configured username; it does not
  // delete users, positions, orders, account balances, or any other database data.
  db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?) ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash")
    .run(config.adminUser,hash(config.adminPassword),"admin");
}
export function login(username:string,password:string){const u:any=db.prepare("SELECT * FROM users WHERE username=?").get(username);if(!u||u.password_hash!==hash(password))throw new Error("INVALID_CREDENTIALS");return jwt.sign({sub:u.id,username:u.username,role:u.role},config.jwtSecret,{expiresIn:"8h"});}
export function verify(token:string){return jwt.verify(token,config.jwtSecret) as any}
