import { solana } from './solana.js';
import { config } from './config.js';

export type TokenIntel = {
  mint:string;
  supply?:number;
  decimals?:number;
  largestHolderPct?:number;
  top10HolderPct?:number;
  mintAuthorityPresent?:boolean;
  freezeAuthorityPresent?:boolean;
  rpcCheckedAt:string;
  riskScore:number;
  flags:string[];
};

function rawAmount(value:unknown):bigint|undefined {
  if (typeof value === 'bigint') return value;
  if (typeof value === 'string' && /^\d+$/.test(value)) { try { return BigInt(value); } catch {} }
  if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) { try { return BigInt(value); } catch {} }
  return undefined;
}
function pct(part:bigint,total:bigint):number|undefined {
  if (total <= 0n || part < 0n) return undefined;
  // Scale before converting to Number to avoid precision loss for raw token amounts.
  const scaled = (part * 100_000_000n) / total;
  const result = Number(scaled) / 1_000_000;
  return Number.isFinite(result) ? Math.min(100, result) : undefined;
}

export async function inspectToken(mint:string):Promise<TokenIntel>{
  const flags:string[]=[]; let supply=0, decimals=0, largestHolderPct:number|undefined, top10HolderPct:number|undefined;
  let mintAuthorityPresent:boolean|undefined; let freezeAuthorityPresent:boolean|undefined;
  let rawSupply:bigint|undefined;
  try {
    const s:any=await solana.tokenSupply(mint);
    const v=s?.value;
    decimals=Number(v?.decimals??0);
    rawSupply=rawAmount(v?.amount);
    const ui=Number(v?.uiAmountString ?? v?.uiAmount);
    supply=Number.isFinite(ui)&&ui>0?ui:(rawSupply!==undefined?Number(rawSupply)/Math.pow(10,decimals):0);
  } catch { flags.push('SUPPLY_UNAVAILABLE'); }
  try {
    const m:any=await solana.mintAccount(mint);
    const info=m?.value?.data?.parsed?.info;
    if (!info) throw new Error('MINT_PARSED_INFO_MISSING');
    mintAuthorityPresent=Boolean(info.mintAuthority); freezeAuthorityPresent=Boolean(info.freezeAuthority);
    if(mintAuthorityPresent) flags.push('MINT_AUTHORITY_PRESENT');
    if(freezeAuthorityPresent) flags.push('FREEZE_AUTHORITY_PRESENT');
  } catch { flags.push('MINT_METADATA_UNAVAILABLE'); }
  try {
    const l:any=await solana.largestAccounts(mint);
    const rows:Array<any>=Array.isArray(l?.value)?l.value:[];
    if (!rows.length) throw new Error('LARGEST_ACCOUNTS_EMPTY');
    const amounts=rows.map(r=>rawAmount(r?.amount)).filter((n):n is bigint=>n!==undefined).sort((a,b)=>a>b?-1:a<b?1:0);
    if(rawSupply!==undefined && rawSupply>0n && amounts.length){
      largestHolderPct=pct(amounts[0],rawSupply);
      const top10=amounts.slice(0,10).reduce((sum,n)=>sum+n,0n);
      top10HolderPct=pct(top10,rawSupply);
    } else if (supply>0) {
      const uiAmounts=rows.map(r=>Number(r?.uiAmountString ?? r?.uiAmount)).filter(n=>Number.isFinite(n)&&n>=0).sort((a,b)=>b-a);
      if(uiAmounts.length){largestHolderPct=Math.min(100,uiAmounts[0]/supply*100);top10HolderPct=Math.min(100,uiAmounts.slice(0,10).reduce((a,b)=>a+b,0)/supply*100);}
    } else flags.push('HOLDER_SUPPLY_UNAVAILABLE');
    if(largestHolderPct===undefined) flags.push('HOLDER_PERCENTAGE_UNAVAILABLE');
  } catch { flags.push('HOLDER_DISTRIBUTION_UNAVAILABLE'); }
  let risk=0;
  if(mintAuthorityPresent) risk+=25;
  if(freezeAuthorityPresent) risk+=25;
  if(largestHolderPct!=null){ if(largestHolderPct>=25) risk+=35; else if(largestHolderPct>=15) risk+=20; else if(largestHolderPct>=8) risk+=10; }
  if(flags.some(x=>x.endsWith('UNAVAILABLE'))) risk+=10;
  return {mint,supply,decimals,largestHolderPct,top10HolderPct,mintAuthorityPresent,freezeAuthorityPresent,rpcCheckedAt:new Date().toISOString(),riskScore:Math.min(100,risk),flags};
}
