import { config } from './config.js';

const WSOL = 'So11111111111111111111111111111111111111112';
const TIMEOUT_MS = 5_000;

export type EvidenceStatus = 'OBSERVED' | 'UNKNOWN' | 'UNAVAILABLE';
export interface V86ExternalEvidence {
  mint: string;
  checkedAt: string;
  rugcheck: { status: EvidenceStatus; score?: number; risks?: Array<{ name: string; level?: string; description?: string }>; source: string; note: string };
  sellQuote: { status: EvidenceStatus; outputAmount?: string; priceImpactPct?: string; routeCount?: number; source: string; note: string };
  lpLockOrBurn: { status: 'UNKNOWN'; source: string; note: string };
  decision: 'WATCH';
  liveExecutionEnabled: false;
}

async function getJson(url: string): Promise<any> {
  const response = await fetch(url, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(TIMEOUT_MS) });
  if (!response.ok) throw new Error(`HTTP_${response.status}`);
  return response.json();
}

/**
 * External evidence is deliberately diagnostic only. A RugCheck score or a Jupiter
 * quote is not proof that a token is safe, and a quote is not an executed sell test.
 * LP lock/burn requires venue-specific pool + LP-token evidence and remains UNKNOWN.
 */
export async function inspectV86ExternalEvidence(mint: string): Promise<V86ExternalEvidence> {
  const checkedAt = new Date().toISOString();
  const cleanMint = String(mint || '').trim();
  if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(cleanMint)) {
    throw new Error('INVALID_SOLANA_MINT');
  }

  const rugBase = (process.env.RUGCHECK_API_BASE_URL || 'https://api.rugcheck.xyz/v1').replace(/\/+$/, '');
  const quoteBase = (process.env.JUPITER_QUOTE_URL || 'https://quote-api.jup.ag/v6/quote').replace(/\/+$/, '');
  const amountRaw = Math.max(1, Math.trunc(Number(process.env.V86_SELL_QUOTE_AMOUNT_RAW || '1000000')));
  const [rug, quote] = await Promise.allSettled([
    getJson(`${rugBase}/tokens/${encodeURIComponent(cleanMint)}/report`),
    getJson(`${quoteBase}?inputMint=${encodeURIComponent(cleanMint)}&outputMint=${WSOL}&amount=${amountRaw}&slippageBps=100`),
  ]);

  let rugcheck: V86ExternalEvidence['rugcheck'];
  if (rug.status === 'fulfilled') {
    const body = rug.value;
    const risks = Array.isArray(body?.risks) ? body.risks.slice(0, 50).map((r: any) => ({
      name: String(r?.name || r?.description || 'Unnamed risk').slice(0, 180),
      level: r?.level === undefined ? undefined : String(r.level).slice(0, 40),
      description: r?.description === undefined ? undefined : String(r.description).slice(0, 300),
    })) : [];
    const score = Number(body?.score_normalised ?? body?.scoreNormalised ?? body?.score);
    rugcheck = {
      status: 'OBSERVED',
      ...(Number.isFinite(score) ? { score } : {}),
      risks,
      source: 'RugCheck API',
      note: 'Informazione di terza parte: non è una certificazione di sicurezza né una prova di LP lock/burn.',
    };
  } else {
    rugcheck = { status: 'UNAVAILABLE', source: 'RugCheck API', note: String(rug.reason?.message || rug.reason || 'Provider unavailable').slice(0, 240) };
  }

  let sellQuote: V86ExternalEvidence['sellQuote'];
  if (quote.status === 'fulfilled' && quote.value && Array.isArray(quote.value.routePlan) && quote.value.routePlan.length > 0 && String(quote.value.outAmount || '').length > 0) {
    sellQuote = {
      status: 'OBSERVED',
      outputAmount: String(quote.value.outAmount),
      ...(quote.value.priceImpactPct !== undefined ? { priceImpactPct: String(quote.value.priceImpactPct) } : {}),
      routeCount: quote.value.routePlan.length,
      source: 'Jupiter quote API',
      note: 'È disponibile una quotazione indicativa; non prova che una transazione di vendita riuscirà on-chain.',
    };
  } else {
    sellQuote = {
      status: quote.status === 'fulfilled' ? 'UNKNOWN' : 'UNAVAILABLE',
      source: 'Jupiter quote API',
      note: quote.status === 'rejected' ? String(quote.reason?.message || quote.reason || 'Provider unavailable').slice(0, 240) : 'Nessun percorso di quotazione utilizzabile; la vendibilità resta non verificata.',
    };
  }

  return {
    mint: cleanMint, checkedAt, rugcheck, sellQuote,
    lpLockOrBurn: {
      status: 'UNKNOWN', source: 'Venue-specific on-chain verifier',
      note: 'Non verificato: servono pool/venue identificati e prova on-chain del lock/burn delle quote LP. Non inferire dal report del token.',
    },
    decision: 'WATCH',
    liveExecutionEnabled: false,
  };
}
