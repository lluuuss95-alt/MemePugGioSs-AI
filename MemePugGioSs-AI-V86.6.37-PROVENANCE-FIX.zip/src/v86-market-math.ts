export interface SolQuotedMarketInput {
  priceNumerator: bigint | number;
  priceDenominator: bigint | number;
  tokenDecimals: number;
  realQuoteReserve: bigint | number;
  solUsd: number;
  quoteDecimals?: number;
}
export interface SolQuotedMarketOutput {
  priceQuote: number;
  priceUsd: number;
  realLiquidityQuote: number;
  liquidityUsd: number;
}

/** Converts raw-unit reserve ratios to USD. Liquidity uses actual reserves only. */
export function deriveSolQuotedMarket(input: SolQuotedMarketInput): SolQuotedMarketOutput | null {
  const numerator = Number(input.priceNumerator);
  const denominator = Number(input.priceDenominator);
  const realQuoteReserve = Number(input.realQuoteReserve);
  const solUsd = Number(input.solUsd);
  const tokenDecimals = Number(input.tokenDecimals);
  const quoteDecimals = Number(input.quoteDecimals ?? 9);
  if (![numerator, denominator, realQuoteReserve, solUsd, tokenDecimals, quoteDecimals].every(Number.isFinite)) return null;
  if (numerator <= 0 || denominator <= 0 || realQuoteReserve <= 0 || solUsd <= 0 || tokenDecimals < 0 || tokenDecimals > 18 || quoteDecimals < 0 || quoteDecimals > 18) return null;
  const priceQuote = (numerator / denominator) * Math.pow(10, tokenDecimals - quoteDecimals);
  const realLiquidityQuote = realQuoteReserve / Math.pow(10, quoteDecimals);
  const priceUsd = priceQuote * solUsd;
  const liquidityUsd = realLiquidityQuote * solUsd;
  if (![priceQuote, realLiquidityQuote, priceUsd, liquidityUsd].every(Number.isFinite) || priceQuote <= 0 || priceUsd <= 0 || liquidityUsd <= 0) return null;
  return { priceQuote, priceUsd, realLiquidityQuote, liquidityUsd };
}
