export interface V25HttpRpc {
  getAccountInfo(address: string, commitment?: string): Promise<any>;
  getTokenAccountBalance(address: string, commitment?: string): Promise<any>;
  getTokenSupply(address: string, commitment?: string): Promise<any>;
  getTransaction(signature: string, commitment?: string): Promise<any>;
}

export class JsonRpcHttpClient implements V25HttpRpc {
  private nextId = 1;
  constructor(private readonly endpoint: string, private readonly fetchImpl: typeof fetch = fetch) {}

  private async call(method: string, params: unknown[]): Promise<any> {
    const fallbackEndpoints = (process.env.SOLANA_RPC_FALLBACK_URLS || "https://api.mainnet-beta.solana.com")
      .split(",").map(value => value.trim()).filter(Boolean);
    const endpoints = [...new Set([this.endpoint, ...fallbackEndpoints].filter(Boolean))];
    const failures: string[] = [];
    for (const endpoint of endpoints) {
      let response: Response;
      try {
        response = await this.fetchImpl(endpoint, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id: this.nextId++, method, params }),
          signal: AbortSignal.timeout(10_000),
        });
      } catch (error) {
        const e = error as { name?: string; message?: string; cause?: { code?: string; message?: string } };
        failures.push(`RPC_TRANSPORT_${e?.name ?? "ERROR"}:${e?.message ?? String(error)}${e?.cause ? ` cause=${e.cause.code ?? ""}:${e.cause.message ?? ""}` : ""}`);
        continue;
      }
      if (!response.ok) {
        failures.push(`RPC_HTTP_${response.status}`);
        // A rate limit or client/configuration error on the primary should not
        // prevent trying a distinct fallback; avoid retrying identical URLs.
        continue;
      }
      let body: any;
      try { body = await response.json() as any; }
      catch (error) { failures.push(`RPC_INVALID_JSON:${error instanceof Error ? error.message : String(error)}`); continue; }
      if (body?.error) {
        failures.push(`RPC_${body.error.code ?? "ERROR"}:${body.error.message ?? "UNKNOWN"}`);
        continue;
      }
      if (!body || !Object.prototype.hasOwnProperty.call(body, "result")) {
        failures.push("RPC_RESULT_MISSING");
        continue;
      }
      return body.result;
    }
    throw new Error(`RPC_ALL_ENDPOINTS_FAILED:${failures.join(" | ")}`.slice(0, 500));
  }

  getAccountInfo(address: string, commitment = "finalized") {
    return this.call("getAccountInfo", [address, { encoding: "base64", commitment }]);
  }
  getTokenAccountBalance(address: string, commitment = "finalized") {
    return this.call("getTokenAccountBalance", [address, { commitment }]);
  }
  getTokenSupply(address: string, commitment = "finalized") {
    return this.call("getTokenSupply", [address, { commitment }]);
  }
  getTransaction(signature: string, commitment = "confirmed") {
    return this.call("getTransaction", [signature, { commitment, encoding: "json", maxSupportedTransactionVersion: 0 }]);
  }
}
