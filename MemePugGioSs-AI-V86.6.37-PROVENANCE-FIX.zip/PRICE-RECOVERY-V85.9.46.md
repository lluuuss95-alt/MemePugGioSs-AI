# V85.9.46 — DexScreener Token-Pairs Recovery

- Replaces the per-token fallback with DexScreener's documented `/token-pairs/v1/solana/{tokenAddress}` endpoint.
- Removes the unauthenticated Pump.fun coin-detail request that was returning HTTP 404 in production.
- Adds per-token probe/error counters to `/api/health`.
- Reports DEGRADED when tokens were checked but no verified market observations were obtained.
- Never fabricates prices; missing market data remains blank.
- PAPER/SHADOW only; no live transaction execution.

Build verification still needs to run on Render.
