# V85.9.41 — DexScreener Market Enrichment

- Adds a server-side market-data enrichment worker using the public DexScreener Solana token endpoint.
- Enriches recently observed tokens with actual observed USD price, USD liquidity, five-minute volume, transaction buy pressure, and pair age when the provider returns those fields.
- Selects the most liquid returned pair for each requested mint and does not invent missing values or holder counts.
- Stores observations through the existing ingestion queue and exposes worker health in `/api/health` under `marketEnrichment`.
- No wallet signing, transaction broadcasting, or live execution is added. PAPER/SHADOW safety gates remain in place.

## Validation note

The source syntax and archive layout should be checked before deployment. A full local TypeScript build could not be completed in this environment because project dependencies (including Node.js type definitions, Express, `ws`, and `better-sqlite3`) are not installed and package installation did not complete. Render's build log must confirm `tsc -p tsconfig.build.json` succeeds before relying on this release.
