# Validation report — V86.6.12 Persistent 429 Cooldown

## Changes in this candidate
- Persistent SQLite cooldown state for DexScreener and GeckoTerminal.
- Exponential backoff: 30 minutes, 1 hour, 2 hours, 4 hours, then 6-hour local cap.
- `Retry-After` accepts both delta-seconds and HTTP-date formats; provider-requested waits longer than the local backoff are honored.
- Cooldown state clears after an accepted successful provider response.
- Release identifier updated in `/api/health`; live execution remains disabled.
- Render deployment instructions use the same extracted project root for build and start.

## Checks run here
- `ci/v8612-cooldown-regression.mjs` — PASS
- `ci/v868-market-data-pipeline-repair.mjs` — PASS
- `ci/v867-market-fallback-automation-test.mjs` — PASS
- `ci/v866-market-recovery-test.mjs` — PASS
- `ci/v865-market-pipeline.mjs` — PASS
- `ci/v951-market-resilience.mjs` — PASS
- package.json/package-lock version consistency — PASS

## Checks not certified here
- Full TypeScript build: BLOCKED in this environment because dependency installation timed out and the local `node_modules` tree is incomplete (missing TypeScript type definitions). Render must run `npm ci` and `npm run build` successfully before this candidate is accepted.
- Live provider requests from Render: NOT RUN. A successful static check cannot prove that DexScreener or GeckoTerminal will lift an IP/account-side 429.
- Cooldown persistence across redeploys depends on Render using a persistent disk for the SQLite database. If SQLite is ephemeral, restart persistence is not guaranteed.

## Safety
PAPER/SHADOW only. No private keys, signing, or live transaction broadcasting are introduced by this change.
