(()=>{'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={token:sessionStorage.getItem('mpg_v5_token')||'',snapshot:null,health:null,tokens:[],opportunities:[],signals:[],traders:[],view:'home',busy:false};
const walletState={address:'',provider:null,connecting:false};
const money=v=>{const n=Number(v);return Number.isFinite(n)?new Intl.NumberFormat('it-IT',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n):'—'};
const tokenPrice=v=>{const n=Number(v);if(v===null||v===undefined||v===''||!Number.isFinite(n)||n<=0)return'—';return new Intl.NumberFormat('it-IT',{style:'decimal',maximumSignificantDigits:8}).format(n)+' USD'};
const num=v=>{const n=Number(v);return Number.isFinite(n)?new Intl.NumberFormat('it-IT',{maximumFractionDigits:4}).format(n):'—'};
const short=v=>{if(v===null||v===undefined||v==='')return'—';const s=String(v);return s.length>18?s.slice(0,8)+'…'+s.slice(-5):s};
const fmtDate=v=>{if(!v)return'—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('it-IT',{dateStyle:'short',timeStyle:'short'})};
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(msg,bad=false){const el=$('#toast');el.textContent=msg;el.classList.toggle('bad',bad);el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,3500)}
async function api(url,opts={}){const headers={...(opts.headers||{})};if(state.token)headers.Authorization='Bearer '+state.token;if(opts.body)headers['Content-Type']='application/json';const r=await fetch(url,{...opts,headers});if(r.status===401){logout(false);throw new Error('Sessione scaduta. Accedi di nuovo.')}if(!r.ok)throw new Error(url+' · HTTP '+r.status);return r.json()}
function showApp(){ $('#login-screen').hidden=true;$('#app').hidden=false; }
function restorePhantomSession(){const provider=phantomProvider(),saved=sessionStorage.getItem('mpg_phantom_public_address');if(provider&&saved&&provider.publicKey&&String(provider.publicKey)===saved){walletState.provider=provider;walletState.address=saved;renderPhantomWallet();updatePhantomBalance()}else renderPhantomWallet()}
function showLogin(){ $('#app').hidden=true;$('#login-screen').hidden=false; }
function logout(notify=true){state.token='';sessionStorage.removeItem('mpg_v5_token');showLogin();if(notify)toast('Hai effettuato la disconnessione.')}
function phantomProvider(){return window.phantom?.solana||(window.solana?.isPhantom?window.solana:null)}
function renderPhantomWallet(balance){const connected=Boolean(walletState.address);const title=$('#phantom-wallet-title'),detail=$('#phantom-wallet-detail'),button=$('#phantom-connect'),disconnect=$('#phantom-disconnect');if(title)title.textContent=connected?'Phantom collegato':'Wallet Phantom non collegato';if(detail)detail.textContent=connected?`Indirizzo pubblico: ${walletState.address}. Connessione in sola lettura; nessuna firma o transazione è stata richiesta.`:'Collega il wallet per visualizzare indirizzo e saldo SOL. Nessuna firma o transazione verrà richiesta in modalità PAPER/SHADOW.';if(button){button.textContent=walletState.connecting?'Connessione…':connected?'Phantom collegato':'Connetti Phantom';button.disabled=walletState.connecting;}if(disconnect)disconnect.hidden=!connected;setText('phantom-wallet-balance',connected&&Number.isFinite(Number(balance))?`${num(balance)} SOL`:'—')}
async function updatePhantomBalance(){if(!walletState.address||!state.token)return;try{const data=await api(`/api/wallet/balance?address=${encodeURIComponent(walletState.address)}`);if(data.address!==walletState.address)return;renderPhantomWallet(data.sol);}catch(e){setText('phantom-wallet-balance','Non disponibile');if($('#phantom-wallet-detail'))$('#phantom-wallet-detail').textContent=`Wallet connesso (${walletState.address}), ma il saldo non è disponibile: ${e.message||'errore RPC'}. La connessione non autorizza operazioni.`}}
async function connectPhantom(){if(walletState.connecting)return;const provider=phantomProvider();if(!provider){toast('Phantom non rilevato. Apri la dashboard nel browser integrato di Phantom oppure installa l’estensione ufficiale.',true);return;}walletState.connecting=true;walletState.provider=provider;renderPhantomWallet();try{const response=await provider.connect();const address=String(response?.publicKey||provider.publicKey||'');if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address))throw new Error('Phantom non ha restituito un indirizzo Solana valido.');walletState.address=address;sessionStorage.setItem('mpg_phantom_public_address',address);renderPhantomWallet();await updatePhantomBalance();toast('Phantom collegato in sola lettura. Nessuna transazione firmata.');}catch(e){walletState.address='';sessionStorage.removeItem('mpg_phantom_public_address');renderPhantomWallet();toast(e?.code===4001?'Connessione Phantom rifiutata.':`Connessione Phantom non riuscita: ${e.message||'errore'}`,true)}finally{walletState.connecting=false;renderPhantomWallet()}}
async function disconnectPhantom(){const provider=walletState.provider||phantomProvider();try{if(provider?.disconnect)await provider.disconnect()}catch{}walletState.address='';walletState.provider=null;sessionStorage.removeItem('mpg_phantom_public_address');renderPhantomWallet();toast('Wallet Phantom disconnesso dalla dashboard.')}
$('#phantom-connect')?.addEventListener('click',connectPhantom);$('#phantom-disconnect')?.addEventListener('click',disconnectPhantom);
window.addEventListener('load',()=>{const provider=phantomProvider();if(provider){walletState.provider=provider;provider.on?.('accountChanged',key=>{walletState.address=key?String(key):'';if(walletState.address)sessionStorage.setItem('mpg_phantom_public_address',walletState.address);else sessionStorage.removeItem('mpg_phantom_public_address');renderPhantomWallet();if(walletState.address)updatePhantomBalance()});provider.on?.('disconnect',()=>{walletState.address='';sessionStorage.removeItem('mpg_phantom_public_address');renderPhantomWallet()});}renderPhantomWallet()});
$('#login-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.submitter;const error=$('#login-error');error.hidden=true;btn.disabled=true;btn.textContent='Accesso in corso…';try{const result=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#username').value.trim(),password:$('#password').value})});const data=await result.json().catch(()=>({}));if(!result.ok||!data.token)throw new Error('Credenziali non valide. Controlla ADMIN_USER e ADMIN_PASSWORD nelle variabili Render.');state.token=data.token;sessionStorage.setItem('mpg_v5_token',data.token);$('#password').value='';showApp();restorePhantomSession();await refreshAll();await refreshTradingMode();startPolling();}catch(err){error.textContent=err.message||'Accesso non riuscito.';error.hidden=false;}finally{btn.disabled=false;btn.innerHTML='Accedi alla dashboard <span>↗</span>'}});
function setText(id,v){const el=document.getElementById(id);if(el)el.textContent=v===undefined||v===null?'—':String(v)}
function setScrollableText(id,v){const el=document.getElementById(id);if(!el)return;const next=v===undefined||v===null?'—':String(v);if(el.textContent===next)return;const previousTop=el.scrollTop;el.textContent=next;el.scrollTop=Math.min(previousTop,Math.max(0,el.scrollHeight-el.clientHeight));}
function setRows(id,rows,cols,empty){const el=document.getElementById(id);if(!el)return;if(!rows||!rows.length){el.innerHTML=`<tr><td class="empty-cell" colspan="${cols}">${esc(empty||'Nessun dato restituito dal backend.')}</td></tr>`;return}el.innerHTML=rows.map(row=>'<tr>'+row.map(cell=>`<td>${cell===null||cell===undefined?'—':cell}</td>`).join('')+'</tr>').join('')}
function pick(o,keys){for(const k of keys)if(o&&o[k]!==undefined&&o[k]!==null)return o[k];return undefined}
function renderState(s){state.snapshot=s;const a=s.account||{},e=s.engine||{};setText('equity',money(a.equity));setText('cash',money(a.cash));setText('position-count',(s.positions||[]).length);setText('engine-status',e.running?'RUNNING':'IDLE');setText('engine-subtitle',e.running?'Motore segnalato come attivo':'Il motore non risulta in esecuzione');setText('chart-equity',money(a.equity));setText('paper-cash',money(a.cash));setText('paper-equity',money(a.equity));setText('paper-positions',(s.positions||[]).length);setText('updated-at','Aggiornato '+new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'}));setText('health-time',new Date().toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'}));setText('runtime-engine',e.running?'RUNNING':'IDLE');setScrollableText('runtime-json',JSON.stringify(e,null,2));setText('connection-label','COLLEGATO');setText('api-health','ONLINE');setText('health-badge','ONLINE');
const orders=s.orders||[];setRows('recent-orders',orders.slice(0,6).map(o=>[esc(pick(o,['side','type','action'])||'Ordine'),esc(short(pick(o,['symbol','mint','token','tokenMint']))),esc(num(pick(o,['quantity','amount','size']))),esc(pick(o,['status','state'])||'—')]),4,'Nessun ordine registrato.');setRows('orders-table',orders.slice(0,100).map(o=>[esc(pick(o,['id','order_id'])||'—'),esc(short(pick(o,['symbol','mint','token']))),esc(pick(o,['side','type'])||'—'),esc(num(pick(o,['quantity','amount','size']))),esc(pick(o,['status','state'])||'—')]),5,'Nessun ordine registrato.');
const positions=s.positions||[];setRows('positions-table',positions.map(p=>[esc(short(pick(p,['symbol','mint','token']))),esc(num(pick(p,['quantity','amount','size']))),esc(money(pick(p,['averageEntry','avgPrice','avg_price','entryPrice','entry_price']))),esc(money(pick(p,['marketValue','market_value','value']))),esc(money(pick(p,['unrealizedPnl','pnl','unrealized_pnl'])))]),5,'Nessuna posizione aperta.');}
function renderRiskScan(data){const summary=data?.summary||{};const counts=summary.counts||summary;setText('risk-rejected',counts.REJECTED??counts.rejected??0);setText('risk-watch',counts.WATCH??counts.watch??0);setText('risk-candidate',counts.CANDIDATE??counts.candidates??0);const reviews=Array.isArray(data?.reviews)?data.reviews:(Array.isArray(data?.reviews?.reviews)?data.reviews.reviews:[]);const el=$('#risk-scan-table');if(!el)return;if(!reviews.length){el.innerHTML='<tr><td colspan="7" class="empty-cell">Nessuna valutazione ancora disponibile. Avvia una scansione dopo aver ricevuto token dal feed.</td></tr>';return;}el.innerHTML=reviews.map(r=>{let reasons=Array.isArray(r.reasons)?r.reasons:[];if(!reasons.length&&r.reasons_json){try{reasons=JSON.parse(r.reasons_json)}catch{reasons=[]}}const decision=String(r.decision||'WATCH');const label=decision==='REJECTED'?'SCARTATO':decision==='CANDIDATE'?'CANDIDATO':'OSSERVA';const score=Number(r.risk_score??r.riskScore);const liquidity=r.liquidity_usd??r.liquidityUsd;const holders=r.holders;return `<tr><td>${esc(r.symbol||r.name||short(r.mint))}</td><td><strong>${esc(label)}</strong></td><td>${Number.isFinite(score)?score+'/100':'—'}</td><td>${liquidity==null?'—':money(liquidity)}</td><td>${holders==null?'—':esc(holders)}</td><td>${esc((reasons||[]).slice(0,3).join(' · ')||'Controlli preliminari')}</td><td>${esc(fmtDate(r.checked_at||r.checkedAt))}</td></tr>`}).join('');setText('risk-scan-note',`Ultimo aggiornamento: ${fmtDate(summary.lastCheckedAt||data?.checkedAt)}. I candidati sono preliminari: nessun punteggio garantisce che un token sia sicuro.`)}
async function refreshRiskScan(){try{renderRiskScan(await api('/api/v86/risk-scan?limit=80'))}catch(e){setText('risk-scan-note','Scanner non disponibile: '+(e.message||'errore backend'))}}
async function refreshCapitalPolicy(){try{const p=await api('/api/capital-policy');if(document.activeElement!==$('#capital-max'))$('#capital-max').value=Number(p.max_capital_usd??p.maxCapitalUsd??0);if(document.activeElement!==$('#capital-order-max'))$('#capital-order-max').value=Number(p.max_order_usd??p.maxOrderUsd??0);const result=$('#capital-policy-result');if(result&&result.dataset.saved!=='1'){result.hidden=false;result.className='form-result';result.textContent=Number(p.max_capital_usd??p.maxCapitalUsd??0)>0?`Limiti attivi in PAPER: capitale ${money(p.max_capital_usd??p.maxCapitalUsd)}, ordine ${money(p.max_order_usd??p.maxOrderUsd)}.`:'Limiti non configurati: gli acquisti PAPER sono bloccati finché non imposti il capitale.'}}catch{}}
function renderTokens(rows){
  state.tokens=Array.isArray(rows)?rows:[];
  renderPaperTokenOptions();
  setText('token-caption',`${state.tokens.length} token · aggiornamento automatico ogni 10 secondi · ultimo aggiornamento ${new Date().toLocaleTimeString('it-IT')}`);
  setText('market-token-count',state.tokens.length);
  const data=state.tokens.slice(0,200).map(t=>[
    esc(pick(t,['symbol','name'])||'—'),
    (t.mint&&/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(String(t.mint))?`<a class="mint-link" href="https://solscan.io/token/${encodeURIComponent(t.mint)}" target="_blank" rel="noopener noreferrer" title="Apri il token su Solscan">${esc(short(t.mint))}</a> <button type="button" class="copy-mint" data-mint="${esc(t.mint)}" aria-label="Copia mint address">Copia</button>`:'—'),
    esc(tokenPrice(pick(t,['verified_price']))),
    esc(Number(t.verified_liquidity)>0?money(t.verified_liquidity):'Non verificata'),
    esc(t.risk_score===null||t.risk_score===undefined?'Non disponibile':num(t.risk_score)),
    esc(t.largest_holder_pct===null||t.largest_holder_pct===undefined?'—':num(t.largest_holder_pct)+'%'),
    esc(t.mint_authority_present===null||t.mint_authority_present===undefined?'Non verificata':(t.mint_authority_present?'Presente':'Assente')),
    esc(t.source||'—'),
    esc(fmtDate(pick(t,['market_observed_at','last_observed_at','last_seen','updated_at','created_at'])))
  ]);
  setRows('tokens-table',data,9,'Nessun token trovato nel database. La fonte potrebbe non essere configurata.');
}
function renderOpp(rows){
  state.opportunities=Array.isArray(rows)?rows:[];
  setText('market-opp-count',state.opportunities.length);
  const data=state.opportunities.slice(0,100).map(x=>[
    esc(pick(x,['symbol','name'])||short(x.mint)),
    (x.mint&&/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(String(x.mint))?`<a class="mint-link" href="https://solscan.io/token/${encodeURIComponent(x.mint)}" target="_blank" rel="noopener noreferrer">${esc(short(x.mint))}</a>`:'—'),
    esc(tokenPrice(x.price)),esc(Number(x.liquidity)>0?money(x.liquidity):'Non verificata'),
    esc(num(x.score)),esc(x.riskScore===100&&Array.isArray(x.flags)&&x.flags.includes('RISK_DATA_UNAVAILABLE')?'Non disponibile':num(x.riskScore)),
    esc(x.tradable?'AMMESSO':'BLOCCATO')
  ]);
  setRows('signals-table',data,7,'Nessuna opportunità disponibile. Non vengono generati segnali dimostrativi.');
}
function renderTraders(rows){
  state.traders=Array.isArray(rows)?rows:[];
  const data=state.traders.slice(0,100).map(t=>[
    esc(short(pick(t,['wallet','address','publicKey','trader','name']))),
    esc(num(pick(t,['score','rank','performanceScore']))),
    esc(num(pick(t,['reputation','reputationScore','score']))),
    esc(pick(t,['status'])||'Osservato')
  ]);
  setRows('traders-table',data,4,'Nessun trader disponibile tramite le API correnti.');
}
function paperEligibleTokens(){
  return state.tokens.filter(t=>{
    const mint=String(t.mint||'');
    const price=Number(pick(t,['verified_price']));
    const liquidity=Number(pick(t,['verified_liquidity']));
    const observed=Date.parse(pick(t,['market_observed_at'])||'');
    return mint.length>=32&&mint.length<=44&&Number.isFinite(price)&&price>0&&Number.isFinite(liquidity)&&liquidity>0&&Number.isFinite(observed);
  });
}
function renderPaperTokenOptions(){
  const select=$('#paper-token');if(!select)return;
  const prior=select.value;const eligible=paperEligibleTokens();
  select.innerHTML=eligible.length?'<option value="">Seleziona un token verificato…</option>'+eligible.map(t=>`<option value="${esc(t.mint)}">${esc(t.symbol||t.name||short(t.mint))} · ${esc(short(t.mint))} · ${esc(tokenPrice(pick(t,['verified_price'])))}</option>`).join(''):'<option value="">Nessun token con prezzo e liquidità verificati</option>';
  if(prior&&eligible.some(t=>t.mint===prior))select.value=prior;
  updatePaperTokenInfo();
}
function updatePaperTokenInfo(){
  const select=$('#paper-token'),info=$('#paper-token-info'),submit=$('#paper-submit');if(!select||!info||!submit)return;
  const t=state.tokens.find(x=>x.mint===select.value);const side=$('#paper-side')?.value||'BUY';
  if(!t){info.textContent='Il sistema non propone token senza dati di mercato verificati.';submit.disabled=true;return;}
  const price=Number(pick(t,['verified_price'])),liquidity=Number(pick(t,['verified_liquidity']));const observed=Date.parse(pick(t,['market_observed_at'])||'');const age=Date.now()-observed;
  const position=(state.snapshot?.positions||[]).find(p=>p.mint===t.mint);const fresh=Number.isFinite(age)&&age>=0&&age<=90000;
  const liquidityOK=Number.isFinite(liquidity)&&liquidity>=Math.max(100,Number($('#paper-quote')?.value||25)*10);
  const sellQuantity=price>0?Number($('#paper-quote')?.value||25)/price:Infinity;const canSell=side!=='SELL'||(Number(position?.quantity||0)>0&&sellQuantity<=Number(position?.quantity||0));
  info.textContent=`Prezzo: ${tokenPrice(price)} · Liquidità: ${money(liquidity)} · Osservazione: ${Number.isFinite(age)?(age<0?'orario non valido':`${Math.floor(age/1000)}s fa`):'non disponibile'}. ${!fresh?'DATO NON AGGIORNATO: ordine bloccato.':!liquidityOK?'Liquidità insufficiente per l’importo selezionato.':!canSell?'Quantità superiore alla posizione PAPER disponibile.':'Dati verificati; l’ordine resta soggetto ai controlli di rischio del backend.'}`;
  submit.disabled=!(fresh&&liquidityOK&&canSell&&price>0&&liquidity>0);
}
$('#paper-token')?.addEventListener('change',updatePaperTokenInfo);
$('#paper-side')?.addEventListener('change',updatePaperTokenInfo);
$('#paper-quote')?.addEventListener('input',updatePaperTokenInfo);
const modeSelect=$('#trading-mode-select');
async function refreshTradingMode(){try{const data=await api('/api/trading/mode');if(modeSelect)modeSelect.value=data.requestedMode||'PAPER';setText('trading-mode-effective',`Modalità attiva: ${data.effectiveMode||'PAPER'}`);setText('trading-mode-status',data.requestedMode==='LIVE'?'Modalità REALE richiesta ma BLOCCATA: nessun ordine reale verrà inviato finché i gate di sicurezza non saranno certificati.':'PAPER attiva: nessun ordine reale viene inviato.')}catch{setText('trading-mode-effective','Modalità attiva: PAPER');setText('trading-mode-status','Stato modalità non disponibile; il backend mantiene il trading reale disabilitato.')}}
$('#trading-mode-apply')?.addEventListener('click',async()=>{const requested=modeSelect?.value||'PAPER';const btn=$('#trading-mode-apply');btn.disabled=true;try{const result=await api('/api/trading/mode',{method:'POST',body:JSON.stringify({mode:requested})});setText('trading-mode-effective',`Modalità attiva: ${result.effectiveMode}`);setText('trading-mode-status',result.requestedMode==='LIVE'?'Modalità REALE richiesta ma BLOCCATA: nessun ordine reale verrà inviato finché i gate di sicurezza non saranno certificati.':'PAPER attiva: nessun ordine reale viene inviato.');toast(result.requestedMode==='LIVE'?'Trading reale non attivato: controlli di sicurezza ancora incompleti.':'Modalità PAPER applicata.');}catch(err){toast(err.message||'Impossibile cambiare modalità.',true)}finally{btn.disabled=false}});
$('#paper-order-form')?.addEventListener('submit',async e=>{
  e.preventDefault();const result=$('#paper-order-result'),btn=$('#paper-submit');if(!result||!btn)return;
  const mint=$('#paper-token').value,t=state.tokens.find(x=>x.mint===mint),side=$('#paper-side').value,quote=Number($('#paper-quote').value);
  if(!t||!Number.isFinite(quote)||quote<5||quote>1000){result.textContent='Seleziona un token valido e un importo tra 5 e 1.000 USD.';result.className='form-result bad';result.hidden=false;return;}
  const price=Number(pick(t,['verified_price'])),liquidity=Number(pick(t,['verified_liquidity'])),observedAt=pick(t,['market_observed_at']);
  const age=Date.now()-Date.parse(observedAt||'');
  if(!Number.isFinite(age)||age<0||age>90000||price<=0||liquidity<Math.max(100,quote*10)){result.textContent='Ordine bloccato: prezzo/liquidità mancanti, dati scaduti o liquidità insufficiente. Aggiorna i dati e riprova.';result.className='form-result bad';result.hidden=false;return;}
  const quantity=quote/price;const position=(state.snapshot?.positions||[]).find(p=>p.mint===mint);
  if(side==='SELL'&&quantity>Number(position?.quantity||0)){result.textContent='Ordine bloccato: quantità da vendere superiore alla posizione PAPER disponibile.';result.className='form-result bad';result.hidden=false;return;}
  btn.disabled=true;btn.textContent='Verifica ordine…';result.hidden=true;
  try{
    const response=await api('/api/paper/order',{method:'POST',body:JSON.stringify({orderId:`paper-${crypto.randomUUID()}`,mint,symbol:t.symbol||t.name||short(mint),side,quantity,ask:price,bid:price,liquidity,observedAt})});
    result.textContent=`Ordine PAPER confermato: ${side} ${num(response.quantity)} unità a ${tokenPrice(response.price)}. Commissione simulata: ${money(response.fee)}. Nessuna transazione reale inviata.`;result.className='form-result good';result.hidden=false;
    await refreshAll();
  }catch(err){result.textContent=`Ordine non eseguito: ${err.message||'errore backend'}. Nessun ordine è stato dichiarato riuscito.`;result.className='form-result bad';result.hidden=false;}
  finally{btn.textContent='Esegui ordine simulato';updatePaperTokenInfo();}
});


function analyzePumpfunToken(t){
  const price=Number(pick(t,['verified_price']));
  const liquidity=Number(pick(t,['verified_liquidity']));
  const observed=Date.parse(pick(t,['market_observed_at'])||'');
  const age=Date.now()-observed;
  const riskKnown=t.risk_score!==null&&t.risk_score!==undefined&&Number.isFinite(Number(t.risk_score));
  const authorityKnown=[true,false,0,1].includes(t.mint_authority_present);
  const freezeKnown=[true,false,0,1].includes(t.freeze_authority_present);
  const mintAuthorityPresent=t.mint_authority_present===true||Number(t.mint_authority_present)===1;
  const freezeAuthorityPresent=t.freeze_authority_present===true||Number(t.freeze_authority_present)===1;
  const checks={mint:!!t.mint,price:Number.isFinite(price)&&price>0,liquidity:Number.isFinite(liquidity)&&liquidity>0,fresh:Number.isFinite(age)&&age>=0&&age<=90000,risk:riskKnown,authority:authorityKnown&&!mintAuthorityPresent,freezeAuthority:freezeKnown&&!freezeAuthorityPresent,holderKnown:t.largest_holder_pct!==null&&t.largest_holder_pct!==undefined&&Number.isFinite(Number(t.largest_holder_pct))&&Number(t.largest_holder_pct)<=25,liquidityDepth:Number.isFinite(liquidity)&&liquidity>=10000,lowRisk:riskKnown&&Number(t.risk_score)<=35};
  const reasons=[];
  if(!checks.mint)reasons.push('mint mancante');
  if(!checks.price)reasons.push('prezzo non verificato');
  if(!checks.liquidity)reasons.push('liquidità non verificata');
  else if(!checks.liquidityDepth)reasons.push('liquidità sotto 10.000 USD');
  if(!checks.fresh)reasons.push('dati più vecchi di 90 secondi o data assente');
  if(!checks.risk)reasons.push('punteggio rischio assente');
  else if(!checks.lowRisk)reasons.push('rischio oltre soglia conservativa (35/100)');
  if(!checks.authority)reasons.push('autorità mint non verificata o ancora presente');
  if(!checks.freezeAuthority)reasons.push('freeze authority non verificata o ancora presente');
  if(!checks.holderKnown)reasons.push('holder maggiore non verificato o oltre 25%');
  const eligible=Object.values(checks).every(Boolean);
  return {t,price,liquidity,age,riskKnown,eligible,reasons};
}

function drawEquityChart(curve,lineId,areaId,emptyId){
  const line=document.getElementById(lineId),area=areaId?document.getElementById(areaId):null,empty=document.getElementById(emptyId);
  const points=(Array.isArray(curve)?curve:[]).filter(x=>Number.isFinite(Number(x.equity))).slice(-180);
  if(points.length<2){if(line)line.setAttribute('points','');if(area)area.setAttribute('points','');if(empty)empty.hidden=false;return;}
  const vals=points.map(x=>Number(x.equity)),min=Math.min(...vals),max=Math.max(...vals),span=max-min||1;
  const coords=vals.map((v,i)=>`${(i/(vals.length-1)*700+10).toFixed(2)},${(175-(v-min)/span*150).toFixed(2)}`).join(' ');
  if(line)line.setAttribute('points',coords);
  if(area)area.setAttribute('points',`10,180 ${coords} 710,180`);
  if(empty)empty.hidden=true;
}
function renderAutoPaper(data){
  if(!data)return;
  const pnl=Number(data.totalPnl||0),realized=Number(data.realizedPnl||0),unrealized=Number(data.unrealizedPnl||0);
  setText('paper-total-pnl',money(pnl));setText('paper-realized-pnl',money(realized));setText('paper-unrealized-pnl',money(unrealized));
  setText('chart-pnl-label',`P/L totale: ${money(pnl)}`);
  const status=$('#auto-paper-status'),detail=$('#auto-paper-detail'),button=$('#auto-paper-toggle');
  if(status)status.textContent=data.enabled?'AUTOMAZIONE PAPER ATTIVA':'AUTOMAZIONE PAPER DISATTIVATA';
  if(detail){const l=data.limits||{},d=data.diagnostics||{},blocks=Object.entries(d.blockedBy||{}).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([k,v])=>`${k}: ${v}`).join(', ');detail.textContent=`Capitale iniziale ${money(data.startingCapital)} · ${data.openPositions||0} posizioni aperte · max ${l.maxOpenPositions||3} posizioni · allocazione ${l.positionPct||2}% per posizione · stop-loss ${l.stopLossPct||8}% · take-profit ${l.takeProfitPct||15}%. Stato: ${d.scanStatus||'IN ATTESA'} · ultimo ciclo ${d.lastTickAt?fmtDate(d.lastTickAt):'in attesa'} · ultima scansione ${d.lastScanAt?fmtDate(d.lastScanAt):'in attesa'} · token esaminati ${d.candidateCount||0} · idonei ${d.eligibleCount||0}${blocks?` · blocchi: ${blocks}`:''}${d.lastTickError?` · errore motore: ${d.lastTickError}`:''}. I dati non verificati bloccano l’ingresso.`;}
  if(button){button.textContent=data.enabled?'Disattiva trading automatico PAPER':'Attiva trading automatico PAPER';button.classList.toggle('danger',Boolean(data.enabled));button.disabled=false;}
  drawEquityChart(data.curve,'paper-equity-line',null,'paper-equity-chart-empty');
  drawEquityChart(data.curve,'equity-line','equity-area','equity-chart-empty');
  const events=(data.events||[]).slice(0,30).map(x=>[
    esc(fmtDate(x.ts)),esc(x.symbol||short(x.mint)),esc(x.action||'—'),esc(x.price?tokenPrice(x.price):'—'),esc(money(x.pnl||0)),esc(x.reason||'—')
  ]);
  setRows('auto-paper-events',events,6,'Nessuna attività automatica registrata. Abilita il motore per avviare il monitoraggio PAPER.');
}
$('#auto-paper-toggle')?.addEventListener('click',async()=>{
  const button=$('#auto-paper-toggle');if(!button)return;const enable=button.textContent.toLowerCase().includes('attiva');
  button.disabled=true;button.textContent=enable?'Attivazione…':'Disattivazione…';
  try{const data=await api('/api/paper/auto',{method:'POST',body:JSON.stringify({enabled:enable})});renderAutoPaper(data);toast(enable?'Trading automatico PAPER attivato. Nessuna transazione reale.':'Trading automatico PAPER disattivato.');await refreshAll();}
  catch(e){button.disabled=false;button.textContent=enable?'Attiva trading automatico PAPER':'Disattiva trading automatico PAPER';toast(`Impossibile modificare il motore: ${e.message||'errore'}`,true);}
});
$('#wallet-monitor-form')?.addEventListener('submit',async e=>{e.preventDefault();const result=$('#wallet-monitor-result'),btn=$('#wallet-monitor-submit');const wallet=$('#wallet-address').value.trim();if(!result||!btn)return;result.hidden=false;if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(wallet)){result.className='form-result bad';result.textContent='Indirizzo Solana non valido.';return;}btn.disabled=true;btn.textContent='Verifica wallet…';try{const history=await api(`/api/v34/wallet/${encodeURIComponent(wallet)}/history?limit=20`);await api('/api/v34/follow',{method:'POST',body:JSON.stringify({wallet,copyPaper:true})});result.className='form-result good';result.textContent=`Wallet pubblico registrato in PAPER. Firme recenti restituite dall'RPC: ${(history.signatures||[]).length}. Questo conteggio non equivale a trade classificati.`;$('#wallet-address').value='';await refreshAll();await renderFollowingWallets();const h=$('#wallet-history');if(h){h.hidden=false;h.textContent=`Ultima verifica ${new Date().toLocaleTimeString('it-IT')}: ${(history.signatures||[]).length} firme recenti. Per classificare BUY/SELL serve parsing delle transazioni e dati quote verificati.`}}catch(err){result.className='form-result bad';result.textContent=`Wallet non aggiunto: ${err.message||'errore API'}. Verifica che RPC Solana sia configurato su Render.`}finally{btn.disabled=false;btn.textContent='Aggiungi wallet da monitorare';}});
async function renderFollowingWallets(){const box=$('#wallet-following');if(!box||!state.token)return;try{const rows=await api('/api/v34/following');if(!Array.isArray(rows)||!rows.length){box.textContent='Nessun wallet seguito.';return;}box.innerHTML=rows.map(w=>`<div class="health-row"><span><a class="mint-link" href="https://solscan.io/account/${encodeURIComponent(w.wallet)}" target="_blank" rel="noopener noreferrer">${esc(short(w.wallet))}</a></span><strong>${w.copy_paper?'PAPER':'MONITORAGGIO'}</strong></div>`).join('')}catch{box.textContent='Impossibile caricare i wallet seguiti.'}}
document.addEventListener('click',async e=>{const b=e.target.closest('[data-mint]');if(!b)return;try{await navigator.clipboard.writeText(b.dataset.mint);toast('Mint address copiato.')}catch{toast('Copia non disponibile nel browser.',true)}});
async function refreshAll(){if(state.busy||!state.token)return;state.busy=true;setText('connection-label','AGGIORNAMENTO');try{const healthP=fetch('/api/health').then(r=>r.json()).catch(()=>null);const results=await Promise.allSettled([api('/api/state'),api('/api/tokens'),api('/api/opportunities'),api('/api/v34/traders'),healthP,api('/api/paper/auto')]);if(results[0].status==='fulfilled')renderState(results[0].value);else throw results[0].reason;if(results[1].status==='fulfilled')renderTokens(results[1].value);if(results[2].status==='fulfilled')renderOpp(results[2].value);if(results[3].status==='fulfilled')renderTraders(results[3].value);if(results[5].status==='fulfilled')renderAutoPaper(results[5].value);await renderFollowingWallets();await Promise.all([refreshRiskScan(),refreshCapitalPolicy()]);if(results[4].status==='fulfilled'&&results[4].value){state.health=results[4].value;setText('footer-version',String(state.health.release||state.health.diagnosticBuildId||`Versione ${state.health.version||'non verificata'}`));setText('rpc-status',String(state.health.rpc||'—').toUpperCase());setText('api-health',state.health.ok?'ONLINE':'ATTENZIONE');setText('runtime-api',state.health.ok?'ONLINE':'ATTENZIONE');const feed=state.health.pumpPortal||{};const feedTime=feed.lastMessageAt?fmtDate(feed.lastMessageAt):'nessun messaggio ancora';const feedError=feed.lastError?' · Ultimo errore segnalato: sì (dettaglio nei log backend)':' · Nessun errore segnalato';setText('market-summary',`Servizio: ${state.health.ok?'online':'da verificare'} · Versione: ${state.health.version||'—'} · RPC: ${state.health.rpc||'non configurato'} · WebSocket Solana: ${state.health.chainStream?'configurato':'non configurato'} · PumpPortal: ${feed.status||'stato non disponibile'} · messaggi ricevuti: ${Number(feed.messages||0)} · token nuovi ricevuti: ${Number(feed.tokensReceived||0)} · ultimo messaggio: ${feedTime}${feedError}. Un endpoint collegato non garantisce da solo un feed aggiornato né costituisce un segnale di trading.`);setScrollableText('runtime-json',JSON.stringify({health:state.health,engine:state.snapshot?.engine||{}},null,2));}else{setText('rpc-status','NON VERIFICATO');setText('market-summary','Health check non disponibile. Controlla la connessione del backend.')}setText('connection-label','COLLEGATO');}catch(err){setText('connection-label','ERRORE');toast(err.message||'Errore durante il caricamento dei dati.',true)}finally{state.busy=false}}
function go(view){if(!document.getElementById('view-'+view))return;state.view=view;$$('.page').forEach(p=>p.classList.toggle('active',p.id==='view-'+view));$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));setText('page-name',({home:'Home',market:'Mercato Solana',tokens:'Nuovi token',signals:'Segnali AI',paper:'Paper Trading',copy:'Copy Trading',runtime:'Stato motore'})[view]||view);$('#sidebar').classList.remove('open');}
$('#paper-engine-diagnostic')?.addEventListener('click',async e=>{const btn=e.currentTarget,box=$('#paper-engine-diagnostics');btn.disabled=true;btn.textContent='Verifica in corso…';box.hidden=false;box.textContent='Lettura stato motore PAPER…';try{const data=await api('/api/diagnostics/paper-engine');box.textContent=JSON.stringify(data,null,2);toast('Diagnostica motore PAPER completata.')}catch(err){box.textContent=err.message||'Diagnostica non riuscita.';toast('Diagnostica motore PAPER non riuscita.',true)}finally{btn.disabled=false;btn.textContent='Verifica motore PAPER'}});
$('#run-risk-scan')?.addEventListener('click',async()=>{const b=$('#run-risk-scan');b.disabled=true;b.textContent='Scansione…';try{const data=await api('/api/v86/risk-scan/run',{method:'POST',body:JSON.stringify({limit:500})});renderRiskScan({summary:{...data.summary,lastCheckedAt:data.checkedAt},reviews:data.reviews});toast(`Scansione completata: ${data.scanned} token valutati.`)}catch(e){toast('Scansione non riuscita: '+e.message,true)}finally{b.disabled=false;b.textContent='Scansiona adesso'}});
$('#capital-policy-form')?.addEventListener('submit',async e=>{e.preventDefault();const result=$('#capital-policy-result'),button=$('#capital-policy-save');const maxCapital=Number($('#capital-max').value),maxOrder=Number($('#capital-order-max').value);result.hidden=false;result.className='form-result';button.disabled=true;try{const data=await api('/api/capital-policy',{method:'PUT',body:JSON.stringify({maxCapitalUsd:maxCapital,maxOrderUsd:maxOrder})});result.dataset.saved='1';result.className='form-result good';result.textContent=data.maxCapitalUsd>0?`Limiti salvati: capitale massimo ${money(data.maxCapitalUsd)}, ordine massimo ${money(data.maxOrderUsd)}. Si applicano al PAPER, non al saldo Phantom.`:'Acquisti PAPER bloccati: limiti a zero.';toast('Limiti del capitale salvati.')}catch(err){result.className='form-result bad';result.textContent=err.message||'Salvataggio non riuscito.'}finally{button.disabled=false}});
$('#navigation').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b)go(b.dataset.view)});document.addEventListener('click',e=>{const b=e.target.closest('[data-goto]');if(b)go(b.dataset.goto)});$('#menu-toggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));$('#refresh').addEventListener('click',refreshAll);$('#runtime-refresh').addEventListener('click',refreshAll);$('#reload-tokens').addEventListener('click',async()=>{try{renderTokens(await api('/api/tokens'));toast('Elenco token aggiornato.')}catch(e){toast(e.message,true)}});$('#logout').addEventListener('click',()=>logout());
let poll=null;function startPolling(){if(poll)clearInterval(poll);poll=setInterval(refreshAll,10000)}
if(state.token){showApp();restorePhantomSession();refreshAll().then(startPolling)}else showLogin();
})();