# V85.9.39 — Pump.fun discovery feed

This release starts a PumpPortal WebSocket discovery subscription (`subscribeNewToken`) automatically when the backend starts. New-token metadata is queued into the existing ingestion pipeline and becomes available through the existing authenticated token API/dashboard after the engine drains the queue.

- Default endpoint: `wss://pumpportal.fun/api/data`
- Optional override: `PUMPPORTAL_WS_URL`
- Health: `GET /api/health` now includes `pumpPortal` status, message count, received-token count, last message time and last error.
- Reconnects automatically after the socket closes.
- Deduplicates mint addresses in memory and event IDs in the existing database pipeline.
- Does not manufacture price, liquidity, volume, AI signals, or profit values. A new-token event alone is not a trade signal.
- Trading remains PAPER/SHADOW only; this integration does not sign or broadcast transactions.

The existing `MARKET_FEED_URL` HTTP feed remains supported. Full runtime build/test should be confirmed by Render logs after deploying.
