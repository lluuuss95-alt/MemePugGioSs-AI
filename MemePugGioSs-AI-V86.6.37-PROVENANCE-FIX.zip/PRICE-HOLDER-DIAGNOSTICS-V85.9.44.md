# V85.9.44 — Price & Holder Diagnostics

- Holder concentration now uses raw integer token amounts from `getTokenSupply` and `getTokenLargestAccounts`, avoiding missing percentages when RPC `uiAmount` is null for large values. Computes largest holder and top-10 concentration.
- Failed intelligence checks no longer store a misleading risk score of 10 as though it were a measured score. The unavailable flag remains explicit.
- Market enrichment retries a rotating sample of recent tokens against DexScreener and the Pump.fun coin endpoint. For Pump.fun bonding-curve tokens, it only records a positive price implied by provider-reported USD market cap and total supply; otherwise the value stays unavailable rather than being fabricated.
- Additional counters are exposed through the existing `/api/health` `marketEnrichment` object.
- Safety remains PAPER/SHADOW: no wallet signing or live transaction broadcasting is added.

Build note: the archive is intended for the repository's existing Render build command, which generates `package-lock.json` before running `npm ci`.
