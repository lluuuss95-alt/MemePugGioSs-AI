# MemePugGioSs AI — Dashboard UI refresh

Questa build aggiorna la dashboard web del progetto mantenendo il backend e le protezioni PAPER/SHADOW esistenti.

## Cosa cambia
- Nuova UI responsive in italiano con sidebar e sezioni Home, Mercato, Token, Segnali AI, Paper Trading, Copy Trading, Assistente AI e Runtime.
- Accesso tramite form che chiama `POST /api/login`; non è più richiesto incollare manualmente un JWT.
- Le schermate usano le API esistenti (`/api/state`, `/api/tokens`, `/api/opportunities`, `/api/v34/traders`, `/api/health`).
- Nessun dato dimostrativo per profitti, token o performance. Lo storico equity resta esplicitamente non disponibile finché il backend non espone una serie storica.
- Nessun comando di trading reale aggiunto; la UI è in sola lettura per ordini/posizioni.

## Pubblicazione
Caricare il contenuto di questo ZIP nel repository GitHub e lasciare che Render esegua il deployment già configurato. Se Render usa il repository con un archivio ZIP al suo interno, sostituire quell'archivio con questa nuova versione mantenendo il nome previsto dalla configurazione esistente.

## Accesso
Il login usa `ADMIN_USER` e `ADMIN_PASSWORD` configurati nell'ambiente Render. Non usare valori di esempio come credenziali reali. `JWT_SECRET` deve essere un segreto lungo e casuale. Se l'utente admin è già presente nel database, cambiare `ADMIN_PASSWORD` nell'ambiente potrebbe non aggiornare la password già memorizzata: non resettare il database senza backup.

## Sicurezza
Mantenere `APP_MODE=PAPER`, `LIVE_EXECUTION_ENABLED=false`, `SIGNING_ENABLED=false`, `BROADCAST_ENABLED=false`, `PRIVATE_KEY_ACCESS=false` e `AUTO_PROMOTION=false`. Questa UI non abilita trading live.
