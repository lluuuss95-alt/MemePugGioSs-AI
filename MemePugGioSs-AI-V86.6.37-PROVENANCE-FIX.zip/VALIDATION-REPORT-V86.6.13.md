# Validation report — V86.6.13 Provider and PAPER diagnostics

## Implemented
- Added authenticated `GET /api/diagnostics/market-providers`.
- Manual provider probe is cached for five minutes, sends at most one request to each provider per run, and skips a provider while its existing cooldown is active.
- Probe reports HTTP status, latency, selected rate-limit/Cloudflare headers, short response preview, and cooldown. A 429 updates the existing persistent cooldown state.
- The result explicitly warns that a 429 from Render is compatible with provider/source-network throttling but does not prove shared-IP limiting.
- Added authenticated read-only `GET /api/diagnostics/paper-engine` with automation state, last tick/scan status, fresh verified observations, and risk-record counts.
- Added two diagnostic buttons and JSON result panels to the dashboard.
- Real execution remains disabled; diagnostics do not enable automation or create orders.

## Checks run
- `node ci/v8613-provider-paper-diagnostics.mjs` — PASS.
- `node ci/v8612-cooldown-regression.mjs` — PASS.
- `node ci/v867-market-fallback-automation-test.mjs` — PASS.
- `node ci/v868-market-data-pipeline-repair.mjs` — PASS.
- `node ci/v866-market-recovery-test.mjs` — PASS.
- `node ci/v865-market-pipeline.mjs` — PASS.
- `node ci/v951-market-resilience.mjs` — PASS.
- `node --check dashboard/app.js`, `node --check dist/server.js`, and `node --check dist/market-enrichment.js` — PASS.
- TypeScript source was transpiled to refresh `dist` using the installed TypeScript transpiler. This is a syntax/transpile check only, not a full type-check.

## Not yet certified
- Full `npm ci` and `npm run build` could not be completed in this working environment because package installation timed out and the local dependency tree remained incomplete. Render must pass both commands before deployment is accepted.
- The provider probe has not yet been run from the live Render process. Therefore the actual egress/IP cause remains undetermined until the operator clicks **Verifica accesso provider** after deployment.
- The PAPER engine's real runtime state must be read with **Verifica motore PAPER** after deployment. This diagnostic is read-only and will report whether automation is disabled or whether market/risk gates are blocking entries.

## Deploy commands
Build Command:
`set -eu; ZIP="./MemePugGioSs-AI-V86.6.13-PROVIDER-PAPER-DIAGNOSTICS.zip"; test -f "$ZIP"; rm -rf certification-source; mkdir -p certification-source; unzip -q "$ZIP" -d certification-source; cd certification-source; npm ci --no-audit --no-fund; npm run build`

Start Command:
`cd certification-source && npm start`

Do not enable live execution. Keep PAPER/SHADOW mode.
