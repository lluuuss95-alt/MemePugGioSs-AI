# V85.9.45 — Market Fetch Resilience

- DexScreener batch request failures no longer abort the whole enrichment cycle.
- The service proceeds with bounded per-token DexScreener and Pump.fun fallback attempts.
- Health diagnostics preserve request stage, error name/message, and nested cause code/message when available.
- A cycle with failed external requests remains DEGRADED even if the process and trading engine are online.
- Prices are written only from valid observed provider data; no synthetic zero prices are generated.
- PAPER/SHADOW only: no signing, broadcasting, or live trading was added.

Build confirmation must come from Render.
