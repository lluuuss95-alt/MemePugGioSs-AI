import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../dashboard/app.js', import.meta.url), 'utf8');
const start = source.indexOf('function setScrollableText(');
assert.notEqual(start, -1, 'scroll-preservation helper must exist');
const end = source.indexOf('\n', start);
assert.notEqual(end, -1, 'scroll-preservation helper must be a standalone line');
const helper = source.slice(start, end);

const element = { textContent: 'old', scrollTop: 180, scrollHeight: 900, clientHeight: 400 };
const document = { getElementById: id => id === 'runtime-json' ? element : null };
const run = value => vm.runInNewContext(`${helper}; setScrollableText('runtime-json', ${JSON.stringify(value)})`, { document });

run('updated');
assert.equal(element.textContent, 'updated');
assert.equal(element.scrollTop, 180, 'current scroll position should survive content updates');
run('updated');
assert.equal(element.scrollTop, 180, 'identical content should not trigger a rewrite');
element.scrollTop = 700;
element.scrollHeight = 600;
element.clientHeight = 400;
run('shorter content');
assert.equal(element.scrollTop, 200, 'scroll position should clamp to the new maximum');

console.log('PASS dashboard runtime scroll-preservation regression test');
