import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/market-enrichment.ts', import.meta.url), 'utf8');
assert.doesNotMatch(source, /dexscreener|geckoterminal|api\.dexscreener\.com|api\.geckoterminal\.com/i);
assert.match(source, /providerRequests: 0/);
assert.match(source, /Intentionally disabled/);
console.log('V948 MARKET PROVIDER REMOVAL REGRESSION PASS');
