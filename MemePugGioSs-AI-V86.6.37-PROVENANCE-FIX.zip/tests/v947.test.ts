import assert from 'node:assert/strict';

const { runMarketEnrichment, marketEnrichmentStatus } = await import('../src/market-enrichment.js');
const result = await runMarketEnrichment();
assert.equal(result.status, 'DISABLED');
assert.equal(result.enabled, false);
assert.equal(result.providerRequests, 0);
const status = marketEnrichmentStatus();
assert.equal(status.status, 'DISABLED');
assert.equal(status.enabled, false);
assert.equal(status.providerRequests, 0);
console.log('V947 PROVIDER REMOVAL REGRESSION PASS');
