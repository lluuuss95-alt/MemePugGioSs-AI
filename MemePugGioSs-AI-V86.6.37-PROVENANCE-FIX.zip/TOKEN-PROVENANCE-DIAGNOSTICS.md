# V85.9.40 — Token provenance diagnostics

Changes:
- `/api/tokens` includes the most recent observation price, holders, liquidity, and observation timestamp when present.
- The token table displays the mint address (shortened on screen, full address on hover), source, and latest observation time.
- The Market page reports PumpPortal connection state, message count, newly received token count, last message time, and whether the feed reported an error.
- No synthetic market values or trading signals are generated. Live execution remains disabled; PAPER/SHADOW only.

Validation: JavaScript syntax check passed (`node --check dashboard/app.js`). A full TypeScript build could not be completed in this environment because dependency installation timed out; confirm the build in Render logs before treating this release as deployed.
