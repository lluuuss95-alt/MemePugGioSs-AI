# V85.9.47 — Token Pipeline Recovery

## Fixes
- Market enrichment now starts after 3 seconds and rechecks every 15 seconds, so a first cycle that starts before the PumpPortal stream delivers tokens does not leave enrichment idle for a full minute.
- `/api/health` market-enrichment details now expose total persisted tokens, eligible mint count, PumpPortal-origin token count, and ingestion queue depth.
- An empty token inventory reports `WAITING_FOR_TOKENS` with a diagnostic instead of misleadingly reporting `OK`.
- Keeps DexScreener as the only price/liquidity observation provider; no fabricated prices and no Pump.fun coin-detail fallback.
- PAPER/SHADOW only; live execution, signing, and broadcasting remain disabled.

## Verification
- Static source gate, test-source gate, static PAPER E2E gate, and PAPER/SHADOW safety gate pass on the packaged source.
- Full dependency-backed TypeScript build and runtime test suite must be run in Render/GitHub Actions; this environment could not complete npm dependency installation.
