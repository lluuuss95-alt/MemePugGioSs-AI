# Validation report — V86.6.18

- Corrected stale assertions in `tests/v948.test.ts` and `ci/v950-unified-fixes.mjs`: the intended GeckoTerminal fallback budget is 2 per cycle.
- Preserved the runtime fallback budget, cooldowns, negative cache, in-flight request deduplication, and PAPER-only safety gates.
- This patch addresses the known CI failure; a full certification run is still required before calling the release certified.
