import assert from 'node:assert/strict';
import { evaluateV86LearningLab } from '../dist/v86-learning-lab.js';

const insufficient = evaluateV86LearningLab(Array.from({length:50},(_,i)=>({ts:i+1,price:1+i*0.001})));
assert.equal(insufficient.status,'INSUFFICIENT_DATA');
assert.equal(insufficient.policy.liveExecutionEnabled,false);
assert.equal(insufficient.policy.autoPromotion,false);

const bars = Array.from({length:300},(_,i)=>({
  ts:i+1,
  price: 1 + i*0.001 + Math.sin(i/4)*0.025 + Math.sin(i/17)*0.012
}));
const result = evaluateV86LearningLab(bars);
assert.equal(result.status,'EVALUATED');
assert.equal(result.candidates.length,3);
assert.equal(result.trainBars,210);
assert.equal(result.testBars,90);
assert.equal(result.policy.mode,'PAPER_ONLY');
assert.equal(result.policy.liveExecutionEnabled,false);
assert.equal(result.policy.autoPromotion,false);
assert.ok(result.candidates.every(c=>Number.isFinite(c.score)));
assert.ok(result.candidates.every(c=>typeof c.eligibleForPaperTrial==='boolean'));
assert.ok(result.recommendation===null || result.candidates.some(c=>c.strategyId===result.recommendation && c.eligibleForPaperTrial));

assert.throws(()=>evaluateV86LearningLab(Array.from({length:200},(_,i)=>({ts:200-i,price:1+i/1000}))),/STRICTLY_INCREASING/);
assert.throws(()=>evaluateV86LearningLab(Array.from({length:200},(_,i)=>({ts:i+1,price:i===10?0:1+i/1000}))),/POSITIVE_PRICES/);
console.log('V86.6.30 learning-lab runtime checks PASS; paper-only, chronological holdout, no auto-promotion.');
