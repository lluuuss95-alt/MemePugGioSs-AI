import fs from 'node:fs';
import assert from 'node:assert/strict';
const files=['src/db.ts','dist/db.js','src/paper.ts','dist/paper.js','src/server.ts','dist/server.js'];
const contents=files.map(f=>[f,fs.readFileSync(f,'utf8')]);
for(const [name,s] of contents){
 if(name.endsWith('db.ts')||name.endsWith('db.js')){assert.match(s,/reference_price REAL/);assert.match(s,/v86_paper_equity_snapshots/);assert.match(s,/ALTER TABLE fills ADD COLUMN slippage_bps REAL/);}
 if(name.endsWith('paper.ts')||name.endsWith('paper.js')){assert.match(s,/reference_observed_at/);assert.match(s,/slippageBps/);assert.match(s,/PAPER_FILL/);assert.match(s,/v86_paper_equity_snapshots/);}
 if(name.endsWith('server.ts')||name.endsWith('server.js')){assert.match(s,/learning-lab\/equity-snapshots/);assert.match(s,/averageAdverseSlippageBps/);assert.match(s,/liveExecutionEnabled\s*:\s*false/);}
}
console.log('V86.6.33 PAPER reference-price/slippage and equity-snapshot static checks PASS; live execution remains disabled.');
