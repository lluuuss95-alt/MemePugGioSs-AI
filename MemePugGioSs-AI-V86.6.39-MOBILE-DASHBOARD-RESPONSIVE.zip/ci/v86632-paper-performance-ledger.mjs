import fs from 'node:fs';
import assert from 'node:assert/strict';
const src=fs.readFileSync('src/server.ts','utf8');
const dist=fs.readFileSync('dist/server.js','utf8');
for (const text of [src,dist]) {
 assert.match(text,/\/api\/v86\/learning-lab\/performance\/:mint/);
 assert.match(text,/realizedPnl/);
 assert.match(text,/unrealizedPnl/);
 assert.match(text,/totalFees/);
 assert.match(text,/HIGH_VOLATILITY/);
 assert.match(text,/liveExecutionEnabled\s*:\s*false/);
 assert.match(text,/autoPromotion\s*:\s*false/);
 assert.match(text,/Historical fills before V86\.6\.33 may not have a stored reference price/);
}
console.log('V86.6.32 PAPER performance ledger static checks PASS; no auto-promotion and live execution disabled.');
